import { cookies } from "next/headers";

const COOKIE_NAME = "ariamj-admin";

export async function createSession() {
  const cookieStore = await cookies();

  cookieStore.set(COOKIE_NAME, "logged-in", {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
  });
}

export async function destroySession() {
  const cookieStore = await cookies();

  cookieStore.delete(COOKIE_NAME);
}

export async function isAuthenticated() {
  const cookieStore = await cookies();

  return cookieStore.get(COOKIE_NAME)?.value === "logged-in";
}