export const NEWS_STATUS: Record<string, { label: string; cls: string }> = {
  PUBLISHED: { label: "منتشر شده", cls: "bg-green-100 text-green-700" },
  DRAFT: { label: "پیش‌نویس", cls: "bg-zinc-100 text-zinc-600" },
  PENDING: { label: "در انتظار بررسی", cls: "bg-yellow-100 text-yellow-700" },
  REJECTED: { label: "رد شده", cls: "bg-red-100 text-red-700" },
};

export function slugify(s: string) {
  return s
    .trim()
    .toLowerCase()
    .replace(/[^\u0600-\u06FFa-z0-9\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-");
}

export function readMinutes(content?: string | null) {
  const words = (content ?? "").split(/\s+/).filter(Boolean).length;
  return Math.max(1, Math.round(words / 200));
}

export function faDate(d?: string | Date | null) {
  if (!d) return "";
  return new Date(d).toLocaleDateString("fa-IR");
}