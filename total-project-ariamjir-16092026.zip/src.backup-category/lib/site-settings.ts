import { prisma } from "./prisma";

/* خواندن SiteSettings از DB با ساختار پیش‌فرض
   اگر رکورد وجود نداشت، seed خودکار انجام می‌شود */

export interface SocialLink {
  key: string;
  name: string;
  url: string;
  color?: string;
  active: boolean;
  iconName?: string;
}

export interface CustomColumn {
  title: string;
  links: { label: string; href: string }[];
}

export interface TrustBadge {
  name: string;
  imageUrl: string;
  url?: string;
}

export interface FooterLink {
  label: string;
  href: string;
}

export interface SiteSettings {
  id: string;
  logoUrl: string | null;
  brandName: string;
  tagline: string;
  about: string | null;
  phones: string[];
  mobiles: string[];
  emails: string[];
  address: string | null;
  workingHours: string | null;
  socials: SocialLink[];
  customColumns: CustomColumn[];
  trustBadges: TrustBadge[];
  footerLinks: FooterLink[];
  copyright: string | null;
  newsletterEnabled: boolean;
  newsletterTitle: string;
  newsletterDesc: string;
}

const DEFAULT_SETTINGS: Omit<SiteSettings, "id"> = {
  logoUrl: null,
  brandName: "ARIA MJ",
  tagline: "بزرگ‌ترین مارکت‌پلیس ماشین‌آلات سنگین ایران",
  about:
    "آریا ماشین جم، مرجع تخصصی خرید، فروش، اجاره و خدمات ماشین‌آلات راهسازی، معدنی، عمرانی و صنعتی در سراسر ایران.",
  phones: ["021-91009900", "021-91009901"],
    mobiles: ["09121234567"],
  emails: ["info@ariamj.com", "support@ariamj.com"],
  address: "تهران، بزرگراه نواب، خیابان جمهوری، پلاک ۱۲۳",
  workingHours: "شنبه تا چهارشنبه ۸ تا ۱۷ · پنجشنبه ۸ تا ۱۳",
  socials: [
    { key: "instagram", name: "اینستاگرام", url: "https://instagram.com/ariamachinejam", color: "#E1306C", active: true },
    { key: "telegram", name: "تلگرام", url: "https://t.me/ariamjcom", color: "#0088CC", active: true },
    { key: "whatsapp", name: "واتساپ", url: "https://wa.me/qr/NZUDSXMYK5PBB1", color: "#25D366", active: true },
    { key: "linkedin", name: "لینکدین", url: "https://linkedin.com/ariamachinejam", color: "#0A66C2", active: true },
    { key: "youtube", name: "یوتیوب", url: "https://youtube.com/ariamachinejam", color: "#FF0000", active: true },
    { key: "x", name: "ایکس (توییتر)", url: "https://x.com/ariamachinejam", color: "#000000", active: true },
    { key: "aparat", name: "آپارات", url: "https://aparat.com/ariamachinejam", color: "#ED145B", active: true },
    { key: "bale", name: "بله", url: "", color: "#00D0FF", active: false },
    { key: "rubika", name: "روبیکا", url: "", color: "#9C27B0", active: false },
    { key: "eitaa", name: "ایتا", url: "", color: "#EF6C00", active: false },
  ],
  customColumns: [
    {
      title: "دسترسی سریع",
      links: [
        { label: "بازار ماشین‌آلات", href: "/machines" },
        { label: "فروش دستگاه", href: "/machines/new" },
        { label: "خدمات صنعتی", href: "/services" },
        { label: "قطعات یدکی", href: "/parts" },
        { label: "پایگاه دانش", href: "/knowledge" },
        { label: "مرکز آموزش", href: "/academy" },
        { label: "مشاوره رایگان", href: "/consulting" },
        { label: "اخبار و مقالات", href: "/news" },
      ],
    },
    {
      title: "دسته‌بندی‌ها",
      links: [
        { label: "ماشین‌آلات راهسازی", href: "/machines?category=road-construction" },
        { label: "ماشین‌آلات معدنی", href: "/machines?category=mining" },
        { label: "ماشین‌آلات عمرانی", href: "/machines?category=civil" },
        { label: "نفت، گاز و پتروشیمی", href: "/machines?category=oil-gas" },
        { label: "صنایع بتن و سیمان", href: "/machines?category=concrete" },
        { label: "صنایع نیروگاهی", href: "/machines?category=power" },
      ],
    },
  ],
  trustBadges: [
    { name: "نماد اعتماد الکترونیکی", imageUrl: "/images/badges/enamad.png", url: "https://enamad.ir" },
    { name: "نشان ملی ثبت", imageUrl: "/images/badges/samandehi.png", url: "https://samandehi.ir" },
  ],
  footerLinks: [
    { label: "قوانین و مقررات", href: "/legal/terms" },
    { label: "حریم خصوصی", href: "/legal/privacy" },
    { label: "شرایط استفاده", href: "/legal/conditions" },
    { label: "درباره ما", href: "/about" },
    { label: "تماس با ما", href: "/contact" },
  ],
  copyright: "© ۱۴۰۴ تمامی حقوق برای گروه صنعتی آریا ماشین جم محفوظ است.",
  newsletterEnabled: true,
  newsletterTitle: "عضویت در خبرنامه",
  newsletterDesc: "از جدیدترین آگهی‌ها و فرصت‌های صنعتی باخبر شوید",
};

export async function getSiteSettings(): Promise<SiteSettings> {
  const record = await prisma.siteSettings.findUnique({
    where: { id: "main" },
  });

  if (!record) {
    // Seed خودکار
    const created = await prisma.siteSettings.create({
      data: {
        id: "main",
        ...DEFAULT_SETTINGS,
        phones: DEFAULT_SETTINGS.phones as any,
        emails: DEFAULT_SETTINGS.emails as any,
        socials: DEFAULT_SETTINGS.socials as any,
        customColumns: DEFAULT_SETTINGS.customColumns as any,
        trustBadges: DEFAULT_SETTINGS.trustBadges as any,
        footerLinks: DEFAULT_SETTINGS.footerLinks as any,
      },
    });
    return normalize(created);
  }

  return normalize(record);
}

function normalize(record: any): SiteSettings {
  return {
    id: record.id,
    logoUrl: record.logoUrl,
    brandName: record.brandName,
    tagline: record.tagline,
    about: record.about,
    phones: Array.isArray(record.phones) ? record.phones : [],
    mobiles: Array.isArray(record.mobiles) ? record.mobiles : [],
    emails: Array.isArray(record.emails) ? record.emails : [],
    address: record.address,
    workingHours: record.workingHours,
    socials: Array.isArray(record.socials) ? record.socials : [],
    customColumns: Array.isArray(record.customColumns) ? record.customColumns : [],
    trustBadges: Array.isArray(record.trustBadges) ? record.trustBadges : [],
    footerLinks: Array.isArray(record.footerLinks) ? record.footerLinks : [],
    copyright: record.copyright,
    newsletterEnabled: record.newsletterEnabled,
    newsletterTitle: record.newsletterTitle,
    newsletterDesc: record.newsletterDesc,
  };
}