import { prisma } from "@/lib/prisma";

/* ============================================================
   آمار صفحه اول — منابع داینامیک از دیتابیس
============================================================ */

export interface StatItem {
  title: string;
  source: string;      // machines | brands | ... | manual
  manualText?: string; // فقط برای source=manual
  suffix?: string;     // مثلاً "+"
  active?: boolean;
}

export const STAT_SOURCES = [
  { key: "machines", label: "تعداد ماشین‌آلات (واقعی)" },
  { key: "adsPublished", label: "آگهی‌های منتشرشده (واقعی)" },
  { key: "brands", label: "تعداد برندها (واقعی)" },
  { key: "categories", label: "تعداد دسته‌بندی‌ها (واقعی)" },
  { key: "users", label: "تعداد کاربران (واقعی)" },
  { key: "services", label: "تعداد خدمات (واقعی)" },
  { key: "manual", label: "عدد/متن دستی" },
];

export const DEFAULT_ITEMS: StatItem[] = [
  { title: "ماشین‌آلات فعال", source: "machines", suffix: "+" },
  { title: "برند معتبر", source: "brands", suffix: "+" },
  { title: "کاربر فعال", source: "users", suffix: "+" },
  { title: "آگهی موفق", source: "adsPublished", suffix: "+" },
];

/* شمارش زنده از دیتابیس */
export async function realCounts(): Promise<Record<string, number>> {
  const [machines, adsPublished, brands, categories, users, services] =
    await Promise.all([
      prisma.machine.count(),
      prisma.machine.count({ where: { status: "PUBLISHED" } }),
      prisma.brand.count(),
      prisma.category.count(),
      prisma.user.count(),
      prisma.serviceItem.count().catch(() => 0),
    ]);

  return { machines, adsPublished, brands, categories, users, services };
}

/* تبدیل آیتم‌ها به مقدار قابل نمایش */
export async function resolveStats(items: StatItem[]) {
  const real = await realCounts();

  return items
    .filter((i) => i.active !== false)
    .map((i) => {
      const display =
        i.source === "manual"
          ? (i.manualText ?? "۰") + (i.suffix ?? "")
          : (real[i.source] ?? 0).toLocaleString("fa-IR") + (i.suffix ?? "");

            return { title: i.title, display, source: i.source };
    });
}