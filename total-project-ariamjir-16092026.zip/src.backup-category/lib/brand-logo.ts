/* ============================================================
   لوگوی واقعی برندها — بدون دخالت ادمین
   ۱) Clearbit (لوگوی رسمی برند) ۲) Google Favicon ۳) AI
============================================================ */

export function brandDomain(name: string, slug?: string): string {
  const base = (slug ?? name)
    .toLowerCase()
    .replace(/[^a-z0-9]/g, "");
  return `${base}.com`;
}

export function faviconLogo(domain: string): string {
  return `https://www.google.com/s2/favicons?domain=${domain}&sz=128`;
}

export function clearbitLogo(domain: string): string {
  return `https://logo.clearbit.com/${domain}`;
}

async function probe(url: string, minBytes: number): Promise<boolean> {
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 8000);
    const res = await fetch(url, { signal: ctrl.signal, redirect: "follow" });
    clearTimeout(t);

    if (!res.ok) return false;
    const ct = res.headers.get("content-type") ?? "";
    if (!ct.includes("image")) return false;

    const buf = await res.arrayBuffer();
    return buf.byteLength >= minBytes;
  } catch {
    return false;
  }
}

export async function resolveRealLogo(
  name: string,
  slug?: string
): Promise<string | null> {
  const domain = brandDomain(name, slug);

  /* ۱) لوگوی رسمی برند */
  if (await probe(clearbitLogo(domain), 500)) {
    return clearbitLogo(domain);
  }

  /* ۲) favicon واقعی گوگل — تقریباً همیشه جواب می‌دهد */
  if (await probe(faviconLogo(domain), 200)) {
    return faviconLogo(domain);
  }

  /* ۳) آخرین راه: تولید AI */
  try {
    const prompt =
      `minimal flat vector logo emblem for heavy machinery brand "${name}", ` +
      `industrial geometric symbol, orange #F58220 and charcoal gray, centered on clean white background, ` +
      `professional logo design, bold simple wordmark "${name}" below the emblem, no photo`;

    const url = `https://image.pollinations.ai/prompt/${encodeURIComponent(
      prompt
    )}?width=512&height=512&nologo=true&seed=${Math.floor(Math.random() * 1e6)}`;

    if (await probe(url, 500)) return url;
  } catch {}

  return null;
}