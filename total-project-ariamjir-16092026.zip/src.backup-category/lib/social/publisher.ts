import { prisma } from "@/lib/prisma";
import { SITE_URL } from "@/lib/seo";

export function buildCaption(m: any): string {
  const price = m.price?.price
    ? `${Number(m.price.price).toLocaleString("fa-IR")} تومان`
    : "تماس بگیرید";

  const specs = [];
  if (m.specification?.manufactureYear) specs.push(`📅 مدل: ${m.specification.manufactureYear}`);
  if (m.specification?.workingHours) specs.push(`⏱ کارکرد: ${m.specification.workingHours} ساعت`);
  if (m.specification?.enginePower) specs.push(`⚙️ قدرت موتور: ${m.specification.enginePower}`);
  if (m.city) specs.push(`📍 شهر: ${m.city}`);

  return [
    `🚜 *${m.title}*`,
    `🏷 برند: ${m.brand?.name ?? "—"}`,
    `💰 قیمت: ${price}`,
    ...specs,
    "",
    "📋 *توضیحات:*",
    `${m.description ?? "توضیحات تکمیلی در سایت"}`,
    "",
    "🔗 *لینک آگهی:*",
    `${SITE_URL}/machines/${m.slug}`,
    "",
    "#آریا_ماشین_جم #ماشین_آلات_سنگین",
  ].filter(Boolean).join("\n");
}

function telegramBaseUrl(): string {
  const proxy = process.env.TELEGRAM_PROXY_URL?.trim();
  if (proxy) return proxy.replace(/\/+$/, "");
  return "https://api.telegram.org";
}

async function fetchWithRetry(url: string, init: RequestInit, retries = 2): Promise<Response> {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 20000);

  try {
    const res = await fetch(url, { ...init, signal: controller.signal });
    clearTimeout(timeoutId);
    return res;
  } catch (err: any) {
    clearTimeout(timeoutId);
    if (retries > 0) {
      await new Promise((r) => setTimeout(r, 1500));
      return fetchWithRetry(url, init, retries - 1);
    }
    throw new Error(`Network error: ${err.name} - ${err.message}`);
  }
}

export async function sendTelegram(caption: string, imageUrl?: string): Promise<string> {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  const chat = process.env.TELEGRAM_CHAT_ID;

  if (!token || !chat) throw new Error("تنظیمات تلگرام در .env ناقص است");

  const base = telegramBaseUrl();

  if (imageUrl) {
    try {
      const res = await fetchWithRetry(`${base}/bot${token}/sendPhoto`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ chat_id: chat, photo: imageUrl, caption, parse_mode: "Markdown" }),
      });
      const j = await res.json();
      if (j.ok) return String(j.result?.message_id ?? "");
      
      if (j.description?.includes("failed to get HTTP URL content")) {
        console.log("[Telegram] ⚠️ عکس قابل دانلود نیست. فقط متن ارسال می‌شود.");
      } else {
        throw new Error(j.description ?? "Telegram API error");
      }
    } catch (err) {
      console.log("[Telegram] ⚠️ خطا در ارسال عکس. فقط متن ارسال می‌شود.");
    }
  }

  const resText = await fetchWithRetry(`${base}/bot${token}/sendMessage`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ chat_id: chat, text: caption, parse_mode: "Markdown" }),
  });
  
  const jText = await resText.json();
  if (!jText.ok) throw new Error(jText.description ?? "Telegram API error");
  
  return String(jText.result?.message_id ?? "");
}

export async function publishMachine(machineId: string, network: string) {
  const m = await prisma.machine.findUnique({
    where: { id: machineId },
    include: { brand: true, price: true, specification: true, images: { take: 1, orderBy: { sortOrder: "asc" } } },
  });

  if (!m) throw new Error("ماشین یافت نشد");

  const caption = buildCaption(m);
  
  let imageUrl: string | undefined;
  if (m.images?.[0]?.url) {
    const imgUrl = m.images[0].url;
    if (imgUrl.startsWith("https://") && !imgUrl.includes("localhost") && !imgUrl.includes("127.0.0.1")) {
      imageUrl = imgUrl;
    }
  }

  const externalId = await sendTelegram(caption, imageUrl);

  return prisma.socialPost.create({
    data: { machineId, network, caption, imageUrl: imageUrl ?? null, status: "PUBLISHED", externalId, publishedAt: new Date() },
  });
}

export async function getQueue() {
  const posted = await prisma.socialPost.findMany({ where: { status: "PUBLISHED" }, select: { machineId: true } });
  const postedIds = new Set(posted.map((p: any) => p.machineId).filter(Boolean));

  const machines = await prisma.machine.findMany({
    where: { status: "PUBLISHED", active: true },
    orderBy: { createdAt: "desc" },
    take: 30,
    include: { brand: true, price: true, images: { take: 1, orderBy: { sortOrder: "asc" } } },
  });

  return (machines as any[]).filter((m) => !postedIds.has(m.id));
}