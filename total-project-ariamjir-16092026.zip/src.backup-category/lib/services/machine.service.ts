import { prisma } from "@/lib/prisma";
import { Prisma, RecordStatus } from "@prisma/client";

const machineInclude = {
  brand: true,

  category: true,

  price: true,

  specification: true,

  images: {
    orderBy: [
      {
        isPrimary: "desc",
      },
      {
        sortOrder: "asc",
      },
    ],

    take: 1,
  },
} satisfies Prisma.MachineInclude;

export async function getFeaturedMachines(limit = 8) {
  return prisma.machine.findMany({
    where: {
      featured: true,
      active: true,
      status: RecordStatus.PUBLISHED,
    },

    orderBy: [
      {
        publishedAt: "desc",
      },
      {
        createdAt: "desc",
      },
    ],

    take: limit,

    include: machineInclude,
  });
}

export async function getLatestMachines(limit = 8) {
  return prisma.machine.findMany({
    where: {
      active: true,
      status: RecordStatus.PUBLISHED,
    },

    orderBy: [
      {
        publishedAt: "desc",
      },
      {
        createdAt: "desc",
      },
    ],

    take: limit,

    include: machineInclude,
  });
}

export async function getMachineBySlug(slug: string) {
  return prisma.machine.findUnique({
    where: {
      slug,
    },

    include: {
      brand: true,

      category: true,

      seller: true,

      price: true,

      specification: true,

      features: {
        orderBy: {
          sortOrder: "asc",
        },
      },

      images: {
        orderBy: [
          {
            isPrimary: "desc",
          },
          {
            sortOrder: "asc",
          },
        ],
      },

      videos: true,

      documents: true,
    },
  });
}

export async function getMachinesByBrand(
  brandId: string,
  limit = 12
) {
  return prisma.machine.findMany({
    where: {
      brandId,
      active: true,
      status: RecordStatus.PUBLISHED,
    },

    take: limit,

    orderBy: {
      publishedAt: "desc",
    },

    include: machineInclude,
  });
}

export async function getMachinesByCategory(
  categoryId: string,
  limit = 12
) {
  return prisma.machine.findMany({
    where: {
      categoryId,
      active: true,
      status: RecordStatus.PUBLISHED,
    },

    take: limit,

    orderBy: {
      publishedAt: "desc",
    },

    include: machineInclude,
  });
}

export async function getRelatedMachines(
  machineId: string,
  categoryId?: string | null,
  limit = 8
) {
  return prisma.machine.findMany({
    where: {
      id: {
        not: machineId,
      },

      categoryId: categoryId ?? undefined,

      active: true,

      status: RecordStatus.PUBLISHED,
    },

    take: limit,

    orderBy: {
      publishedAt: "desc",
    },

    include: machineInclude,
  });
}

export async function searchMachines(params: {
  categoryId?: string;
  brandId?: string;
  provinceId?: string;
  cityId?: string;
  keyword?: string;
  featured?: boolean;
  page?: number;
  limit?: number;
}) {
  const {
    categoryId,
    brandId,
    provinceId,
    cityId,
    keyword,
    featured,
    page = 1,
    limit = 12,
  } = params;

  return prisma.machine.findMany({
    where: {
      active: true,

      status: RecordStatus.PUBLISHED,

      featured,

      categoryId,

      brandId,

      specification: {
        provinceId,

        cityId,
      },

      OR: keyword
        ? [
            {
              title: {
                contains: keyword,
                mode: "insensitive",
              },
            },

            {
              shortDescription: {
                contains: keyword,
                mode: "insensitive",
              },
            },
          ]
        : undefined,
    },

    skip: (page - 1) * limit,

    take: limit,

    orderBy: {
      publishedAt: "desc",
    },

    include: machineInclude,
  });
}

export async function countMachines() {
  return prisma.machine.count({
    where: {
      active: true,
      status: RecordStatus.PUBLISHED,
    },
  });
}

export async function countFeaturedMachines() {
  return prisma.machine.count({
    where: {
      featured: true,
      active: true,
      status: RecordStatus.PUBLISHED,
    },
  });
}