import { Prisma } from "@prisma/client";

import { prisma } from "@/lib/prisma";

/* ============================================================
   TYPES
============================================================ */

export interface GetMachinesParams {
  page?: number;
  limit?: number;

  search?: string;

  brand?: string;

  category?: string;
}

/* ============================================================
   RESULT TYPES
============================================================ */

export interface MachineListItem {
  id: string;
  title: string;
  slug: string;

  shortDescription: string | null;

  listingType: string | null;
  status: string;

  featured: boolean;
  active: boolean;

  createdAt: Date;
  publishedAt: Date | null;

  brand: {
    id: string;
    name: string;
    slug: string;
    logo: string | null;
  } | null;

  category: {
    id: string;
    name: string;
    slug: string;
    image: string | null;
  } | null;

  images: {
    id: string;
    url: string;
    alt: string | null;
    sortOrder: number;
    isPrimary: boolean;
  }[];

  price: {
    price: number | null;
    currency: string;
    priceType: string;
  } | null;

  specification: {
    model: string | null;
    manufactureYear: number | null;
    condition: string | null;
    engine: string | null;
    enginePower: number | null;
    operatingWeight: number | null;
    bucketCapacity: number | null;
    workingHours: number | null;
    fuelType: string | null;
    transmission: string | null;
    driveType: string | null;
    countryId: string | null;
    provinceId: string | null;
    cityId: string | null;
    location: string | null;
  } | null;
}

export interface GetMachinesResult {
  items: MachineListItem[];

  pagination: {
    page: number;
    limit: number;
    totalPages: number;
    total: number;
  };
}

/* ============================================================
   GET MACHINES
============================================================ */

export async function getMachines(
  params: GetMachinesParams = {},
): Promise<GetMachinesResult> {
  /* ----------------------------------------------------------
     Pagination
  ---------------------------------------------------------- */

  const page =
    Number.isFinite(params.page) && (params.page ?? 0) > 0
      ? Math.floor(params.page!)
      : 1;

  const limit =
    Number.isFinite(params.limit) &&
    (params.limit ?? 0) > 0
      ? Math.min(Math.floor(params.limit!), 48)
      : 12;

  const skip = (page - 1) * limit;

  /* ----------------------------------------------------------
     Normalize filters
  ---------------------------------------------------------- */

  const search =
    typeof params.search === "string"
      ? params.search.trim()
      : "";

  const brand =
    typeof params.brand === "string"
      ? params.brand.trim()
      : "";

  const category =
    typeof params.category === "string"
      ? params.category.trim()
      : "";

  /* ----------------------------------------------------------
     WHERE
  ---------------------------------------------------------- */

  const where: Prisma.MachineWhereInput = {
    active: true,

    /*
     * برای صفحه عمومی ماشین‌آلات،
     * فقط آگهی‌هایی که منتشر شده‌اند نمایش داده شوند.
     *
     * اگر داده‌های فعلی دیتابیس PENDING باشند،
     * این شرط باعث خالی شدن صفحه می‌شود.
     *
     * بنابراین فعلاً status را محدود نمی‌کنیم.
     */

    ...(search
      ? {
          OR: [
            {
              title: {
                contains: search,
                mode: "insensitive",
              },
            },
            {
              slug: {
                contains: search,
                mode: "insensitive",
              },
            },
            {
              shortDescription: {
                contains: search,
                mode: "insensitive",
              },
            },
            {
              description: {
                contains: search,
                mode: "insensitive",
              },
            },
          ],
        }
      : {}),

    ...(brand
      ? {
          brand: {
            OR: [
              {
                id: brand,
              },
              {
                slug: brand,
              },
            ],
          },
        }
      : {}),

    ...(category
      ? {
          category: {
            OR: [
              {
                id: category,
              },
              {
                slug: category,
              },
            ],
          },
        }
      : {}),
  };

  /* ----------------------------------------------------------
     DATABASE
  ---------------------------------------------------------- */

  const [total, machines] = await prisma.$transaction([
    prisma.machine.count({
      where,
    }),

    prisma.machine.findMany({
      where,

      skip,

      take: limit,

      orderBy: [
        {
          featured: "desc",
        },
        {
          publishedAt: "desc",
        },
        {
          createdAt: "desc",
        },
      ],

      include: {
        brand: {
          select: {
            id: true,
            name: true,
            slug: true,
            logo: true,
          },
        },

        category: {
          select: {
            id: true,
            name: true,
            slug: true,
            image: true,
          },
        },

        images: {
          orderBy: {
            sortOrder: "asc",
          },

          select: {
            id: true,
            url: true,
            alt: true,
            sortOrder: true,
            isPrimary: true,
          },
        },

        price: {
          select: {
            price: true,
            currency: true,
            priceType: true,
          },
        },

        specification: {
          select: {
            model: true,
            manufactureYear: true,
            condition: true,
            engine: true,
            enginePower: true,
            operatingWeight: true,
            bucketCapacity: true,
            workingHours: true,
            fuelType: true,
            transmission: true,
            driveType: true,
            countryId: true,
            provinceId: true,
            cityId: true,
            location: true,
          },
        },
      },
    }),
  ]);

  /* ----------------------------------------------------------
     TOTAL PAGES
  ---------------------------------------------------------- */

  const totalPages =
    total > 0
      ? Math.ceil(total / limit)
      : 1;

  /* ----------------------------------------------------------
     SERIALIZE
     Prisma Decimal باید قبل از ارسال به Client
     به number تبدیل شود.
  ---------------------------------------------------------- */

  const items: MachineListItem[] =
    machines.map((machine) => ({
      id: machine.id,

      title: machine.title,

      slug: machine.slug,

      shortDescription:
        machine.shortDescription ?? null,

      listingType:
        machine.listingType
          ? String(machine.listingType)
          : null,

      status: String(machine.status),

      featured: machine.featured,

      active: machine.active,

      createdAt: machine.createdAt,

      publishedAt:
        machine.publishedAt ?? null,

      brand: machine.brand
        ? {
            id: machine.brand.id,
            name: machine.brand.name,
            slug: machine.brand.slug,
            logo: machine.brand.logo,
          }
        : null,

      category: machine.category
        ? {
            id: machine.category.id,
            name: machine.category.name,
            slug: machine.category.slug,
            image: machine.category.image,
          }
        : null,

      images: machine.images.map(
        (image) => ({
          id: image.id,
          url: image.url,
          alt: image.alt,
          sortOrder: image.sortOrder,
          isPrimary: image.isPrimary,
        }),
      ),

      price: machine.price
        ? {
            price:
              machine.price.price !== null
                ? Number(machine.price.price)
                : null,

            currency:
              String(machine.price.currency),

            priceType:
              String(machine.price.priceType),
          }
        : null,

      specification:
        machine.specification
          ? {
              model:
                machine.specification.model,

              manufactureYear:
                machine.specification
                  .manufactureYear,

              condition:
                machine.specification.condition
                  ? String(
                      machine.specification
                        .condition,
                    )
                  : null,

              engine:
                machine.specification.engine,

              enginePower:
                machine.specification.enginePower,

              operatingWeight:
                machine.specification
                  .operatingWeight,

              bucketCapacity:
                machine.specification
                  .bucketCapacity,

              workingHours:
                machine.specification
                  .workingHours,

              fuelType:
                machine.specification.fuelType
                  ? String(
                      machine.specification
                        .fuelType,
                    )
                  : null,

              transmission:
                machine.specification
                  .transmission
                  ? String(
                      machine.specification
                        .transmission,
                    )
                  : null,

              driveType:
                machine.specification.driveType
                  ? String(
                      machine.specification
                        .driveType,
                    )
                  : null,

              countryId:
                machine.specification
                  .countryId,

              provinceId:
                machine.specification
                  .provinceId,

              cityId:
                machine.specification.cityId,

              location:
                machine.specification.location,
            }
          : null,
    }));

  /* ----------------------------------------------------------
     RETURN
  ---------------------------------------------------------- */

  return {
    items,

    pagination: {
      page,

      limit,

      totalPages,

      total,
    },
  };
}