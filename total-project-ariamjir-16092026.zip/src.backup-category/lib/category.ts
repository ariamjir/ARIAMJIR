import { prisma } from "@/lib/prisma";

export async function getCategories() {
  return prisma.category.findMany({
    orderBy: {
      sortOrder: "asc",
    },
  });
}

export async function getCategory(id: string) {
  return prisma.category.findUnique({
    where: {
      id,
    },
  });
}

export async function createCategory(data: {
  name: string;
  slug: string;
  description?: string;
  icon?: string;
  sortOrder?: number;
  active?: boolean;
}) {
  return prisma.category.create({
    data: {
      name: data.name,
      slug: data.slug,
      description: data.description,
      icon: data.icon,
      sortOrder: data.sortOrder ?? 0,
      active: data.active ?? true,
    },
  });
}

export async function updateCategory(
  id: string,
  data: {
    name: string;
    slug: string;
    description?: string;
    icon?: string;
    sortOrder?: number;
    active?: boolean;
  }
) {
  return prisma.category.update({
    where: {
      id,
    },
    data: {
      name: data.name,
      slug: data.slug,
      description: data.description,
      icon: data.icon,
      sortOrder: data.sortOrder,
      active: data.active,
    },
  });
}

export async function deleteCategory(id: string) {
  return prisma.category.delete({
    where: {
      id,
    },
  });
}