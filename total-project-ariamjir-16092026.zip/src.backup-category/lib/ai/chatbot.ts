import { prisma } from "@/lib/prisma";

/* ============================================================
   چت‌بات ARIA MJ — اطلاعات پویا از سایت + endpoint ساده Pollinations
   ✅ رایگان + بدون API key
   ✅ اطلاعات تماس از دیتابیس خوانده می‌شود (نه hardcoded)
============================================================ */

interface SiteInfo {
  siteName: string;
  phone: string;
  mobile: string;
  email: string;
  address: string;
  workingHours: string;
  social: {
    instagram: string;
    telegram: string;
    whatsapp: string;
    linkedin: string;
    youtube: string;
    aparat: string;
  };
}

async function fetchSiteInfo(): Promise<SiteInfo> {
  try {
    const res = await fetch("http://localhost:3000/api/site-info", {
      cache: "no-store",
    });
    if (!res.ok) throw new Error("fetch failed");
    const j = await res.json();
    if (j.success) return j.data;
  } catch {}

  /* fallback در صورت خطا */
  return {
    siteName: "آریا ماشین جم",
    phone: "",
    mobile: "",
    email: "info@ariamj.ir",
    address: "",
    workingHours: "شنبه تا پنجشنبه ۹ تا ۱۸",
    social: { instagram: "", telegram: "", whatsapp: "", linkedin: "", youtube: "", aparat: "" },
  };
}

export async function buildContext(userMessage: string): Promise<string> {
  const q = userMessage.toLowerCase();
  const parts: string[] = [];

  /* ۱) اطلاعات تماس پویا از دیتابیس */
  const info = await fetchSiteInfo();
  const contactLines: string[] = [];
  if (info.phone) contactLines.push(`- تلفن: ${info.phone}`);
  if (info.mobile) contactLines.push(`- موبایل: ${info.mobile}`);
  if (info.email) contactLines.push(`- ایمیل: ${info.email}`);
  if (info.address) contactLines.push(`- آدرس: ${info.address}`);
  if (info.workingHours) contactLines.push(`- ساعات کاری: ${info.workingHours}`);

  const socialLines: string[] = [];
  if (info.social.instagram) socialLines.push(`- اینستاگرام: ${info.social.instagram}`);
  if (info.social.telegram) socialLines.push(`- تلگرام: ${info.social.telegram}`);
  if (info.social.whatsapp) socialLines.push(`- واتساپ: ${info.social.whatsapp}`);
  if (info.social.linkedin) socialLines.push(`- لینکدین: ${info.social.linkedin}`);
  if (info.social.youtube) socialLines.push(`- یوتیوب: ${info.social.youtube}`);
  if (info.social.aparat) socialLines.push(`- آپارات: ${info.social.aparat}`);

  parts.push(`اطلاعات تماس ${info.siteName}:\n${contactLines.join("\n")}`);
  if (socialLines.length > 0) {
    parts.push(`شبکه‌های اجتماعی:\n${socialLines.join("\n")}`);
  }

  /* ۲) ماشین‌آلات */
  if (
    q.includes("ماشین") || q.includes("بیل") || q.includes("لودر") ||
    q.includes("جرثقیل") || q.includes("خرید") || q.includes("فروش") ||
    q.includes("دستگاه") || q.includes("بولدوزر")
  ) {
    const machines = await prisma.machine.findMany({
      where: { status: "PUBLISHED", active: true },
      take: 5,
      orderBy: { createdAt: "desc" },
      include: { brand: true, price: true },
    });
    if (machines.length > 0) {
      parts.push(
        "ماشین‌آلات موجود:\n" +
          machines
            .map((m) =>
              `- ${m.title} (${m.brand?.name ?? ""}) — ${
                m.price?.price
                  ? `${Number(m.price.price).toLocaleString("fa-IR")} تومان`
                  : "تماس بگیرید"
              } — /machines/${m.slug}`
            )
            .join("\n")
      );
    }
  }

  /* ۳) قطعات یدکی */
  if (q.includes("قطعه") || q.includes("یدکی") || q.includes("فیلتر")) {
    const parts_list = await prisma.sparePart.findMany({
      where: { status: "PUBLISHED", active: true },
      take: 5,
      orderBy: { createdAt: "desc" },
      include: { brand: true, price: true },
    });
    if (parts_list.length > 0) {
      parts.push(
        "قطعات یدکی:\n" +
          parts_list
            .map((p) =>
              `- ${p.title} (${p.brand?.name ?? ""}) — OEM: ${p.oemNumber ?? "—"} — /parts/${p.slug}`
            )
            .join("\n")
      );
    }
  }

  /* ۴) خدمات */
  if (q.includes("خدمات") || q.includes("تعمیر") || q.includes("اجاره") || q.includes("سرویس")) {
    const services = await prisma.serviceItem.findMany({
      where: { active: true },
      take: 10,
    });
    if (services.length > 0) {
      parts.push(
        "خدمات آریا ماشین جم:\n" +
          services.map((s) => `- ${s.title}: ${s.description ?? ""}`).join("\n")
      );
    }
    const rentals = await prisma.rentalListing.findMany({
      where: { status: "APPROVED" },
      take: 3,
      include: { machine: { include: { brand: true } } },
    });
    if (rentals.length > 0) {
      parts.push(
        "قابل اجاره:\n" +
          rentals
            .map((r) =>
              `- ${r.machine.title} — روزانه ${
                r.dailyPrice
                  ? `${Number(r.dailyPrice).toLocaleString("fa-IR")} تومان`
                  : "توافقی"
              } — /rental/${r.machine.slug}`
            )
            .join("\n")
      );
    }
  }

  /* ۵) برندها */
  if (q.includes("برند") || q.includes("کوماتسو") || q.includes("کاترپیلار") || q.includes("ولوو")) {
    const brands = await prisma.brand.findMany({
      where: { active: true },
      take: 10,
      orderBy: { name: "asc" },
    });
    if (brands.length > 0) {
      parts.push("برندها: " + brands.map((b) => b.name).join("، "));
    }
  }

  /* ۶) صفحات سایت */
  parts.push(`صفحات سایت ${info.siteName}:
- /machines : بازار ماشین‌آلات
- /parts : قطعات یدکی
- /rental : اجاره ماشین‌آلات
- /services : خدمات فنی
- /brands : برندها
- /news : اخبار
- /knowledge : مرکز دانش
- /sellers : فروشندگان
- /compare : مقایسه`);

  return parts.join("\n\n");
}

export const SYSTEM_PROMPT = `تو دستیار هوشمند آریا ماشین جم (ARIA MJ) هستی. نام تو "آریا" است.
لحن: حرفه‌ای، صمیمی، فارسی روان.

وظایف:
- پاسخ به سوالات خرید/فروش/اجاره ماشین‌آلات سنگین
- راهنمایی قطعات یدکی و خدمات فنی
- معرفی برندها و مدل‌ها
- ارائه اطلاعات تماس صحیح از context

قوانین مهم:
- فقط درباره ماشین‌آلات سنگین و خدمات مرتبط پاسخ بده
- پاسخ کوتاه (حداکثر ۳ پاراگراف)
- از اطلاعات context استفاده کن، اطلاعات ساختگی نده
- قیمت‌ها با اعداد فارسی
- اگر سوال درباره تماس بود، اطلاعات دقیق از context را بده (نه شماره‌های فرضی)
- در پایان یک سوال یا پیشنهاد مطرح کن`;

/**
 * فراخوانی endpoint ساده Pollinations (GET request)
 * این endpoint در ایران باز است و سریع‌تر پاسخ می‌دهد
 */
export async function streamPollinations(
  messages: Array<{ role: string; content: string }>,
  onChunk: (chunk: string) => void,
  signal: AbortSignal
): Promise<void> {
  /* ترکیب prompt از messages */
  const fullPrompt = messages
    .map((m) => `${m.role.toUpperCase()}: ${m.content}`)
    .join("\n\n");

  const encoded = encodeURIComponent(fullPrompt);
  const url = `https://text.pollinations.ai/${encoded}?model=mistral&private=true&json=false`;

  const res = await fetch(url, {
    method: "GET",
    signal,
    headers: { Accept: "text/plain" },
  });

  if (!res.ok) {
    throw new Error(`Pollinations error ${res.status}`);
  }

  if (!res.body) {
    throw new Error("No response body");
  }

  const reader = res.body.getReader();
  const decoder = new TextDecoder();

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    const chunk = decoder.decode(value, { stream: true });
    if (chunk) onChunk(chunk);
  }
}