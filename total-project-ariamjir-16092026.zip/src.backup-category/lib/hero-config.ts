export interface CardOverride {
  tag?: string;
  title?: string;
  desc?: string;
  href?: string;
  img?: string;
  active?: boolean;
}

export interface QuickLink {
  label: string;
  href: string;
}

export interface HeroConfig {
  content: {
    gap: number;
    lineGap: number;
    align: "right" | "center" | "left";
    vertical: "top" | "middle" | "bottom";
  };
  background: {
    mode: "single" | "slider";
    interval: number;
    zoom: boolean;
    overlay: number;
  };
  cards: {
    visible: boolean;
    sizeMode: "preset" | "custom";
    size: "sm" | "md" | "lg";
    custom: { sideW: number; sideH: number; midW: number; midH: number };
    tilt: boolean;
    items: Record<string, CardOverride>;
  };
  stats: { visible: boolean };
  search: {
    visible: boolean;
    title: string;
    subtitle: string;
    buttonText: string;
    showCategory: boolean;
    showBrand: boolean;
    showYear: boolean;
    showPrice: boolean;
    quickLinks: QuickLink[];
  };
}

export const DEFAULT_HERO_CONFIG: HeroConfig = {
  content: { gap: 24, lineGap: 16, align: "right", vertical: "middle" },
  background: { mode: "single", interval: 5, zoom: true, overlay: 30 },
  cards: {
    visible: true,
    sizeMode: "preset",
    size: "md",
    custom: { sideW: 265, sideH: 500, midW: 285, midH: 540 },
    tilt: true,
    items: {},
  },
  stats: { visible: true },
  search: {
    visible: true,
    title: "دنبال چه چیزی هستید؟",
    subtitle:
      "بزرگ‌ترین پلتفرم خرید، فروش، اجاره و خدمات ماشین‌آلات سنگین",
    buttonText: "جستجو",
    showCategory: true,
    showBrand: true,
    showYear: true,
    showPrice: true,
    quickLinks: [
      { label: "بیل مکانیکی", href: "/machines?category=excavator" },
      { label: "لودر", href: "/machines?category=loader" },
      { label: "بولدوزر", href: "/machines?category=bulldozer" },
      { label: "جرثقیل", href: "/machines?category=crane" },
    ],
  },
};

export function mergeHeroConfig(raw: any): HeroConfig {
  const d = DEFAULT_HERO_CONFIG;
  if (!raw) return d;
  return {
    content: { ...d.content, ...(raw.content ?? {}) },
    background: { ...d.background, ...(raw.background ?? {}) },
    cards: {
      ...d.cards,
      ...(raw.cards ?? {}),
      custom: { ...d.cards.custom, ...(raw?.cards?.custom ?? {}) },
      items: raw?.cards?.items ?? {},
    },
    stats: { ...d.stats, ...(raw.stats ?? {}) },
    search: {
      ...d.search,
      ...(raw.search ?? {}),
      quickLinks: raw?.search?.quickLinks ?? d.search.quickLinks,
    },
  };
}

export const CARD_SIZES = {
  sm: {
    side: "h-[clamp(300px,26vw,440px)] w-[clamp(140px,12vw,225px)]",
    mid: "h-[clamp(330px,28vw,480px)] w-[clamp(150px,13vw,245px)]",
  },
  md: {
    side: "h-[clamp(330px,29vw,500px)] w-[clamp(160px,14vw,265px)]",
    mid: "h-[clamp(360px,31vw,540px)] w-[clamp(170px,15vw,285px)]",
  },
  lg: {
    side: "h-[clamp(360px,32vw,560px)] w-[clamp(180px,16vw,300px)]",
    mid: "h-[clamp(390px,34vw,600px)] w-[clamp(190px,17vw,320px)]",
  },
};