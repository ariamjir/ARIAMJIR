import { prisma } from "@/lib/prisma";

export async function getProducts() {
  return prisma.product.findMany({
    orderBy: {
      createdAt: "desc",
    },
  });
}

export async function getProduct(id: string) {
  return prisma.product.findUnique({
    where: {
      id,
    },
  });
}

export async function createProduct(data: {
  title: string;
  slug: string;
  description?: string;
  image?: string;
  price?: number;
  categoryId?: string | null;
  brandId?: string | null;
  stock?: number;
  featured?: boolean;
  active?: boolean;
}) {
  return prisma.product.create({
    data: {
      title: data.title,
      slug: data.slug,
      description: data.description,
      image: data.image,
      price: data.price ?? null,
      categoryId: data.categoryId ?? null,
      brandId: data.brandId ?? null,
      stock: data.stock ?? 0,
      featured: data.featured ?? false,
      active: data.active ?? true,
    },
  });
}

export async function updateProduct(
  id: string,
  data: {
    title: string;
    slug: string;
    description?: string;
    image?: string;
    price?: number;
    categoryId?: string | null;
    brandId?: string | null;
    stock?: number;
    featured?: boolean;
    active?: boolean;
  }
) {
  return prisma.product.update({
    where: {
      id,
    },
    data: {
      title: data.title,
      slug: data.slug,
      description: data.description,
      image: data.image,
      price: data.price ?? null,
      categoryId: data.categoryId ?? null,
      brandId: data.brandId ?? null,
      stock: data.stock ?? 0,
      featured: data.featured,
      active: data.active,
    },
  });
}

export async function deleteProduct(id: string) {
  return prisma.product.delete({
    where: {
      id,
    },
  });
}