import { prisma } from "./prisma";

export async function getHeroes() {
  return prisma.hero.findMany({
    orderBy: {
      createdAt: "desc",
    },
    include: {
      slides: {
        where: {
          active: true,
        },
        orderBy: {
          sortOrder: "asc",
        },
      },
    },
  });
}

export async function getActiveHeroes() {
  return prisma.hero.findMany({
    where: {
      active: true,
    },
    orderBy: {
      createdAt: "desc",
    },
    include: {
      slides: {
        where: {
          active: true,
        },
        orderBy: {
          sortOrder: "asc",
        },
      },
    },
  });
}

export async function getHero(id: string) {
  return prisma.hero.findUnique({
    where: {
      id,
    },
    include: {
      slides: {
        orderBy: {
          sortOrder: "asc",
        },
      },
    },
  });
}

export async function createHero(data: {
  title: string;
  subtitle?: string;
  buttonText?: string;
  buttonLink?: string;
  active?: boolean;
}) {
  return prisma.hero.create({
    data: {
      title: data.title,
      subtitle: data.subtitle ?? null,
      buttonText: data.buttonText ?? null,
      buttonLink: data.buttonLink ?? null,
      active: data.active ?? true,
    },
  });
}

export async function updateHero(
  id: string,
  data: {
    title?: string;
    subtitle?: string;
    buttonText?: string;
    buttonLink?: string;
    active?: boolean;
  }
) {
  return prisma.hero.update({
    where: {
      id,
    },
    data: {
      ...(data.title !== undefined && {
        title: data.title,
      }),

      ...(data.subtitle !== undefined && {
        subtitle: data.subtitle,
      }),

      ...(data.buttonText !== undefined && {
        buttonText: data.buttonText,
      }),

      ...(data.buttonLink !== undefined && {
        buttonLink: data.buttonLink,
      }),

      ...(data.active !== undefined && {
        active: data.active,
      }),
    },
  });
}

export async function deleteHero(id: string) {
  return prisma.hero.delete({
    where: {
      id,
    },
  });
}