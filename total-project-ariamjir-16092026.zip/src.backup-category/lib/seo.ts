export const SITE_URL = process.env.SITE_URL ?? "https://ariamj.ir";
export const SITE_NAME = "آریا ماشین جم | ARIA MJ";
export const SITE_DESC =
  "بزرگ‌ترین مارکت‌پلیس خرید، فروش، اجاره و خدمات ماشین‌آلات سنگین، معدنی و راه‌سازی در ایران";