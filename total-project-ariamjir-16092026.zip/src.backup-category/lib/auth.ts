export const ADMIN_USER = "admin";

export const ADMIN_PASSWORD = "123456";

export function validateLogin(username: string, password: string) {
  return (
    username === ADMIN_USER &&
    password === ADMIN_PASSWORD
  );
}