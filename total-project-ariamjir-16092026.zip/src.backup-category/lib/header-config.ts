export interface HeaderConfig {
  logo: {
    url: string;
    width: number;
    height: number;
    alt: string;
    visible: boolean;
  };
  brand: { text: string; visible: boolean };
  tagline: { text: string; visible: boolean };
  cta: { text: string; href: string; visible: boolean };
  layout: { sticky: boolean; transparent: boolean };
}

export const DEFAULT_HEADER_CONFIG: HeaderConfig = {
  logo: {
    url: "/images/logo/ariamj-logo.png",
    width: 44,
    height: 44,
    alt: "ARIA MJ",
    visible: true,
  },
  brand: { text: "ARIA MJ", visible: true },
  tagline: { text: "INDUSTRIAL MARKETPLACE", visible: true },
  cta: { text: "ثبت آگهی", href: "/machines/new", visible: true },
  layout: { sticky: true, transparent: true },
};

export function mergeHeaderConfig(raw: any): HeaderConfig {
  const d = DEFAULT_HEADER_CONFIG;
  if (!raw) return d;
  return {
    logo: { ...d.logo, ...(raw.logo ?? {}) },
    brand: { ...d.brand, ...(raw.brand ?? {}) },
    tagline: { ...d.tagline, ...(raw.tagline ?? {}) },
    cta: { ...d.cta, ...(raw.cta ?? {}) },
    layout: { ...d.layout, ...(raw.layout ?? {}) },
  };
}