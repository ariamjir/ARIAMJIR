export const UploadConfig = {
  image: {
    maxSize: 500 * 1024,
    quality: 80,
    maxWidth: 1920,
    maxHeight: 1920,
    allowedTypes: [
      "image/jpeg",
      "image/png",
      "image/webp",
    ],
  },

  video: {
    maxUploadSize: 500 * 1024 * 1024,

    compressAfter: 10 * 1024 * 1024,

    targetCodec: "libx264",

    audioCodec: "aac",

    crf: 28,

    maxWidth: 1920,

    maxHeight: 1080,

    allowedTypes: [
      "video/mp4",
      "video/webm",
      "video/quicktime",
    ],
  },

  brochure: {
    maxSize: 2 * 1024 * 1024,

    allowedTypes: [
      "application/pdf",
    ],
  },
};