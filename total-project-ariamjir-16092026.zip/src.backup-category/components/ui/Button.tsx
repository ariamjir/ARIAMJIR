"use client";

import { ButtonHTMLAttributes } from "react";

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary";
}

export default function Button({
  variant = "primary",
  className,
  children,
  ...props
}: ButtonProps) {
  const styles =
    variant === "primary"
      ? "bg-[#F58220] text-white hover:bg-[#dd6f18]"
      : "bg-white/5 border border-white/20 text-white hover:bg-white/10";

  return (
    <button
      {...props}
      className={`
        h-[60px]
        rounded-2xl
        px-10
        font-bold

        transition-all
        duration-300

        ${styles}
        ${className ?? ""}
      `}
    >
      {children}
    </button>
  );
}