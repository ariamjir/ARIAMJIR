"use client";

import { useEffect, useRef, useState } from "react";

import Link from "next/link";

/* ============================================================
   تیکر برندها — لایهٔ کوچک (۹ آیتم)، حرکت پله‌ای بی‌درز
   ✅ بدون keyframe · بدون لایهٔ عریض · هرگز خالی نمی‌شود
   ✅ همهٔ برندها به‌نوبت عبور می‌کنند
============================================================ */

const ITEM_W = 208; /* w-52 */
const PER_VIEW = 8;

export default function BrandTicker({ brands }: { brands: any[] }) {
  const [start, setStart] = useState(0);
  const [offset, setOffset] = useState(0);
  const [instant, setInstant] = useState(false);
  const raf = useRef(0);

  /* هر ۳.۵ ثانیه یک پله */
  useEffect(() => {
    if (brands.length <= PER_VIEW) return;
    const t = setInterval(() => setOffset(1), 3500);
    return () => clearInterval(t);
  }, [brands.length]);

  /* بعد از انتقال، شروع را جلو ببر و بدون انیمیشن ریست کن */
  useEffect(() => {
    if (offset !== 1) return;

    const to = setTimeout(() => {
      setInstant(true);
      setStart((s) => (s + 1) % brands.length);
      setOffset(0);

      cancelAnimationFrame(raf.current);
      raf.current = requestAnimationFrame(() =>
        requestAnimationFrame(() => setInstant(false))
      );
    }, 720);

    return () => clearTimeout(to);
  }, [offset, brands.length]);

  if (brands.length === 0) return null;

  const items = Array.from(
    { length: Math.min(brands.length, PER_VIEW + 1) },
    (_, i) => brands[(start + i) % brands.length]
  );

  return (
    <div className="overflow-hidden border-y border-white/5 bg-white/[0.015]">
      <div
        className="flex w-max"
        style={{
          transform: `translateX(-${offset * ITEM_W}px)`,
          transition: instant ? "none" : "transform .7s cubic-bezier(.4,0,.2,1)",
        }}
      >
        {items.map((b, i) => (
          <BrandItem key={`${b.id}-${i}`} b={b} />
        ))}
      </div>
    </div>
  );
}

function BrandItem({ b }: { b: any }) {
  return (
    <Link
      href={`/brands/${b.slug}`}
      title={`${b.name} — ${(b._count?.machines ?? 0).toLocaleString("fa-IR")} دستگاه`}
      className="
        group
        relative
        flex
        h-32
        w-52
        shrink-0
        flex-col
        items-center
        justify-center
        gap-3
        border-l
        border-white/5
        transition
        hover:bg-[#F58220]/10
      "
    >
      {/* چیپ سفید لوگو — واقعی یا مونوگرام داخلی */}
      <span className="flex h-16 w-28 items-center justify-center overflow-hidden rounded-xl bg-white p-2 shadow-[inset_0_2px_6px_rgba(0,0,0,.08)] transition duration-300 group-hover:scale-105">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={b.logo || `/api/brand-logo/${b.slug}`}
          alt={`لوگو ${b.name}`}
          decoding="async"
          referrerPolicy="no-referrer"
          className="max-h-full max-w-full object-contain"
        />
      </span>

      <span className="text-[10px] font-bold text-white/55 transition group-hover:text-[#F58220]">
        {b.name}
      </span>

      <span className="absolute top-2 left-2 rounded-full bg-[#F58220] px-1.5 py-0.5 text-[8px] font-black text-white opacity-0 transition group-hover:opacity-100">
        {(b._count?.machines ?? 0).toLocaleString("fa-IR")} دستگاه
      </span>
    </Link>
  );
}