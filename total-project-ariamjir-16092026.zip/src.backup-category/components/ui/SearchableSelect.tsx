"use client";

import {
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";

import {
  ChevronDown,
  Check,
  Search,
  Loader2,
} from "lucide-react";

import { countries } from "@/data/countries";

export interface SearchableOption {
  value: string;
  label: string;
  flag?: string;
  disabled?: boolean;
}

interface SearchableSelectProps {
  label?: string;

  value?: string;

  options: SearchableOption[];

  onChange: (value: string) => void;

  placeholder?: string;

  searchPlaceholder?: string;

  emptyText?: string;

  error?: string;

  required?: boolean;

  disabled?: boolean;

  loading?: boolean;

  className?: string;
}

export default function SearchableSelect({
  label,
  value,
  options,
  onChange,
  placeholder = "انتخاب کنید",
  searchPlaceholder = "جستجو...",
  emptyText = "موردی یافت نشد",
  error,
  required = false,
  disabled = false,
  loading = false,
  className = "",
}: SearchableSelectProps) {
  const wrapperRef = useRef<HTMLDivElement>(null);

  const inputRef = useRef<HTMLInputElement>(null);

  const [open, setOpen] = useState(false);

  const [search, setSearch] = useState("");

  const [highlighted, setHighlighted] =
    useState(0);

  useEffect(() => {
    const close = (event: MouseEvent) => {
      if (
        wrapperRef.current &&
        !wrapperRef.current.contains(
          event.target as Node
        )
      ) {
        setOpen(false);
      }
    };

    document.addEventListener("mousedown", close);

    return () =>
      document.removeEventListener(
        "mousedown",
        close
      );
  }, []);

  useEffect(() => {
    if (open) {
      setTimeout(() => {
        inputRef.current?.focus();
      }, 30);
    }
  }, [open]);

  const filteredOptions = useMemo(() => {
    if (!search.trim()) {
      return options;
    }

    const keyword = search
      .toLowerCase()
      .trim();

    return options.filter((item) =>
      item.label
        .toLowerCase()
        .includes(keyword)
    );
  }, [options, search]);

  const selected = useMemo(() => {
    return options.find(
      (item) => item.value === value
    );
  }, [options, value]);

  useEffect(() => {
    setHighlighted(0);
  }, [search]);

  const choose = (option: SearchableOption) => {
    if (option.disabled) return;

    onChange(option.value);

    setSearch("");

    setOpen(false);
  };

  const onKeyDown = (
    e: React.KeyboardEvent<HTMLInputElement>
  ) => {
    switch (e.key) {
      case "ArrowDown":
        e.preventDefault();

        setHighlighted((prev) =>
          Math.min(
            prev + 1,
            filteredOptions.length - 1
          )
        );

        break;

      case "ArrowUp":
        e.preventDefault();

        setHighlighted((prev) =>
          Math.max(prev - 1, 0)
        );

        break;

      case "Enter":
        e.preventDefault();

        if (filteredOptions[highlighted]) {
          choose(filteredOptions[highlighted]);
        }

        break;

      case "Escape":
        setOpen(false);
        break;
    }
  };

  return (
    <div
      ref={wrapperRef}
      className={`relative ${className}`}
    >
      {label && (
        <label className="mb-2 block font-medium">
          {label}

          {required && (
            <span className="mr-1 text-red-600">
              *
            </span>
          )}
        </label>
      )}

      <button
        type="button"
        disabled={disabled}
        onClick={() =>
          setOpen((prev) => !prev)
        }
        className={`
          flex
          w-full
          items-center
          justify-between
          rounded-xl
          border
          bg-white
          px-4
          py-3
          text-right
          transition

          ${
            error
              ? "border-red-500"
              : "border-gray-300 hover:border-orange-400"
          }

          ${
            disabled
              ? "cursor-not-allowed bg-gray-100"
              : ""
          }
        `}
      >
        <span
          className={
            selected
              ? ""
              : "text-gray-400"
          }
        >
          {selected
            ? `${selected.flag ?? ""} ${selected.label}`
            : placeholder}
        </span>

        {loading ? (
          <Loader2 className="h-5 w-5 animate-spin" />
        ) : (
          <ChevronDown
            className={`
              h-5
              w-5
              transition

              ${
                open
                  ? "rotate-180"
                  : ""
              }
            `}
          />
        )}
      </button>
            {open && (
        <div
          className="
            absolute
            z-50
            mt-2
            w-full
            overflow-hidden
            rounded-xl
            border
            border-gray-200
            bg-white
            shadow-2xl
          "
        >
          <div className="border-b p-3">
            <div className="relative">
              <Search
                className="
                  absolute
                  right-3
                  top-3
                  h-4
                  w-4
                  text-gray-400
                "
              />

              <input
                ref={inputRef}
                value={search}
                onChange={(e) =>
                  setSearch(e.target.value)
                }
                onKeyDown={onKeyDown}
                placeholder={searchPlaceholder}
                className="
                  w-full
                  rounded-lg
                  border
                  border-gray-300
                  py-2
                  pr-10
                  pl-3
                  outline-none
                  focus:border-orange-500
                "
              />
            </div>
          </div>

          <div
            className="
              max-h-72
              overflow-y-auto
            "
          >
            {filteredOptions.length === 0 && (
              <div
                className="
                  px-4
                  py-6
                  text-center
                  text-sm
                  text-gray-500
                "
              >
                {emptyText}
              </div>
            )}

            {filteredOptions.map(
              (option, index) => {
                const selectedItem =
                  option.value === value;

                const highlightedItem =
                  highlighted === index;

                return (
                  <button key={`${option.value}-${index}`}
                    type="button"
                    disabled={option.disabled}
                    onClick={() =>
                      choose(option)
                    }
                    className={`
                      flex
                      w-full
                      items-center
                      justify-between
                      px-4
                      py-3
                      text-right
                      transition

                      ${
                        highlightedItem
                          ? "bg-orange-50"
                          : ""
                      }

                      ${
                        selectedItem
                          ? "font-semibold text-orange-600"
                          : ""
                      }

                      ${
                        option.disabled
                          ? "cursor-not-allowed opacity-40"
                          : "hover:bg-orange-50"
                      }
                    `}
                  >
                    <div className="flex items-center gap-2">
                      {option.flag && (
                        <span className="text-lg">
                          {option.flag}
                        </span>
                      )}

                      <span>
                        {option.label}
                      </span>
                    </div>

                    {selectedItem && (
                      <Check
                        className="
                          h-5
                          w-5
                          text-orange-600
                        "
                      />
                    )}
                  </button>
                );
              }
            )}
          </div>
        </div>
      )}

      {error && (
        <p
          className="
            mt-2
            text-sm
            text-red-600
          "
        >
          {error}
        </p>
      )}
          </div>
  );
}

export type {
  SearchableSelectProps,
};