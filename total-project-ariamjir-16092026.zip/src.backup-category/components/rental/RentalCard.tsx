import Link from "next/link";

import { CalendarDays, User, Fuel, Truck } from "lucide-react";

export function toman(v: any) {
  if (v == null) return "توافقی";
  return `${Number(v).toLocaleString("fa-IR")} تومان`;
}

export default function RentalCard({ r }: { r: any }) {
  const m = r.machine;
  const image = m.images?.[0]?.url ?? "/images/machines/default.svg";
  const year = m.specification?.manufactureYear ?? m.year ?? null;

  return (
    <Link
      href={`/rental/${m.slug}`}
      className="group flex h-full flex-col overflow-hidden rounded-2xl border border-white/10 bg-[#141414] transition hover:border-[#F58220]/40"
    >
      <div className="relative aspect-[4/3] overflow-hidden">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={image}
          alt={m.title}
          loading="lazy"
          className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
        />
        {m.category && (
          <span className="absolute top-3 right-3 rounded-full bg-[#F58220] px-2.5 py-1 text-[9px] font-black text-white">
            {m.category.name}
          </span>
        )}
      </div>

      <div className="flex flex-1 flex-col gap-2 p-4">
        <h3 className="line-clamp-2 text-sm font-black text-white transition group-hover:text-[#F58220]">
          اجارهٔ {m.title}
        </h3>

        <div className="text-[10px] text-white/40">
          {m.brand?.name ?? ""} {year ? `· ${year}` : ""}
        </div>

        <div className="flex flex-wrap gap-1.5">
          {r.operatorIncluded && (
            <span className="inline-flex items-center gap-1 rounded-full bg-white/5 px-2 py-0.5 text-[9px] font-bold text-white/60">
              <User className="h-3 w-3" /> اپراتور
            </span>
          )}
          {r.fuelIncluded && (
            <span className="inline-flex items-center gap-1 rounded-full bg-white/5 px-2 py-0.5 text-[9px] font-bold text-white/60">
              <Fuel className="h-3 w-3" /> سوخت
            </span>
          )}
          {r.transportationIncluded && (
            <span className="inline-flex items-center gap-1 rounded-full bg-white/5 px-2 py-0.5 text-[9px] font-bold text-white/60">
              <Truck className="h-3 w-3" /> حمل
            </span>
          )}
          <span className="inline-flex items-center gap-1 rounded-full bg-white/5 px-2 py-0.5 text-[9px] font-bold text-white/60">
            <CalendarDays className="h-3 w-3" /> حداقل {r.minimumRentalDays} روز
          </span>
        </div>

        <div className="mt-auto flex items-center justify-between pt-2">
          <div>
            <div className="text-[9px] text-white/40">روزانه</div>
            <div className="text-sm font-black text-[#F58220]">{toman(r.dailyPrice)}</div>
          </div>
          <span className="rounded-xl bg-[#F58220] px-4 py-2 text-[10px] font-black text-white transition group-hover:bg-[#d96f15]">
            مشاهده و رزرو
          </span>
        </div>
      </div>
    </Link>
  );
}