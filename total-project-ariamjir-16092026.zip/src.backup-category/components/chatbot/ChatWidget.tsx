"use client";

import { useEffect, useRef, useState } from "react";
import { X, Send, Bot, User, Sparkles, Minimize2 } from "lucide-react";

interface Message {
  role: "user" | "assistant";
  content: string;
  time: number;
  streaming?: boolean;
}

const WELCOME = `سلام! من **آریا** هستم، دستیار هوشمند آریا ماشین جم 🚜

می‌تونم کمکت کنم در:
• خرید یا فروش ماشین‌آلات سنگین
• پیدا کردن قطعات یدکی
• خدمات فنی و اجاره دستگاه

چه کمکی از دستم برمیاد؟`;

const SUGGESTIONS = [
  "ماشین‌آلات موجود را ببینم",
  "چه قطعات یدکی‌ای دارید؟",
  "خدمات تعمیرات شما چیه؟",
  "تماس با پشتیبانی",
];

/* ============================================================
   ویجت جرثقیل 🏗️
   - بدون هیچ تغییری در طراحی و انیمیشن اصلی شما
   - فقط قابلیت باز و بسته کردن پنل چت را مدیریت می‌کند
============================================================ */
function CraneWidget({
  open,
  minimized,
  onToggle,
}: {
  open: boolean;
  minimized: boolean;
  onToggle: () => void;
}) {
  const animationState = open && !minimized ? "paused" : "running";

  return (
    <div className="relative h-full w-full select-none">
      {/* جرثقیل ثابت */}
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src="/images/chatbot/crane-static.svg"
        alt=""
        draggable={false}
        className="pointer-events-none absolute inset-0 h-full w-full object-contain"
      />

      {/* سیم متحرک جرثقیل */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute z-10"
        style={{
          left: "50%",
          top: "9%",
          width: "2px",
          height: "42%",
          transform: "translateX(-50%)",
          transformOrigin: "top center",
          background: "linear-gradient(to right, #111 0%, #777 45%, #111 100%)",
          boxShadow: "0 0 3px rgba(0,0,0,.55)",
          animation: "craneCable 2.8s ease-in-out infinite",
          animationPlayState: animationState,
        }}
      />

      {/* گوی هوشمند — کلیک روی آن پنل را باز/بسته می‌کند */}
      <button
        type="button"
        onClick={onToggle}
        aria-label="گفتگو با آریا"
        title={open && !minimized ? "بستن چت" : "گفتگو با آریا"}
        className="absolute z-20 cursor-pointer rounded-full border-0 bg-transparent p-0 outline-none transition-transform duration-200 hover:scale-[1.04] focus-visible:ring-2 focus-visible:ring-sky-400"
        style={{
          left: "50%",
          top: "49%",
          width: "58%",
          aspectRatio: "1 / 1",
          transform: "translate(-50%, -50%)",
          animation: "craneOrb 2.8s ease-in-out infinite",
          animationPlayState: animationState,
        }}
      >
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src="/images/chatbot/assistant-orb.svg"
          alt="دستیار هوشمند آریا"
          draggable={false}
          className="pointer-events-none h-full w-full object-contain drop-shadow-[0_14px_22px_rgba(0,0,0,.38)]"
        />
      </button>
    </div>
  );
}

export default function ChatWidget() {
  const [open, setOpen] = useState(false);
  const [minimized, setMinimized] = useState(false); // حالت جدید برای پنهان کردن پنل
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const abortRef = useRef<AbortController | null>(null);

  useEffect(() => {
    try {
      const saved = localStorage.getItem("ariamj-chat");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) setMessages(parsed);
      }
    } catch {}
  }, []);

  useEffect(() => {
    if (messages.length > 0) {
      try {
        localStorage.setItem("ariamj-chat", JSON.stringify(messages.slice(-30)));
      } catch {}
    }
  }, [messages]);

  useEffect(() => {
    scrollRef.current?.scrollTo({
      top: scrollRef.current.scrollHeight,
      behavior: "smooth",
    });
  }, [messages, busy]);

  useEffect(() => {
    if (open && !minimized) setTimeout(() => inputRef.current?.focus(), 200);
  }, [open, minimized]);

  const send = async (text?: string) => {
    const msg = (text ?? input).trim();
    if (!msg || busy) return;

    const userMsg: Message = { role: "user", content: msg, time: Date.now() };
    const assistantId = Date.now() + 1;
    const assistantMsg: Message = {
      role: "assistant",
      content: "",
      time: assistantId,
      streaming: true,
    };

    setMessages((prev) => [...prev, userMsg, assistantMsg]);
    setInput("");
    setBusy(true);
    abortRef.current = new AbortController();

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: msg,
          history: [...messages, userMsg].slice(-6).map((m) => ({
            role: m.role,
            content: m.content,
          })),
        }),
        signal: abortRef.current.signal,
      });

      if (!res.body) throw new Error("No body");

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let fullContent = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() || "";

        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed.startsWith("data:")) continue;
          try {
            const data = JSON.parse(trimmed.slice(5));
            if (data.type === "chunk") {
              fullContent += data.content;
              setMessages((prev) =>
                prev.map((m) =>
                  m.time === assistantId ? { ...m, content: fullContent } : m
                )
              );
            }
          } catch {}
        }
      }

      setMessages((prev) =>
        prev.map((m) =>
          m.time === assistantId
            ? { ...m, streaming: false, content: fullContent || "پاسخی دریافت نشد." }
            : m
        )
      );
    } catch (error: any) {
      if (error.name !== "AbortError") {
        setMessages((prev) =>
          prev.map((m) =>
            m.time === assistantId
              ? {
                  ...m,
                  streaming: false,
                  content: "متأسفم، الان نمی‌تونم پاسخ بدم. لطفاً چند لحظه دیگر دوباره تلاش کنید.",
                }
              : m
          )
        );
      }
    } finally {
      setBusy(false);
      abortRef.current = null;
    }
  };

  const clear = () => {
    if (!confirm("تاریخچه پاک شود؟")) return;
    setMessages([]);
    localStorage.removeItem("ariamj-chat");
  };

  const stop = () => {
    abortRef.current?.abort();
    setBusy(false);
  };

  const displayMessages: Message[] =
    messages.length === 0
      ? [{ role: "assistant", content: WELCOME, time: Date.now() }]
      : messages;

  // تابع مدیریت کلیک روی جرثقیل
  const handleCraneClick = () => {
    if (!open) {
      setOpen(true);
      setMinimized(false);
    } else if (minimized) {
      setMinimized(false); // اگر مینیمایز بود، بازش کن
    } else {
      setOpen(false); // اگر باز بود، کلاً ببند
    }
  };

  return (
    <>
      <style jsx global>{`
        @keyframes craneOrb {
          0%, 100% { transform: translate(-50%, -50%) translateY(-10px); }
          50% { transform: translate(-50%, -50%) translateY(18px); }
        }
        @keyframes craneCable {
          0%, 100% { height: 38%; }
          50% { height: 45%; }
        }
      `}</style>

      {/* ویجت جرثقیل — همیشه در گوشه صفحه است */}
      <div className="fixed bottom-2 left-2 z-50 w-[150px] aspect-[832/1216]">
        <CraneWidget
          open={open}
          minimized={minimized}
          onToggle={handleCraneClick}
        />

        {/* نشان AI */}
        {!open && (
          <span className="pointer-events-none absolute right-1 top-1 flex h-6 w-6 items-center justify-center rounded-full bg-red-500 text-[10px] font-black text-white shadow-lg">
            AI
          </span>
        )}
      </div>

      {/* پنل چت — فقط زمانی نمایش داده می‌شود که باز باشد و مینیمایز نشده باشد */}
      {open && !minimized && (
        <div className="fixed bottom-2 left-40 z-50 flex h-[600px] w-[380px] max-h-[calc(100vh-2rem)] flex-col overflow-hidden rounded-3xl border border-white/10 bg-[#0a0a0a] shadow-2xl">
          {/* Header */}
          <div className="flex items-center justify-between border-b border-white/10 bg-gradient-to-r from-[#1a2733] to-[#0d141b] px-5 py-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center overflow-hidden rounded-full border border-sky-400/30 bg-black">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src="/images/chatbot/crane-bot.png"
                  alt=""
                  className="h-full w-full scale-[2.2] object-cover object-[68%_60%]"
                />
              </div>
              <div>
                <div className="flex items-center gap-1.5 text-sm font-black text-white">
                  آریا <Sparkles className="h-3 w-3 text-sky-400" />
                </div>
                <div className="text-[10px] text-white/60">دستیار هوشمند آریا ماشین جم</div>
              </div>
            </div>
            <div className="flex gap-1">
              {messages.length > 0 && (
                <button
                  onClick={clear}
                  className="rounded-lg px-2 py-1 text-[10px] font-bold text-white/60 transition hover:bg-white/10 hover:text-white"
                  title="پاک کردن تاریخچه"
                >
                  <X className="h-4 w-4" />
                </button>
              )}
              {/* دکمه مینیمایز (پنهان کردن پنل بدون بستن کامل) */}
              <button
                onClick={() => setMinimized(true)}
                className="rounded-lg px-2 py-1 text-[10px] font-bold text-white/60 transition hover:bg-white/10 hover:text-white"
                title="پنهان کردن پنل چت"
              >
                <Minimize2 className="h-4 w-4" />
              </button>
            </div>
          </div>

          {/* Messages */}
          <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 py-4">
            <div className="space-y-4">
              {displayMessages.map((m, i) => (
                <MessageBubble key={i} message={m} />
              ))}
            </div>

            {messages.length === 0 && (
              <div className="mt-4 space-y-2">
                <div className="text-[10px] font-bold text-white/40">سوالات پیشنهادی:</div>
                {SUGGESTIONS.map((s, i) => (
                  <button
                    key={i}
                    onClick={() => send(s)}
                    className="block w-full rounded-xl border border-white/10 bg-white/[0.03] px-3 py-2 text-right text-[11px] text-white/70 transition hover:border-sky-400/40 hover:text-sky-300"
                  >
                    {s}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Input */}
          <div className="border-t border-white/10 bg-[#0a0a0a] p-3">
            <div className="flex items-center gap-2">
              <input
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && send()}
                placeholder="سوال خود را بنویسید..."
                className="flex-1 rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white placeholder:text-white/30 outline-none focus:border-sky-400/40"
                disabled={busy}
              />
              {busy ? (
                <button
                  onClick={stop}
                  className="flex h-10 w-10 items-center justify-center rounded-xl bg-red-500 text-white transition hover:bg-red-600"
                  title="توقف"
                >
                  <X className="h-4 w-4" />
                </button>
              ) : (
                <button
                  onClick={() => send()}
                  disabled={!input.trim()}
                  className="flex h-10 w-10 items-center justify-center rounded-xl bg-sky-500 text-white transition hover:bg-sky-600 disabled:opacity-40"
                >
                  <Send className="h-4 w-4" />
                </button>
              )}
            </div>
            <div className="mt-2 text-center text-[9px] text-white/30">
              پاسخ‌ها بر اساس اطلاعات واقعی سایت تولید می‌شوند
            </div>
          </div>
        </div>
      )}
    </>
  );
}

function MessageBubble({ message }: { message: Message }) {
  const isUser = message.role === "user";

  const html = message.content
    .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
    .replace(/`(.+?)`/g, '<code class="rounded bg-white/10 px-1.5 py-0.5 text-sky-300">$1</code>')
    .replace(/\[(.+?)\]\((.+?)\)/g, '<a href="$2" class="text-sky-300 underline" target="_blank" rel="noopener">$1</a>')
    .replace(/\n/g, "<br/>");

  return (
    <div className={`flex items-start gap-2 ${isUser ? "flex-row-reverse" : ""}`}>
      <div
        className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-full ${
          isUser ? "bg-white/10 text-white" : "bg-sky-400/20 text-sky-300"
        }`}
      >
        {isUser ? <User className="h-3.5 w-3.5" /> : <Bot className="h-3.5 w-3.5" />}
      </div>
      <div
        className={`max-w-[75%] rounded-2xl px-4 py-2.5 text-[13px] leading-6 ${
          isUser
            ? "rounded-tr-sm bg-sky-600 text-white"
            : "rounded-tl-sm bg-white/5 text-white/90"
        }`}
      >
        <span dangerouslySetInnerHTML={{ __html: html }} />
        {message.streaming && (
          <span className="inline-block h-4 w-1 animate-pulse bg-sky-400 align-middle" />
        )}
      </div>
    </div>
  );
}