"use client";

export default function MachineFilters() {
  return (
    <div className="rounded-xl border p-4">
      Machine Filters
    </div>
  );
}