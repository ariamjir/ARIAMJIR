"use client";

export default function SearchBar() {
  return (
    <input
      className="w-full rounded-xl border p-3"
      placeholder="Search..."
    />
  );
}