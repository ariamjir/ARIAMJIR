"use client";

interface Props {
  title: string;
  description?: string;
}

export default function EmptyState({
  title,
  description,
}: Props) {
  return (
    <div className="rounded-xl border p-10 text-center">
      <h3 className="text-xl font-bold">{title}</h3>

      {description && (
        <p className="mt-2 text-gray-500">
          {description}
        </p>
      )}
    </div>
  );
}