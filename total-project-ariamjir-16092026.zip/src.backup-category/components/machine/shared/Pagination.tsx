"use client";

interface Props {
  page: number;
  totalPages: number;
  total: number;
}

export default function Pagination({
  page,
  totalPages,
}: Props) {
  return (
    <div className="flex justify-center gap-2 py-8">
      <span>
        Page {page} / {totalPages}
      </span>
    </div>
  );
}
