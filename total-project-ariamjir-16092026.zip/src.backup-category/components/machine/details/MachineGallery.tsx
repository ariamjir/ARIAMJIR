"use client";

import { useMemo, useState } from "react";

import Image from "next/image";

import { ChevronLeft, ChevronRight, Maximize2, Play } from "lucide-react";

interface MediaItem{

id:string;

type:string;

url:string;

thumbnail?:string;

title?:string;

}

interface Props{

media:MediaItem[];

}

export default function MachineGallery({

media,

}:Props){

const items=

useMemo(

()=>media??[],

[media]

);

const[active,setActive]=

useState(0);

if(items.length===0){

return(

<div className="flex aspect-[4/3] items-center justify-center rounded-2xl border bg-gray-100">

بدون تصویر

</div>

);

}

const current=

items[active];

const previous=()=>{

setActive(

prev=>

prev===0

?items.length-1

:prev-1

);

};

const next=()=>{

setActive(

prev=>

prev===items.length-1

?0

:prev+1

);

};

return(

<div className="space-y-4">

<div className="relative aspect-[4/3] overflow-hidden rounded-2xl bg-black">

{

current.type==="video"

?

<div className="flex h-full items-center justify-center text-white">

<Play className="h-12 w-12"/>

</div>

:

<Image

src={current.url}

alt={current.title??"Machine"}

fill

priority

className="object-cover"

/>

}

<button

type="button"

onClick={previous}

className="absolute left-3 top-1/2 -translate-y-1/2 rounded-full bg-white/90 p-2 shadow"

>

<ChevronLeft className="h-5 w-5"/>

</button>

<button

type="button"

onClick={next}

className="absolute right-3 top-1/2 -translate-y-1/2 rounded-full bg-white/90 p-2 shadow"

>

<ChevronRight className="h-5 w-5"/>

</button>

<button

type="button"

className="absolute right-3 top-3 rounded-full bg-white/90 p-2 shadow"

>

<Maximize2 className="h-5 w-5"/>

</button>

</div>

<div className="grid grid-cols-5 gap-3 md:grid-cols-7">

{

items.map(

(item,index)=>(

<button

key={item.id}

type="button"

onClick={()=>setActive(index)}

className={`relative aspect-square overflow-hidden rounded-xl border-2

${

index===active

?"border-orange-500"

:"border-gray-200"

}

`}

>

{

item.type==="video"

?

<div className="flex h-full items-center justify-center bg-gray-100">

<Play className="h-6 w-6"/>

</div>

:

<Image

src={item.thumbnail??item.url}

alt={item.title??""}

fill

className="object-cover"

/>

}

</button>

)

)

}

</div>

</div>

);

}