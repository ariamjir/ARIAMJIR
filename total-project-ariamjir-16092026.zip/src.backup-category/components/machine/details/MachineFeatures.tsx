"use client";

import { CheckCircle2 } from "lucide-react";

interface Props {

  features: string[];

}

export default function MachineFeatures({

  features,

}: Props) {

    if (

  !features ||

  features.length === 0

) {

  return null;

}

return (

<div className="rounded-2xl border bg-white p-6 shadow-sm">

<h2 className="mb-6 text-2xl font-bold">

امکانات و تجهیزات

</h2>

<div

className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-3"

>

    {

features.map(

(feature,index)=>(

<div

key={`${feature}-${index}`}

className="flex items-center gap-3 rounded-xl border border-gray-200 bg-gray-50 px-4 py-3 transition hover:border-orange-400 hover:bg-orange-50"

>

    <CheckCircle2

className="h-5 w-5 shrink-0 text-green-600"

/>

<span

className="text-sm font-medium text-gray-800"

>

{feature}

</span>

</div>

)

)

}

</div>

</div>

);

}