"use client";

interface Props {
  machine: any;
}

export default function MachineSpecificationTable({
  machine,
}: Props) {
  const groups = [
    {
      title: "مشخصات عمومی",
      items: [
        ["برند", machine.brand?.nameFa],
        ["مدل", machine.model],
        ["دسته بندی", machine.category?.nameFa],
        ["سال ساخت", machine.year],
        ["کشور سازنده", machine.country],
        ["وضعیت", machine.condition],
      ],
    },

    {
      title: "مشخصات موتور",
      items: [
        ["مدل موتور", machine.engineModel],
        ["سازنده موتور", machine.engineBrand],
        ["قدرت", machine.enginePower],
        ["حجم موتور", machine.engineVolume],
        ["تعداد سیلندر", machine.cylinderCount],
        ["سوخت", machine.fuelType],
      ],
    },

    {
      title: "سیستم انتقال قدرت",
      items: [
        ["گیربکس", machine.transmission],
        ["نوع حرکت", machine.driveType],
        ["حداکثر سرعت", machine.maxSpeed],
        ["فرمان", machine.steering],
        ["ترمز", machine.brakeType],
      ],
    },

    {
      title: "ابعاد",
      items: [
        ["طول", machine.length],
        ["عرض", machine.width],
        ["ارتفاع", machine.height],
        ["وزن", machine.weight],
        ["ظرفیت باکت", machine.bucketCapacity],
        ["ظرفیت لیفت", machine.liftCapacity],
      ],
    },
  ];

  return (
    <div className="space-y-8">
      {groups.map((group) => (
        <div
          key={group.title}
          className="overflow-hidden rounded-2xl border"
        >
          <div className="border-b bg-gray-50 px-6 py-4">
            <h3 className="font-bold">{group.title}</h3>
          </div>

          <div className="divide-y">
            {group.items.map(([label, value]) => (
              <div
                key={String(label)}
                className="grid grid-cols-2 gap-4 px-6 py-4"
              >
                <div className="font-medium text-gray-500">
                  {label}
                </div>

                <div>{value || "-"}</div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}