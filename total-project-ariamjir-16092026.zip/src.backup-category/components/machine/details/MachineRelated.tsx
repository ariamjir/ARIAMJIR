"use client";

import MachineCard from "../card/MachineCard";

interface Props {

  machines:any[];

}

export default function MachineRelated({

  machines,

}:Props){

    if(

!machines ||

machines.length===0

){

return null;

}

return(

<section className="space-y-6">

<div className="flex items-center justify-between">

<h2 className="text-2xl font-bold">

ماشین‌های مشابه

</h2>

<p className="text-sm text-gray-500">

{machines.length} دستگاه

</p>

</div>

<div

className="grid grid-cols-1 gap-6 md:grid-cols-2 xl:grid-cols-4"

>

    {

machines.map(

(machine)=>(

<MachineCard

key={machine.id}

machine={machine}

/>

)

)

}

</div>

</section>

);

}