"use client";

import { FileText, Download, FileArchive } from "lucide-react";

interface DocumentItem {

  id: string;

  title: string;

  type: string;

  url: string;

  size?: string;

}

interface Props {

  documents: DocumentItem[];

}

export default function MachineDocuments({

  documents,

}: Props) {

    if (

  !documents ||

  documents.length === 0

) {

  return null;

}

return (

<div className="rounded-2xl border bg-white p-6 shadow-sm">

<h2 className="mb-6 text-2xl font-bold">

مدارک و فایل‌ها

</h2>

<div className="space-y-4">

{

documents.map((doc)=>(

<div

key={doc.id}

className="flex items-center justify-between rounded-xl border border-gray-200 p-4 transition hover:border-orange-400"

>

    <div className="flex items-center gap-4">

<div className="rounded-xl bg-orange-100 p-3">

<FileArchive

className="h-6 w-6 text-orange-600"

/>

</div>

<div>

    <h3 className="font-semibold">

{doc.title}

</h3>

<p className="text-sm text-gray-500">

{doc.type}

{

doc.size &&

` • ${doc.size}`

}

</p>

</div>

</div>

<a

href={doc.url}

target="_blank"

download

className="flex items-center gap-2 rounded-xl bg-orange-500 px-4 py-2 text-white transition hover:bg-orange-600"

>

<Download className="h-4 w-4"/>

دانلود

</a>

</div>

))

}

</div>

</div>

);

}