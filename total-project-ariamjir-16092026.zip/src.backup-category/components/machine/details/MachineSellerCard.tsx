"use client";

import Link from "next/link";

import { Phone, MessageCircle, Building2, BadgeCheck, MapPin } from "lucide-react";

interface Props {
  seller: any;
}

export default function MachineSellerCard({ seller }: Props) {
  const whatsapp = seller?.mobile
    ? `https://wa.me/${seller.mobile.replace(/^0/, "98")}`
    : "#";

  const sellerSlug = seller?.companySlug ?? seller?.slug;

  return (
    <div className="rounded-2xl border bg-white p-6 shadow-sm">
      <div className="mb-6 flex items-center gap-4">
        <div className="flex h-16 w-16 items-center justify-center rounded-full bg-orange-100">
          <Building2 className="h-8 w-8 text-orange-600" />
        </div>
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-lg font-bold">{seller?.name}</h3>
            {seller?.verified && <BadgeCheck className="h-5 w-5 text-blue-600" />}
          </div>
          <p className="text-sm text-gray-500">{seller?.company}</p>
        </div>
      </div>

      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <MapPin className="h-4 w-4 text-gray-500" />
          <span>{seller?.city}</span>
        </div>
        <div className="flex items-center gap-2">
          <Phone className="h-4 w-4 text-gray-500" />
          <span>{seller?.mobile}</span>
        </div>
      </div>

      <div className="mt-6 grid grid-cols-2 gap-3">
        <a
          href={`tel:${seller?.mobile}`}
          className="rounded-xl bg-orange-500 px-4 py-3 text-center text-white transition hover:bg-orange-600"
        >
          تماس
        </a>
        <a
          href={whatsapp}
          target="_blank"
          rel="noopener noreferrer"
          className="rounded-xl border px-4 py-3 text-center transition hover:bg-green-50"
        >
          واتساپ
        </a>
        <Link
          href={`/chat/${seller?.id}`}
          className="rounded-xl border px-4 py-3 text-center transition hover:bg-gray-50"
        >
          <MessageCircle className="mx-auto mb-1 h-5 w-5" />
          چت
        </Link>
        {/* ✅ لینک صحیح به پروفایل فروشنده با slug */}
        <Link
          href={sellerSlug ? `/sellers/${sellerSlug}` : `/sellers`}
          className="rounded-xl border px-4 py-3 text-center transition hover:bg-gray-50"
        >
          همه آگهی‌ها
        </Link>
      </div>
    </div>
  );
}