"use client";

import { Calendar, Clock3, Fuel, Cog, MapPin, Factory } from "lucide-react";

interface Props {
  machine: any;
}

export default function MachineInformation({
  machine,
}: Props) {

    const items = [

{
label:"برند",
value:machine.brand?.nameFa,
icon:Factory,
},

{
label:"مدل",
value:machine.model,
icon:Cog,
},

{
label:"سال ساخت",
value:machine.year,
icon:Calendar,
},

{
label:"کارکرد",
value:machine.workingHours,
icon:Clock3,
},

{
label:"سوخت",
value:machine.fuelType,
icon:Fuel,
},

{
label:"کشور سازنده",
value:machine.country,
icon:MapPin,
},

{
label:"وضعیت",
value:machine.condition,
icon:Cog,
},

];

return(

<div className="rounded-2xl border bg-white p-6 shadow-sm">

<h2 className="mb-6 text-2xl font-bold">

مشخصات دستگاه

</h2>

<div className="grid grid-cols-1 gap-4 md:grid-cols-2">

{

items.map((item)=>(

<div

key={item.label}

className="flex items-start gap-3 rounded-xl border p-4"

>

    <item.icon

className="mt-1 h-5 w-5 text-orange-500"

/>

<div>

<p className="text-sm text-gray-500">

{item.label}

</p>

<p className="font-semibold">

{item.value || "-"}

</p>

</div>

</div>

))

}

</div>

<div className="mt-8 rounded-xl bg-gray-50 p-5">

<h3 className="mb-3 font-bold">

توضیحات

</h3>

<p className="whitespace-pre-line text-gray-700">

{machine.description || "توضیحی ثبت نشده است."}

</p>

</div>

</div>

);

}