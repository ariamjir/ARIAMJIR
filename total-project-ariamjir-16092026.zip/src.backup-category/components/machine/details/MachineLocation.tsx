"use client";

import Link from "next/link";
import { MapPin, Navigation } from "lucide-react";

interface Props {
  machine: any;
}

export default function MachineLocation({
  machine,
}: Props) {

    const latitude = machine.latitude;

const longitude = machine.longitude;

const hasLocation =
  latitude &&
  longitude;

const mapUrl = hasLocation
  ? `https://www.google.com/maps?q=${latitude},${longitude}`
  : "#";

  return (

<div className="rounded-2xl border bg-white p-6 shadow-sm">

<h2 className="mb-6 text-2xl font-bold">

موقعیت دستگاه

</h2>

<div className="space-y-4">

<div className="flex items-center gap-3">

<MapPin className="h-5 w-5 text-orange-500"/>

<span>

{machine.country}

{" / "}

{machine.province}

{" / "}

{machine.city}

</span>

</div>

<div className="rounded-xl bg-gray-50 p-4">

<p className="font-medium">

آدرس

</p>

<p className="mt-2 text-gray-600">

{machine.address || "ثبت نشده"}

</p>

</div>

<div className="aspect-[16/8] overflow-hidden rounded-2xl border bg-gray-100">

{

hasLocation

?

<div className="flex h-full items-center justify-center">

<p className="text-gray-500">

در این قسمت نقشه Leaflet نمایش داده خواهد شد.

</p>

</div>

:

<div className="flex h-full items-center justify-center">

<p className="text-gray-400">

مختصات جغرافیایی ثبت نشده است.

</p>

</div>

}

</div>

<div className="mt-6 flex gap-3">

<Link

href={mapUrl}

target="_blank"

className="inline-flex items-center gap-2 rounded-xl bg-orange-500 px-5 py-3 text-white transition hover:bg-orange-600"

>

<Navigation className="h-5 w-5"/>

مسیریابی با Google Maps

</Link>

</div>

</div>

</div>

);

}