"use client";

import MachineCard from "../card/MachineCard";
import EmptyState from "../shared/EmptyState";
import Pagination from "../shared/Pagination";

interface Props {
  machines: any[];

  pagination: {
    page: number;
    totalPages: number;
    total: number;
  };
}

export default function MachineList({
  machines,
  pagination,
}: Props) {
  if (machines.length === 0) {
    return (
      <EmptyState
        title="هیچ ماشینی پیدا نشد."
        description="فیلترها را تغییر دهید یا دوباره جستجو کنید."
      />
    );
  }

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 gap-6 md:grid-cols-2 xl:grid-cols-3">
        {machines.map((machine) => (
          <MachineCard
            key={machine.id}
            machine={machine}
          />
        ))}
      </div>

      <Pagination
        page={pagination.page}
        totalPages={pagination.totalPages}
        total={pagination.total}
      />
    </div>
  );
}