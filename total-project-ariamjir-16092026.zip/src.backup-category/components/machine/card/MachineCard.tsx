"use client";

import Image from "next/image";
import Link from "next/link";

import { Heart, GitCompare, MapPin, Calendar, Check } from "lucide-react";

import useCompare from "@/modules/compare/hooks/useCompare";

/* ============================================================
   کارت ماشین — با دکمهٔ فعال مقایسه
   ✅ اتصال به compareStore (حداکثر ۴ دستگاه)
   ✅ حالت فعال سبزرنگ روی دکمه
   ✅ تصویر پیش‌فرض اصلاح‌شده
============================================================ */

interface Props {
  machine: any;
}

export default function MachineCard({ machine }: Props) {
  const { add, remove, exists } = useCompare();

  const image =
    machine.media?.find((item: any) => item.featured)?.url ||
    machine.media?.[0]?.url ||
    "/images/machines/default.svg";

  const inCompare = exists(machine.id);

  const toggleCompare = () => {
    if (inCompare) {
      remove(machine.id);
      return;
    }

    add({
      id: machine.id,
      slug: machine.slug,
      title: machine.title,
      image,
      brand: machine.brand?.nameFa ?? machine.brand?.name ?? "",
      model: machine.model ?? machine.specification?.model ?? "",
      category: machine.category?.nameFa ?? machine.category?.name ?? "",
      year: machine.year,
      condition: machine.condition,
    });
  };

  return (
    <div className="group overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-sm transition hover:-translate-y-1 hover:shadow-xl">
      <div className="relative aspect-[4/3] overflow-hidden">
        <Image
          src={image}
          alt={machine.title}
          fill
          unoptimized
          className="object-cover transition duration-500 group-hover:scale-105"
        />

        <div className="absolute right-3 top-3 flex gap-2">
          <button
            type="button"
            className="rounded-full bg-white/90 p-2 shadow transition hover:text-red-500"
            title="علاقه‌مندی‌ها"
          >
            <Heart className="h-5 w-5" />
          </button>

          {/* ✅ دکمهٔ فعال مقایسه */}
          <button
            type="button"
            onClick={toggleCompare}
            className={`rounded-full p-2 shadow transition ${
              inCompare
                ? "bg-green-600 text-white"
                : "bg-white/90 hover:text-orange-600"
            }`}
            title={inCompare ? "حذف از مقایسه" : "افزودن به مقایسه"}
          >
            {inCompare ? <Check className="h-5 w-5" /> : <GitCompare className="h-5 w-5" />}
          </button>
        </div>
      </div>

      <div className="space-y-3 p-5">
        <h3 className="line-clamp-2 text-lg font-bold">{machine.title}</h3>

        <p className="text-sm text-gray-500">{machine.brand?.nameFa}</p>

        <div className="flex items-center justify-between text-sm text-gray-500">
          <div className="flex items-center gap-1">
            <Calendar className="h-4 w-4" />
            {machine.year}
          </div>
          <div className="flex items-center gap-1">
            <MapPin className="h-4 w-4" />
            {machine.city}
          </div>
        </div>

        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs text-gray-400">قیمت</p>
            <p className="text-xl font-bold text-orange-600">{machine.priceLabel}</p>
          </div>
          <Link
            href={`/machines/${machine.slug}`}
            className="rounded-xl bg-orange-500 px-5 py-2 text-white transition hover:bg-orange-600"
          >
            مشاهده
          </Link>
        </div>
      </div>
    </div>
  );
}