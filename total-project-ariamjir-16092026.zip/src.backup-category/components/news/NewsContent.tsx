/* رندر محتوای خبر — پشتیبانی از ## تیتر و ![تصویر](آدرس) */
export default function NewsContent({ content }: { content: string }) {
  return (
    <div>
      {content.split(/\n/).map((line, i) => {
        const t = line.trim();
        if (!t) return null;

        if (t.startsWith("## ") || t.startsWith("# ")) {
          return (
            <h2 key={i} className="mt-8 mb-3 text-xl font-black text-white">
              {t.replace(/^#+\s/, "")}
            </h2>
          );
        }

        const m = t.match(/^!\[[^\]]*\]\((.+)\)$/);
        if (m) {
          return (
            /* eslint-disable-next-line @next/next/no-img-element */
            <img key={i} src={m[1]} alt="" className="my-6 w-full rounded-2xl border border-white/10" />
          );
        }

        return (
          <p key={i} className="mt-4 text-sm leading-8 text-white/70">
            {t}
          </p>
        );
      })}
    </div>
  );
}