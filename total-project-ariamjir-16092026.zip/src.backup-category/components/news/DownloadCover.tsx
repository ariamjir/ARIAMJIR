"use client";

import { useState } from "react";

import { Download, Loader2 } from "lucide-react";

/* ============================================================
   دکمهٔ دانلود تصویر شاخص — با واترمارک ARIA MJ + دامنه
============================================================ */

export default function DownloadCover({ url, title }: { url: string; title: string }) {
  const [busy, setBusy] = useState(false);

  const handle = async () => {
    setBusy(true);
    try {
      const res = await fetch(`/api/download/image?url=${encodeURIComponent(url)}`);
      if (!res.ok) throw new Error("download failed");
      const blob = await res.blob();
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = `ariamj-${title.replace(/\s+/g, "-").slice(0, 40)}.jpg`;
      document.body.appendChild(a);
      a.click();
      a.remove();
    } finally {
      setBusy(false);
    }
  };

  return (
    <button
      onClick={handle}
      disabled={busy}
      className="
        inline-flex
        items-center
        gap-2
        rounded-xl
        border
        border-white/10
        bg-white/[0.05]
        px-5
        py-2.5
        text-xs
        font-bold
        text-white
        transition
        hover:border-[#F58220]/40
        hover:bg-[#F58220]/10
        hover:text-[#F58220]
        disabled:opacity-60
      "
    >
      {busy ? (
        <Loader2 className="h-4 w-4 animate-spin" />
      ) : (
        <Download className="h-4 w-4" />
      )}
      دانلود تصویر با واترمارک
    </button>
  );
}