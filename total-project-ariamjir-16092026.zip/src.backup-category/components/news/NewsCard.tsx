import Link from "next/link";

import { Eye, Clock3 } from "lucide-react";

import { faDate } from "@/lib/news";

/* ============================================================
   کارت خبر — big (ویترین بزرگ) / row (ردیفی فشرده) / grid
============================================================ */

export default function NewsCard({
  post,
  variant = "grid",
}: {
  post: any;
  variant?: "grid" | "big" | "row";
}) {
  /* ---------- ردیفی ---------- */
  if (variant === "row") {
    return (
      <Link
        href={`/news/${post.slug}`}
        className="group flex gap-4 rounded-2xl border border-white/10 bg-[#141414] p-3 transition hover:border-[#F58220]/40"
      >
        <div className="relative h-24 w-32 shrink-0 overflow-hidden rounded-xl">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={post.coverImage ?? "/images/blog/news-1.jpg"}
            alt={post.title}
            className="h-full w-full object-cover transition duration-700 group-hover:scale-105"
          />
        </div>

        <div className="min-w-0 flex-1">
          {post.category && (
            <span
              className="rounded-full px-2 py-0.5 text-[9px] font-black text-white"
              style={{ backgroundColor: post.category.color ?? "#F58220" }}
            >
              {post.category.name}
            </span>
          )}
          <h3 className="mt-1.5 line-clamp-2 text-sm font-black leading-6 text-white transition group-hover:text-[#F58220]">
            {post.title}
          </h3>
          <div className="mt-2 flex items-center gap-3 text-[9px] text-white/40">
            <span>{faDate(post.publishedAt ?? post.createdAt)}</span>
            <span className="inline-flex items-center gap-1">
              <Clock3 className="h-3 w-3" />
              {post.readMinutes} دقیقه
            </span>
          </div>
        </div>
      </Link>
    );
  }

  /* ---------- بزرگ / شبکه ---------- */
  return (
    <Link
      href={`/news/${post.slug}`}
      className="group flex h-full flex-col overflow-hidden rounded-2xl border border-white/10 bg-[#141414] transition hover:border-[#F58220]/40"
    >
      <div className={`relative overflow-hidden ${variant === "big" ? "aspect-[16/8]" : "aspect-[16/9]"}`}>
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={post.coverImage ?? "/images/blog/news-1.jpg"}
          alt={post.title}
          className="h-full w-full object-cover transition duration-700 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent" />

        {post.category && (
          <span
            className="absolute top-4 right-4 rounded-full px-3 py-1 text-[10px] font-black text-white"
            style={{ backgroundColor: post.category.color ?? "#F58220" }}
          >
            {post.category.name}
          </span>
        )}
      </div>

      <div className="flex flex-1 flex-col p-5">
        <h3 className={`font-black text-white transition group-hover:text-[#F58220] ${variant === "big" ? "text-lg lg:text-xl" : "text-sm"}`}>
          {post.title}
        </h3>

        {post.excerpt && (
          <p className="mt-2 line-clamp-2 text-xs leading-6 text-white/50">{post.excerpt}</p>
        )}

        <div className="mt-auto flex items-center gap-4 pt-4 text-[10px] text-white/40">
          <span>{faDate(post.publishedAt ?? post.createdAt)}</span>
          <span className="inline-flex items-center gap-1">
            <Clock3 className="h-3 w-3" />
            {post.readMinutes} دقیقه
          </span>
          <span className="inline-flex items-center gap-1">
            <Eye className="h-3 w-3" />
            {post.viewCount.toLocaleString("fa-IR")}
          </span>
        </div>
      </div>
    </Link>
  );
}