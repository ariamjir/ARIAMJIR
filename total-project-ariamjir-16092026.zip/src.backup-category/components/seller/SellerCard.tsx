import Link from "next/link";

import {
  BadgeCheck,
  Building2,
  ChevronLeft,
  MapPin,
  Package,
  Star,
} from "lucide-react";

interface SellerCardProps {
  s: {
    id: string;
    name: string;
    slug: string;
    logo?: string | null;
    description?: string | null;
    verified?: boolean;
    featured?: boolean;
    branches?: Array<{
      id?: string;
      title?: string | null;
      city?: {
        name?: string | null;
      } | null;
      province?: {
        name?: string | null;
      } | null;
    }>;
    avgRating?: number | null;
    reviewCount?: number | null;
    machineCount?: number | null;
  };
}

export default function SellerCard({ s }: SellerCardProps) {
  const logo = s.logo ?? "/images/machines/default.svg";

  const branches = s.branches?.length ?? 0;

  const topCity =
    s.branches?.[0]?.city?.name ??
    s.branches?.[0]?.province?.name ??
    "";

  const rating =
    typeof s.avgRating === "number" && s.avgRating > 0
      ? Number(s.avgRating).toFixed(1)
      : null;

  const reviewCount = s.reviewCount ?? 0;

  const machineCount =
    typeof s.machineCount === "number" ? s.machineCount : null;

  return (
    <Link
      href={`/sellers/${s.slug}`}
      aria-label={`مشاهده پروفایل ${s.name}`}
      className="
        group relative flex h-full min-h-[430px] flex-col
        overflow-hidden rounded-[24px]
        border border-white/[0.08]
        bg-[#151515]
        shadow-[0_16px_50px_rgba(0,0,0,0.18)]
        transition-all duration-300
        hover:-translate-y-1
        hover:border-[#F58220]/35
        hover:shadow-[0_24px_70px_rgba(0,0,0,0.30)]
      "
    >
      {/* Top visual area */}
      <div
        className="
          relative aspect-[1.55/1]
          overflow-hidden
          border-b border-white/[0.06]
          bg-[radial-gradient(circle_at_center,rgba(245,130,32,0.08),transparent_60%)]
        "
      >
        {/* subtle decorative grid */}
        <div
          aria-hidden="true"
          className="
            pointer-events-none absolute inset-0 opacity-[0.035]
            [background-image:linear-gradient(rgba(255,255,255,1)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,1)_1px,transparent_1px)]
            [background-size:32px_32px]
          "
        />

        {/* logo container */}
        <div
          className="
            absolute inset-5 flex items-center justify-center
            overflow-hidden rounded-[20px]
            border border-white/[0.07]
            bg-white/[0.025]
            backdrop-blur-sm
          "
        >
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={logo}
            alt={s.name}
            loading="lazy"
            className="
              h-full w-full object-contain p-8
              transition-transform duration-500
              group-hover:scale-[1.06]
            "
          />
        </div>

        {/* verification */}
        {s.verified && (
          <span
            className="
              absolute right-8 top-8
              inline-flex items-center gap-1.5
              rounded-full
              border border-blue-400/20
              bg-[#0b1724]/90
              px-3 py-1.5
              text-[9px] font-black text-blue-300
              shadow-lg backdrop-blur-md
            "
          >
            <BadgeCheck className="h-3.5 w-3.5" />
            تأییدشده
          </span>
        )}

        {/* featured */}
        {s.featured && (
          <span
            className="
              absolute left-8 top-8
              inline-flex items-center
              rounded-full
              bg-[#F58220]
              px-3 py-1.5
              text-[9px] font-black text-white
              shadow-[0_6px_20px_rgba(245,130,32,0.28)]
            "
          >
            فروشنده برتر
          </span>
        )}
      </div>

      {/* Content */}
      <div className="flex flex-1 flex-col p-5">
        {/* Company title */}
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <h3
              className="
                truncate text-[17px] font-black leading-7
                text-white
                transition-colors duration-200
                group-hover:text-[#F58220]
              "
            >
              {s.name}
            </h3>

            {topCity && (
              <div className="mt-1.5 flex items-center gap-1.5 text-[10px] text-white/40">
                <MapPin className="h-3 w-3 shrink-0" />
                <span className="truncate">{topCity}</span>
              </div>
            )}
          </div>

          {s.verified && (
            <BadgeCheck
              aria-label="فروشنده تأییدشده"
              className="mt-1 h-5 w-5 shrink-0 text-blue-400"
            />
          )}
        </div>

        {/* Description */}
        {s.description ? (
          <p className="mt-4 line-clamp-2 min-h-[42px] text-[11px] leading-6 text-white/45">
            {s.description}
          </p>
        ) : (
          <div className="min-h-[42px]" />
        )}

        {/* Statistics */}
        <div
          className="
            mt-auto grid grid-cols-3 gap-2
            border-t border-white/[0.06]
            pt-4
          "
        >
          <Stat
            icon={<Building2 className="h-3.5 w-3.5" />}
            value={branches.toLocaleString("fa-IR")}
            label="شعبه"
          />

          <Stat
            icon={
              <Star
                className={`h-3.5 w-3.5 ${
                  rating ? "fill-current text-amber-400" : "text-white/20"
                }`}
              />
            }
            value={rating ?? "—"}
            label="امتیاز"
          />

          <Stat
            icon={<Package className="h-3.5 w-3.5" />}
            value={
              machineCount !== null
                ? machineCount.toLocaleString("fa-IR")
                : reviewCount.toLocaleString("fa-IR")
            }
            label={machineCount !== null ? "دستگاه" : "نظر"}
          />
        </div>

        {/* Footer */}
        <div
          className="
            mt-4 flex items-center justify-between
            border-t border-white/[0.06]
            pt-4
          "
        >
          <span className="text-[10px] text-white/35">
            {reviewCount > 0
              ? `${reviewCount.toLocaleString("fa-IR")} نظر مشتری`
              : "فروشنده آریا ماشین جم"}
          </span>

          <span
            className="
              inline-flex items-center gap-1
              text-[10px] font-black text-[#F58220]
              transition-transform duration-300
              group-hover:-translate-x-1
            "
          >
            مشاهده پروفایل
            <ChevronLeft className="h-3.5 w-3.5" />
          </span>
        </div>
      </div>
    </Link>
  );
}

function Stat({
  icon,
  value,
  label,
}: {
  icon: React.ReactNode;
  value: string;
  label: string;
}) {
  return (
    <div className="rounded-xl bg-white/[0.025] px-2 py-2.5 text-center">
      <div className="flex items-center justify-center gap-1.5 text-sm font-black text-white">
        {icon}
        <span>{value}</span>
      </div>

      <div className="mt-0.5 text-[9px] text-white/35">
        {label}
      </div>
    </div>
  );
}