"use client";

import {
  Building2,
  ChevronLeft,
  ChevronRight,
  Loader2,
  Search,
  SlidersHorizontal,
  Sparkles,
  X,
} from "lucide-react";

import { useCallback, useEffect, useRef, useState } from "react";

import SellerCard from "@/components/seller/SellerCard";

interface SellerListData {
  items: Array<{
    id: string;
    name: string;
    slug: string;
    logo?: string | null;
    description?: string | null;
    verified?: boolean;
    featured?: boolean;
    branches?: Array<{
      id?: string;
      title?: string | null;
      city?: {
        name?: string | null;
      } | null;
      province?: {
        name?: string | null;
      } | null;
    }>;
    avgRating?: number | null;
    reviewCount?: number | null;
    machineCount?: number | null;
  }>;
  page: number;
  pages: number;
  total?: number;
}

interface SellersResponse {
  success: boolean;
  data?: SellerListData;
  message?: string;
}

export default function SellerListClient() {
  const [data, setData] = useState<SellerListData | null>(null);

  const [page, setPage] = useState(1);

  const [q, setQ] = useState("");
  const [searchInput, setSearchInput] = useState("");

  const [featuredOnly, setFeaturedOnly] = useState(false);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const requestId = useRef(0);

  /*
   * ------------------------------------------------------------
   * Search debounce
   * ------------------------------------------------------------
   */
  useEffect(() => {
    const timer = window.setTimeout(() => {
      setQ(searchInput.trim());
      setPage(1);
    }, 400);

    return () => window.clearTimeout(timer);
  }, [searchInput]);

  /*
   * ------------------------------------------------------------
   * Fetch sellers
   * ------------------------------------------------------------
   */
  const loadSellers = useCallback(async () => {
    const currentRequest = ++requestId.current;

    setLoading(true);
    setError("");

    const params = new URLSearchParams({
      page: String(page),
    });

    if (q) {
      params.set("q", q);
    }

    if (featuredOnly) {
      params.set("featured", "1");
    }

    try {
      const response = await fetch(`/api/sellers?${params.toString()}`, {
        method: "GET",
        headers: {
          Accept: "application/json",
        },
        cache: "no-store",
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }

      const result = (await response.json()) as SellersResponse;

      if (currentRequest !== requestId.current) {
        return;
      }

      if (!result.success || !result.data) {
        throw new Error(result.message || "خطا در دریافت فروشندگان");
      }

      setData(result.data);
    } catch (err) {
      if (currentRequest !== requestId.current) {
        return;
      }

      console.error("Seller list error:", err);

      setError(
        "در دریافت فهرست فروشندگان مشکلی پیش آمد. لطفاً دوباره تلاش کنید.",
      );
    } finally {
      if (currentRequest === requestId.current) {
        setLoading(false);
      }
    }
  }, [page, q, featuredOnly]);

  useEffect(() => {
    void loadSellers();
  }, [loadSellers]);

  /*
   * ------------------------------------------------------------
   * Reset filters
   * ------------------------------------------------------------
   */
  const resetFilters = () => {
    setSearchInput("");
    setQ("");
    setFeaturedOnly(false);
    setPage(1);
  };

  const hasFilters = Boolean(searchInput || featuredOnly);

  return (
    <main className="mx-auto max-w-[1440px] px-5 pb-20 pt-32 lg:px-10">
      {/* ========================================================
          HEADER
      ======================================================== */}
      <header className="mx-auto mb-10 max-w-3xl text-center">
        <div className="inline-flex items-center gap-2 rounded-full border border-[#F58220]/20 bg-[#F58220]/[0.07] px-4 py-2">
          <Sparkles className="h-3.5 w-3.5 text-[#F58220]" />

          <span className="text-[10px] font-black tracking-[0.18em] text-[#F58220]">
            VERIFIED SELLERS
          </span>
        </div>

        <h1 className="mt-5 text-3xl font-black tracking-tight text-white md:text-4xl lg:text-[42px]">
          فروشندگان ماشین‌آلات سنگین
        </h1>

        <p className="mx-auto mt-4 max-w-2xl text-sm leading-7 text-white/45 md:text-[15px]">
          شبکه‌ای از فروشندگان حرفه‌ای ماشین‌آلات راه‌سازی، معدنی، عمرانی و
          صنعتی در سراسر ایران
        </p>
      </header>

      {/* ========================================================
          SEARCH / FILTER BAR
      ======================================================== */}
      <section
        aria-label="جستجو و فیلتر فروشندگان"
        className="
          mb-10 rounded-[24px]
          border border-white/[0.07]
          bg-[#141414]/90
          p-3
          shadow-[0_20px_60px_rgba(0,0,0,0.18)]
          backdrop-blur-xl
          md:p-4
        "
      >
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center">
          {/* Search */}
          <div className="relative min-w-0 flex-1">
            <Search
              aria-hidden="true"
              className="
                pointer-events-none absolute right-4 top-1/2
                h-4 w-4 -translate-y-1/2
                text-white/30
              "
            />

            <input
              type="search"
              value={searchInput}
              onChange={(event) => setSearchInput(event.target.value)}
              onKeyDown={(event) => {
                if (event.key === "Escape") {
                  setSearchInput("");
                  setQ("");
                  setPage(1);
                }
              }}
              placeholder="جستجوی نام شرکت یا فروشنده..."
              aria-label="جستجوی نام شرکت یا فروشنده"
              dir="rtl"
              className="
                h-12 w-full rounded-xl
                border border-white/[0.08]
                bg-white/[0.035]
                pr-11 pl-11
                text-xs text-white
                outline-none
                placeholder:text-white/25
                transition
                focus:border-[#F58220]/50
                focus:bg-white/[0.05]
                focus:ring-2
                focus:ring-[#F58220]/10
              "
            />

            {searchInput && (
              <button
                type="button"
                aria-label="پاک کردن جستجو"
                onClick={() => {
                  setSearchInput("");
                  setQ("");
                  setPage(1);
                }}
                className="
                  absolute left-3 top-1/2
                  flex h-7 w-7 -translate-y-1/2
                  items-center justify-center
                  rounded-lg
                  text-white/30
                  transition
                  hover:bg-white/10
                  hover:text-white
                "
              >
                <X className="h-3.5 w-3.5" />
              </button>
            )}
          </div>

          {/* Featured filter */}
          <label
            className="
              flex h-12 shrink-0 cursor-pointer
              items-center justify-center gap-3
              rounded-xl
              border border-white/[0.08]
              bg-white/[0.025]
              px-5
              text-xs font-bold text-white/65
              transition
              hover:border-[#F58220]/30
              hover:bg-white/[0.04]
            "
          >
            <input
              type="checkbox"
              checked={featuredOnly}
              onChange={(event) => {
                setFeaturedOnly(event.target.checked);
                setPage(1);
              }}
              className="h-4 w-4 accent-[#F58220]"
            />

            <SlidersHorizontal className="h-3.5 w-3.5 text-[#F58220]" />

            فقط فروشندگان برتر
          </label>

          {/* Reset */}
          {hasFilters && (
            <button
              type="button"
              onClick={resetFilters}
              className="
                h-12 shrink-0 rounded-xl
                border border-white/[0.08]
                px-5
                text-xs font-bold text-white/50
                transition
                hover:border-white/15
                hover:bg-white/[0.04]
                hover:text-white
              "
            >
              حذف فیلترها
            </button>
          )}
        </div>
      </section>

      {/* ========================================================
          RESULT META
      ======================================================== */}
      {data && !loading && (
        <div className="mb-5 flex items-center justify-between gap-4">
          <div className="text-[11px] text-white/35">
            {data.total !== undefined ? (
              <>
                <span className="font-black text-white/65">
                  {data.total.toLocaleString("fa-IR")}
                </span>{" "}
                فروشنده
              </>
            ) : (
              <>
                <span className="font-black text-white/65">
                  {data.items.length.toLocaleString("fa-IR")}
                </span>{" "}
                فروشنده
              </>
            )}
          </div>

          {q && (
            <div className="text-[10px] text-white/30">
              نتیجه جستجو برای «{q}»
            </div>
          )}
        </div>
      )}

      {/* ========================================================
          ERROR
      ======================================================== */}
      {error && (
        <div className="mb-8 rounded-2xl border border-red-400/15 bg-red-400/[0.05] p-6 text-center">
          <p className="text-xs font-bold text-red-300">{error}</p>

          <button
            type="button"
            onClick={() => void loadSellers()}
            className="
              mt-4 rounded-lg
              border border-red-400/20
              px-4 py-2
              text-[10px] font-bold text-red-300
              transition
              hover:bg-red-400/10
            "
          >
            تلاش دوباره
          </button>
        </div>
      )}

      {/* ========================================================
          CONTENT
      ======================================================== */}
      {!data && loading ? (
        <SellerListSkeleton />
      ) : !error && data?.items.length === 0 ? (
        <EmptyState hasFilters={hasFilters} onReset={resetFilters} />
      ) : (
        <>
          {/* Loading overlay when changing page/filter */}
          <div className="relative">
            {loading && data && (
              <div
                className="
                  absolute inset-0 z-10
                  flex items-start justify-center
                  rounded-3xl
                  bg-[#0B0B0B]/45
                  pt-12
                  backdrop-blur-[2px]
                "
              >
                <div className="flex items-center gap-2 rounded-full border border-white/10 bg-[#151515] px-4 py-2.5 shadow-xl">
                  <Loader2 className="h-4 w-4 animate-spin text-[#F58220]" />

                  <span className="text-[10px] font-bold text-white/60">
                    در حال بارگذاری...
                  </span>
                </div>
              </div>
            )}

            <div
              className="
                grid gap-5
                sm:grid-cols-2
                lg:grid-cols-3
                xl:grid-cols-4
              "
            >
              {data?.items.map((seller) => (
                <SellerCard key={seller.id} s={seller} />
              ))}
            </div>
          </div>

          {/* ====================================================
              PAGINATION
          ==================================================== */}
          {data && data.pages > 1 && (
            <nav
              aria-label="صفحه‌بندی فروشندگان"
              className="mt-12 flex items-center justify-center gap-2"
            >
              <button
                type="button"
                disabled={page <= 1 || loading}
                onClick={() => setPage((current) => current - 1)}
                aria-label="صفحه قبل"
                className="
                  flex h-10 w-10 items-center justify-center
                  rounded-xl
                  border border-white/[0.08]
                  bg-white/[0.025]
                  text-white/60
                  transition
                  hover:border-[#F58220]/30
                  hover:bg-[#F58220]/[0.06]
                  hover:text-white
                  disabled:cursor-not-allowed
                  disabled:opacity-30
                "
              >
                <ChevronRight className="h-4 w-4" />
              </button>

              <div
                className="
                  flex h-10 min-w-[100px]
                  items-center justify-center
                  rounded-xl
                  border border-white/[0.08]
                  bg-white/[0.025]
                  px-4
                  text-[11px] font-black text-white/70
                "
              >
                صفحه {page.toLocaleString("fa-IR")} از{" "}
                {data.pages.toLocaleString("fa-IR")}
              </div>

              <button
                type="button"
                disabled={page >= data.pages || loading}
                onClick={() => setPage((current) => current + 1)}
                aria-label="صفحه بعد"
                className="
                  flex h-10 w-10 items-center justify-center
                  rounded-xl
                  border border-white/[0.08]
                  bg-white/[0.025]
                  text-white/60
                  transition
                  hover:border-[#F58220]/30
                  hover:bg-[#F58220]/[0.06]
                  hover:text-white
                  disabled:cursor-not-allowed
                  disabled:opacity-30
                "
              >
                <ChevronLeft className="h-4 w-4" />
              </button>
            </nav>
          )}
        </>
      )}
    </main>
  );
}

/* ==============================================================
   Skeleton
============================================================== */

function SellerListSkeleton() {
  return (
    <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
      {Array.from({ length: 8 }).map((_, index) => (
        <div
          key={index}
          className="
            min-h-[430px]
            animate-pulse
            overflow-hidden
            rounded-[24px]
            border border-white/[0.06]
            bg-[#141414]
          "
        >
          <div className="aspect-[1.55/1] bg-white/[0.04]" />

          <div className="space-y-4 p-5">
            <div className="h-5 w-2/3 rounded-lg bg-white/[0.05]" />
            <div className="h-3 w-1/3 rounded bg-white/[0.04]" />
            <div className="h-10 rounded-lg bg-white/[0.035]" />

            <div className="grid grid-cols-3 gap-2 pt-4">
              <div className="h-14 rounded-xl bg-white/[0.035]" />
              <div className="h-14 rounded-xl bg-white/[0.035]" />
              <div className="h-14 rounded-xl bg-white/[0.035]" />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

/* ==============================================================
   Empty state
============================================================== */

function EmptyState({
  hasFilters,
  onReset,
}: {
  hasFilters: boolean;
  onReset: () => void;
}) {
  return (
    <div
      className="
        rounded-[28px]
        border border-dashed border-white/[0.1]
        bg-white/[0.02]
        px-6 py-20
        text-center
      "
    >
      <div
        className="
          mx-auto flex h-16 w-16
          items-center justify-center
          rounded-2xl
          bg-white/[0.04]
        "
      >
        {hasFilters ? (
          <Search className="h-7 w-7 text-white/20" />
        ) : (
          <Building2 className="h-7 w-7 text-white/20" />
        )}
      </div>

      <h2 className="mt-5 text-lg font-black text-white/70">
        {hasFilters
          ? "فروشنده‌ای با این مشخصات پیدا نشد"
          : "هنوز فروشنده‌ای ثبت نشده است"}
      </h2>

      <p className="mx-auto mt-2 max-w-md text-xs leading-6 text-white/35">
        {hasFilters
          ? "عبارت جستجو یا فیلترهای انتخاب‌شده را تغییر دهید و دوباره امتحان کنید."
          : "به‌زودی فروشندگان حرفه‌ای آریا ماشین جم در این بخش نمایش داده خواهند شد."}
      </p>

      {hasFilters && (
        <button
          type="button"
          onClick={onReset}
          className="
            mt-6 rounded-xl
            bg-[#F58220]
            px-6 py-3
            text-xs font-black text-white
            transition
            hover:bg-[#df7017]
          "
        >
          حذف فیلترها
        </button>
      )}
    </div>
  );
}