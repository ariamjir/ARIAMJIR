/* اسپارک‌لاین کوچک برای پنل‌های آماری */
const PATHS = [
  "M2 16 L12 12 L22 14 L32 8 L42 10 L52 5 L62 7",
  "M2 14 L12 15 L22 10 L32 12 L42 7 L52 9 L62 4",
  "M2 17 L12 13 L22 15 L32 9 L42 11 L52 6 L62 8",
  "M2 15 L12 11 L22 13 L32 10 L42 6 L52 8 L62 5",
];

export default function Sparkline({
  variant = 0,
  className = "h-4 w-full",
}: {
  variant?: number;
  className?: string;
}) {
  return (
    <svg
      viewBox="0 0 64 20"
      preserveAspectRatio="none"
      className={className}
      fill="none"
      aria-hidden="true"
    >
      <path
        d={PATHS[variant % PATHS.length]}
        stroke="#F58220"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}