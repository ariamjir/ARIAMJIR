"use client";

import Image from "next/image";

import {
  Pencil,
  Trash2,
  Star,
  FolderTree,
} from "lucide-react";

type Category = {
  id: string;
  parentId: string | null;
  name: string;
  slug: string;
  icon: string | null;
  image: string | null;
  description: string | null;
  sortOrder: number;
  active: boolean;
  createdAt?: string;
  updatedAt?: string;

  /* ✅ فیلدهای اختیاری جدید — از API ادمین می‌آیند.
     اختیاری‌اند تا با typeهای قدیمی‌تر هم سازگار بمانند. */
  featured?: boolean;
  showInMenu?: boolean;
  showOnHomepage?: boolean;
  machinesCount?: number;
  childrenCount?: number;
};

interface CategoryTableProps {
  categories: Category[];
  onDelete: (id: string) => Promise<void>;
  /* ✅ جدید — اختیاری، تا اگر جایی پاس داده نشد خطا ندهد */
  onEdit?: (id: string) => void;
}

/* ============================================================
   فرمت تاریخ به فارسی (امن در برابر مقدار نامعتبر)
============================================================ */

function formatDate(dateString?: string): string {
  if (!dateString) return "-";

  try {
    return new Date(dateString).toLocaleDateString(
      "fa-IR",
      {
        year: "numeric",
        month: "long",
        day: "numeric",
      }
    );
  } catch {
    return dateString;
  }
}

export default function CategoryTable({
  categories,
  onDelete,
  onEdit,
}: CategoryTableProps) {
  /* ------------------- Empty ------------------- */
  if (categories.length === 0) {
    return (
      <div className="rounded-lg border p-6 text-center text-gray-500">
        دسته‌بندی‌ای یافت نشد.
      </div>
    );
  }

  /* ------------------- Table ------------------- */
  return (
    <div className="overflow-x-auto rounded-lg border">
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-100">
          <tr>
            <th className="px-4 py-3 text-right text-sm font-semibold text-gray-600">
              نام
            </th>
            <th className="px-4 py-3 text-right text-sm font-semibold text-gray-600">
              اسلاگ
            </th>
            <th className="px-4 py-3 text-center text-sm font-semibold text-gray-600">
              ماشین‌آلات
            </th>
            <th className="px-4 py-3 text-right text-sm font-semibold text-gray-600">
              تاریخ ایجاد
            </th>
            <th className="px-4 py-3 text-center text-sm font-semibold text-gray-600">
              عملیات
            </th>
          </tr>
        </thead>

        <tbody className="divide-y divide-gray-100">
          {categories.map((category) => (
            <tr
              key={category.id}
              className="transition-colors hover:bg-orange-50/40"
            >
              {/* ------------------- نام + آیکون + وضعیت ------------------- */}
              <td className="px-4 py-3">
                <div className="flex items-center gap-3">
                  {/* تصویر / آیکون / placeholder */}
                  <div
                    className="
                      flex
                      h-10
                      w-10

                      shrink-0

                      items-center
                      justify-center

                      overflow-hidden

                      rounded-lg

                      bg-orange-50

                      ring-1
                      ring-orange-100
                    "
                  >
                    {category.image ? (
                      <Image
                        src={category.image}
                        alt={category.name}
                        width={40}
                        height={40}
                        className="h-full w-full object-cover"
                      />
                    ) : category.icon ? (
                      <Image
                        src={category.icon}
                        alt={category.name}
                        width={24}
                        height={24}
                        className="h-6 w-6 object-contain"
                      />
                    ) : (
                      <FolderTree className="h-5 w-5 text-[#F58220]" />
                    )}
                  </div>

                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="truncate font-medium text-gray-900">
                        {category.name}
                      </span>

                      {/* نشان ویژه */}
                      {category.featured && (
                        <Star
                          className="h-3.5 w-3.5 shrink-0 fill-[#F58220] text-[#F58220]"
                          aria-label="ویژه"
                        />
                      )}
                    </div>

                    {/* badge وضعیت */}
                    <span
                      className={
                        category.active
                          ? "mt-1 inline-flex items-center rounded-full bg-green-100 px-2 py-0.5 text-xs font-medium text-green-700"
                          : "mt-1 inline-flex items-center rounded-full bg-gray-100 px-2 py-0.5 text-xs font-medium text-gray-500"
                      }
                    >
                      {category.active
                        ? "فعال"
                        : "غیرفعال"}
                    </span>
                  </div>
                </div>
              </td>

              {/* ------------------- اسلاگ ------------------- */}
              <td className="px-4 py-3">
                <span className="font-mono text-sm text-gray-500">
                  {category.slug ?? "-"}
                </span>
              </td>

              {/* ------------------- تعداد ماشین‌آلات ------------------- */}
              <td className="px-4 py-3 text-center">
                <span
                  className="
                    inline-flex
                    items-center

                    rounded-full

                    bg-gray-100

                    px-2.5
                    py-0.5

                    text-xs
                    font-medium
                    text-gray-700
                  "
                >
                  {(
                    category.machinesCount ?? 0
                  ).toLocaleString("fa-IR")}
                </span>
              </td>

              {/* ------------------- تاریخ ایجاد ------------------- */}
              <td className="px-4 py-3 text-sm text-gray-500">
                {formatDate(category.createdAt)}
              </td>

              {/* ------------------- عملیات ------------------- */}
              <td className="px-4 py-3">
                <div className="flex items-center justify-center gap-2">
                  {/* ✅ دکمهٔ ویرایش — فقط اگر onEdit پاس داده شده باشد */}
                  {onEdit && (
                    <button
                      type="button"
                      onClick={() =>
                        onEdit(category.id)
                      }
                      className="
                        inline-flex
                        items-center
                        gap-1

                        rounded-lg

                        border
                        border-orange-500

                        px-3
                        py-1.5

                        text-sm
                        font-medium
                        text-orange-600

                        transition

                        hover:bg-orange-50
                      "
                    >
                      <Pencil className="h-3.5 w-3.5" />
                      ویرایش
                    </button>
                  )}

                  {/* دکمهٔ حذف (بدون تغییر در عملکرد) */}
                  <button
                    type="button"
                    onClick={() =>
                      onDelete(category.id)
                    }
                    className="
                      inline-flex
                      items-center
                      gap-1

                      rounded-lg

                      border
                      border-red-500

                      px-3
                      py-1.5

                      text-sm
                      font-medium
                      text-red-600

                      transition

                      hover:bg-red-50
                    "
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                    حذف
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}