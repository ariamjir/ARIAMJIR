"use client";

import { useEffect, useMemo, useState } from "react";

import Image from "next/image";
import { useRouter } from "next/navigation";

import {
  useForm,
  Controller,
} from "react-hook-form";

import { zodResolver } from "@hookform/resolvers/zod";

import { z } from "zod";

import {
  Save,
  FolderTree,
  ImageIcon,
  FileText,
  Settings2,
  Search,
  Link2,
  BarChart3,
} from "lucide-react";

import SearchableSelect from "@/components/ui/SearchableSelect";

import {
  categoryService,
} from "@/modules/category";

import type {
  Category,
  CategoryFormData,
} from "@/modules/category/types";

import {
  mediaService,
} from "@/modules/media";

import type {
  MediaFile,
} from "@/modules/media/types";

interface Props {
  categoryId?: string;
}

/* ============================================================
   Validation
============================================================ */

const categorySchema = z.object({
  parentId: z.string().nullable(),

  name: z
    .string()
    .min(2, "نام دسته‌بندی الزامی است")
    .max(150),

  slug: z
    .string()
    .min(2)
    .max(180)
    .regex(
      /^[a-z0-9-]+$/,
      "Slug فقط باید شامل حروف انگلیسی، عدد و - باشد."
    ),

  description: z
    .string()
    .max(1000)
    .optional(),

  icon: z.string().optional(),

  image: z.string().optional(),

  sortOrder: z.number(),

  active: z.boolean(),

  featured: z.boolean(),

  showOnHomepage: z.boolean(),

  showInMenu: z.boolean(),

  metaTitle: z.string().optional(),

  metaDescription: z.string().optional(),

  keywords: z.string().optional(),
});

type FormValues =
  z.infer<typeof categorySchema>;

/* ============================================================
   Keyword Normalizer
   ------------------------------------------------------------
   Prisma فیلد keywords را به صورت String? (رشته) ذخیره می‌کند.
   این helper تضمین می‌کند هم هنگام خواندن و هم هنگام ارسال،
   همیشه یک رشته‌ی معتبر داشته باشیم (نه آرایه).
============================================================ */

function keywordsToString(
  value: unknown
): string {
  if (Array.isArray(value)) {
    return value.join(", ");
  }

  if (typeof value === "string") {
    return value;
  }

  return "";
}

export default function CategoryForm({
  categoryId,
}: Props) {

  const router = useRouter();

  /* ============================================================
     States
  ============================================================ */

  const [loading, setLoading] =
    useState(false);

  const [uploading, setUploading] =
    useState(false);

  const [parents, setParents] =
    useState<Category[]>([]);

  const [machinesCount, setMachinesCount] =
  useState(0);

  const [childrenCount, setChildrenCount] =
    useState(0);

  const [createdAt, setCreatedAt] =
    useState("");

  const [updatedAt, setUpdatedAt] =
    useState("");

  const [selectedImage, setSelectedImage] =
    useState<MediaFile | null>(null);

  const [selectedIcon, setSelectedIcon] =
    useState<MediaFile | null>(null);

  /* ============================================================
     React Hook Form
  ============================================================ */

  const {

    register,

    control,

    watch,

    reset,

    setValue,

    handleSubmit,

    formState: {
      errors,
    },

  } = useForm<FormValues>({

    resolver:
      zodResolver(categorySchema),

    defaultValues: {

      parentId: null,

      name: "",

      slug: "",

      description: "",

      icon: "",

      image: "",

      sortOrder: 0,

      active: true,

      featured: false,

      showInMenu: true,

      showOnHomepage: true,

      metaTitle: "",

      metaDescription: "",

      keywords: "",

    },

  });

  /* ============================================================
     Watches
  ============================================================ */

  const watchedName =
    watch("name");

  const watchedSlug =
    watch("slug");

  const watchedImage =
    watch("image");

  const watchedIcon =
    watch("icon");

  /* ============================================================
     Auto Slug
  ============================================================ */

  useEffect(() => {

    if (
      watchedSlug.length > 0 ||
      watchedName.length === 0
    ) {
      return;
    }

    const slug =
      watchedName

        .trim()

        .toLowerCase()

        .replace(/\s+/g, "-")

        .replace(/[^a-z0-9-]/g, "");

    setValue(
      "slug",
      slug
    );

  }, [
    watchedName,
    watchedSlug,
    setValue,
  ]);

  /* ============================================================
     Initial Load
  ============================================================ */

  useEffect(() => {

    loadParents();

    if (categoryId) {

      loadCategory();

    }

  }, [
    categoryId,
  ]);

    /* ============================================================
     Load Parent Categories
  ============================================================ */

  async function loadParents() {

    try {

      const data =
        await categoryService.getRootCategories();

      setParents(data);

    } catch (error) {

      console.error(
        "Load Parents:",
        error
      );

    }

  }

  /* ============================================================
     Load Category
  ============================================================ */

  async function loadCategory() {

    if (!categoryId) return;

    try {

      setLoading(true);

      const category =
        await categoryService.getById(
          categoryId
        );

      reset({

        parentId:
          category.parentId ?? null,

        name:
          category.name,

        slug:
          category.slug,

        description:
          category.description ?? "",

        icon:
          category.icon ?? "",

        image:
          category.image ?? "",

        sortOrder:
          category.sortOrder,

        active:
          category.active,

        featured:
          category.featured ?? false,

        showInMenu:
          category.showInMenu,

        showOnHomepage:
          category.showOnHomepage,

        metaTitle:
          category.metaTitle ?? "",

        metaDescription:
          category.metaDescription ?? "",

        // ✅ هماهنگ با Prisma (String?) — همیشه رشته
        keywords:
          keywordsToString(
            category.keywords
          ),

      });

      setMachinesCount(
        category.machinesCount ?? 0
      );

      setChildrenCount(
        category.childrenCount ?? 0
      );

      setCreatedAt(
        category.createdAt ?? ""
      );

      setUpdatedAt(
        category.updatedAt ?? ""
      );

    } catch (error) {

      console.error(error);

    } finally {

      setLoading(false);

    }

  }

  /* ============================================================
     Upload Image
  ============================================================ */

  async function uploadImage(
    file: File
  ) {

    try {

      setUploading(true);

      mediaService.validateImage(file);

      const uploaded =
        await mediaService.upload(
          file,
          "categories"
        );

      setSelectedImage(uploaded);

      setValue(
        "image",
        uploaded.url
      );

    } catch (error) {

      console.error(error);

    } finally {

      setUploading(false);

    }

  }

  /* ============================================================
     Upload Icon
  ============================================================ */

  async function uploadIcon(
    file: File
  ) {

    try {

      setUploading(true);

      mediaService.validateImage(file);

      const uploaded =
        await mediaService.upload(
          file,
          "categories"
        );

      setSelectedIcon(uploaded);

      setValue(
        "icon",
        uploaded.url
      );

    } catch (error) {

      console.error(error);

    } finally {

      setUploading(false);

    }

  }

  /* ============================================================
     Parent Options
  ============================================================ */

  const parentOptions =
    useMemo(() => {

      return parents.map(
        (category) => ({

          value:
            category.id,

          label:
            category.name,

        })
      );

    }, [
      parents,
    ]);

      /* ============================================================
     Submit
  ============================================================ */

  const onSubmit = async (
    values: FormValues
  ) => {

    try {

      setLoading(true);

      const payload: CategoryFormData = {

        parentId:
          values.parentId,

        name:
          values.name.trim(),

        slug:
          values.slug.trim(),

        description:
          values.description,

        image:
          values.image,

        icon:
          values.icon,

        sortOrder:
          values.sortOrder,

        active:
          values.active,

        featured:
          values.featured,

        showInMenu:
          values.showInMenu,

        showOnHomepage:
          values.showOnHomepage,

        metaTitle:
          values.metaTitle,

        metaDescription:
          values.metaDescription,

        // ✅ هماهنگ با Prisma (String?) — رشته ارسال می‌شود، نه آرایه
        keywords:
          keywordsToString(
            values.keywords
          ) as unknown as CategoryFormData["keywords"],

      };

      if (categoryId) {

        await categoryService.update(

          categoryId,

          payload

        );

      } else {

        await categoryService.create(
          payload
        );

      }

      router.push(
        "/admin/categories"
      );

      router.refresh();

    } catch (error) {

      console.error(error);

    } finally {

      setLoading(false);

    }

  };

  /* ============================================================
     Delete
  ============================================================ */

  async function removeCategory() {

    if (!categoryId) return;

    const confirmDelete =
      confirm(
        "آیا از حذف این دسته‌بندی اطمینان دارید؟"
      );

    if (!confirmDelete) return;

    try {

      setLoading(true);

      await categoryService.remove(
        categoryId
      );

      router.push(
        "/admin/categories"
      );

      router.refresh();

    } finally {

      setLoading(false);

    }

  }

  /* ============================================================
     Render
  ============================================================ */

  return (

    <form

      onSubmit={handleSubmit(
        onSubmit
      )}

      className="space-y-8"

    >

      <div className="rounded-2xl border bg-white p-8 shadow-sm">

        <div className="mb-8 flex items-center gap-3">

          <FolderTree
            className="h-7 w-7 text-orange-500"
          />

          <div>

            <h2 className="text-2xl font-bold">

              {

                categoryId

                  ? "ویرایش دسته‌بندی"

                  : "ایجاد دسته‌بندی"

              }

            </h2>

            <p className="text-sm text-gray-500">

              مدیریت اطلاعات اصلی دسته‌بندی

            </p>

          </div>

        </div>

        <div className="grid grid-cols-12 gap-6">

          {/* Parent */}

          <div className="col-span-12 lg:col-span-6">

            <label className="mb-2 block font-medium">

              دسته والد

            </label>

            <Controller

              control={control}

              name="parentId"

              render={({ field }) => (

                <SearchableSelect

                  value={
                    field.value ?? ""
                  }

                  onChange={field.onChange}

                  options={parentOptions}

                  placeholder="بدون والد"

                />

              )}

            />

          </div>

          {/* Sort */}

          <div className="col-span-12 lg:col-span-6">

            <label className="mb-2 block font-medium">

              ترتیب نمایش

            </label>

            <input

              type="number"

              {...register(
                "sortOrder",
                {
                  valueAsNumber: true,
                }
              )}

              className="w-full rounded-lg border px-4 py-3"

            />

          </div>

          {/* Name */}

          <div className="col-span-12 lg:col-span-6">

            <label className="mb-2 block font-medium">

              نام دسته‌بندی

            </label>

            <input

              {...register("name")}

              className="w-full rounded-lg border px-4 py-3"

            />

            {errors.name && (

              <p className="mt-2 text-sm text-red-500">

                {errors.name.message}

              </p>

            )}

          </div>

          {/* Slug */}

          <div className="col-span-12 lg:col-span-6">

            <label className="mb-2 block font-medium">

              Slug

            </label>

            <input

              {...register("slug")}

              className="w-full rounded-lg border px-4 py-3"

            />

            {errors.slug && (

              <p className="mt-2 text-sm text-red-500">

                {errors.slug.message}

              </p>

            )}

          </div>

                    {/* Description */}

          <div className="col-span-12">

            <label className="mb-2 block font-medium">

              توضیحات

            </label>

            <textarea

              rows={6}

              {...register("description")}

              className="w-full rounded-lg border px-4 py-3"

            />

          </div>

          {/* Image */}

          <div className="col-span-12 lg:col-span-6">

            <label className="mb-3 block font-medium">

              تصویر دسته‌بندی

            </label>

            <input

              type="file"

              accept="image/*"

              onChange={async (e) => {

                const file =
                  e.target.files?.[0];

                if (!file) return;

                await uploadImage(file);

              }}

            />

            {watchedImage && (

              <div className="mt-4 overflow-hidden rounded-xl border">

                <Image

                  src={watchedImage}

                  alt="Category"

                  width={400}
                  height={240}

                  className="h-52 w-full object-cover"

                />

              </div>

            )}

          </div>

          {/* Icon */}

          <div className="col-span-12 lg:col-span-6">

            <label className="mb-3 block font-medium">

              آیکون

            </label>

            <input

              type="file"

              accept="image/*"

              onChange={async (e) => {

                const file =
                  e.target.files?.[0];

                if (!file) return;

                await uploadIcon(file);

              }}

            />

            {watchedIcon && (

              <div className="mt-4 flex h-32 w-32 items-center justify-center rounded-xl border">

                <Image

                  src={watchedIcon}

                  alt="Icon"

                  width={96}
                  height={96}

                />

              </div>

            )}

          </div>

        </div>

      </div>

      {/* ============================================================
          SEO
      ============================================================ */}

      <div className="rounded-2xl border bg-white p-8 shadow-sm">

        <div className="mb-6 flex items-center gap-3">

          <Search className="h-6 w-6 text-orange-500" />

          <h3 className="text-xl font-bold">

            تنظیمات SEO

          </h3>

        </div>

        <div className="space-y-5">

          <input

            {...register("metaTitle")}

            placeholder="Meta Title"

            className="w-full rounded-lg border px-4 py-3"

          />

          <textarea

            rows={4}

            {...register("metaDescription")}

            placeholder="Meta Description"

            className="w-full rounded-lg border px-4 py-3"

          />

          <input

            {...register("keywords")}

            placeholder="keyword1, keyword2"

            className="w-full rounded-lg border px-4 py-3"

          />

        </div>

      </div>

      {/* ============================================================
          Settings
      ============================================================ */}

      <div className="rounded-2xl border bg-white p-8 shadow-sm">

        <div className="mb-6 flex items-center gap-3">

          <Settings2 className="h-6 w-6 text-orange-500" />

          <h3 className="text-xl font-bold">

            تنظیمات

          </h3>

        </div>

        <div className="space-y-4">

          <label className="flex items-center gap-3">

            <input

              type="checkbox"

              {...register("active")}

            />

            فعال

          </label>

          <label className="flex items-center gap-3">

            <input

              type="checkbox"

              {...register("featured")}

            />

            ویژه (Featured)

          </label>

          <label className="flex items-center gap-3">

            <input

              type="checkbox"

              {...register("showInMenu")}

            />

            نمایش در منو

          </label>

          <label className="flex items-center gap-3">

            <input

              type="checkbox"

              {...register("showOnHomepage")}

            />

            نمایش در صفحه اصلی

          </label>

        </div>

      </div>

      {/* ============================================================
          Statistics
      ============================================================ */}

      {categoryId && (

        <div className="rounded-2xl border bg-white p-8 shadow-sm">

          <div className="mb-6 flex items-center gap-3">

            <BarChart3 className="h-6 w-6 text-orange-500" />

            <h3 className="text-xl font-bold">

              اطلاعات

            </h3>

          </div>

          <div className="grid grid-cols-2 gap-6">

            <div>

              <div className="text-sm text-gray-500">

                تعداد ماشین‌آلات

              </div>

              <div className="text-2xl font-bold">

                {machinesCount}

              </div>

            </div>

            <div>

              <div className="text-sm text-gray-500">

                تعداد زیرمجموعه

              </div>

              <div className="text-2xl font-bold">

                {childrenCount}

              </div>

            </div>

            <div>

              <div className="text-sm text-gray-500">

                تاریخ ایجاد

              </div>

              <div>

                {createdAt}

              </div>

            </div>

            <div>

              <div className="text-sm text-gray-500">

                آخرین بروزرسانی

              </div>

              <div>

                {updatedAt}

              </div>

            </div>

          </div>

        </div>

      )}

      {/* ============================================================
          Actions
      ============================================================ */}

      <div className="flex items-center justify-between">

        <div>

          {categoryId && (

            <button

              type="button"

              onClick={removeCategory}

              className="rounded-lg border border-red-500 px-6 py-3 text-red-500"

            >

              حذف دسته‌بندی

            </button>

          )}

        </div>

        <button

          type="submit"

          disabled={loading || uploading}

          className="flex items-center gap-2 rounded-xl bg-orange-500 px-8 py-3 font-semibold text-white"

        >

          <Save className="h-5 w-5" />

          {loading

            ? "در حال ذخیره..."

            : "ذخیره"}

        </button>

      </div>

    </form>

  );

}