"use client";

import { useEffect, useState } from "react";

import { Bot, Loader2, RefreshCw } from "lucide-react";

export default function AiNewsControls() {
  const [enabled, setEnabled] = useState(true);
  const [busy, setBusy] = useState<"" | "news" | "knowledge">("");

  useEffect(() => {
    fetch("/api/admin/ai-settings")
      .then((r) => r.json())
      .then((j) => {
        if (j.success) setEnabled(j.data.enabled !== false);
      });
  }, []);

  const toggle = async () => {
    const next = !enabled;
    setEnabled(next);
    await fetch("/api/admin/ai-settings", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ enabled: next }),
    });
  };

  const generate = async (kind: "news" | "knowledge") => {
    setBusy(kind);
    try {
      await fetch(`/api/cron/generate-news?force=1&kind=${kind}`, { method: "POST" });
      /* بازخوانی لیست توسط رویداد سفارشی */
      window.dispatchEvent(new CustomEvent("news:reload"));
    } finally {
      setBusy("");
    }
  };

  return (
    <div className="flex flex-wrap items-center gap-3 rounded-2xl border border-violet-200 bg-violet-50 p-3">
      <span className="inline-flex items-center gap-2 text-sm font-black text-violet-700">
        <Bot className="h-4 w-4" />
        خبرنگار هوش مصنوعی
      </span>

      <button
        onClick={() => generate("news")}
        disabled={!!busy}
        className="inline-flex items-center gap-2 rounded-lg bg-violet-600 px-4 py-2 text-xs font-bold text-white transition hover:bg-violet-700 disabled:opacity-60"
      >
        {busy === "news" ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <RefreshCw className="h-3.5 w-3.5" />}
        تولید خبر (پیش‌نویس)
      </button>

      <button
        onClick={() => generate("knowledge")}
        disabled={!!busy}
        className="inline-flex items-center gap-2 rounded-lg border border-violet-300 bg-white px-4 py-2 text-xs font-bold text-violet-700 transition hover:bg-violet-100 disabled:opacity-60"
      >
        {busy === "knowledge" ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <RefreshCw className="h-3.5 w-3.5" />}
        تولید مقالهٔ دانشنامه
      </button>

      <label className="mr-auto flex cursor-pointer items-center gap-2 text-xs font-bold text-zinc-600">
        <input
          type="checkbox"
          checked={enabled}
          onChange={toggle}
          className="h-4 w-4 accent-violet-600"
        />
        تولید خودکار روزانه (cron)
      </label>
    </div>
  );
}