"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

type Props = {
  categoryId?: string;
};

export default function CategoryForm({ categoryId }: Props) {
  const router = useRouter();

  const [loading, setLoading] = useState(false);

  const [form, setForm] = useState({
    name: "",
    slug: "",
    description: "",
    icon: "",
    sortOrder: 0,
    active: true,
  });

  useEffect(() => {
    if (!categoryId) return;

    async function loadCategory() {
      const res = await fetch(`/api/admin/categories/${categoryId}`);
      const data = await res.json();

      setForm({
        name: data.name ?? "",
        slug: data.slug ?? "",
        description: data.description ?? "",
        icon: data.icon ?? "",
        sortOrder: data.sortOrder ?? 0,
        active: data.active ?? true,
      });
    }

    loadCategory();
  }, [categoryId]);

  async function submit() {
    setLoading(true);

    const url = categoryId
      ? `/api/admin/categories/${categoryId}`
      : "/api/admin/categories";

    const method = categoryId ? "PUT" : "POST";

    await fetch(url, {
      method,
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(form),
    });

    router.push("/admin/categories");
    router.refresh();
  }

  return (
    <div className="space-y-4 rounded-xl border bg-white p-6">
      <input
        className="w-full rounded border p-3"
        placeholder="نام دسته‌بندی"
        value={form.name}
        onChange={(e) =>
          setForm({ ...form, name: e.target.value })
        }
      />

      <input
        className="w-full rounded border p-3"
        placeholder="Slug"
        value={form.slug}
        onChange={(e) =>
          setForm({ ...form, slug: e.target.value })
        }
      />

      <textarea
        rows={5}
        className="w-full rounded border p-3"
        placeholder="توضیحات"
        value={form.description}
        onChange={(e) =>
          setForm({
            ...form,
            description: e.target.value,
          })
        }
      />

      <input
        className="w-full rounded border p-3"
        placeholder="آیکون"
        value={form.icon}
        onChange={(e) =>
          setForm({
            ...form,
            icon: e.target.value,
          })
        }
      />

      <input
        type="number"
        className="w-full rounded border p-3"
        placeholder="ترتیب نمایش"
        value={form.sortOrder}
        onChange={(e) =>
          setForm({
            ...form,
            sortOrder: Number(e.target.value),
          })
        }
      />

      <label className="flex items-center gap-3">
        <input
          type="checkbox"
          checked={form.active}
          onChange={(e) =>
            setForm({
              ...form,
              active: e.target.checked,
            })
          }
        />
        فعال
      </label>

      <button
        disabled={loading}
        onClick={submit}
        className="rounded-lg bg-orange-500 px-6 py-3 text-white"
      >
        {loading ? "در حال ذخیره..." : "ذخیره دسته‌بندی"}
      </button>
    </div>
  );
}