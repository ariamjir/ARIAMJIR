"use client";

import Link from "next/link";
import { useMemo, useState } from "react";

export type MachineRow = {
  id: string;

  title: string;
  slug: string;

  model: string | null;

  image: string | null;

  manufactureYear: number | null;

  province: string | null;

  city: string | null;

  price: number | string | null;

  views: number;

  featured: boolean;

  active: boolean;

  createdAt: string;

  brand?: {
    name: string;
  } | null;

  category?: {
    name: string;
  } | null;
};

type Props = {
  machines: MachineRow[];
};

export default function MachineTable({
  machines,
}: Props) {
  const [search, setSearch] = useState("");

  const [onlyActive, setOnlyActive] =
    useState(false);

  const filtered = useMemo(() => {
    return machines.filter((machine) => {
      const text = [
        machine.title,
        machine.slug,
        machine.model,
        machine.brand?.name,
        machine.category?.name,
        machine.city,
        machine.province,
      ]
        .join(" ")
        .toLowerCase();

      if (
        search &&
        !text.includes(search.toLowerCase())
      ) {
        return false;
      }

      if (
        onlyActive &&
        !machine.active
      ) {
        return false;
      }

      return true;
    });
  }, [
    machines,
    search,
    onlyActive,
  ]);

  return (
    <div className="space-y-6">
     
     <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">

  <div className="flex w-full gap-3">

    <input
      type="text"
      value={search}
      onChange={(e) =>
        setSearch(e.target.value)
      }
      placeholder="جستجوی ماشین..."
      className="w-full rounded-lg border border-gray-300 px-4 py-3 outline-none focus:border-orange-500"
    />

  </div>

  <label className="flex items-center gap-2 whitespace-nowrap rounded-lg border px-4 py-3">

    <input
      type="checkbox"
      checked={onlyActive}
      onChange={(e) =>
        setOnlyActive(
          e.target.checked
        )
      }
    />

    <span>
      فقط ماشین‌های فعال
    </span>

  </label>

</div>

<div className="overflow-x-auto rounded-xl border border-gray-200 bg-white shadow-sm">

  <table className="min-w-full">

    <thead className="bg-gray-100">

      <tr className="text-right text-sm font-bold">

        <th className="px-4 py-3">
          تصویر
        </th>

        <th className="px-4 py-3">
          عنوان
        </th>

        <th className="px-4 py-3">
          برند
        </th>

        <th className="px-4 py-3">
          دسته
        </th>

        <th className="px-4 py-3">
          مدل
        </th>

        <th className="px-4 py-3">
          سال
        </th>

        <th className="px-4 py-3">
          استان
        </th>

        <th className="px-4 py-3">
          قیمت
        </th>

        <th className="px-4 py-3">
          بازدید
        </th>

        <th className="px-4 py-3">
          وضعیت
        </th>

        <th className="px-4 py-3">
          ویژه
        </th>

        <th className="px-4 py-3">
          عملیات
        </th>

      </tr>

    </thead>

    <tbody>
  {filtered.map((machine) => (
    <tr
      key={machine.id}
      className="border-t hover:bg-gray-50"
    >
      <td className="p-4">
        {machine.image ? (
          <img
            src={machine.image}
            alt={machine.title}
            className="h-16 w-20 rounded-lg border object-cover"
          />
        ) : (
          <div className="flex h-16 w-20 items-center justify-center rounded-lg border bg-gray-100 text-xs">
            بدون تصویر
          </div>
        )}
      </td>

      <td className="p-4">
        <div className="font-bold">
          {machine.title}
        </div>

        <div className="text-xs text-gray-500">
          {machine.slug}
        </div>
      </td>

      <td className="p-4">
        {machine.brand?.name ?? "-"}
      </td>

      <td className="p-4">
        {machine.category?.name ?? "-"}
      </td>

      <td className="p-4">
        {machine.model ?? "-"}
      </td>

      <td className="p-4">
        {machine.manufactureYear ?? "-"}
      </td>

      <td className="p-4">
        {machine.province ?? "-"}
      </td>

      <td className="p-4">
        {machine.price == null
          ? "-"
          : Number(machine.price).toLocaleString("fa-IR")}
      </td>

      <td className="p-4">
        {machine.views}
      </td>

      <td className="p-4">
        {machine.active ? (
          <span className="rounded-full bg-green-100 px-3 py-1 text-xs font-bold text-green-700">
            فعال
          </span>
        ) : (
          <span className="rounded-full bg-red-100 px-3 py-1 text-xs font-bold text-red-700">
            غیرفعال
          </span>
        )}
      </td>

      <td className="p-4">
        {machine.featured ? (
          <span className="rounded-full bg-orange-100 px-3 py-1 text-xs font-bold text-orange-700">
            ویژه
          </span>
        ) : (
          "-"
        )}
      </td>

      <td className="p-4">
        <div className="flex gap-2">
          <Link
            href={`/admin/machines/edit/${machine.id}`}
            className="rounded-lg bg-blue-600 px-3 py-2 text-xs font-bold text-white"
          >
            ویرایش
          </Link>

          <button
            type="button"
            onClick={async () => {
              if (!confirm("حذف شود؟")) return;

              const res = await fetch(
                `/api/admin/machines/${machine.id}`,
                {
                  method: "DELETE",
                }
              );

              if (res.ok) {
                window.location.reload();
              }
            }}
            className="rounded-lg bg-red-600 px-3 py-2 text-xs font-bold text-white"
          >
            حذف
          </button>
        </div>
      </td>
    </tr>
  ))}
</tbody>
        </table>
      </div>

      <div className="text-sm text-gray-500">
        تعداد ماشین‌ها:
        <span className="mr-2 font-bold">
          {filtered.length}
        </span>
      </div>
    </div>
  );
}