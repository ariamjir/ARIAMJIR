"use client";

import { useEffect, useRef, useState } from "react";

import Link from "next/link";
import { useRouter } from "next/navigation";

import {
  Save,
  Loader2,
  CheckCircle2,
  Upload,
  ArrowRight,
  Plus,
  Type,
  Image as ImageIcon,
  Trash2,
} from "lucide-react";

import { slugify, readMinutes, faDate } from "@/lib/news";

const INP = "w-full rounded-lg border border-zinc-200 bg-white px-3 py-2 text-sm outline-none focus:border-emerald-400";
const TA = "w-full resize-y rounded-lg border border-zinc-200 bg-white px-3 py-2 text-sm leading-7 outline-none focus:border-emerald-400";
const TOOL = "inline-flex items-center gap-1.5 rounded-lg border border-zinc-200 bg-zinc-50 px-3 py-1.5 text-[11px] font-bold text-zinc-600 transition hover:border-emerald-300 hover:text-emerald-600";

export default function KnowledgeEditorForm({ id }: { id?: string }) {
  const router = useRouter();
  const [form, setForm] = useState<any>(null);
  const [cats, setCats] = useState<any[]>([]);
  const [newCat, setNewCat] = useState("");
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [loading, setLoading] = useState(true);
  const contentRef = useRef<HTMLTextAreaElement>(null);

    const del = async () => {
    if (!id) return;
    if (!confirm("این مقاله برای همیشه حذف شود؟")) return;
    await fetch("/api/admin/knowledge", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ deleteId: id }),
    });
    router.push("/admin/knowledge");
  };

  const loadCats = () =>
    fetch("/api/admin/news/categories")
      .then((r) => r.json())
      .then((j) => {
        if (j.success) setCats(j.data ?? []);
      });

    useEffect(() => {
    Promise.all([
      loadCats(),
      id ? fetch(`/api/admin/knowledge?id=${id}`).then((r) => r.json()) : Promise.resolve({ success: true, data: null }),
    ])
      .then(([, j]) => {
        const p = j?.data;
        setForm(
          p
            ? {
                ...p,
                /* ✅ هیچ input ای null نگیرد */
                title: p.title ?? "",
                slug: p.slug ?? "",
                excerpt: p.excerpt ?? "",
                content: p.content ?? "",
                coverImage: p.coverImage ?? "",
                categoryId: p.categoryId ?? "",
                authorName: p.authorName ?? "",
                metaTitle: p.metaTitle ?? "",
                metaDescription: p.metaDescription ?? "",
                tagsText: (p.tags ?? []).join("، "),
                publishedLocal: p.publishedAt
                  ? new Date(p.publishedAt).toISOString().slice(0, 16)
                  : "",
              }
            : {
                title: "",
                slug: "",
                excerpt: "",
                content: "",
                coverImage: "",
                categoryId: "",
                authorName: "",
                tagsText: "",
                status: "DRAFT",
                featured: false,
                publishedLocal: "",
                metaTitle: "",
                metaDescription: "",
              }
        );
      })
      .finally(() => setLoading(false));
  }, [id]);

  const set = (k: string, v: any) => {
    setForm((f: any) => ({ ...f, [k]: v }));
    setSaved(false);
  };

  const insert = (snippet: string) => {
    const el = contentRef.current;
    if (!el) return set("content", (form.content ?? "") + snippet);
    const { selectionStart: s, selectionEnd: e, value } = el;
    const next = value.slice(0, s) + snippet + value.slice(e);
    set("content", next);
    requestAnimationFrame(() => {
      el.focus();
      el.selectionStart = el.selectionEnd = s + snippet.length;
    });
  };

  const upload = async (file: File) => {
    const fd = new FormData();
    fd.append("file", file);
    fd.append("folder", "knowledge");
    const res = await fetch("/api/upload/image", { method: "POST", body: fd });
    const j = await res.json();
    const url = j.url || j.path || j.src || "";
    if (url) set("coverImage", url);
  };

  const addCat = async () => {
    if (!newCat.trim()) return;
    await fetch("/api/admin/news/categories", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: newCat.trim() }),
    });
    setNewCat("");
    loadCats();
  };

  const save = async () => {
    setSaving(true);
    try {
      const body = {
        title: form.title,
        slug: form.slug || slugify(form.title),
        excerpt: form.excerpt,
        content: form.content,
        coverImage: form.coverImage,
        categoryId: form.categoryId || null,
        authorName: form.authorName,
        tags: (form.tagsText ?? "").split(/[،,]/).map((t: string) => t.trim()).filter(Boolean),
        status: form.status,
        featured: !!form.featured,
        publishedAt: form.publishedLocal ? new Date(form.publishedLocal).toISOString() : null,
        metaTitle: form.metaTitle,
        metaDescription: form.metaDescription,
      };

      const res = await fetch("/api/admin/knowledge", {
        method: id ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(id ? { id, ...body } : body),
      });
      const j = await res.json();
      if (j.success) {
        setSaved(true);
        setTimeout(() => setSaved(false), 2500);
      }
    } finally {
      setSaving(false);
    }
  };

  if (loading || !form) {
    return (
      <div className="flex h-64 items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-emerald-500" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <Link href="/admin/knowledge" className="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-zinc-200 bg-white text-zinc-600 transition hover:border-emerald-300">
            <ArrowRight className="h-4 w-4" />
          </Link>
          <h1 className="text-2xl font-black text-zinc-800">{id ? "ویرایش مقاله" : "مقالهٔ جدید"}</h1>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          {id && (
            <button
              onClick={del}
              className="inline-flex items-center gap-2 rounded-xl border border-red-200 bg-red-50 px-5 py-2.5 text-sm font-black text-red-600 transition hover:bg-red-100"
            >
              <Trash2 className="h-4 w-4" />
              حذف مقاله
            </button>
          )}
          <button
            onClick={save}
            disabled={saving}
            className="inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-6 py-2.5 text-sm font-black text-white shadow transition hover:bg-emerald-700 disabled:opacity-60"
          >
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : saved ? <CheckCircle2 className="h-4 w-4" /> : <Save className="h-4 w-4" />}
            {saved ? "ذخیره شد" : "ذخیره"}
          </button>
        </div>
      </div>

      <div className="grid gap-6 xl:grid-cols-[1fr_360px]">
        <div className="space-y-6">
          <div className="space-y-4 rounded-2xl border border-zinc-200 bg-white p-6 shadow-sm">
            <Field label="عنوان مقاله *">
              <input
                value={form.title}
                onChange={(e) => {
                  set("title", e.target.value);
                  if (!id) set("slug", slugify(e.target.value));
                }}
                className={INP}
              />
            </Field>
            <div className="grid gap-4 md:grid-cols-2">
              <Field label="نامک (slug)">
                <input value={form.slug} onChange={(e) => set("slug", e.target.value)} dir="ltr" className={INP} />
              </Field>
              <Field label="نویسنده">
                <input value={form.authorName} onChange={(e) => set("authorName", e.target.value)} className={INP} />
              </Field>
            </div>
            <Field label="خلاصه">
              <textarea value={form.excerpt} onChange={(e) => set("excerpt", e.target.value)} rows={2} className={TA} />
            </Field>

            <Field label={`متن کامل — زمان مطالعه: ${readMinutes(form.content)} دقیقه`}>
              <div className="mb-2 flex flex-wrap gap-2">
                <button type="button" onClick={() => insert("\n## تیتر بخش\n")} className={TOOL}>
                  <Type className="h-3.5 w-3.5" /> تیتر
                </button>
                <button type="button" onClick={() => insert("\n![تصویر](/images/blog/news-1.jpg)\n")} className={TOOL}>
                  <ImageIcon className="h-3.5 w-3.5" /> تصویر میان‌متن
                </button>
              </div>
              <textarea
                ref={contentRef}
                value={form.content}
                onChange={(e) => set("content", e.target.value)}
                rows={12}
                placeholder={"متن مقاله...\nبا ## تیتر و ![تصویر](آدرس) ساختار بدهید."}
                className={TA}
              />
            </Field>
          </div>

          <div className="space-y-4 rounded-2xl border border-zinc-200 bg-white p-6 shadow-sm">
            <h2 className="text-sm font-black text-zinc-800">سئو</h2>
            <Field label="Meta Title">
              <input value={form.metaTitle} onChange={(e) => set("metaTitle", e.target.value)} className={INP} />
            </Field>
            <Field label="Meta Description">
              <textarea value={form.metaDescription} onChange={(e) => set("metaDescription", e.target.value)} rows={2} className={TA} />
            </Field>
          </div>
        </div>

        <div className="space-y-6">
          <div className="space-y-4 rounded-2xl border border-zinc-200 bg-white p-6 shadow-sm">
            <Field label="تصویر شاخص">
              <div className="flex items-center gap-2">
                {form.coverImage && (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={form.coverImage} alt="" className="h-14 w-20 rounded-lg object-cover" />
                )}
                <input value={form.coverImage} onChange={(e) => set("coverImage", e.target.value)} dir="ltr" className={INP} />
                <label className="inline-flex h-9 w-9 shrink-0 cursor-pointer items-center justify-center rounded-lg border border-zinc-200 bg-white text-zinc-600 transition hover:border-emerald-300 hover:text-emerald-600">
                  <Upload className="h-4 w-4" />
                  <input
                    type="file"
                    accept="image/*"
                    hidden
                    onChange={(e) => {
                      const f = e.target.files?.[0];
                      if (f) upload(f);
                      e.target.value = "";
                    }}
                  />
                </label>
              </div>
            </Field>

            <Field label="دسته‌بندی">
              <select value={form.categoryId} onChange={(e) => set("categoryId", e.target.value)} className={INP}>
                <option value="">بدون دسته</option>
                {cats.map((c) => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
              <div className="mt-2 flex items-center gap-2">
                <input value={newCat} onChange={(e) => setNewCat(e.target.value)} placeholder="دستهٔ جدید..." className={INP} />
                <button type="button" onClick={addCat} className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-zinc-800 text-white transition hover:bg-zinc-700">
                  <Plus className="h-4 w-4" />
                </button>
              </div>
            </Field>

            <Field label="برچسب‌ها (با ویرگول)">
              <input value={form.tagsText} onChange={(e) => set("tagsText", e.target.value)} className={INP} />
            </Field>

            <div className="grid grid-cols-2 gap-4">
              <Field label="وضعیت">
                <select value={form.status} onChange={(e) => set("status", e.target.value)} className={INP}>
                  <option value="DRAFT">پیش‌نویس</option>
                  <option value="PENDING">در انتظار بررسی</option>
                  <option value="PUBLISHED">منتشر شده</option>
                </select>
              </Field>
              <Field label="تاریخ انتشار">
                <input type="datetime-local" value={form.publishedLocal} onChange={(e) => set("publishedLocal", e.target.value)} dir="ltr" className={INP} />
              </Field>
            </div>

            <label className="flex cursor-pointer items-center gap-2 text-xs font-bold text-zinc-600">
              <input type="checkbox" checked={!!form.featured} onChange={(e) => set("featured", e.target.checked)} className="h-4 w-4 accent-emerald-600" />
              مقالهٔ ویژه (نمایش بزرگ در صفحهٔ اول)
            </label>
          </div>

          {/* پیش‌نمایش زنده */}
          <div className="overflow-hidden rounded-2xl border border-white/10 bg-[#141414] shadow-lg">
            {form.coverImage && (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={form.coverImage} alt="" className="aspect-video w-full object-cover" />
            )}
            <div className="p-4">
              <div className="text-[10px] font-bold text-emerald-400">
                {cats.find((c) => c.id === form.categoryId)?.name ?? "آموزشی"}
              </div>
              <div className="mt-1 text-sm font-black text-white">{form.title || "عنوان مقاله"}</div>
              <div className="mt-2 line-clamp-2 text-[11px] text-white/50">{form.excerpt}</div>
              <div className="mt-3 flex items-center gap-3 text-[10px] text-white/40">
                <span>⏱ {readMinutes(form.content)} دقیقه</span>
                <span>{faDate(form.publishedLocal || new Date())}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="mb-1.5 text-xs font-bold text-zinc-600">{label}</div>
      {children}
    </div>
  );
}