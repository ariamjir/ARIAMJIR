"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

import { ChevronLeft } from "lucide-react";

/* ============================================================
   Breadcrumb — سبک WordPress/Amazon Seller
============================================================ */

const LABELS: Record<string, string> = {
  dashboard: "داشبورد",
  home: "صفحه اصلی",
  "homepage-layout": "چیدمان صفحه اول",
  menu: "منوی سایت",
  machines: "ماشین‌آلات",
  ads: "آگهی‌ها",
  news: "اخبار",
  knowledge: "مرکز دانش",
  services: "خدمات",
  brands: "برندها",
  categories: "دسته‌بندی‌ها",
  users: "کاربران",
  settings: "تنظیمات",
  "premium-listings": "فروش ویژه آریا",
  hero: "هیرو و اسلایدر",
  footer: "فوتر",
  stats: "آمار",
  report: "گزارش ماهانه",
  new: "ثبت جدید",
  edit: "ویرایش",
};

export default function Breadcrumbs() {
  const pathname = usePathname();

  const segs = pathname
    .split("/")
    .filter(Boolean)
    .filter((p) => p !== "admin");

  if (segs.length === 0) return null;

  return (
    <nav className="mb-5 flex flex-wrap items-center gap-1.5 text-[11px] text-zinc-500">
      <Link
        href="/admin/dashboard"
        className="font-bold transition hover:text-orange-600"
      >
        پنل مدیریت
      </Link>

      {segs.map((seg, i) => {
        const href = "/admin/" + segs.slice(0, i + 1).join("/");
        const last = i === segs.length - 1;
        const label = LABELS[seg] ?? seg;

        return (
          <span key={href} className="flex items-center gap-1.5">
            <ChevronLeft className="h-3 w-3 text-zinc-400" />
            {last ? (
              <span className="font-black text-zinc-800">{label}</span>
            ) : (
              <Link href={href} className="transition hover:text-orange-600">
                {label}
              </Link>
            )}
          </span>
        );
      })}
    </nav>
  );
}