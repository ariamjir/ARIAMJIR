"use client";

import Image from "next/image";
import { useEffect, useState } from "react";

interface HeroSlide {
  id: string;
  image: string;
  title: string | null;
  subtitle: string | null;
  link: string | null;
  sortOrder: number;
  active: boolean;
}

interface Props {
  heroId: string;
  slide?: HeroSlide;
  onSuccess?: () => void;
}

const HERO_IMAGES = [
  "/images/hero/hero-1.jpg",
  "/images/hero/hero-2.jpg",
  "/images/hero/hero-3.jpg",
  "/images/hero/hero-4.jpg",
  "/images/hero/hero-5.jpg",
  "/images/hero/hero-6.jpg",
  "/images/hero/hero-7.jpg",
  "/images/hero/hero-8.jpg",
  "/images/hero/hero-9.jpg",
];

export default function HeroSlideForm({
  heroId,
  slide,
  onSuccess,
}: Props) {
  const editing = !!slide;

  const [loading, setLoading] =
    useState(false);

  const [form, setForm] = useState({
    image: HERO_IMAGES[0],
    title: "",
    subtitle: "",
    link: "",
    sortOrder: 0,
    active: true,
  });

  useEffect(() => {
    if (!slide) {
      setForm({
        image: HERO_IMAGES[0],
        title: "",
        subtitle: "",
        link: "",
        sortOrder: 0,
        active: true,
      });

      return;
    }

    setForm({
      image: slide.image,
      title: slide.title ?? "",
      subtitle: slide.subtitle ?? "",
      link: slide.link ?? "",
      sortOrder: slide.sortOrder,
      active: slide.active,
    });
  }, [slide]);

  function change(
    e: React.ChangeEvent<
      HTMLInputElement | HTMLTextAreaElement
    >
  ) {
    const {
      name,
      value,
      type,
    } = e.target;

    setForm((prev) => ({
      ...prev,
      [name]:
        type === "number"
          ? Number(value)
          : value,
    }));
  }

  function selectImage(
    image: string
  ) {
    setForm((prev) => ({
      ...prev,
      image,
    }));
  }

  function changeCheckbox(
    e: React.ChangeEvent<HTMLInputElement>
  ) {
    setForm((prev) => ({
      ...prev,
      active: e.target.checked,
    }));
  }

  async function submit(
    e: React.FormEvent
  ) {
    e.preventDefault();

    setLoading(true);

    try {
      const url = editing
        ? `/api/admin/hero/slides/${slide!.id}`
        : "/api/admin/hero/slides";

      const method = editing
        ? "PUT"
        : "POST";

      const body = editing
        ? form
        : {
            heroId,
            ...form,
          };

      const res = await fetch(url, {
        method,
        headers: {
          "Content-Type":
            "application/json",
        },
        body: JSON.stringify(body),
      });

      if (!res.ok) {
        throw new Error();
      }

      if (!editing) {
        setForm({
          image: HERO_IMAGES[0],
          title: "",
          subtitle: "",
          link: "",
          sortOrder: 0,
          active: true,
        });
      }

      onSuccess?.();
    } catch {
      alert("خطا در ذخیره اسلاید");
    }

    setLoading(false);
  }

  return (

        <form
      onSubmit={submit}
      className="space-y-8"
    >
      <div>
        <label className="mb-4 block text-lg font-bold">
          انتخاب تصویر اسلاید
        </label>

        <div className="grid grid-cols-2 gap-5 md:grid-cols-3 lg:grid-cols-3">
          {HERO_IMAGES.map((image) => (
            <button
              key={image}
              type="button"
              onClick={() => selectImage(image)}
              className={`overflow-hidden rounded-2xl border-4 transition ${
                form.image === image
                  ? "border-orange-500"
                  : "border-transparent hover:border-orange-300"
              }`}
            >
              <div className="relative h-40 w-full">
                <Image
                  src={image}
                  alt={image}
                  fill
                  className="object-cover"
                />
              </div>
            </button>
          ))}
        </div>
      </div>

      <div>
        <label className="mb-2 block font-bold">
          مسیر تصویر
        </label>

        <input
          value={form.image}
          readOnly
          className="
            w-full
            rounded-xl
            border
            bg-gray-100
            px-4
            py-3
            text-sm
            text-gray-600
          "
        />
      </div>

      <div>
        <label className="mb-2 block font-bold">
          پیش نمایش
        </label>

        <div className="overflow-hidden rounded-2xl border">
          <div className="relative h-72 w-full">
            <Image
              src={form.image}
              alt="Preview"
              fill
              priority
              className="object-cover"
            />
          </div>
        </div>
      </div>

      <div>
        <label className="mb-2 block font-bold">
          عنوان
        </label>

        <input
          name="title"
          value={form.title}
          onChange={change}
          className="w-full rounded-xl border px-4 py-3"
        />
      </div>

      <div>
        <label className="mb-2 block font-bold">
          زیرعنوان
        </label>

        <textarea
          name="subtitle"
          value={form.subtitle}
          onChange={change}
          rows={4}
          className="w-full rounded-xl border px-4 py-3"
        />
      </div>

      <div>
        <label className="mb-2 block font-bold">
          لینک دکمه
        </label>

        <input
          name="link"
          value={form.link}
          onChange={change}
          placeholder="/machines"
          className="w-full rounded-xl border px-4 py-3"
        />
      </div>

      <div>
        <label className="mb-2 block font-bold">
          ترتیب نمایش
        </label>

        <input
          type="number"
          name="sortOrder"
          value={form.sortOrder}
          onChange={change}
          className="w-full rounded-xl border px-4 py-3"
        />
      </div>

      <label className="flex items-center gap-3">
        <input
          type="checkbox"
          checked={form.active}
          onChange={changeCheckbox}
        />

        <span className="font-medium">
          اسلاید فعال باشد
        </span>
      </label>

      <button
        type="submit"
        disabled={loading}
        className="
          w-full
          rounded-xl
          bg-orange-500
          py-4
          font-bold
          text-white
          transition
          hover:bg-orange-600
          disabled:opacity-50
        "
      >
        {loading
          ? "در حال ذخیره..."
          : editing
          ? "ذخیره تغییرات"
          : "افزودن اسلاید"}
      </button>
    </form>
  );
}