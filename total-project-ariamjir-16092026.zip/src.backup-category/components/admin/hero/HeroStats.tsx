"use client";

import type { Hero, HeroStat } from "@prisma/client";

import { Pencil, Trash2 } from "lucide-react";

interface HeroWithStats extends Hero {
  stats: HeroStat[];
}

interface Props {
  hero: HeroWithStats;
  onEdit: (stat: HeroStat) => void;
}

export default function HeroStats({
  hero,
  onEdit,
}: Props) {
  async function remove(id: string) {
    const ok = confirm("آیا از حذف این آمار مطمئن هستید؟");

    if (!ok) return;

    const res = await fetch(
      `/api/admin/hero/stats/${id}`,
      {
        method: "DELETE",
      }
    );

    if (!res.ok) {
      alert("حذف انجام نشد");
      return;
    }

    window.location.reload();
  }

  const stats = [...hero.stats].sort(
    (a: HeroStat, b: HeroStat) =>
      a.sortOrder - b.sortOrder
  );

  if (stats.length === 0) {
    return (
      <div className="rounded-2xl border bg-white p-12 text-center text-gray-500">
        هنوز آماری ثبت نشده است.
      </div>
    );
  }

  return (
    <div className="overflow-hidden rounded-2xl border bg-white shadow-sm">
      <table className="w-full">

        <thead className="bg-gray-100">
          <tr>
            <th className="px-6 py-4 text-right">
              عنوان
            </th>

            <th className="px-6 py-4 text-right">
              مقدار
            </th>

            <th className="px-6 py-4 text-center">
              ترتیب
            </th>

            <th className="px-6 py-4 text-center">
              وضعیت
            </th>

            <th className="px-6 py-4 text-center">
              عملیات
            </th>
          </tr>
        </thead>

        <tbody>

          {stats.map((stat: HeroStat) => (
            <tr
              key={stat.id}
              className="border-t"
            >
              <td className="px-6 py-5 font-medium">
                {stat.title}
              </td>

              <td className="px-6 py-5 font-bold text-orange-600">
                {stat.value}
              </td>

              <td className="px-6 py-5 text-center">
                {stat.sortOrder}
              </td>

              <td className="px-6 py-5 text-center">
                <span
                  className={
                    stat.active
                      ? "rounded-full bg-green-100 px-3 py-1 text-sm text-green-700"
                      : "rounded-full bg-red-100 px-3 py-1 text-sm text-red-700"
                  }
                >
                  {stat.active
                    ? "فعال"
                    : "غیرفعال"}
                </span>
              </td>

              <td className="px-6 py-5">
                <div className="flex items-center justify-center gap-3">

                  <button
                    type="button"
                    onClick={() => onEdit(stat)}
                    className="rounded-lg border p-2 hover:bg-gray-100"
                  >
                    <Pencil size={18} />
                  </button>

                  <button
                    type="button"
                    onClick={() => remove(stat.id)}
                    className="rounded-lg border border-red-200 p-2 text-red-600 hover:bg-red-50"
                  >
                    <Trash2 size={18} />
                  </button>

                </div>
              </td>
            </tr>
          ))}

        </tbody>

      </table>
    </div>
  );
}