"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";

import type { Hero, HeroSlide } from "@prisma/client";

interface Props {
  hero: Hero & {
    slides: HeroSlide[];
  };

  onEdit?: (slide: HeroSlide) => void;
}

export default function HeroSlides({
  hero,
}: Props) {
  const router = useRouter();

  const [loadingId, setLoadingId] = useState<string | null>(
    null
  );

  async function removeSlide(id: string) {
    if (!confirm("اسلاید حذف شود؟")) {
      return;
    }

    try {
      setLoadingId(id);

      const res = await fetch(
        `/api/admin/hero/slides/${id}`,
        {
          method: "DELETE",
        }
      );

      if (!res.ok) {
        throw new Error();
      }

      router.refresh();
    } catch {
      alert("خطا در حذف اسلاید");
    } finally {
      setLoadingId(null);
    }
  }

  return (
    <div className="space-y-6">

      <div className="flex items-center justify-between">

        <h2 className="text-2xl font-bold">
          اسلایدهای هدر
        </h2>

        <Link
          href={`/admin/hero/edit/${hero.id}?tab=slides&new=1`}
          className="
            rounded-xl
            bg-orange-500
            px-5
            py-3
            font-bold
            text-white
            transition
            hover:bg-orange-600
          "
        >
          افزودن اسلاید
        </Link>

      </div>

      {hero.slides.length === 0 && (
        <div
          className="
            rounded-2xl
            border
            border-dashed
            p-10
            text-center
            text-gray-500
          "
        >
          هنوز اسلایدی ثبت نشده است.
        </div>
      )}

      <div className="space-y-4">

        {hero.slides
          .sort(
            (a, b) =>
              a.sortOrder - b.sortOrder
          )
          .map((slide) => (
            <div
              key={slide.id}
              className="
                flex
                items-center
                justify-between
                rounded-2xl
                border
                bg-white
                p-5
                shadow-sm
              "
            >
              <div className="flex items-center gap-5">

                <img
                  src={slide.image}
                  alt=""
                  className="
                    h-24
                    w-40
                    rounded-xl
                    object-cover
                  "
                />

                <div>

                  <h3 className="font-bold">
                    {slide.title || "بدون عنوان"}
                  </h3>

                  <p className="mt-1 text-sm text-gray-500">
                    {slide.subtitle}
                  </p>

                  <div className="mt-2 flex gap-3 text-sm">

                    <span>
                      ترتیب:
                      {" "}
                      {slide.sortOrder}
                    </span>

                    <span
                      className={
                        slide.active
                          ? "text-green-600"
                          : "text-red-600"
                      }
                    >
                      {slide.active
                        ? "فعال"
                        : "غیرفعال"}
                    </span>

                  </div>

                </div>

              </div>

              <div className="flex gap-3">

                <Link
                  href={`/admin/hero/edit/${hero.id}?slide=${slide.id}`}
                  className="
                    rounded-lg
                    border
                    px-4
                    py-2
                    transition
                    hover:bg-gray-100
                  "
                >
                  ویرایش
                </Link>

                <button
                  onClick={() =>
                    removeSlide(slide.id)
                  }
                  disabled={
                    loadingId === slide.id
                  }
                  className="
                    rounded-lg
                    bg-red-500
                    px-4
                    py-2
                    text-white
                    transition
                    hover:bg-red-600
                    disabled:opacity-50
                  "
                >
                  {loadingId === slide.id
                    ? "..."
                    : "حذف"}
                </button>

              </div>

            </div>
          ))}

      </div>

    </div>
  );
}