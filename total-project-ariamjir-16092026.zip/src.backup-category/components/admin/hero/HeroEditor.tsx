"use client";

import { useEffect, useMemo, useState } from "react";

import { useSearchParams, useRouter } from "next/navigation";

import type {
  Hero,
  HeroSlide,
  HeroStat,
} from "@prisma/client";

import HeroForm from "../HeroForm";
import HeroSlides from "./HeroSlides";
import HeroStats from "./HeroStats";
import HeroSlideForm from "./HeroSlideForm";
import HeroStatForm from "./HeroStatForm";

interface Props {
  hero: Hero & {
    slides: HeroSlide[];
    stats: HeroStat[];
  };
}

type Tab =
  | "hero"
  | "slides"
  | "stats";

export default function HeroEditor({
  hero,
}: Props) {
  const router = useRouter();

  const searchParams = useSearchParams();

  const slideId =
    searchParams.get("slide");

  const statId =
    searchParams.get("stat");

  const [tab, setTab] =
    useState<Tab>("hero");

  const editingSlide =
    useMemo(
      () =>
        hero.slides.find(
          (x) => x.id === slideId
        ),
      [hero.slides, slideId]
    );

  const editingStat =
    useMemo(
      () =>
        hero.stats.find(
          (x) => x.id === statId
        ),
      [hero.stats, statId]
    );

  useEffect(() => {
    if (slideId) {
      setTab("slides");
    }

    if (statId) {
      setTab("stats");
    }
  }, [slideId, statId]);

  function clearSlideEdit() {
    router.push(
      `/admin/hero/edit/${hero.id}`
    );
  }

  function clearStatEdit() {
    router.push(
      `/admin/hero/edit/${hero.id}`
    );
  }

  return (
    <div className="space-y-8">

      <div className="flex flex-wrap gap-3">

        <button
          onClick={() => setTab("hero")}
          className={`rounded-xl px-6 py-3 font-bold transition ${
            tab === "hero"
              ? "bg-orange-500 text-white"
              : "border bg-white"
          }`}
        >
          اطلاعات هدر
        </button>

        <button
          onClick={() => setTab("slides")}
          className={`rounded-xl px-6 py-3 font-bold transition ${
            tab === "slides"
              ? "bg-orange-500 text-white"
              : "border bg-white"
          }`}
        >
          اسلایدها
        </button>

        <button
          onClick={() => setTab("stats")}
          className={`rounded-xl px-6 py-3 font-bold transition ${
            tab === "stats"
              ? "bg-orange-500 text-white"
              : "border bg-white"
          }`}
        >
          آمار
        </button>

      </div>

      {tab === "hero" && (
        <HeroForm hero={hero} />
      )}

      {tab === "slides" && (
        <div className="space-y-8">

          <HeroSlides
  hero={hero}
  onEdit={(slide) => {
    router.push(
      `/admin/hero/edit/${hero.id}?slide=${slide.id}`
    );
  }}
/>

          <div className="rounded-2xl border bg-white p-8 shadow-sm">

            <div className="mb-6 flex items-center justify-between">

              <h2 className="text-2xl font-bold">
                {editingSlide
                  ? "ویرایش اسلاید"
                  : "افزودن اسلاید"}
              </h2>

              {editingSlide && (
                <button
                  onClick={clearSlideEdit}
                  className="rounded-xl border px-5 py-2"
                >
                  انصراف
                </button>
              )}

            </div>

            <HeroSlideForm
              heroId={hero.id}
              slide={editingSlide}
              onSuccess={() => {
                router.refresh();
                clearSlideEdit();
              }}
            />

          </div>

        </div>
      )}

      {tab === "stats" && (
        <div className="space-y-8">

          <HeroStats
  hero={hero}
  onEdit={(stat) => {
    router.push(
      `/admin/hero/edit/${hero.id}?stat=${stat.id}`
    );
  }}
/>

          <div className="rounded-2xl border bg-white p-8 shadow-sm">

            <div className="mb-6 flex items-center justify-between">

              <h2 className="text-2xl font-bold">
                {editingStat
                  ? "ویرایش آمار"
                  : "افزودن آمار"}
              </h2>

              {editingStat && (
                <button
                  onClick={clearStatEdit}
                  className="rounded-xl border px-5 py-2"
                >
                  انصراف
                </button>
              )}

            </div>

            <HeroStatForm
              heroId={hero.id}
              stat={editingStat}
              onSuccess={() => {
                router.refresh();
                clearStatEdit();
              }}
            />

          </div>

        </div>
      )}

    </div>
  );
}