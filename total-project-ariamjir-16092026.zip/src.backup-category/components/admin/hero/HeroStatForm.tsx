"use client";

import { useEffect, useState } from "react";

import {
  HeroStat,
  HeroStatSource,
  HeroStatType,
} from "@prisma/client";

interface Props {
  heroId: string;
  stat?: HeroStat;
  onSuccess?: () =>void;
}

type FormData = {
  title: string;
  type: HeroStatType;
  source: HeroStatSource;
  value: string;
  icon: string;
  sortOrder: number;
  active: boolean;
};

const sourceOptions = [
  {
    value: HeroStatSource.MACHINES,
    label: "تعداد ماشین‌آلات",
  },
  {
    value: HeroStatSource.BRANDS,
    label: "تعداد برندها",
  },
  {
    value: HeroStatSource.CATEGORIES,
    label: "تعداد دسته‌بندی‌ها",
  },
  {
    value: HeroStatSource.PARTS,
    label: "تعداد قطعات",
  },
  {
    value: HeroStatSource.SERVICES,
    label: "تعداد خدمات",
  },
  {
    value: HeroStatSource.DEALERS,
    label: "نمایندگی‌ها",
  },
  {
    value: HeroStatSource.COMPANIES,
    label: "شرکت‌ها",
  },
  {
    value: HeroStatSource.USERS,
    label: "کاربران",
  },
  {
    value: HeroStatSource.NEWS,
    label: "اخبار",
  },
  {
    value: HeroStatSource.ARTICLES,
    label: "مقالات",
  },
  {
    value: HeroStatSource.AUCTIONS,
    label: "مزایده‌ها",
  },
  {
    value: HeroStatSource.FOLLOWERS,
    label: "دنبال‌کنندگان",
  },
];

export default function HeroStatForm({
  heroId,
  stat,
  onSuccess,
}: Props) {
  const editing = Boolean(stat);

  const [loading, setLoading] =
    useState(false);

  const [form, setForm] =
    useState<FormData>({
      title: "",
      type: HeroStatType.MANUAL,
      source: HeroStatSource.MANUAL,
      value: "",
      icon: "",
      sortOrder: 0,
      active: true,
    });

  useEffect(() => {
    if (!stat) return;

    setForm({
      title: stat.title,
      type: stat.type,
      source: stat.source,
      value: stat.value ?? "",
      icon: stat.icon ?? "",
      sortOrder: stat.sortOrder,
      active: stat.active,
    });
  }, [stat]);

  function change(
    e:
      | React.ChangeEvent<HTMLInputElement>
      | React.ChangeEvent<HTMLSelectElement>
  ) {
    const {
      name,
      value,
      type,
    } = e.target;

    setForm((prev) => {
      const next = {
        ...prev,
        [name]:
          type === "number"
            ? Number(value)
            : value,
      };

      if (
        name === "type"
      ) {
        if (
          value === HeroStatType.MANUAL
        ) {
          next.source =
            HeroStatSource.MANUAL;
        } else {
          next.source =
            HeroStatSource.MACHINES;
          next.value = "";
        }
      }

      return next;
    });
  }

  function changeActive(
    e: React.ChangeEvent<HTMLInputElement>
  ) {
    setForm((prev) => ({
      ...prev,
      active: e.target.checked,
    }));
  }

  async function submit(
    e: React.FormEvent<HTMLFormElement>
  ) {
    e.preventDefault();

    setLoading(true);

    try {
      const url = editing
        ? `/api/admin/hero/stats/${stat!.id}`
        : "/api/admin/hero/stats";

      const method = editing
        ? "PUT"
        : "POST";

      const body = editing
        ? form
        : {
            heroId,
            ...form,
          };

      const res = await fetch(url, {
        method,
        headers: {
          "Content-Type":
            "application/json",
        },
        body: JSON.stringify(body),
      });

      if (!res.ok)
        throw new Error();

      onSuccess?.();
    } catch (err) {
      console.error(err);
      alert("خطا در ذخیره");
    } finally {
      setLoading(false);
    }
  }

  return (
    <form
      onSubmit={submit}
      className="space-y-6"
    >
      <div>
        <label className="mb-2 block font-bold">
          عنوان
        </label>

        <input
          name="title"
          value={form.title}
          onChange={change}
          required
          className="w-full rounded-xl border px-4 py-3"
        />
      </div>

      <div>
        <label className="mb-2 block font-bold">
          نوع آمار
        </label>

        <select
          name="type"
          value={form.type}
          onChange={change}
          className="w-full rounded-xl border px-4 py-3"
        >
          <option value="MANUAL">
            دستی
          </option>

          <option value="DYNAMIC">
            داینامیک
          </option>
        </select>
      </div>

      {form.type ===
        HeroStatType.DYNAMIC && (
        <div>
          <label className="mb-2 block font-bold">
            منبع اطلاعات
          </label>

          <select
            name="source"
            value={form.source}
            onChange={change}
            className="w-full rounded-xl border px-4 py-3"
          >
            {sourceOptions.map(
              (item) => (
                <option
                  key={item.value}
                  value={item.value}
                >
                  {item.label}
                </option>
              )
            )}
          </select>
        </div>
      )}

      {form.type ===
        HeroStatType.MANUAL && (
        <div>
          <label className="mb-2 block font-bold">
            مقدار
          </label>

          <input
            name="value"
            value={form.value}
            onChange={change}
            placeholder="مثلاً 250+"
            className="w-full rounded-xl border px-4 py-3"
          />
        </div>
      )}

      <div>
        <label className="mb-2 block font-bold">
          آیکون
        </label>

        <input
          name="icon"
          value={form.icon}
          onChange={change}
          placeholder="Boxes"
          className="w-full rounded-xl border px-4 py-3"
        />
      </div>

      <div>
        <label className="mb-2 block font-bold">
          ترتیب نمایش
        </label>

        <input
          type="number"
          name="sortOrder"
          value={form.sortOrder}
          onChange={change}
          className="w-full rounded-xl border px-4 py-3"
        />
      </div>

      <label className="flex items-center gap-3">
        <input
          type="checkbox"
          checked={form.active}
          onChange={changeActive}
        />

        <span>
          فعال باشد
        </span>
      </label>

      <button
        disabled={loading}
        className="w-full rounded-xl bg-orange-500 py-4 font-bold text-white"
      >
        {loading
          ? "در حال ذخیره..."
          : editing
          ? "ذخیره تغییرات"
          : "افزودن آمار"}
      </button>
    </form>
  );
}