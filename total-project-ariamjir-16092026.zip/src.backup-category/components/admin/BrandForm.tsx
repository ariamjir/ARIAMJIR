"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

type Props = {
  brandId?: string;
};

export default function BrandForm({ brandId }: Props) {
  const router = useRouter();

  const [loading, setLoading] = useState(false);

  const [form, setForm] = useState({
    name: "",
    slug: "",
    description: "",
    logo: "",
    sortOrder: 0,
    active: true,
  });

  useEffect(() => {
    if (!brandId) return;

    async function loadBrand() {
      const res = await fetch(`/api/admin/brands/${brandId}`);
      const data = await res.json();

      setForm({
        name: data.name ?? "",
        slug: data.slug ?? "",
        description: data.description ?? "",
        logo: data.logo ?? "",
        sortOrder: data.sortOrder ?? 0,
        active: data.active ?? true,
      });
    }

    loadBrand();
  }, [brandId]);

  async function submit() {
    setLoading(true);

    const url = brandId
      ? `/api/admin/brands/${brandId}`
      : "/api/admin/brands";

    const method = brandId ? "PUT" : "POST";

    await fetch(url, {
      method,
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(form),
    });

    router.push("/admin/brands");
    router.refresh();
  }

  return (
    <div className="space-y-4 rounded-xl border bg-white p-6">

      <input
        className="w-full rounded border p-3"
        placeholder="نام برند"
        value={form.name}
        onChange={(e) =>
          setForm({ ...form, name: e.target.value })
        }
      />

      <input
        className="w-full rounded border p-3"
        placeholder="Slug"
        value={form.slug}
        onChange={(e) =>
          setForm({ ...form, slug: e.target.value })
        }
      />

      <textarea
        rows={5}
        className="w-full rounded border p-3"
        placeholder="توضیحات"
        value={form.description}
        onChange={(e) =>
          setForm({
            ...form,
            description: e.target.value,
          })
        }
      />

      <input
        className="w-full rounded border p-3"
        placeholder="لوگوی برند"
        value={form.logo}
        onChange={(e) =>
          setForm({
            ...form,
            logo: e.target.value,
          })
        }
      />

      <input
        type="number"
        className="w-full rounded border p-3"
        placeholder="ترتیب نمایش"
        value={form.sortOrder}
        onChange={(e) =>
          setForm({
            ...form,
            sortOrder: Number(e.target.value),
          })
        }
      />

      <label className="flex items-center gap-3">
        <input
          type="checkbox"
          checked={form.active}
          onChange={(e) =>
            setForm({
              ...form,
              active: e.target.checked,
            })
          }
        />
        برند فعال
      </label>

      <button
        disabled={loading}
        onClick={submit}
        className="rounded-lg bg-orange-500 px-6 py-3 text-white"
      >
        {loading ? "در حال ذخیره..." : "ذخیره برند"}
      </button>

    </div>
  );
}