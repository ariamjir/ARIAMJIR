"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

interface Hero {
  id: string;
  badge: string | null;
  title: string;
  subtitle: string | null;
  description: string | null;
  buttonText: string | null;
  buttonLink: string | null;
  secondButtonText: string | null;
  secondButtonLink: string | null;
  active: boolean;
}

interface Props {
  hero?: Hero;
}

export default function HeroForm({
  hero,
}: Props) {
  const router = useRouter();

  const editing = !!hero;

  const [loading, setLoading] =
    useState(false);

  const [form, setForm] = useState({
    badge: "",
    title: "",
    subtitle: "",
    description: "",
    buttonText: "",
    buttonLink: "",
    secondButtonText: "",
    secondButtonLink: "",
    active: true,
  });

  useEffect(() => {
    if (!hero) return;

    setForm({
      badge: hero.badge ?? "",
      title: hero.title,
      subtitle: hero.subtitle ?? "",
      description:
        hero.description ?? "",
      buttonText:
        hero.buttonText ?? "",
      buttonLink:
        hero.buttonLink ?? "",
      secondButtonText:
        hero.secondButtonText ?? "",
      secondButtonLink:
        hero.secondButtonLink ?? "",
      active: hero.active,
    });
  }, [hero]);

  function change(
    e: React.ChangeEvent<
      HTMLInputElement | HTMLTextAreaElement
    >
  ) {
    const { name, value } = e.target;

    setForm((prev) => ({
      ...prev,
      [name]: value,
    }));
  }

  function changeCheckbox(
    e: React.ChangeEvent<HTMLInputElement>
  ) {
    setForm((prev) => ({
      ...prev,
      active: e.target.checked,
    }));
  }

  async function submit(
    e: React.FormEvent
  ) {
    e.preventDefault();

    setLoading(true);

    try {
      const url = editing
        ? `/api/admin/hero/${hero.id}`
        : "/api/admin/hero";

      const method = editing
        ? "PUT"
        : "PATCH";

      const res = await fetch(url, {
        method,
        headers: {
          "Content-Type":
            "application/json",
        },
        body: JSON.stringify(form),
      });

      if (!res.ok) {
        throw new Error();
      }

      router.push("/admin/hero");
      router.refresh();

    } catch {
      alert("خطا در ذخیره اطلاعات");
    }

    setLoading(false);
  }

  return (
    <form
      onSubmit={submit}
      className="space-y-6 rounded-2xl bg-white p-8 shadow"
    >
      <div>
        <label className="mb-2 block font-bold">
          Badge
        </label>

        <input
          name="badge"
          value={form.badge}
          onChange={change}
          className="w-full rounded-xl border px-4 py-3"
          placeholder="Industrial Marketplace"
        />
      </div>

      <div>
        <label className="mb-2 block font-bold">
          عنوان
        </label>

        <input
          required
          name="title"
          value={form.title}
          onChange={change}
          className="w-full rounded-xl border px-4 py-3"
        />
      </div>

      <div>
        <label className="mb-2 block font-bold">
          زیرعنوان
        </label>

        <input
          name="subtitle"
          value={form.subtitle}
          onChange={change}
          className="w-full rounded-xl border px-4 py-3"
        />
      </div>

      <div>
        <label className="mb-2 block font-bold">
          توضیحات
        </label>

        <textarea
          rows={5}
          name="description"
          value={form.description}
          onChange={change}
          className="w-full rounded-xl border px-4 py-3"
        />
      </div>

            <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">

        <div>
          <label className="mb-2 block font-bold">
            متن دکمه اول
          </label>

          <input
            name="buttonText"
            value={form.buttonText}
            onChange={change}
            className="w-full rounded-xl border px-4 py-3"
          />
        </div>

        <div>
          <label className="mb-2 block font-bold">
            لینک دکمه اول
          </label>

          <input
            name="buttonLink"
            value={form.buttonLink}
            onChange={change}
            className="w-full rounded-xl border px-4 py-3"
            placeholder="/machines"
          />
        </div>

      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">

        <div>
          <label className="mb-2 block font-bold">
            متن دکمه دوم
          </label>

          <input
            name="secondButtonText"
            value={form.secondButtonText}
            onChange={change}
            className="w-full rounded-xl border px-4 py-3"
          />
        </div>

        <div>
          <label className="mb-2 block font-bold">
            لینک دکمه دوم
          </label>

          <input
            name="secondButtonLink"
            value={form.secondButtonLink}
            onChange={change}
            className="w-full rounded-xl border px-4 py-3"
            placeholder="/services"
          />
        </div>

      </div>

      <label className="flex items-center gap-3 rounded-xl border p-4">

        <input
          type="checkbox"
          checked={form.active}
          onChange={changeCheckbox}
        />

        <span className="font-medium">
          Hero فعال باشد
        </span>

      </label>

      <button
        type="submit"
        disabled={loading}
        className="
          w-full
          rounded-xl
          bg-orange-500
          py-4
          font-bold
          text-white
          transition
          hover:bg-orange-600
          disabled:cursor-not-allowed
          disabled:opacity-50
        "
      >
        {loading
          ? "در حال ذخیره..."
          : editing
          ? "ذخیره تغییرات"
          : "ایجاد Hero"}
      </button>

    </form>
  );
}