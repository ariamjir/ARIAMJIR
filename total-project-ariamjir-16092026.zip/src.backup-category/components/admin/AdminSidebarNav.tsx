"use client";

import { useState } from "react";

import Link from "next/link";
import { usePathname } from "next/navigation";

import {
  ChevronDown,
  LayoutDashboard,
  MonitorSmartphone,
  Wrench,
  Crown,
  Megaphone,
  Newspaper,
  BookOpen,
  Building2,
  FolderTree,
  Users,
  Settings,
  Share2,
} from "lucide-react";

/* ============================================================
   منوی سایدبار ادمین — گروه‌بندی‌شده سبک Shopify
   ✅ گارد کامل روی icon — هرگز crash نمی‌شود
============================================================ */

interface ChildItem {
  title: string;
  href: string;
}

interface MenuItem {
  title: string;
  href?: string;
  icon?: any;
  children?: ChildItem[];
}

const MENU: MenuItem[] = [
  { title: "داشبورد", href: "/admin/dashboard", icon: LayoutDashboard },
  {
    title: "صفحه اصلی",
    icon: MonitorSmartphone,
    children: [
      { title: "بخش‌ها و کارت‌ها", href: "/admin/home" },
      { title: "چیدمان صفحه اول", href: "/admin/homepage-layout" },
      { title: "منوی سایت", href: "/admin/menu" },
      { title: "هدر سایت", href: "/admin/home/header" },
      { title: "هیرو و اسلایدر", href: "/admin/home/hero" },
      { title: "فوتر", href: "/admin/home/footer" },
      { title: "آمار", href: "/admin/home/stats" },
      { title: "چرا ARIA MJ؟", href: "/admin/home/why-us" },
    ],
  },
  { title: "ماشین‌آلات", href: "/admin/machines", icon: Wrench },
  { title: "فروش ویژه آریا", href: "/admin/premium-listings", icon: Crown },
  { title: "آگهی‌ها", href: "/admin/ads", icon: Megaphone },
  { title: "اخبار", href: "/admin/news", icon: Newspaper },
  { title: "مرکز دانش", href: "/admin/knowledge", icon: BookOpen },
  { title: "خدمات", href: "/admin/services", icon: Wrench },
  {
    title: "برندها",
    icon: Building2,
    children: [
      { title: "مدیریت برندها", href: "/admin/brands" },
      { title: "برندهای صفحه اول + لوگو AI", href: "/admin/brands/home" },
    ],
  },
  { title: "دسته‌بندی‌ها", href: "/admin/categories", icon: FolderTree },
  { title: "کاربران", href: "/admin/users", icon: Users },
  { title: "انتشار اجتماعی", href: "/admin/social", icon: Share2 },
  { title: "تنظیمات", href: "/admin/settings", icon: Settings },
];

/* ✅ آیکون امن — rename به Icon (حرف بزرگ) تا TypeScript آن را component بداند */
function SafeIcon({ icon: Icon }: { icon?: any }) {
  if (!Icon) {
    return (
      <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-zinc-700 text-[10px] text-zinc-300">
        •
      </span>
    );
  }
  return <Icon size={19} className="shrink-0" />;
}

export default function AdminSidebarNav() {
  const pathname = usePathname();

  const [open, setOpen] = useState<string[]>(() =>
    MENU.filter((m) =>
      m.children?.some(
        (c) => pathname === c.href || pathname.startsWith(c.href + "/")
      )
    ).map((m) => m.title)
  );

  const toggle = (t: string) =>
    setOpen((o) => (o.includes(t) ? o.filter((x) => x !== t) : [...o, t]));

  return (
    <div className="space-y-1">
      {MENU.map((item) => {
        /* ---------- گروه جمع‌شونده ---------- */
        if (item.children) {
          const isOpen = open.includes(item.title);
          const groupActive = item.children.some(
            (c) => pathname === c.href || pathname.startsWith(c.href + "/")
          );

          return (
            <div key={item.title}>
              <button
                onClick={() => toggle(item.title)}
                className={`
                  flex
                  w-full
                  min-h-11
                  items-center
                  gap-3
                  rounded-xl
                  px-4
                  py-2.5
                  text-sm
                  font-medium
                  transition
                  ${
                    groupActive
                      ? "bg-zinc-800 text-white"
                      : "text-zinc-300 hover:bg-zinc-800 hover:text-white"
                  }
                `}
              >
                <SafeIcon icon={item.icon} />
                <span className="flex-1 truncate text-right">{item.title}</span>
                <ChevronDown
                  size={16}
                  className={`transition-transform ${isOpen ? "rotate-180" : ""}`}
                />
              </button>

              {isOpen && (
                <div className="mr-6 mt-1 space-y-1 border-r border-zinc-800 pr-3">
                  {item.children.map((c) => (
                    <Link
                      key={c.href}
                      href={c.href}
                      className={`
                        block
                        rounded-lg
                        px-3
                        py-2
                        text-[13px]
                        transition
                        ${
                          pathname === c.href
                            ? "bg-orange-500/15 font-bold text-orange-400"
                            : "text-zinc-400 hover:bg-zinc-800 hover:text-white"
                        }
                      `}
                    >
                      {c.title}
                    </Link>
                  ))}
                </div>
              )}
            </div>
          );
        }

        /* ---------- آیتم ساده ---------- */
        const active =
          pathname === item.href || pathname.startsWith(item.href + "/");

        return (
          <Link
            key={item.href}
            href={item.href!}
            className={`
              flex
              min-h-11
              items-center
              gap-3
              rounded-xl
              px-4
              py-2.5
              text-sm
              font-medium
              transition
              ${
                active
                  ? "bg-orange-500/15 text-orange-400"
                  : "text-zinc-300 hover:bg-zinc-800 hover:text-white"
              }
            `}
          >
            <SafeIcon icon={item.icon} />
            <span className="truncate">{item.title}</span>
          </Link>
        );
      })}
    </div>
  );
}