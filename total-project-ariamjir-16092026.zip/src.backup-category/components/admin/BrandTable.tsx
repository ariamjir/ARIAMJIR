"use client";

import Link from "next/link";

type Brand = {
  id: string;
  name: string;
  slug: string;
  logo: string | null;
  sortOrder: number;
  active: boolean;
};

type Props = {
  brands: Brand[];
  onDelete: (id: string) => void;
};

export default function BrandTable({
  brands,
  onDelete,
}: Props) {
  return (
    <div className="overflow-x-auto rounded-xl border bg-white">

      <table className="w-full">

        <thead className="bg-gray-100">

          <tr>
            <th className="p-4">لوگو</th>
            <th className="p-4">نام</th>
            <th className="p-4">Slug</th>
            <th className="p-4">ترتیب</th>
            <th className="p-4">وضعیت</th>
            <th className="p-4">عملیات</th>
          </tr>

        </thead>

        <tbody>

          {brands.map((brand) => (

            <tr
              key={brand.id}
              className="border-t"
            >

              <td className="p-4">

                {brand.logo ? (

                  <img
                    src={brand.logo}
                    className="h-12 w-12 rounded-lg object-contain"
                  />

                ) : (

                  <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-gray-200 text-xs">
                    -
                  </div>

                )}

              </td>

              <td className="p-4 font-medium">
                {brand.name}
              </td>

              <td className="p-4">
                {brand.slug}
              </td>

              <td className="p-4">
                {brand.sortOrder}
              </td>

              <td className="p-4">
                {brand.active ? "فعال" : "غیرفعال"}
              </td>

              <td className="p-4">

                <div className="flex gap-2">

                  <Link
                    href={`/admin/brands/edit/${brand.id}`}
                    className="rounded bg-blue-500 px-3 py-2 text-sm text-white"
                  >
                    ویرایش
                  </Link>

                  <button
                    onClick={() => onDelete(brand.id)}
                    className="rounded bg-red-500 px-3 py-2 text-sm text-white"
                  >
                    حذف
                  </button>

                </div>

              </td>

            </tr>

          ))}

        </tbody>

      </table>

    </div>
  );
}