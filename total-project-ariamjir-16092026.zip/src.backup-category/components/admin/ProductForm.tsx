"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

type Props = {
  productId?: string;
};

type ProductFormState = {
  title: string;
  slug: string;
  brand: string;
  category: string;
  description: string;
  image: string;
  price: string;
  stock: number;
  featured: boolean;
  active: boolean;
};

export default function ProductForm({
  productId,
}: Props) {
  const router = useRouter();

  const [loading, setLoading] = useState(false);

  const [uploading, setUploading] =
    useState(false);

  const [form, setForm] =
    useState<ProductFormState>({
      title: "",
      slug: "",
      brand: "",
      category: "",
      description: "",
      image: "",
      price: "",
      stock: 0,
      featured: false,
      active: true,
    });

  useEffect(() => {
    if (!productId) return;

    async function loadProduct() {
      try {
        const res = await fetch(
          `/api/admin/products/${productId}`
        );

        if (!res.ok) return;

        const data = await res.json();

        setForm({
          title: data.title ?? "",
          slug: data.slug ?? "",
          brand: data.brand ?? "",
          category: data.category ?? "",
          description:
            data.description ?? "",
          image: data.image ?? "",
          price:
            data.price != null
              ? String(data.price)
              : "",
          stock: data.stock ?? 0,
          featured:
            data.featured ?? false,
          active:
            data.active ?? true,
        });
      } catch (err) {
        console.error(err);
      }
    }

    loadProduct();
  }, [productId]);

  async function uploadImage(
    file: File
  ) {
    setUploading(true);

    try {
      const formData =
        new FormData();

      formData.append(
        "file",
        file
      );

      const res = await fetch(
        "/api/admin/upload",
        {
          method: "POST",
          body: formData,
        }
      );

      const data =
        await res.json();

      setForm((prev) => ({
        ...prev,
        image: data.url,
      }));
    } catch (err) {
      console.error(err);
      alert("خطا در آپلود تصویر");
    }

    setUploading(false);
  }

  async function submit() {
    setLoading(true);

    const url = productId
      ? `/api/admin/products/${productId}`
      : "/api/admin/products";

    const method = productId
      ? "PUT"
      : "POST";

    try {
      await fetch(url, {
        method,
        headers: {
          "Content-Type":
            "application/json",
        },
        body: JSON.stringify({
          ...form,
          price:
            form.price === ""
              ? null
              : Number(form.price),
        }),
      });

      router.push(
        "/admin/products"
      );

      router.refresh();
    } catch (err) {
      console.error(err);
    }

    setLoading(false);
    }
      return (
    <div className="space-y-6 rounded-xl border bg-white p-6 shadow-sm">

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">

        <div>
          <label className="mb-2 block font-medium">
            عنوان محصول
          </label>

          <input
            className="w-full rounded-lg border p-3"
            value={form.title}
            onChange={(e) =>
              setForm({
                ...form,
                title: e.target.value,
              })
            }
          />
        </div>

        <div>
          <label className="mb-2 block font-medium">
            Slug
          </label>

          <input
            className="w-full rounded-lg border p-3"
            value={form.slug}
            onChange={(e) =>
              setForm({
                ...form,
                slug: e.target.value,
              })
            }
          />
        </div>

        <div>
          <label className="mb-2 block font-medium">
            برند
          </label>

          <input
            className="w-full rounded-lg border p-3"
            value={form.brand}
            onChange={(e) =>
              setForm({
                ...form,
                brand: e.target.value,
              })
            }
          />
        </div>

        <div>
          <label className="mb-2 block font-medium">
            دسته‌بندی
          </label>

          <input
            className="w-full rounded-lg border p-3"
            value={form.category}
            onChange={(e) =>
              setForm({
                ...form,
                category: e.target.value,
              })
            }
          />
        </div>

        <div>
          <label className="mb-2 block font-medium">
            قیمت
          </label>

          <input
            type="number"
            className="w-full rounded-lg border p-3"
            value={form.price}
            onChange={(e) =>
              setForm({
                ...form,
                price: e.target.value,
              })
            }
          />
        </div>

        <div>
          <label className="mb-2 block font-medium">
            موجودی
          </label>

          <input
            type="number"
            className="w-full rounded-lg border p-3"
            value={form.stock}
            onChange={(e) =>
              setForm({
                ...form,
                stock: Number(e.target.value),
              })
            }
          />
        </div>

      </div>

      <div>

        <label className="mb-2 block font-medium">
          توضیحات
        </label>

        <textarea
          rows={8}
          className="w-full rounded-lg border p-3"
          value={form.description}
          onChange={(e) =>
            setForm({
              ...form,
              description:
                e.target.value,
            })
          }
        />

      </div>

      <div className="space-y-3">

        <label className="block font-medium">
          تصویر محصول
        </label>

        <input
          type="file"
          accept="image/*"
          onChange={(e) => {
            const file =
              e.target.files?.[0];

            if (file) {
              uploadImage(file);
            }
          }}
        />

        {uploading && (
          <div className="rounded-lg bg-orange-100 p-3 text-sm text-orange-700">
            در حال آپلود تصویر...
          </div>
        )}

        {form.image && (
          <img
            src={form.image}
            alt="preview"
            className="h-56 rounded-lg border object-cover"
          />
        )}

      </div>

      <div className="flex flex-wrap gap-6">

        <label className="flex items-center gap-2">

          <input
            type="checkbox"
            checked={form.featured}
            onChange={(e) =>
              setForm({
                ...form,
                featured:
                  e.target.checked,
              })
            }
          />

          محصول ویژه

        </label>

        <label className="flex items-center gap-2">

          <input
            type="checkbox"
            checked={form.active}
            onChange={(e) =>
              setForm({
                ...form,
                active:
                  e.target.checked,
              })
            }
          />

          فعال

        </label>

      </div>
            <div className="flex justify-end">

        <button
          type="button"
          disabled={loading || uploading}
          onClick={submit}
          className="rounded-lg bg-orange-500 px-8 py-3 font-medium text-white transition hover:bg-orange-600 disabled:cursor-not-allowed disabled:opacity-60"
        >
          {loading
            ? "در حال ذخیره..."
            : productId
            ? "بروزرسانی محصول"
            : "ذخیره محصول"}
        </button>

      </div>

    </div>
  );
}