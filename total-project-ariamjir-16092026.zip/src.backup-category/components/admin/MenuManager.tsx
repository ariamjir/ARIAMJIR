"use client";

import {
  useCallback,
  useEffect,
  useMemo,
  useState,
} from "react";

import {
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Edit3,
  ExternalLink,
  GripVertical,
  Menu as MenuIcon,
  Plus,
  Save,
  Trash2,
  X,
} from "lucide-react";

interface Category {
  id: string;
  name: string;
  slug: string;
}

interface MenuItem {
  id: string;
  title: string;
  href: string | null;
  parentId: string | null;
  type: string;
  icon: string | null;
  categoryId: string | null;
  sortOrder: number;
  active: boolean;
  showDesktop: boolean;
  showMobile: boolean;
  openInNewTab: boolean;
  megaMenu: boolean;

  category?: {
    id: string;
    name: string;
    slug: string;
  } | null;
}

interface FormValues {
  title: string;
  href: string;
  parentId: string;
  type: string;
  icon: string;
  categoryId: string;
  sortOrder: number;
  active: boolean;
  showDesktop: boolean;
  showMobile: boolean;
  openInNewTab: boolean;
  megaMenu: boolean;
}

const emptyForm: FormValues = {
  title: "",
  href: "",
  parentId: "",
  type: "LINK",
  icon: "",
  categoryId: "",
  sortOrder: 1,
  active: true,
  showDesktop: true,
  showMobile: true,
  openInNewTab: false,
  megaMenu: false,
};

export default function MenuManager() {
  const [items, setItems] = useState<MenuItem[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);

  const [loading, setLoading] = useState(true);

  const [saving, setSaving] = useState(false);

  const [error, setError] = useState<string | null>(
    null,
  );

  const [editingId, setEditingId] = useState<string | null>(
    null,
  );

  const [showForm, setShowForm] = useState(false);

  const [form, setForm] = useState<FormValues>(
    emptyForm,
  );

  /* =========================================================
     LOAD
  ========================================================= */

  const load = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);

      const response = await fetch(
        "/api/admin/menu",
        {
          cache: "no-store",
        },
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data?.error ||
            "خطا در دریافت منو",
        );
      }

      setItems(
        Array.isArray(data.items)
          ? data.items
          : [],
      );

      setCategories(
        Array.isArray(data.categories)
          ? data.categories
          : [],
      );
    } catch (error) {
      console.error(
        "[MenuManager]",
        error,
      );

      setError(
        error instanceof Error
          ? error.message
          : "خطا در دریافت منو",
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  /* =========================================================
     TREE
  ========================================================= */

  const childrenMap = useMemo(() => {
    const map = new Map<
      string | null,
      MenuItem[]
    >();

    for (const item of items) {
      const key = item.parentId;

      const list = map.get(key) ?? [];

      list.push(item);

      map.set(key, list);
    }

    for (const list of map.values()) {
      list.sort(
        (a, b) =>
          a.sortOrder - b.sortOrder,
      );
    }

    return map;
  }, [items]);

  /* =========================================================
     EDIT
  ========================================================= */

  function startCreate() {
    const roots =
      childrenMap.get(null) ?? [];

    setEditingId(null);

    setForm({
      ...emptyForm,
      sortOrder:
        roots.length > 0
          ? Math.max(
              ...roots.map(
                (item) =>
                  item.sortOrder,
              ),
            ) + 1
          : 1,
    });

    setShowForm(true);
  }

  function startEdit(item: MenuItem) {
    setEditingId(item.id);

    setForm({
      title: item.title,
      href: item.href ?? "",
      parentId: item.parentId ?? "",
      type: item.type,
      icon: item.icon ?? "",
      categoryId:
        item.categoryId ?? "",
      sortOrder: item.sortOrder,
      active: item.active,
      showDesktop: item.showDesktop,
      showMobile: item.showMobile,
      openInNewTab:
        item.openInNewTab,
      megaMenu: item.megaMenu,
    });

    setShowForm(true);
  }

  function closeForm() {
    if (saving) return;

    setShowForm(false);
    setEditingId(null);
    setForm(emptyForm);
  }

  /* =========================================================
     SAVE
  ========================================================= */

  async function saveItem() {
    if (!form.title.trim()) {
      setError(
        "عنوان منو را وارد کنید.",
      );
      return;
    }

    try {
      setSaving(true);
      setError(null);

      const payload = {
        ...form,
        title: form.title.trim(),
        href:
          form.href.trim() || null,
        icon:
          form.icon.trim() || null,
        parentId:
          form.parentId || null,
        categoryId:
          form.categoryId || null,
      };

      const response = await fetch(
        "/api/admin/menu",
        {
          method: editingId
            ? "PATCH"
            : "POST",

          headers: {
            "Content-Type":
              "application/json",
          },

          body: JSON.stringify(
            editingId
              ? {
                  id: editingId,
                  ...payload,
                }
              : payload,
          ),
        },
      );

      const data =
        await response.json();

      if (!response.ok) {
        throw new Error(
          data?.error ||
            "خطا در ذخیره منو",
        );
      }

      await load();

      closeForm();
    } catch (error) {
      console.error(
        "[MenuManager.save]",
        error,
      );

      setError(
        error instanceof Error
          ? error.message
          : "خطا در ذخیره منو",
      );
    } finally {
      setSaving(false);
    }
  }

  /* =========================================================
     DELETE
  ========================================================= */

  async function deleteItem(
    item: MenuItem,
  ) {
    const hasChildren =
      items.some(
        (child) =>
          child.parentId === item.id,
      );

    const message = hasChildren
      ? `آیتم «${item.title}» دارای زیرمنو است. با حذف آن تمام زیرمنوهایش نیز حذف می‌شوند. ادامه می‌دهید؟`
      : `آیا از حذف «${item.title}» مطمئن هستید؟`;

    if (!window.confirm(message)) {
      return;
    }

    try {
      setError(null);

      const response = await fetch(
        "/api/admin/menu",
        {
          method: "DELETE",

          headers: {
            "Content-Type":
              "application/json",
          },

          body: JSON.stringify({
            id: item.id,
          }),
        },
      );

      const data =
        await response.json();

      if (!response.ok) {
        throw new Error(
          data?.error ||
            "خطا در حذف منو",
        );
      }

      await load();
    } catch (error) {
      console.error(
        "[MenuManager.delete]",
        error,
      );

      setError(
        error instanceof Error
          ? error.message
          : "خطا در حذف منو",
      );
    }
  }

  /* =========================================================
     TOGGLE
  ========================================================= */

  async function toggleActive(
    item: MenuItem,
  ) {
    try {
      const response = await fetch(
        "/api/admin/menu",
        {
          method: "PATCH",

          headers: {
            "Content-Type":
              "application/json",
          },

          body: JSON.stringify({
            id: item.id,
            active: !item.active,
          }),
        },
      );

      if (!response.ok) {
        throw new Error(
          "خطا در تغییر وضعیت",
        );
      }

      await load();
    } catch (error) {
      console.error(error);

      setError(
        "تغییر وضعیت منو انجام نشد.",
      );
    }
  }

  /* =========================================================
     MOVE
  ========================================================= */

  async function moveItem(
    item: MenuItem,
    direction: "up" | "down",
  ) {
    const siblings = [
      ...(childrenMap.get(
        item.parentId,
      ) ?? []),
    ].sort(
      (a, b) =>
        a.sortOrder -
        b.sortOrder,
    );

    const index =
      siblings.findIndex(
        (x) => x.id === item.id,
      );

    const targetIndex =
      direction === "up"
        ? index - 1
        : index + 1;

    if (
      index < 0 ||
      targetIndex < 0 ||
      targetIndex >= siblings.length
    ) {
      return;
    }

    const target =
      siblings[targetIndex];

    try {
      const response =
        await Promise.all([
          fetch(
            "/api/admin/menu",
            {
              method: "PATCH",
              headers: {
                "Content-Type":
                  "application/json",
              },
              body: JSON.stringify({
                id: item.id,
                sortOrder:
                  target.sortOrder,
              }),
            },
          ),

          fetch(
            "/api/admin/menu",
            {
              method: "PATCH",
              headers: {
                "Content-Type":
                  "application/json",
              },
              body: JSON.stringify({
                id: target.id,
                sortOrder:
                  item.sortOrder,
              }),
            },
          ),
        ]);

      if (
        response.some(
          (res) => !res.ok,
        )
      ) {
        throw new Error(
          "خطا در تغییر ترتیب",
        );
      }

      await load();
    } catch (error) {
      console.error(error);

      setError(
        "تغییر ترتیب منو انجام نشد.",
      );
    }
  }

  /* =========================================================
     RENDER TREE
  ========================================================= */

  function renderItems(
    parentId: string | null,
    depth = 0,
  ) {
    const list =
      childrenMap.get(parentId) ?? [];

    return list.map(
      (item, index) => {
        const children =
          childrenMap.get(
            item.id,
          ) ?? [];

        return (
          <div key={item.id}>
            <div
              className="
                group
                flex
                items-center
                gap-3
                rounded-2xl
                border
                border-zinc-200
                bg-white
                px-4
                py-3
                shadow-sm
                transition
                hover:border-orange-200
                hover:shadow-md
              "
              style={{
                marginRight:
                  depth * 32,
              }}
            >
              {/* Drag indicator */}

              <div className="text-zinc-300">
                <GripVertical
                  size={18}
                />
              </div>

              {/* Arrow */}

              <div
                className={`
                  flex
                  h-9
                  w-9
                  shrink-0
                  items-center
                  justify-center
                  rounded-lg
                  ${
                    depth > 0
                      ? "bg-zinc-100 text-zinc-500"
                      : "bg-orange-50 text-orange-500"
                  }
                `}
              >
                {children.length >
                0 ? (
                  <ChevronDown
                    size={18}
                  />
                ) : (
                  <MenuIcon
                    size={17}
                  />
                )}
              </div>

              {/* Title */}

              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <span
                    className="
                      truncate
                      font-bold
                      text-zinc-800
                    "
                  >
                    {item.title}
                  </span>

                  {depth > 0 && (
                    <span
                      className="
                        rounded-full
                        bg-zinc-100
                        px-2
                        py-0.5
                        text-[10px]
                        font-bold
                        text-zinc-500
                      "
                    >
                      زیرمنو
                    </span>
                  )}

                  {item.megaMenu && (
                    <span
                      className="
                        rounded-full
                        bg-orange-100
                        px-2
                        py-0.5
                        text-[10px]
                        font-bold
                        text-orange-600
                      "
                    >
                      Mega
                    </span>
                  )}
                </div>

                <div className="mt-1 flex items-center gap-3 text-xs text-zinc-400">
                  <span>
                    {item.href ||
                      "بدون لینک"}
                  </span>

                  {item.category && (
                    <span>
                      دسته:
                      {" "}
                      {
                        item.category
                          .name
                      }
                    </span>
                  )}
                </div>
              </div>

              {/* Desktop */}

              <span
                className={`
                  hidden
                  rounded-full
                  px-2.5
                  py-1
                  text-[10px]
                  font-bold
                  md:inline-flex
                  ${
                    item.showDesktop
                      ? "bg-blue-50 text-blue-600"
                      : "bg-zinc-100 text-zinc-400"
                  }
                `}
              >
                دسکتاپ
              </span>

              {/* Mobile */}

              <span
                className={`
                  hidden
                  rounded-full
                  px-2.5
                  py-1
                  text-[10px]
                  font-bold
                  lg:inline-flex
                  ${
                    item.showMobile
                      ? "bg-purple-50 text-purple-600"
                      : "bg-zinc-100 text-zinc-400"
                  }
                `}
              >
                موبایل
              </span>

              {/* Active */}

              <button
                type="button"
                onClick={() =>
                  toggleActive(
                    item,
                  )
                }
                className={`
                  rounded-full
                  px-3
                  py-1.5
                  text-xs
                  font-bold
                  transition
                  ${
                    item.active
                      ? "bg-green-50 text-green-600 hover:bg-green-100"
                      : "bg-red-50 text-red-500 hover:bg-red-100"
                  }
                `}
              >
                {item.active
                  ? "فعال"
                  : "غیرفعال"}
              </button>

              {/* Ordering */}

              <div
                className="
                  hidden
                  items-center
                  gap-1
                  xl:flex
                "
              >
                <button
                  type="button"
                  disabled={
                    index === 0
                  }
                  onClick={() =>
                    moveItem(
                      item,
                      "up",
                    )
                  }
                  className="
                    rounded-lg
                    p-2
                    text-zinc-400
                    transition
                    hover:bg-zinc-100
                    hover:text-zinc-800
                    disabled:opacity-30
                  "
                  title="بالا"
                >
                  <ChevronRight
                    size={17}
                  />
                </button>

                <button
                  type="button"
                  disabled={
                    index ===
                    list.length - 1
                  }
                  onClick={() =>
                    moveItem(
                      item,
                      "down",
                    )
                  }
                  className="
                    rounded-lg
                    p-2
                    text-zinc-400
                    transition
                    hover:bg-zinc-100
                    hover:text-zinc-800
                    disabled:opacity-30
                  "
                  title="پایین"
                >
                  <ChevronLeft
                    size={17}
                  />
                </button>
              </div>

              {/* Edit */}

              <button
                type="button"
                onClick={() =>
                  startEdit(
                    item,
                  )
                }
                className="
                  rounded-xl
                  p-2.5
                  text-zinc-500
                  transition
                  hover:bg-orange-50
                  hover:text-orange-500
                "
                title="ویرایش"
              >
                <Edit3 size={17} />
              </button>

              {/* Delete */}

              <button
                type="button"
                onClick={() =>
                  deleteItem(
                    item,
                  )
                }
                className="
                  rounded-xl
                  p-2.5
                  text-zinc-500
                  transition
                  hover:bg-red-50
                  hover:text-red-500
                "
                title="حذف"
              >
                <Trash2 size={17} />
              </button>
            </div>

            {children.length > 0 && (
              <div className="mt-2 space-y-2">
                {renderItems(
                  item.id,
                  depth + 1,
                )}
              </div>
            )}
          </div>
        );
      },
    );
  }

  /* =========================================================
     LOADING
  ========================================================= */

  if (loading) {
    return (
      <div
        className="
          rounded-3xl
          border
          border-zinc-200
          bg-white
          p-10
          text-center
        "
      >
        <div
          className="
            mx-auto
            h-8
            w-8
            animate-spin
            rounded-full
            border-2
            border-zinc-200
            border-t-orange-500
          "
        />

        <p className="mt-4 text-sm text-zinc-500">
          در حال دریافت منوی سایت...
        </p>
      </div>
    );
  }

  /* =========================================================
     UI
  ========================================================= */

  return (
    <div className="space-y-6">
      {/* Error */}

      {error && (
        <div
          className="
            flex
            items-center
            justify-between
            rounded-2xl
            border
            border-red-200
            bg-red-50
            px-5
            py-4
            text-sm
            font-medium
            text-red-600
          "
        >
          <span>{error}</span>

          <button
            type="button"
            onClick={() =>
              setError(null)
            }
          >
            <X size={18} />
          </button>
        </div>
      )}

      {/* Header */}

      <div
        className="
          flex
          flex-col
          gap-4
          rounded-3xl
          border
          border-zinc-200
          bg-white
          p-6
          shadow-sm
          sm:flex-row
          sm:items-center
          sm:justify-between
        "
      >
        <div>
          <h2 className="text-xl font-black text-zinc-900">
            منوی سایت
          </h2>

          <p className="mt-1 text-sm text-zinc-500">
            {items.length} آیتم در منوی سایت
          </p>
        </div>

        <button
          type="button"
          onClick={startCreate}
          className="
            inline-flex
            items-center
            justify-center
            gap-2
            rounded-xl
            bg-orange-500
            px-5
            py-3
            text-sm
            font-black
            text-white
            shadow-lg
            shadow-orange-500/20
            transition
            hover:bg-orange-600
          "
        >
          <Plus size={18} />

          افزودن آیتم منو
        </button>
      </div>

      {/* Tree */}

      <div
        className="
          rounded-3xl
          border
          border-zinc-200
          bg-zinc-50
          p-4
          shadow-sm
        "
      >
        {items.length === 0 ? (
          <div className="py-20 text-center">
            <MenuIcon
              size={40}
              className="mx-auto text-zinc-300"
            />

            <p className="mt-4 font-bold text-zinc-600">
              هنوز آیتمی برای منو ثبت نشده است.
            </p>

            <button
              type="button"
              onClick={startCreate}
              className="
                mt-5
                rounded-xl
                bg-orange-500
                px-5
                py-3
                text-sm
                font-bold
                text-white
              "
            >
              اولین آیتم را ایجاد کنید
            </button>
          </div>
        ) : (
          <div className="space-y-2">
            {renderItems(null)}
          </div>
        )}
      </div>

      {/* =====================================================
          FORM
      ===================================================== */}

      {showForm && (
        <div
          className="
            fixed
            inset-0
            z-[200]
            flex
            items-center
            justify-center
            bg-black/60
            p-4
            backdrop-blur-sm
          "
        >
          <div
            className="
              max-h-[92vh]
              w-full
              max-w-3xl
              overflow-y-auto
              rounded-3xl
              bg-white
              shadow-2xl
            "
          >
            {/* Form header */}

            <div
              className="
                sticky
                top-0
                z-10
                flex
                items-center
                justify-between
                border-b
                border-zinc-200
                bg-white
                px-6
                py-5
              "
            >
              <div>
                <h3 className="text-xl font-black text-zinc-900">
                  {editingId
                    ? "ویرایش آیتم منو"
                    : "افزودن آیتم منو"}
                </h3>

                <p className="mt-1 text-xs text-zinc-500">
                  تنظیم ساختار و نحوه نمایش آیتم
                </p>
              </div>

              <button
                type="button"
                onClick={closeForm}
                className="
                  rounded-xl
                  p-2
                  text-zinc-400
                  hover:bg-zinc-100
                  hover:text-zinc-700
                "
              >
                <X size={20} />
              </button>
            </div>

            <div className="space-y-6 p-6">
              {/* Title */}

              <div>
                <label className="mb-2 block text-sm font-bold text-zinc-700">
                  عنوان منو
                </label>

                <input
                  value={form.title}
                  onChange={(event) =>
                    setForm({
                      ...form,
                      title:
                        event.target
                          .value,
                    })
                  }
                  placeholder="مثلاً ماشین‌آلات"
                  className="
                    w-full
                    rounded-xl
                    border
                    border-zinc-200
                    bg-zinc-50
                    px-4
                    py-3
                    text-sm
                    outline-none
                    transition
                    focus:border-orange-500
                    focus:bg-white
                  "
                />
              </div>

              {/* Link */}

              <div>
                <label className="mb-2 block text-sm font-bold text-zinc-700">
                  لینک
                </label>

                <input
                  dir="ltr"
                  value={form.href}
                  onChange={(event) =>
                    setForm({
                      ...form,
                      href:
                        event.target
                          .value,
                    })
                  }
                  placeholder="/machines"
                  className="
                    w-full
                    rounded-xl
                    border
                    border-zinc-200
                    bg-zinc-50
                    px-4
                    py-3
                    text-left
                    text-sm
                    outline-none
                    transition
                    focus:border-orange-500
                    focus:bg-white
                  "
                />
              </div>

              {/* Parent + Type */}

              <div className="grid gap-5 md:grid-cols-2">
                <div>
                  <label className="mb-2 block text-sm font-bold text-zinc-700">
                    آیتم والد
                  </label>

                  <select
                    value={
                      form.parentId
                    }
                    onChange={(
                      event,
                    ) =>
                      setForm({
                        ...form,
                        parentId:
                          event.target
                            .value,
                      })
                    }
                    className="
                      w-full
                      rounded-xl
                      border
                      border-zinc-200
                      bg-zinc-50
                      px-4
                      py-3
                      text-sm
                      outline-none
                      focus:border-orange-500
                    "
                  >
                    <option value="">
                      منوی اصلی
                    </option>

                    {items
                      .filter(
                        (item) =>
                          item.id !==
                          editingId,
                      )
                      .map(
                        (item) => (
                          <option
                            key={
                              item.id
                            }
                            value={
                              item.id
                            }
                          >
                            {item.parentId
                              ? "↳ "
                              : ""}
                            {
                              item.title
                            }
                          </option>
                        ),
                      )}
                  </select>
                </div>

                <div>
                  <label className="mb-2 block text-sm font-bold text-zinc-700">
                    نوع
                  </label>

                  <select
                    value={form.type}
                    onChange={(
                      event,
                    ) =>
                      setForm({
                        ...form,
                        type:
                          event.target
                            .value,
                      })
                    }
                    className="
                      w-full
                      rounded-xl
                      border
                      border-zinc-200
                      bg-zinc-50
                      px-4
                      py-3
                      text-sm
                      outline-none
                      focus:border-orange-500
                    "
                  >
                    <option value="LINK">
                      لینک
                    </option>

                    <option value="CATEGORY">
                      دسته‌بندی
                    </option>

                    <option value="MEGA">
                      Mega Menu
                    </option>

                    <option value="CUSTOM">
                      سفارشی
                    </option>
                  </select>
                </div>
              </div>

              {/* Category */}

              <div>
                <label className="mb-2 block text-sm font-bold text-zinc-700">
                  اتصال به دسته‌بندی
                </label>

                <select
                  value={
                    form.categoryId
                  }
                  onChange={(
                    event,
                  ) =>
                    setForm({
                      ...form,
                      categoryId:
                        event.target
                          .value,
                    })
                  }
                  className="
                    w-full
                    rounded-xl
                    border
                    border-zinc-200
                    bg-zinc-50
                    px-4
                    py-3
                    text-sm
                    outline-none
                    focus:border-orange-500
                  "
                >
                  <option value="">
                    بدون اتصال به دسته‌بندی
                  </option>

                  {categories.map(
                    (category) => (
                      <option
                        key={
                          category.id
                        }
                        value={
                          category.id
                        }
                      >
                        {
                          category.name
                        }
                      </option>
                    ),
                  )}
                </select>
              </div>

              {/* Icon + Order */}

              <div className="grid gap-5 md:grid-cols-2">
                <div>
                  <label className="mb-2 block text-sm font-bold text-zinc-700">
                    آیکون
                  </label>

                  <input
                    value={form.icon}
                    onChange={(
                      event,
                    ) =>
                      setForm({
                        ...form,
                        icon:
                          event.target
                            .value,
                      })
                    }
                    placeholder="مثلاً Truck"
                    className="
                      w-full
                      rounded-xl
                      border
                      border-zinc-200
                      bg-zinc-50
                      px-4
                      py-3
                      text-sm
                      outline-none
                      focus:border-orange-500
                    "
                  />
                </div>

                <div>
                  <label className="mb-2 block text-sm font-bold text-zinc-700">
                    ترتیب
                  </label>

                  <input
                    type="number"
                    value={
                      form.sortOrder
                    }
                    onChange={(
                      event,
                    ) =>
                      setForm({
                        ...form,
                        sortOrder:
                          Number(
                            event.target
                              .value,
                          ),
                      })
                    }
                    className="
                      w-full
                      rounded-xl
                      border
                      border-zinc-200
                      bg-zinc-50
                      px-4
                      py-3
                      text-sm
                      outline-none
                      focus:border-orange-500
                    "
                  />
                </div>
              </div>

              {/* Options */}

              <div
                className="
                  grid
                  gap-3
                  rounded-2xl
                  border
                  border-zinc-200
                  bg-zinc-50
                  p-5
                  sm:grid-cols-2
                "
              >
                <label className="flex cursor-pointer items-center gap-3">
                  <input
                    type="checkbox"
                    checked={
                      form.active
                    }
                    onChange={(
                      event,
                    ) =>
                      setForm({
                        ...form,
                        active:
                          event.target
                            .checked,
                      })
                    }
                    className="h-4 w-4 accent-orange-500"
                  />

                  <span className="text-sm font-bold text-zinc-700">
                    فعال
                  </span>
                </label>

                <label className="flex cursor-pointer items-center gap-3">
                  <input
                    type="checkbox"
                    checked={
                      form.showDesktop
                    }
                    onChange={(
                      event,
                    ) =>
                      setForm({
                        ...form,
                        showDesktop:
                          event.target
                            .checked,
                      })
                    }
                    className="h-4 w-4 accent-orange-500"
                  />

                  <span className="text-sm font-bold text-zinc-700">
                    نمایش در دسکتاپ
                  </span>
                </label>

                <label className="flex cursor-pointer items-center gap-3">
                  <input
                    type="checkbox"
                    checked={
                      form.showMobile
                    }
                    onChange={(
                      event,
                    ) =>
                      setForm({
                        ...form,
                        showMobile:
                          event.target
                            .checked,
                      })
                    }
                    className="h-4 w-4 accent-orange-500"
                  />

                  <span className="text-sm font-bold text-zinc-700">
                    نمایش در موبایل
                  </span>
                </label>

                <label className="flex cursor-pointer items-center gap-3">
                  <input
                    type="checkbox"
                    checked={
                      form.openInNewTab
                    }
                    onChange={(
                      event,
                    ) =>
                      setForm({
                        ...form,
                        openInNewTab:
                          event.target
                            .checked,
                      })
                    }
                    className="h-4 w-4 accent-orange-500"
                  />

                  <span className="text-sm font-bold text-zinc-700">
                    باز شدن در تب جدید
                  </span>
                </label>

                <label className="flex cursor-pointer items-center gap-3 sm:col-span-2">
                  <input
                    type="checkbox"
                    checked={
                      form.megaMenu
                    }
                    onChange={(
                      event,
                    ) =>
                      setForm({
                        ...form,
                        megaMenu:
                          event.target
                            .checked,
                      })
                    }
                    className="h-4 w-4 accent-orange-500"
                  />

                  <span className="text-sm font-bold text-zinc-700">
                    فعال‌سازی Mega Menu
                  </span>
                </label>
              </div>
            </div>

            {/* Form actions */}

            <div
              className="
                flex
                items-center
                justify-end
                gap-3
                border-t
                border-zinc-200
                bg-zinc-50
                px-6
                py-4
              "
            >
              <button
                type="button"
                onClick={closeForm}
                disabled={saving}
                className="
                  rounded-xl
                  border
                  border-zinc-200
                  bg-white
                  px-5
                  py-3
                  text-sm
                  font-bold
                  text-zinc-600
                  hover:bg-zinc-100
                "
              >
                انصراف
              </button>

              <button
                type="button"
                onClick={saveItem}
                disabled={saving}
                className="
                  inline-flex
                  items-center
                  gap-2
                  rounded-xl
                  bg-orange-500
                  px-6
                  py-3
                  text-sm
                  font-black
                  text-white
                  shadow-lg
                  shadow-orange-500/20
                  transition
                  hover:bg-orange-600
                  disabled:cursor-not-allowed
                  disabled:opacity-50
                "
              >
                <Save size={17} />

                {saving
                  ? "در حال ذخیره..."
                  : "ذخیره آیتم"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}