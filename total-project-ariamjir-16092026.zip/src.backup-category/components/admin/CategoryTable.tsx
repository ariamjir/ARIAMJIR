"use client";

import Link from "next/link";

type Category = {
  id: string;
  name: string;
  slug: string;
  icon: string | null;
  sortOrder: number;
  active: boolean;
};

type Props = {
  categories: Category[];
  onDelete: (id: string) => void;
};

export default function CategoryTable({
  categories,
  onDelete,
}: Props) {
  return (
    <div className="overflow-x-auto rounded-xl border bg-white">
      <table className="w-full">

        <thead className="bg-gray-100">
          <tr>
            <th className="p-4">آیکون</th>
            <th className="p-4">نام</th>
            <th className="p-4">Slug</th>
            <th className="p-4">ترتیب</th>
            <th className="p-4">وضعیت</th>
            <th className="p-4">عملیات</th>
          </tr>
        </thead>

        <tbody>

          {categories.map((category) => (

            <tr key={category.id} className="border-t">

              <td className="p-4">
                {category.icon ? (
                  <img
                    src={category.icon}
                    className="h-10 w-10 rounded-lg object-contain"
                  />
                ) : (
                  <div className="flex h-10 w-10 items-center justify-center rounded bg-gray-200">
                    -
                  </div>
                )}
              </td>

              <td className="p-4">{category.name}</td>

              <td className="p-4">{category.slug}</td>

              <td className="p-4">{category.sortOrder}</td>

              <td className="p-4">
                {category.active ? "فعال" : "غیرفعال"}
              </td>

              <td className="p-4">

                <div className="flex gap-2">

                  <Link
                    href={`/admin/categories/edit/${category.id}`}
                    className="rounded bg-blue-600 px-3 py-2 text-sm text-white"
                  >
                    ویرایش
                  </Link>

                  <button
                    onClick={() => onDelete(category.id)}
                    className="rounded bg-red-600 px-3 py-2 text-sm text-white"
                  >
                    حذف
                  </button>

                </div>

              </td>

            </tr>

          ))}

        </tbody>

      </table>
    </div>
  );
}