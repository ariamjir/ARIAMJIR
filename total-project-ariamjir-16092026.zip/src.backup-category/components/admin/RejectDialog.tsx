"use client";

import { useState } from "react";

import { X, AlertTriangle } from "lucide-react";

interface Props {
  open: boolean;
  title: string;
  onClose: () => void;
  onConfirm: (reason: string) => Promise<void> | void;
}

const PRESETS = [
  "اطلاعات ناقص یا نادرست",
  "تصاویر نامناسب یا کیفیت پایین",
  "قیمت‌گذاری غیرمنطقی",
  "نقض قوانین سایت",
  "تکراری بودن آگهی",
];

export default function RejectDialog({
  open,
  title,
  onClose,
  onConfirm,
}: Props) {
  const [reason, setReason] = useState("");
  const [busy, setBusy] = useState(false);

  if (!open) return null;

  const submit = async () => {
    if (!reason.trim()) return alert("دلیل رد را بنویسید.");
    setBusy(true);
    try {
      await onConfirm(reason.trim());
      setReason("");
      onClose();
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
      <div className="w-full max-w-lg rounded-2xl bg-white p-6 shadow-2xl">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-2 text-red-600">
            <AlertTriangle className="h-5 w-5" />
            <h3 className="text-lg font-black text-zinc-800">رد آگهی</h3>
          </div>
          <button onClick={onClose} className="text-zinc-400 hover:text-zinc-600">
            <X className="h-5 w-5" />
          </button>
        </div>

        <p className="mt-2 text-sm text-zinc-600">
          آگهی <span className="font-bold">{title}</span> رد می‌شود و به فروشنده اطلاع داده خواهد شد.
        </p>

        <div className="mt-4">
          <div className="mb-1.5 text-xs font-bold text-zinc-600">
            دلایل سریع:
          </div>
          <div className="flex flex-wrap gap-2">
            {PRESETS.map((p) => (
              <button
                key={p}
                onClick={() => setReason(p)}
                className="rounded-full border border-zinc-200 bg-zinc-50 px-3 py-1 text-[11px] font-bold text-zinc-600 transition hover:border-red-300 hover:bg-red-50 hover:text-red-600"
              >
                {p}
              </button>
            ))}
          </div>
        </div>

        <div className="mt-4">
          <div className="mb-1.5 text-xs font-bold text-zinc-600">
            دلیل (الزامی):
          </div>
          <textarea
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            rows={3}
            placeholder="دلیل رد آگهی را به‌طور شفاف بنویسید..."
            className="w-full resize-none rounded-xl border border-zinc-200 px-3 py-2 text-sm outline-none focus:border-red-400"
          />
        </div>

        <div className="mt-5 flex items-center justify-end gap-3">
          <button
            onClick={onClose}
            disabled={busy}
            className="rounded-xl border border-zinc-200 bg-white px-5 py-2 text-sm font-bold text-zinc-600 transition hover:border-zinc-300 disabled:opacity-60"
          >
            انصراف
          </button>
          <button
            onClick={submit}
            disabled={busy}
            className="rounded-xl bg-red-600 px-5 py-2 text-sm font-black text-white shadow transition hover:bg-red-700 disabled:opacity-60"
          >
            {busy ? "در حال رد..." : "تأیید و رد"}
          </button>
        </div>
      </div>
    </div>
  );
}