/**
 * Temporary bridge
 * ---------------------------------------
 * All machine default values are now
 * maintained inside:
 *
 * src/modules/machine/data/defaultValues.ts
 *
 * This file exists only for backward
 * compatibility until the old admin
 * machine module is removed.
 */

export {
  machineDefaultValues,
} from "@/modules/machine/data/defaultValues";

