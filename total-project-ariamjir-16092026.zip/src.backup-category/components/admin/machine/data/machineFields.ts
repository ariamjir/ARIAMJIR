export interface MachineField {
  name: string;
  step: number;
}

export const machineFields: MachineField[] = [

  /* ============================
     Step 1
  ============================ */

  { name: "title", step: 1 },
  { name: "slug", step: 1 },
  { name: "listingType", step: 1 },
  { name: "brandId", step: 1 },
  { name: "categoryId", step: 1 },
  { name: "model", step: 1 },
  { name: "modelCode", step: 1 },
  { name: "condition", step: 1 },
  { name: "manufactureYear", step: 1 },
  { name: "description", step: 1 },

  /* ============================
     Step 2
  ============================ */

  { name: "country", step: 2 },
  { name: "provinceId", step: 2 },
  { name: "cityId", step: 2 },
  { name: "district", step: 2 },
  { name: "address", step: 2 },
  { name: "latitude", step: 2 },
  { name: "longitude", step: 2 },

  /* ============================
     Step 3
  ============================ */

  { name: "price", step: 3 },
  { name: "currency", step: 3 },
  { name: "negotiable", step: 3 },
  { name: "financing", step: 3 },
  { name: "installment", step: 3 },

  /* ============================
     Step 4
  ============================ */

  { name: "engine", step: 4 },
  { name: "engineBrand", step: 4 },
  { name: "engineModel", step: 4 },
  { name: "engineSerialNumber", step: 4 },
  { name: "enginePower", step: 4 },
  { name: "enginePowerUnit", step: 4 },
  { name: "fuelType", step: 4 },
  { name: "transmission", step: 4 },
  { name: "transmissionType", step: 4 },
  { name: "driveType", step: 4 },
  { name: "workingHours", step: 4 },
  { name: "engineHours", step: 4 },

  /* ============================
     Step 5
  ============================ */

  { name: "features", step: 5 },

  /* ============================
     Step 6
  ============================ */

  { name: "hydraulicPump", step: 6 },
  { name: "hydraulicPumpBrand", step: 6 },
  { name: "hydraulicPressure", step: 6 },
  { name: "hydraulicFlow", step: 6 },
  { name: "auxiliaryHydraulic", step: 6 },

  { name: "bucketCapacity", step: 6 },
  { name: "bucketUnit", step: 6 },
  { name: "liftingCapacity", step: 6 },
  { name: "payload", step: 6 },
  { name: "diggingDepth", step: 6 },
  { name: "dumpingHeight", step: 6 },
  { name: "reach", step: 6 },
  { name: "boomLength", step: 6 },
  { name: "armLength", step: 6 },
  { name: "maxDigDepth", step: 6 },
  { name: "maxReach", step: 6 },
  { name: "maxSpeed", step: 6 },

  /* ============================
     Step 7
  ============================ */

  { name: "operatingWeight", step: 7 },
  { name: "shippingWeight", step: 7 },
  { name: "length", step: 7 },
  { name: "width", step: 7 },
  { name: "height", step: 7 },
  { name: "wheelbase", step: 7 },
  { name: "groundClearance", step: 7 },

  { name: "batteryVoltage", step: 7 },
  { name: "alternator", step: 7 },
  { name: "starter", step: 7 },

  { name: "cabinType", step: 7 },
  { name: "seatType", step: 7 },
  { name: "airCondition", step: 7 },
  { name: "heater", step: 7 },
  { name: "radio", step: 7 },
  { name: "gps", step: 7 },
  { name: "camera360", step: 7 },

  { name: "tireSize", step: 7 },
  { name: "tireCondition", step: 7 },
  { name: "undercarriageCondition", step: 7 },

  /* ============================
     Step 8
  ============================ */

  { name: "coverImage", step: 8 },
  { name: "gallery", step: 8 },
  { name: "videos", step: 8 },
  { name: "documents", step: 8 },
  { name: "catalogs", step: 8 },
  { name: "brochure", step: 8 },
  { name: "manual", step: 8 },
  { name: "certificate", step: 8 },
  { name: "inspectionReport", step: 8 },
  { name: "invoiceFile", step: 8 },

  /* ============================
     Step 9
  ============================ */

  { name: "sellerFirstName", step: 9 },
  { name: "sellerLastName", step: 9 },
  { name: "sellerCompany", step: 9 },
  { name: "sellerPosition", step: 9 },
  { name: "sellerMobile", step: 9 },
  { name: "sellerPhone", step: 9 },
  { name: "sellerEmail", step: 9 },
  { name: "sellerCountry", step: 9 },
  { name: "sellerProvince", step: 9 },
  { name: "sellerCity", step: 9 },
  { name: "sellerAddress", step: 9 },
  { name: "sellerWebsite", step: 9 },

  /* ============================
     Step 10
  ============================ */

  { name: "showMobile", step: 10 },
  { name: "showPhone", step: 10 },
  { name: "showEmail", step: 10 },
  { name: "showAddress", step: 10 },
  { name: "showWebsite", step: 10 },
  { name: "showSocials", step: 10 },

  /* ============================
     Step 11
  ============================ */

  { name: "metaTitle", step: 11 },
  { name: "metaDescription", step: 11 },
  { name: "metaKeywords", step: 11 },
  { name: "canonicalUrl", step: 11 },
  { name: "robots", step: 11 },
  { name: "openGraphImage", step: 11 },

  /* ============================
     Step 12
  ============================ */

  { name: "status", step: 12 },
  { name: "publishDate", step: 12 },
  { name: "expireDate", step: 12 },
  { name: "autoRenew", step: 12 },
  { name: "urgent", step: 12 },
  { name: "featured", step: 12 },
  { name: "active", step: 12 }

];