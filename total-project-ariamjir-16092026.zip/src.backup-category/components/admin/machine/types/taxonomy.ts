/* ============================================================
   Taxonomy Types
   ARIAMJIR Machine Module
============================================================ */

import type {
  BaseEntity,
  ActivatableEntity,
  SortableEntity,
  SeoEntity,
} from "./common";

/* ============================================================
   Country
============================================================ */

export interface Country
  extends BaseEntity,
    ActivatableEntity,
    SortableEntity {

  code: string;

  iso2: string;

  iso3?: string;

  name: string;

  nameFa: string;

  flag?: string;
}

/* ============================================================
   Brand
============================================================ */

export interface Brand
  extends BaseEntity,
    ActivatableEntity,
    SortableEntity,
    SeoEntity {

  slug: string;

  name: string;

  nameFa: string;

  logo?: string;

  website?: string;

  countryId: string;

  description?: string;

  featured?: boolean;
}

/* ============================================================
   Machine Category
============================================================ */

export interface MachineCategory
  extends BaseEntity,
    ActivatableEntity,
    SortableEntity,
    SeoEntity {

  slug: string;

  name: string;

  nameFa: string;

  icon?: string;

  image?: string;

  description?: string;
}

/* ============================================================
   Machine Subcategory
============================================================ */

export interface MachineSubcategory
  extends BaseEntity,
    ActivatableEntity,
    SortableEntity {

  categoryId: string;

  slug: string;

  name: string;

  nameFa: string;

  icon?: string;
}

/* ============================================================
   Machine Type
============================================================ */

export interface MachineType
  extends BaseEntity,
    ActivatableEntity,
    SortableEntity {

  subcategoryId: string;

  slug: string;

  name: string;

  nameFa: string;

  icon?: string;
}