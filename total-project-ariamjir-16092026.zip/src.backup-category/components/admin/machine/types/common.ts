/* ============================================================
   Common Types
   ARIAMJIR Machine Module
============================================================ */

export type ID = string;

export type Slug = string;

export type Nullable<T> = T | null;

export type Optional<T> = T | undefined;

export interface BaseEntity {
  id: ID;
  createdAt?: Date;
  updatedAt?: Date;
}

export interface SortableEntity {
  sortOrder: number;
}

export interface ActivatableEntity {
  isActive: boolean;
}

export interface SeoEntity {
  seoTitle?: string;
  seoDescription?: string;
  seoKeywords?: string[];
}

export interface TranslatableText {
  fa: string;
  en?: string;
}

export interface Option {
  value: string;
  label: string;
}

export interface SearchableOption extends Option {
  search?: string;
  disabled?: boolean;
  icon?: string;
}