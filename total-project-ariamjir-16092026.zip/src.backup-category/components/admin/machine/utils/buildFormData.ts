import { MachineFormData } from "../schema";

export default function buildFormData(
  data: MachineFormData
): FormData {

  const formData = new FormData();

  Object.entries(data).forEach(([key, value]) => {

    if (value === undefined || value === null) {
      return;
    }

    if (Array.isArray(value)) {

      value.forEach((item) => {

        if (item !== undefined && item !== null) {
          formData.append(key, String(item));
        }

      });

      return;
    }

    if (typeof value === "boolean") {

      formData.append(
        key,
        value ? "true" : "false"
      );

      return;
    }

    if (typeof value === "number") {

      formData.append(
        key,
        value.toString()
      );

      return;
    }

    const objectValue = value as unknown;

if (
  typeof File !== "undefined" &&
  objectValue instanceof File
) {
  formData.append(key, objectValue);
  return;
}

if (objectValue instanceof Date) {
  formData.append(key, objectValue.toISOString());
  return;
}

    if (typeof value === "object") {

      formData.append(
        key,
        JSON.stringify(value)
      );

      return;
    }

    formData.append(
      key,
      String(value)
    );

  });

  return formData;
}