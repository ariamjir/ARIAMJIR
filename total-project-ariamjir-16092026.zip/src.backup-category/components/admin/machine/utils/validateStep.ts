import { FieldErrors } from "react-hook-form";

import { machineFields } from "../data/machineFields";

export function validateStep(

step:number,

errors:FieldErrors

){

const stepFields=

machineFields.filter(

field=>field.step===step

);

const hasError=

stepFields.some(

field=>{

const keys=

field.name.split(".");

let current:any=errors;

for(const key of keys){

if(!current){

return false;

}

current=current[key];

}

return !!current;

}
);

return{

valid:!hasError,

hasError,

fields:

stepFields.map(

field=>field.name

),

};
}