export interface PriceValue {
  amount?: number;

  currency?: string;

  negotiable?: boolean;
}

export const formatNumber = (
  value?: number
): string => {

  if (
    value === undefined ||
    value === null
  ) {
    return "";
  }

  return new Intl.NumberFormat(
    "fa-IR"
  ).format(value);

};

export const formatPrice = (
  price: PriceValue
): string => {

  if (price.negotiable) {
    return "توافقی";
  }

  if (
    price.amount === undefined ||
    price.amount <= 0
  ) {
    return "-";
  }

  return `${formatNumber(
    price.amount
  )} ${price.currency ?? "USD"}`;

};

export const isValidPrice = (
  price: PriceValue
): boolean => {

  if (price.negotiable) {
    return true;
  }

  return (
    typeof price.amount === "number" &&
    price.amount > 0
  );

};

export const normalizePrice = (
  price: PriceValue
): PriceValue => ({

  amount: price.negotiable
    ? undefined
    : price.amount,

  currency:
    price.currency ?? "USD",

  negotiable:
    price.negotiable ?? false,

});

export default {
  formatNumber,
  formatPrice,
  isValidPrice,
  normalizePrice,
};