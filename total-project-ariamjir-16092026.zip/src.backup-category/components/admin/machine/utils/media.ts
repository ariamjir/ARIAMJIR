export type MediaType =

  | "image"

  | "video"

  | "pdf"

  | "youtube"

  | "aparat"

  | "document"

  | "cad"

  | "manual"

  | "certificate"

  | "other";

export interface MachineMedia {

  id?: string;

  type: MediaType;

  title?: string;

  url?: string;

  file?: File;

  featured?: boolean;

  order?: number;

}

export const sortMedia = (

items: MachineMedia[]

) => {

  return [...items].sort(

    (a, b) =>

      (a.order ?? 0) -

      (b.order ?? 0)

  );

};

export const setFeatured = (

items: MachineMedia[],

index: number

): MachineMedia[] => {

  return items.map(

    (item, i) => ({

      ...item,

      featured: i === index,

    })

  );

};

export const removeMedia = (

items: MachineMedia[],

index: number

): MachineMedia[] => {

  return items.filter(

    (_, i) => i !== index

  );

};

export const moveMedia = (

items: MachineMedia[],

from: number,

to: number

): MachineMedia[] => {

  const result = [...items];

  const [item] = result.splice(

    from,

    1

  );

  result.splice(

    to,

    0,

    item

  );

  return result.map(

    (media, index) => ({

      ...media,

      order: index,

    })

  );

};

export const appendMedia = (

items: MachineMedia[],

media: MachineMedia

): MachineMedia[] => {

  return [

    ...items,

    {

      ...media,

      order: items.length,

    },

  ];

};

export default {

  sortMedia,

  appendMedia,

  moveMedia,

  removeMedia,

  setFeatured,

};