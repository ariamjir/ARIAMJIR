const persianMap: Record<string, string> = {
  "آ": "a",
  "ا": "a",
  "ب": "b",
  "پ": "p",
  "ت": "t",
  "ث": "s",
  "ج": "j",
  "چ": "ch",
  "ح": "h",
  "خ": "kh",
  "د": "d",
  "ذ": "z",
  "ر": "r",
  "ز": "z",
  "ژ": "zh",
  "س": "s",
  "ش": "sh",
  "ص": "s",
  "ض": "z",
  "ط": "t",
  "ظ": "z",
  "ع": "",
  "غ": "gh",
  "ف": "f",
  "ق": "gh",
  "ک": "k",
  "گ": "g",
  "ل": "l",
  "م": "m",
  "ن": "n",
  "و": "v",
  "ه": "h",
  "ی": "y",
};

function transliterate(text: string): string {

  return text

    .split("")

    .map((char) => persianMap[char] ?? char)

    .join("");

}

export function createSlug(

text: string

): string {

  return transliterate(text)

    .toLowerCase()

    .trim()

    .replace(/\s+/g, "-")

    .replace(/[^\w-]/g, "")

    .replace(/-+/g, "-");

}

export function createMachineSlug(

brand: string,

model: string

) {

  return createSlug(

    `${brand}-${model}`

  );

}

export default createSlug;