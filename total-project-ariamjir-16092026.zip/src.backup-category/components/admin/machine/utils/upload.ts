export interface UploadResult {

  success: boolean;

  url?: string;

  fileName?: string;

  error?: string;

}

export interface UploadOptions {

  folder?: string;

  maxSize?: number;

  allowedTypes?: string[];

}

export const validateUpload = (

  file: File,

  options?: UploadOptions

): UploadResult => {

  if (

    options?.maxSize &&

    file.size > options.maxSize

  ) {

    return {

      success: false,

      error: "حجم فایل بیش از حد مجاز است.",

    };

  }

    if (

    options?.allowedTypes?.length &&

    !options.allowedTypes.includes(file.type)

  ) {

    return {

      success: false,

      error: "نوع فایل مجاز نیست.",

    };

  }

  return {

    success: true,

  };

};

export const uploadFile = async (

  file: File,

  options?: UploadOptions

): Promise<UploadResult> => {

  const validation =

    validateUpload(

      file,

      options

    );

  if (!validation.success) {

    return validation;

  }

    const formData = new FormData();

  formData.append(

    "file",

    file

  );

  if (options?.folder) {

    formData.append(

      "folder",

      options.folder

    );

  }

    const response = await fetch(

    "/api/upload",

    {

      method: "POST",

      body: formData,

    }

  );

  if (!response.ok) {

    return {

      success: false,

      error: "خطا در آپلود فایل.",

    };

  }

    const result =

    await response.json();

  return {

    success: true,

    url: result.url,

    fileName: result.fileName,

  };

}

export default {

  validateUpload,

  uploadFile,

};