const mobileRegex = /^09\d{9}$/;

const emailRegex =
/^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const urlRegex =
/^(https?:\/\/)?([\w-]+\.)+[\w-]+(\/.*)?$/i;

export const isValidMobile = (

mobile:string

)=>mobileRegex.test(

mobile.trim()

);

export const isValidEmail=(

email:string

)=>emailRegex.test(

email.trim()

);

export const isValidUrl=(

url:string

)=>urlRegex.test(

url.trim()

);

export const isPositiveNumber=(

value:number|undefined

)=>{

return(

typeof value==="number"

&&

value>0

);

};

export const isValidYear=(

year:number

)=>{

    const currentYear=

new Date()

.getFullYear()+1;

return(

year>=1950

&&

year<=currentYear

);

};

export const isValidWorkingHours=(

hours:number

)=>{

return(

hours>=0

&&

hours<=300000

);

};

export const isValidSerial=(

serial:string

)=>{

return(

serial.trim().length>=5

);

};

export const isValidPrice=(

price:number

)=>{

return(

price>=0

);

};

export const isNotEmpty=(

value?:string

)=>{

return(

!!value

&&

value.trim().length>0

);

};

export default{

isValidMobile,

isValidEmail,

isValidUrl,

isPositiveNumber,

isValidYear,

isValidWorkingHours,

isValidSerial,

isValidPrice,

isNotEmpty,

};