export type ListingPlan =

  | "free"

  | "silver"

  | "gold"

  | "diamond"

  | "dealer"

  | "vip";

export interface RenewInfo {

  expiresAt: Date;

  renewCount: number;

  boostCount: number;

}

const PLAN_DAYS: Record<ListingPlan, number> = {

  free: 30,

  silver: 45,

  gold: 60,

  diamond: 90,

  dealer: 180,

  vip: 365,

};

export const calculateExpireDate = (

  plan: ListingPlan,

  from: Date = new Date()

): Date => {

  const result = new Date(from);

  result.setDate(

    result.getDate() +

    PLAN_DAYS[plan]

  );

  return result;

};

export const renewListing = (

  info: RenewInfo,

  plan: ListingPlan

): RenewInfo => ({

  ...info,

  renewCount:

    info.renewCount + 1,

  expiresAt:

    calculateExpireDate(

      plan,

      info.expiresAt

    ),

});

export const boostListing = (

  info: RenewInfo

): RenewInfo => ({

  ...info,

  boostCount:

    info.boostCount + 1,

});

export const isExpired = (

  expiresAt: Date

) => {

  return (

    expiresAt.getTime() <

    Date.now()

  );

};

export default {

  calculateExpireDate,

  renewListing,

  boostListing,

  isExpired,

};