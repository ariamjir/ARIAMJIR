import type { MachineFormData } from "@/modules/machine/schema";

import { formatPrice } from "./price";

export interface MachinePreview {
  title: string;

  subtitle: string;

  price: string;

  location: string;

  condition: string;

  year?: number;

  images: string[];

  features: string[];
}

export function buildMachinePreview(
  machine: MachineFormData
): MachinePreview {

  const title = [
    machine.title,
    machine.model,
  ]
    .filter(Boolean)
    .join(" ");

  const subtitle = [
    machine.brandId,
    machine.categoryId,
  ]
    .filter(Boolean)
    .join(" • ");

  const location = [
    machine.country,
    machine.provinceId,
    machine.cityId,
  ]
    .filter(Boolean)
    .join(" / ");

  const images = (machine.gallery ?? [])
    .filter(Boolean)
    .map(String);

  const features = (machine.features ?? [])
    .filter(Boolean)
    .map(String);

  const price = formatPrice({
    amount: Number(machine.price ?? 0),
    currency: machine.currency ?? "USD",
    negotiable: machine.negotiable ?? false,
  });

  return {
    title,
    subtitle,
    price,
    location,
    condition: machine.condition ?? "used",
    year:
  typeof machine.manufactureYear === "number"
    ? machine.manufactureYear
    : undefined,
    images,
    features,
  };
}

export default buildMachinePreview;