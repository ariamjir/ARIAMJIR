export interface MachineFeatureOption {
  value: string;
  label: string;
}

export const MACHINE_FEATURES: MachineFeatureOption[] = [
  { value: "air_condition", label: "Air Condition" },
  { value: "camera", label: "Camera" },
  { value: "gps", label: "GPS" },
  { value: "heater", label: "Heater" },
  { value: "radio", label: "Radio" },
  { value: "bucket", label: "Bucket" },
  { value: "quick_coupler", label: "Quick Coupler" },
  { value: "hammer_line", label: "Hammer Line" },
];

