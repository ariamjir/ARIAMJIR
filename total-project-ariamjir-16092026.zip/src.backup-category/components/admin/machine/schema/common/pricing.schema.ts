import { z } from "zod";

/* ===========================================================
   Currency
=========================================================== */

export const currencySchema = z.object({
  currency: z.enum([
    "IRR",
    "USD",
    "EUR",
    "AED",
    "TRY",
    "CNY",
  ]).default("USD"),
});

/* ===========================================================
   Sale
=========================================================== */

export const saleSchema = z.object({
  salePrice: z.coerce.number().min(0).optional(),

  negotiable: z.boolean().default(false),

  priceOnCall: z.boolean().default(false),

  discountPrice: z.coerce.number().optional(),

  discountPercent: z.coerce.number().min(0).max(100).optional(),

  taxIncluded: z.boolean().default(false),

  commissionIncluded: z.boolean().default(false),
});

/* ===========================================================
   Rent
=========================================================== */

export const rentSchema = z.object({
  rentAvailable: z.boolean().default(false),

  rentDaily: z.coerce.number().optional(),

  rentWeekly: z.coerce.number().optional(),

  rentMonthly: z.coerce.number().optional(),

  minimumRentDays: z.coerce.number().optional(),

  operatorIncluded: z.boolean().default(false),

  fuelIncluded: z.boolean().default(false),

  insuranceIncluded: z.boolean().default(false),
});

/* ===========================================================
   Auction
=========================================================== */

export const auctionSchema = z.object({
  auctionEnabled: z.boolean().default(false),

  auctionStartPrice: z.coerce.number().optional(),

  auctionReservePrice: z.coerce.number().optional(),

  auctionStartDate: z.string().optional(),

  auctionEndDate: z.string().optional(),

  autoExtendAuction: z.boolean().default(false),
});

/* ===========================================================
   Financing
=========================================================== */

export const financeSchema = z.object({
  financingAvailable: z.boolean().default(false),

  installmentAvailable: z.boolean().default(false),

  downPayment: z.coerce.number().optional(),

  installmentMonths: z.coerce.number().optional(),

  monthlyInstallment: z.coerce.number().optional(),

  bankName: z.string().optional(),
});

/* ===========================================================
   Deposit
=========================================================== */

export const depositSchema = z.object({
  securityDeposit: z.coerce.number().optional(),

  refundableDeposit: z.boolean().default(true),
});

/* ===========================================================
   Export
=========================================================== */

export const exportSchema = z.object({
  exportAvailable: z.boolean().default(false),

  customsCleared: z.boolean().default(false),

  hsCode: z.string().optional(),

  incoterm: z.enum([
    "EXW",
    "FOB",
    "CIF",
    "DAP",
    "DDP",
  ]).optional(),
});

/* ===========================================================
   Pricing Schema
=========================================================== */

export const pricingSchema = currencySchema
  .merge(saleSchema)
  .merge(rentSchema)
  .merge(auctionSchema)
  .merge(financeSchema)
  .merge(depositSchema)
  .merge(exportSchema);

export type PricingInput = z.infer<typeof pricingSchema>;
