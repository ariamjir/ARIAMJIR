import { z } from "zod";

export const basicSchema = z.object({
  /*
  |--------------------------------------------------------------------------
  | Identity
  |--------------------------------------------------------------------------
  */

  title: z
    .string()
    .trim()
    .min(3, "عنوان حداقل باید ۳ کاراکتر باشد.")
    .max(150),

  slug: z
    .string()
    .trim()
    .min(3)
    .max(180)
    .regex(/^[a-z0-9-]+$/),

  /*
  |--------------------------------------------------------------------------
  | Category
  |--------------------------------------------------------------------------
  */

  listingType: z.enum([
    "sale",
    "rent",
    "auction",
  ]),

  categoryId: z.string().optional(),

  subCategoryId: z.string().optional(),

  childCategoryId: z.string().optional(),

  brandId: z.string().optional(),

  model: z.string().optional(),

  series: z.string().optional(),

  modelCode: z.string().optional(),

  stockCode: z.string().optional(),

  serialNumber: z.string().optional(),

  manufactureYear: z.coerce.number().optional(),

  /*
  |--------------------------------------------------------------------------
  | Machine
  |--------------------------------------------------------------------------
  */

  condition: z.enum([
    "new",
    "used",
    "refurbished",
  ]),

  originCountry: z.string().optional(),

  manufacturer: z.string().optional(),

  productionCountry: z.string().optional(),

  assemblyCountry: z.string().optional(),

  /*
  |--------------------------------------------------------------------------
  | Description
  |--------------------------------------------------------------------------
  */

  shortDescription: z
    .string()
    .max(500)
    .optional(),

  description: z
    .string()
    .max(10000)
    .optional(),

  /*
  |--------------------------------------------------------------------------
  | Status
  |--------------------------------------------------------------------------
  */

  active: z.boolean().default(true),

  featured: z.boolean().default(false),

  urgent: z.boolean().default(false),

  verified: z.boolean().default(false),
});

export type BasicInput = z.infer<typeof basicSchema>;
