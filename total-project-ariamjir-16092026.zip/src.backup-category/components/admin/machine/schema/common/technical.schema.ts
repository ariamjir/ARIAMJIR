import { z } from "zod";

/* ===========================================================
   Engine
=========================================================== */

export const engineSchema = z.object({
  engineBrand: z.string().optional(),

  engineModel: z.string().optional(),

  engineSerialNumber: z.string().optional(),

  enginePower: z.coerce.number().optional(),

  enginePowerUnit: z.enum([
    "hp",
    "kw",
  ]).default("hp"),

  engineDisplacement: z.coerce.number().optional(),

  cylinders: z.coerce.number().optional(),

  fuelType: z.enum([
    "diesel",
    "gasoline",
    "electric",
    "hybrid",
    "lng",
    "lpg",
    "battery",
  ]).optional(),

  emissionStandard: z.string().optional(),
});

/* ===========================================================
   Transmission
=========================================================== */

export const transmissionSchema = z.object({
  transmissionType: z.enum([
    "manual",
    "automatic",
    "powershift",
    "hydrostatic",
  ]).optional(),

  gearsForward: z.coerce.number().optional(),

  gearsReverse: z.coerce.number().optional(),
});

/* ===========================================================
   Hydraulic
=========================================================== */

export const hydraulicSchema = z.object({
  hydraulicPump: z.string().optional(),

  hydraulicPressure: z.coerce.number().optional(),

  hydraulicFlow: z.coerce.number().optional(),

  hydraulicTank: z.coerce.number().optional(),
});

/* ===========================================================
   Working Hours
=========================================================== */

export const hourSchema = z.object({
  workingHours: z.coerce.number().optional(),

  idleHours: z.coerce.number().optional(),

  engineHours: z.coerce.number().optional(),

  meterVerified: z.boolean().default(false),
});

/* ===========================================================
   Dimensions
=========================================================== */

export const dimensionSchema = z.object({
  operatingWeight: z.coerce.number().optional(),

  shippingWeight: z.coerce.number().optional(),

  length: z.coerce.number().optional(),

  width: z.coerce.number().optional(),

  height: z.coerce.number().optional(),

  wheelbase: z.coerce.number().optional(),

  groundClearance: z.coerce.number().optional(),
});

/* ===========================================================
   Capacity
=========================================================== */

export const capacitySchema = z.object({
  bucketCapacity: z.coerce.number().optional(),

  bucketUnit: z.enum([
    "m3",
    "liter",
  ]).default("m3"),

  liftingCapacity: z.coerce.number().optional(),

  payload: z.coerce.number().optional(),

  diggingDepth: z.coerce.number().optional(),

  dumpingHeight: z.coerce.number().optional(),

  reach: z.coerce.number().optional(),
});

/* ===========================================================
   Tires
=========================================================== */

export const tireSchema = z.object({
  frontTire: z.string().optional(),

  rearTire: z.string().optional(),

  tireCondition: z.string().optional(),
});

/* ===========================================================
   Tracks
=========================================================== */

export const trackSchema = z.object({
  trackType: z.string().optional(),

  trackWidth: z.coerce.number().optional(),

  shoeWidth: z.coerce.number().optional(),
});

/* ===========================================================
   Cabin
=========================================================== */

export const cabinSchema = z.object({
  airCondition: z.boolean().default(false),

  heater: z.boolean().default(false),

  camera: z.boolean().default(false),

  gps: z.boolean().default(false),

  radio: z.boolean().default(false),

  monitor: z.boolean().default(false),
});

/* ===========================================================
   Electrical
=========================================================== */

export const electricalSchema = z.object({
  batteryVoltage: z.coerce.number().optional(),

  alternator: z.coerce.number().optional(),

  starter: z.string().optional(),
});

/* ===========================================================
   Attachments
=========================================================== */

export const attachmentSchema = z.object({
  quickCoupler: z.boolean().default(false),

  hammerLine: z.boolean().default(false),

  ripper: z.boolean().default(false),

  forks: z.boolean().default(false),

  bucketType: z.string().optional(),
});

/* ===========================================================
   Technical Schema
=========================================================== */

export const technicalSchema = engineSchema
  .merge(transmissionSchema)
  .merge(hydraulicSchema)
  .merge(hourSchema)
  .merge(dimensionSchema)
  .merge(capacitySchema)
  .merge(tireSchema)
  .merge(trackSchema)
  .merge(cabinSchema)
  .merge(electricalSchema)
  .merge(attachmentSchema);

export type TechnicalInput = z.infer<typeof technicalSchema>;
