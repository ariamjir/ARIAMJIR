import { z } from "zod";

/* ===========================================================
   Country
=========================================================== */

export const countrySchema = z.object({
  countryId: z.string().optional(),

  countryCode: z.string().optional(),

  countryName: z.string().optional(),
});

/* ===========================================================
   Province
=========================================================== */

export const provinceSchema = z.object({
  provinceId: z.string().optional(),

  provinceName: z.string().optional(),
});

/* ===========================================================
   City
=========================================================== */

export const citySchema = z.object({
  cityId: z.string().optional(),

  cityName: z.string().optional(),

  district: z.string().optional(),
});

/* ===========================================================
   Address
=========================================================== */

export const addressSchema = z.object({
  address: z.string().optional(),

  postalCode: z.string().optional(),

  warehouseName: z.string().optional(),

  contactPerson: z.string().optional(),
});

/* ===========================================================
   Geo Location
=========================================================== */

export const geoSchema = z.object({
  latitude: z.coerce.number().optional(),

  longitude: z.coerce.number().optional(),

  altitude: z.coerce.number().optional(),

  accuracy: z.coerce.number().optional(),
});

/* ===========================================================
   Map
=========================================================== */

export const mapSchema = z.object({
  mapZoom: z.coerce.number().default(12),

  mapVisible: z.boolean().default(true),

  pinDraggable: z.boolean().default(true),
});

/* ===========================================================
   Visit
=========================================================== */

export const visitSchema = z.object({
  visitAvailable: z.boolean().default(true),

  visitByAppointment: z.boolean().default(true),

  workingDays: z.array(z.string()).default([]),

  workingHours: z.string().optional(),
});

/* ===========================================================
   Delivery
=========================================================== */

export const deliverySchema = z.object({
  deliveryAvailable: z.boolean().default(false),

  deliveryRadius: z.coerce.number().optional(),

  internationalShipping: z.boolean().default(false),

  loadingAvailable: z.boolean().default(false),
});

/* ===========================================================
   Search
=========================================================== */

export const searchLocationSchema = z.object({
  searchable: z.boolean().default(true),

  hideExactLocation: z.boolean().default(false),

  showCityOnly: z.boolean().default(false),
});

/* ===========================================================
   Merge
=========================================================== */

export const locationSchema = countrySchema
  .merge(provinceSchema)
  .merge(citySchema)
  .merge(addressSchema)
  .merge(geoSchema)
  .merge(mapSchema)
  .merge(visitSchema)
  .merge(deliverySchema)
  .merge(searchLocationSchema);

export type LocationInput = z.infer<typeof locationSchema>;
