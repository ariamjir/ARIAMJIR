import { z } from "zod";

export const cabinSchema = z.object({
  ac: z.boolean().default(false),

  heater: z.boolean().default(false),

  camera: z.boolean().default(false),

  monitor: z.boolean().default(false),

  gps: z.boolean().default(false),

  radio: z.boolean().default(false),

  suspensionSeat: z.boolean().default(false),

  rops: z.boolean().default(false),

  fops: z.boolean().default(false),
});

export type CabinInput = z.infer<typeof cabinSchema>;
