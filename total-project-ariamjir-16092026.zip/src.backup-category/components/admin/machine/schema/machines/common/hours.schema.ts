import { z } from "zod";

export const hoursSchema = z.object({
  workingHours: z.coerce.number().optional(),

  idleHours: z.coerce.number().optional(),

  engineHours: z.coerce.number().optional(),

  meterVerified: z.boolean().default(false),
});

export type HoursInput = z.infer<typeof hoursSchema>;
