import { z } from "zod";

export const capacitySchema = z.object({
  liftingCapacity: z.coerce.number().optional(),

  payload: z.coerce.number().optional(),

  bucketCapacity: z.coerce.number().optional(),

  bucketUnit: z.enum([
    "m3",
    "liter",
  ]).default("m3"),

  reach: z.coerce.number().optional(),

  dumpingHeight: z.coerce.number().optional(),

  diggingDepth: z.coerce.number().optional(),
});

export type CapacityInput = z.infer<typeof capacitySchema>;
