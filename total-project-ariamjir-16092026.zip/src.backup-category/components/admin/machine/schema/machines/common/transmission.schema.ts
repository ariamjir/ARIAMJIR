import { z } from "zod";

export const transmissionSchema = z.object({
  transmissionType: z.enum([
    "manual",
    "automatic",
    "powershift",
    "hydrostatic",
  ]).optional(),

  gearsForward: z.coerce.number().optional(),

  gearsReverse: z.coerce.number().optional(),

  driveType: z.enum([
    "2wd",
    "4wd",
    "6x4",
    "6x6",
    "8x4",
    "crawler",
    "wheel",
  ]).optional(),

  differentialLock: z.boolean().default(false),
});

export type TransmissionInput = z.infer<typeof transmissionSchema>;
