import { z } from "zod";

export const engineSchema = z.object({
  engineBrand: z.string().optional(),

  engineModel: z.string().optional(),

  engineSerialNumber: z.string().optional(),

  enginePower: z.coerce.number().optional(),

  powerUnit: z.enum([
    "hp",
    "kw",
  ]).default("hp"),

  displacement: z.coerce.number().optional(),

  cylinders: z.coerce.number().optional(),

  fuelType: z.enum([
    "diesel",
    "gasoline",
    "electric",
    "hybrid",
    "lng",
    "lpg",
    "battery",
  ]).optional(),

  emissionStandard: z.string().optional(),

  turbo: z.boolean().default(false),

  intercooler: z.boolean().default(false),
});

export type EngineInput = z.infer<typeof engineSchema>;
