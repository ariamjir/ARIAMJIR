import { z } from "zod";

export const electricalSchema = z.object({
  batteryVoltage: z.coerce.number().optional(),

  alternator: z.coerce.number().optional(),

  starter: z.string().optional(),

  lightingPackage: z.boolean().default(false),

  beacon: z.boolean().default(false),
});

export type ElectricalInput = z.infer<typeof electricalSchema>;
