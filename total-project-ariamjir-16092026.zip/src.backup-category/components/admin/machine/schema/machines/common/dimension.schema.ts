import { z } from "zod";

export const dimensionSchema = z.object({
  operatingWeight: z.coerce.number().optional(),

  shippingWeight: z.coerce.number().optional(),

  length: z.coerce.number().optional(),

  width: z.coerce.number().optional(),

  height: z.coerce.number().optional(),

  wheelbase: z.coerce.number().optional(),

  groundClearance: z.coerce.number().optional(),
});

export type DimensionInput = z.infer<typeof dimensionSchema>;
