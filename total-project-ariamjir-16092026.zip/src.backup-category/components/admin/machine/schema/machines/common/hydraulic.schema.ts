import { z } from "zod";

export const hydraulicSchema = z.object({
  hydraulicPump: z.string().optional(),

  hydraulicPressure: z.coerce.number().optional(),

  hydraulicFlow: z.coerce.number().optional(),

  hydraulicTank: z.coerce.number().optional(),

  auxiliaryHydraulic: z.boolean().default(false),

  quickCoupler: z.boolean().default(false),
});

export type HydraulicInput = z.infer<typeof hydraulicSchema>;
