import { z } from "zod";

import { engineSchema } from "../common/engine.schema";
import { transmissionSchema } from "../common/transmission.schema";
import { hydraulicSchema } from "../common/hydraulic.schema";
import { dimensionSchema } from "../common/dimension.schema";
import { capacitySchema } from "../common/capacity.schema";
import { cabinSchema } from "../common/cabin.schema";
import { electricalSchema } from "../common/electrical.schema";
import { hoursSchema } from "../common/hours.schema";

/* ===========================================================
   Loader Specific
=========================================================== */

const loaderSpecificSchema = z.object({
  loaderType: z.enum([
    "wheel",
    "skid",
    "backhoe",
    "compact",
  ]).default("wheel"),

  steeringType: z.enum([
    "articulated",
    "skid",
    "front",
  ]).optional(),

  axleBrand: z.string().optional(),

  axleModel: z.string().optional(),

  differentialType: z.string().optional(),

  tireFront: z.string().optional(),

  tireRear: z.string().optional(),

  tireCondition: z.string().optional(),

  bucketType: z.string().optional(),

  bucketWidth: z.coerce.number().optional(),

  bucketCapacity: z.coerce.number().optional(),

  bucketUnit: z.enum([
    "m3",
    "liter",
  ]).default("m3"),

  breakoutForce: z.coerce.number().optional(),

  liftHeight: z.coerce.number().optional(),

  dumpHeight: z.coerce.number().optional(),

  reachAtDump: z.coerce.number().optional(),

  articulationAngle: z.coerce.number().optional(),

  turningRadius: z.coerce.number().optional(),

  travelSpeed: z.coerce.number().optional(),

  rideControl: z.boolean().default(false),

  autoLevelBucket: z.boolean().default(false),

  quickCoupler: z.boolean().default(false),

  thirdHydraulicFunction: z.boolean().default(false),
});

/* ===========================================================
   Loader Schema
=========================================================== */

export const loaderSchema = engineSchema
  .merge(transmissionSchema)
  .merge(hydraulicSchema)
  .merge(dimensionSchema)
  .merge(capacitySchema)
  .merge(cabinSchema)
  .merge(electricalSchema)
  .merge(hoursSchema)
  .merge(loaderSpecificSchema);

export type LoaderInput = z.infer<typeof loaderSchema>;