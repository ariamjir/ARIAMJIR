"use client";

import { useEffect, useState } from "react";

import Link from "next/link";

import { Bell, CheckCheck, Inbox } from "lucide-react";

export default function NotificationsBell() {
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState<any[]>([]);
  const [unread, setUnread] = useState(0);

  const load = () =>
    fetch("/api/admin/notifications")
      .then((r) => r.json())
      .then((j) => {
        if (j.success) {
          setItems(j.data ?? []);
          setUnread(j.unread ?? 0);
        }
      })
      .catch(() => {});

  useEffect(() => {
    load();
    const t = setInterval(load, 30000);
    return () => clearInterval(t);
  }, []);

  const markAll = async () => {
    await fetch("/api/admin/notifications", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ all: true }),
    });
    load();
  };

  return (
    <div className="relative">
      <button
        onClick={() => setOpen((o) => !o)}
        title="اعلان‌ها"
        className="relative flex h-10 w-10 items-center justify-center rounded-xl border border-zinc-200 bg-white text-zinc-600 transition hover:border-orange-300 hover:text-orange-600"
      >
        <Bell className="h-5 w-5" />
        {unread > 0 && (
          <span className="absolute -left-1 -top-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-red-600 px-1 text-[10px] font-black text-white">
            {unread.toLocaleString("fa-IR")}
          </span>
        )}
      </button>

      {open && (
        <div className="absolute left-0 top-12 z-50 w-80 overflow-hidden rounded-2xl border border-zinc-200 bg-white shadow-2xl">
          <div className="flex items-center justify-between border-b border-zinc-100 px-4 py-3">
            <span className="text-sm font-black text-zinc-800">اعلان‌ها</span>
            <button
              onClick={markAll}
              className="inline-flex items-center gap-1 text-[11px] font-bold text-blue-600 hover:text-blue-700"
            >
              <CheckCheck className="h-3.5 w-3.5" />
              خواندن همه
            </button>
          </div>

          <div className="max-h-96 overflow-y-auto">
            {items.length === 0 ? (
              <div className="flex flex-col items-center gap-2 py-10 text-zinc-400">
                <Inbox className="h-8 w-8" />
                <span className="text-xs font-bold">اعلانی وجود ندارد</span>
              </div>
            ) : (
              items.map((n) => (
                <Link
                  key={n.id}
                  href={n.link ?? "/admin/ads"}
                  onClick={() => setOpen(false)}
                  className={`block border-b border-zinc-50 px-4 py-3 transition hover:bg-orange-50 ${
                    n.read ? "opacity-60" : "bg-orange-50/50"
                  }`}
                >
                  <div className="flex items-center gap-2">
                    {!n.read && (
                      <span className="h-2 w-2 shrink-0 rounded-full bg-red-500" />
                    )}
                    <span className="text-[12px] font-black text-zinc-800">
                      {n.title}
                    </span>
                  </div>
                  {n.message && (
                    <p className="mt-1 text-[11px] leading-5 text-zinc-500">
                      {n.message}
                    </p>
                  )}
                  <span className="mt-1 block text-[10px] text-zinc-400">
                    {new Date(n.createdAt).toLocaleDateString("fa-IR")}
                  </span>
                </Link>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}