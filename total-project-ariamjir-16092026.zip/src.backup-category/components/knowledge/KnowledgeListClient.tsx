"use client";

import { useEffect, useState } from "react";

import { Search, Loader2, ChevronLeft, ChevronRight } from "lucide-react";

import KnowledgeCard from "@/components/knowledge/KnowledgeCard";

export default function KnowledgeListClient() {
  const [data, setData] = useState<any>(null);
  const [page, setPage] = useState(1);
  const [cat, setCat] = useState("");
  const [q, setQ] = useState("");

  useEffect(() => {
    const params = new URLSearchParams({ page: String(page) });
    if (cat) params.set("category", cat);
    if (q.trim()) params.set("q", q.trim());

    fetch(`/api/knowledge?${params.toString()}`)
      .then((r) => r.json())
      .then((j) => {
        if (j.success) setData(j.data);
      });
  }, [page, cat, q]);

  return (
    <div className="mx-auto max-w-[1440px] px-5 py-16 lg:px-10">
      <div className="mb-10 text-center">
        <div className="text-xs font-black tracking-[0.3em] text-emerald-400">ARIA MJ ACADEMY</div>
        <h1 className="mt-3 text-3xl font-black text-white lg:text-4xl">مرکز دانش و مقالات آموزشی</h1>
        <p className="mt-3 text-sm text-white/50">راهنماهای تخصصی ماشین‌آلات سنگین برای خریداران و بهره‌برداران</p>
      </div>

      <div className="mb-8 flex flex-wrap items-center justify-center gap-3">
        <div className="relative">
          <Search className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-white/30" />
          <input
            value={q}
            onChange={(e) => { setQ(e.target.value); setPage(1); }}
            placeholder="جستجو در مقالات..."
            className="h-11 w-64 rounded-xl border border-white/10 bg-white/[0.05] pr-9 pl-3 text-xs text-white outline-none focus:border-emerald-400/60"
          />
        </div>
        <button
          onClick={() => { setCat(""); setPage(1); }}
          className={`rounded-full px-4 py-2 text-[11px] font-bold transition ${!cat ? "bg-emerald-500 text-white" : "border border-white/10 text-white/60 hover:text-white"}`}
        >
          همه
        </button>
        {(data?.categories ?? []).map((c: any) => (
          <button
            key={c.id}
            onClick={() => { setCat(c.slug); setPage(1); }}
            className={`rounded-full px-4 py-2 text-[11px] font-bold transition ${cat === c.slug ? "text-white" : "border border-white/10 text-white/60 hover:text-white"}`}
            style={cat === c.slug ? { backgroundColor: c.color } : undefined}
          >
            {c.name}
          </button>
        ))}
      </div>

      {!data ? (
        <div className="flex h-64 items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-emerald-500" />
        </div>
      ) : (
        <>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {data.items.map((p: any) => (
              <KnowledgeCard key={p.id} post={p} />
            ))}
          </div>

          {data.pages > 1 && (
            <div className="mt-10 flex items-center justify-center gap-3">
              <button disabled={page <= 1} onClick={() => setPage((p) => p - 1)} className="flex h-9 w-9 items-center justify-center rounded-lg border border-white/10 text-white disabled:opacity-40">
                <ChevronRight className="h-4 w-4" />
              </button>
              <span className="text-sm font-bold text-white/60">{page} / {data.pages}</span>
              <button disabled={page >= data.pages} onClick={() => setPage((p) => p + 1)} className="flex h-9 w-9 items-center justify-center rounded-lg border border-white/10 text-white disabled:opacity-40">
                <ChevronLeft className="h-4 w-4" />
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
}