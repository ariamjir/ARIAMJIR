"use client";

import Link from "next/link";

import { useHeaderConfig } from "./useHeaderConfig";

/* ============================================================
   لوگو — تصویر/سایز/متون کاملاً از تنظیمات پنل
============================================================ */

export default function Logo() {
  const cfg = useHeaderConfig();

  return (
    <Link
      href="/"
      className="flex items-center gap-3"
      aria-label={cfg.logo.alt}
    >
      {/* ✅ تصویر لوگو با سایز دلخواه پنل */}
      {cfg.logo.visible && (
        <img
          src={cfg.logo.url}
          alt={cfg.logo.alt}
          style={{ width: cfg.logo.width, height: cfg.logo.height }}
          className="shrink-0 object-contain"
        />
      )}

      <span className="flex flex-col">
        {cfg.brand.visible && (
          <span className="text-lg font-black tracking-wide text-white">
            {cfg.brand.text}
          </span>
        )}

        {cfg.tagline.visible && (
          <span className="mt-0.5 text-[9px] font-bold tracking-[0.3em] text-[#F58220]">
            {cfg.tagline.text}
          </span>
        )}
      </span>
    </Link>
  );
}