"use client";

import { useEffect, useState } from "react";

import {
  DEFAULT_HEADER_CONFIG,
  type HeaderConfig,
} from "@/lib/header-config";

/* ============================================================
   هوک تنظیمات هدر — خواندن از API با fallback به پیش‌فرض‌ها
============================================================ */

export function useHeaderConfig(): HeaderConfig {
  const [cfg, setCfg] = useState<HeaderConfig>(DEFAULT_HEADER_CONFIG);

  useEffect(() => {
    fetch("/api/header")
      .then((r) => r.json())
      .then((j) => {
        if (j.success) setCfg(j.data);
      })
      .catch(() => {});
  }, []);

  return cfg;
}