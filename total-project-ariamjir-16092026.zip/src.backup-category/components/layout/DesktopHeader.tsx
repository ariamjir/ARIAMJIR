"use client";

import Logo from "./Logo";
import NavMenu from "./NavMenu";
import CTAButton from "./CTAButton";

import { useHeaderConfig } from "./useHeaderConfig";

/* ============================================================
   هدر دسکتاپ — حالت‌ها (چسبان/شفاف) از تنظیمات پنل
============================================================ */

export default function DesktopHeader() {
  const cfg = useHeaderConfig();

  return (
    <header
      className={`
        inset-x-0
        top-0
        z-[200]
        ${cfg.layout.sticky ? "fixed" : "absolute"}
      `}
    >
      <div
        className="
          mx-auto
          max-w-[1440px]
          px-4
          lg:px-6
          2xl:px-10
        "
      >
        <div
          className={`
            mt-4
            flex
            h-20
            items-center
            justify-between
            rounded-3xl
            border
            border-white/10
            px-6
            shadow-[0_12px_40px_rgba(0,0,0,.35)]
            lg:px-8
            ${
              cfg.layout.transparent
                ? "bg-black/75 backdrop-blur-2xl"
                : "bg-[#111111]"
            }
          `}
        >
          {/* ==================================================
              LOGO
          ================================================== */}
          <div className="shrink-0">
            <Logo />
          </div>

          {/* ==================================================
              NAVIGATION
          ================================================== */}
          <div className="flex min-w-0 flex-1 justify-center">
            <NavMenu />
          </div>

          {/* ==================================================
              CTA
          ================================================== */}
          <div className="shrink-0">
            <CTAButton />
          </div>
        </div>
      </div>
    </header>
  );
}