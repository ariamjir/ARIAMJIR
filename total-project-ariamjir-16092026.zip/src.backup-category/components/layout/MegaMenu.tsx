"use client";

import Link from "next/link";
import {
  ChevronLeft,
  ExternalLink,
} from "lucide-react";

import { getMenuHref } from "@/features/home/navigation/menuUrl";

/* ============================================================
   TYPES
============================================================ */

type MenuCategory = {
  slug?: string | null;
};

type MenuItem = {
  id: string;
  title: string;

  href: string | null;

  parentId: string | null;

  type: string;

  icon: string | null;

  categoryId: string | null;

  /*
   * بسیار مهم:
   * برای ساخت URL دسته‌بندی
   */
  category?: MenuCategory | null;

  sortOrder: number;

  active: boolean;

  showDesktop: boolean;

  showMobile: boolean;

  openInNewTab: boolean;

  megaMenu: boolean;
};

interface MegaMenuProps {
  item: MenuItem;

  /*
   * فرزندان مستقیم آیتم اصلی
   */
  children: MenuItem[];

  /*
   * کل درخت منو
   */
  allItems: MenuItem[];
}

/* ============================================================
   HELPERS
============================================================ */

/**
 * فقط آیتم‌های فعال و قابل نمایش دسکتاپ
 */
function isVisible(item: MenuItem) {
  return (
    item.active &&
    item.showDesktop
  );
}

/**
 * مرتب‌سازی منو
 */
function sortItems(items: MenuItem[]) {
  return [...items].sort(
    (a, b) =>
      a.sortOrder - b.sortOrder,
  );
}

/**
 * گرفتن فرزندان مستقیم
 */
function getDirectChildren(
  parentId: string,
  allItems: MenuItem[],
) {
  return sortItems(
    allItems.filter(
      (item) =>
        isVisible(item) &&
        item.parentId === parentId,
    ),
  );
}

/**
 * آیا آیتم فرزند دارد؟
 */
function hasChildren(
  itemId: string,
  allItems: MenuItem[],
) {
  return allItems.some(
    (item) =>
      isVisible(item) &&
      item.parentId === itemId,
  );
}

/* ============================================================
   MEGA MENU
============================================================ */

export default function MegaMenu({
  item,
  children,
  allItems,
}: MegaMenuProps) {
  /*
   * اگر آیتم اصلی فرزندی ندارد
   */
  if (!children.length) {
    return null;
  }

  /*
   * ستون‌های اصلی مگا منو
   *
   * مثال:
   *
   * ماشین‌آلات
   *   ├── ماشین‌آلات راهسازی
   *   │     ├── لودر
   *   │     ├── بیل مکانیکی
   *   │     └── گریدر
   *   │
   *   ├── ماشین‌آلات معدنی
   *   └── ماشین‌آلات صنعتی
   */
  const columns = sortItems(
    children.filter(
      (child) =>
        isVisible(child) &&
        child.parentId === item.id,
    ),
  );

  if (!columns.length) {
    return null;
  }

  return (
    <div
      className="
        invisible
        absolute
        right-1/2
        top-[calc(100%-1px)]
        z-[500]

        w-[min(1100px,calc(100vw-32px))]

        translate-x-1/2
        translate-y-3

        rounded-3xl

        border
        border-white/10

        bg-zinc-950/98

        p-6

        opacity-0

        shadow-[0_25px_80px_rgba(0,0,0,.55)]

        backdrop-blur-2xl

        transition-all
        duration-200

        group-hover:visible
        group-hover:translate-y-0
        group-hover:opacity-100
      "
    >
      {/* ======================================================
          ORANGE TOP LINE
      ====================================================== */}

      <div
        className="
          absolute
          -top-[1px]
          left-10
          right-10
          h-[2px]
          rounded-full
          bg-orange-500
        "
      />

      {/* ======================================================
          HEADER
      ====================================================== */}

      <div
        className="
          mb-6
          flex
          items-center
          justify-between
          border-b
          border-white/10
          pb-5
        "
      >
        {/* TITLE */}

        <div className="min-w-0">
          <h3
            className="
              text-lg
              font-black
              text-white
            "
          >
            {item.title}
          </h3>

          <p
            className="
              mt-1
              text-xs
              text-zinc-500
            "
          >
            انتخاب دسته موردنظر
          </p>
        </div>

        {/* VIEW ALL */}

        {item.href && (
          <MenuActionLink
            item={item}
            label="مشاهده همه"
          />
        )}
      </div>

      {/* ======================================================
          COLUMNS
      ====================================================== */}

      <div
        className="
          grid
          grid-cols-2
          gap-x-6
          gap-y-8
          md:grid-cols-3
          xl:grid-cols-4
        "
      >
        {columns.map((column) => {
          /*
           * تمام فرزندان مستقیم ستون
           */
          const subItems =
            getDirectChildren(
              column.id,
              allItems,
            );

          const columnHasChildren =
            subItems.length > 0;

          /*
           * URL ستون
           */
          const columnHref =
            getMenuHref(column);

          return (
            <div
              key={column.id}
              className="
                min-w-0
              "
            >
              {/* =================================================
                  COLUMN HEADER
              ================================================= */}

              <MegaMenuColumnHeader
                item={column}
                href={columnHref}
                hasChildren={
                  columnHasChildren
                }
              />

              {/* =================================================
                  COLUMN CHILDREN
              ================================================= */}

              {columnHasChildren && (
                <div
                  className="
                    mt-1
                    space-y-0.5
                  "
                >
                  {subItems.map(
                    (subItem) => (
                      <MegaMenuLink
                        key={
                          subItem.id
                        }
                        item={
                          subItem
                        }
                      />
                    ),
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* ======================================================
          FOOTER
      ====================================================== */}

      <div
        className="
          mt-6
          flex
          items-center
          justify-between

          border-t
          border-white/10

          pt-4
        "
      >
        <span
          className="
            text-[11px]
            font-medium
            text-zinc-600
          "
        >
          ARIA MJ
        </span>

        <span
          className="
            text-[11px]
            text-zinc-600
          "
        >
          Industrial Marketplace
        </span>
      </div>
    </div>
  );
}

/* ============================================================
   COLUMN HEADER
============================================================ */

function MegaMenuColumnHeader({
  item,
  href,
  hasChildren,
}: {
  item: MenuItem;
  href: string;
  hasChildren: boolean;
}) {
  /*
   * اگر URL معتبر نداریم، لینک واقعی نساز.
   *
   * این کار جلوی رفتن به # را هم می‌گیرد.
   */
  if (!href || href === "#") {
    return (
      <div
        className="
          mb-2
          flex
          items-center
          justify-between
          gap-2

          rounded-xl

          px-3
          py-2.5
        "
      >
        <span
          className="
            truncate
            text-sm
            font-bold
            text-white
          "
        >
          {item.title}
        </span>

        {hasChildren && (
          <ChevronLeft
            size={14}
            className="
              shrink-0
              text-zinc-600
            "
          />
        )}
      </div>
    );
  }

  return (
    <Link
      href={href}
      target={
        item.openInNewTab
          ? "_blank"
          : undefined
      }
      rel={
        item.openInNewTab
          ? "noopener noreferrer"
          : undefined
      }
      className="
        group/column

        mb-2

        flex
        items-center
        justify-between
        gap-2

        rounded-xl

        px-3
        py-2.5

        transition

        hover:bg-white/5
      "
    >
      <span
        className="
          truncate

          text-sm
          font-bold
          text-white

          transition

          group-hover/column:text-orange-400
        "
      >
        {item.title}
      </span>

      <ChevronLeft
        size={14}
        className="
          shrink-0

          text-zinc-600

          transition

          group-hover/column:translate-x-[-2px]
          group-hover/column:text-orange-400
        "
      />
    </Link>
  );
}

/* ============================================================
   MENU ACTION
============================================================ */

function MenuActionLink({
  item,
  label,
}: {
  item: MenuItem;
  label: string;
}) {
  const href = getMenuHref(item);

  if (!href || href === "#") {
    return null;
  }

  return (
    <Link
      href={href}
      target={
        item.openInNewTab
          ? "_blank"
          : undefined
      }
      rel={
        item.openInNewTab
          ? "noopener noreferrer"
          : undefined
      }
      className="
        flex
        shrink-0
        items-center
        gap-1

        rounded-lg

        px-3
        py-2

        text-xs
        font-semibold
        text-orange-400

        transition

        hover:bg-orange-500/10
      "
    >
      {label}

      <ChevronLeft size={14} />
    </Link>
  );
}

/* ============================================================
   MEGA MENU LINK
============================================================ */

function MegaMenuLink({
  item,
}: {
  item: MenuItem;
}) {
  /*
   * URL نهایی را فقط از یک محل تولید می‌کنیم.
   */
  const href = getMenuHref(item);

  /*
   * اگر URL نداریم، آیتم را به # نفرست.
   *
   * این مورد برای جلوگیری از 404/Navigation اشتباه مهم است.
   */
  if (!href || href === "#") {
    return (
      <div
        className="
          flex
          items-center
          gap-2

          rounded-lg

          px-3
          py-2

          text-xs
          text-zinc-500
        "
      >
        <span
          className="
            h-1
            w-1
            shrink-0
            rounded-full
            bg-zinc-700
          "
        />

        <span className="truncate">
          {item.title}
        </span>
      </div>
    );
  }

  return (
    <Link
      href={href}
      target={
        item.openInNewTab
          ? "_blank"
          : undefined
      }
      rel={
        item.openInNewTab
          ? "noopener noreferrer"
          : undefined
      }
      className="
        group/link

        flex
        items-center
        justify-between
        gap-2

        rounded-lg

        px-3
        py-2

        text-xs
        text-zinc-400

        transition

        hover:bg-orange-500/10
        hover:text-orange-400
      "
    >
      <span className="truncate">
        {item.title}
      </span>

      {item.openInNewTab ? (
        <ExternalLink
          size={12}
          className="
            shrink-0

            text-zinc-600

            transition

            group-hover/link:text-orange-400
          "
        />
      ) : (
        <span
          className="
            h-1
            w-1
            shrink-0

            rounded-full

            bg-zinc-700

            transition

            group-hover/link:bg-orange-500
          "
        />
      )}
    </Link>
  );
}