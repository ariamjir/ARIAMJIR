"use client";

import { usePathname } from "next/navigation";

import Header from "./Header";
import Footer from "./Footer";

export default function SiteChrome({
  children,
}: {
  children: React.ReactNode;
}) {
  const pathname = usePathname();

  const isAdmin =
    pathname === "/admin" ||
    pathname.startsWith("/admin/");

  const isLogin =
    pathname === "/login";

  if (isAdmin || isLogin) {
    return <>{children}</>;
  }

  return (
    <>
      <Header />

      {children}

      <Footer />
    </>
  );
}