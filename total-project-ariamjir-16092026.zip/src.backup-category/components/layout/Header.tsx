"use client";

import DesktopHeader from "./DesktopHeader";

export default function Header() {
  return (
    <header>
      <DesktopHeader />
    </header>
  );
}