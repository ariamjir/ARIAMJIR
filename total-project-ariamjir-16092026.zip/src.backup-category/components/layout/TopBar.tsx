"use client";

import {
  Mail,
  Phone,
  Smartphone,
  User,
} from "lucide-react";

export default function TopBar() {
  return (
    <div className="border-b border-white/10 bg-[#111111]">

      <div className="mx-auto flex h-11 max-w-[1600px] items-center justify-between px-8">

        {/* RIGHT */}

        <div className="flex items-center">

          <button
            className="
              flex
              items-center
              gap-2
              text-[14px]
              text-gray-300
              transition
              hover:text-white
            "
          >
            <User
              size={16}
              className="text-[#F47C20]"
            />

            ورود / ثبت نام

          </button>

        </div>

        {/* LEFT */}

        <div className="flex items-center gap-5 text-[14px] text-gray-300">

          <div className="flex items-center gap-2">

            <Mail
              size={15}
              className="text-[#F47C20]"
            />

            info@ariamj.ir

          </div>

          <span className="text-[#555]">|</span>

          <div className="flex items-center gap-2">

            <Phone
              size={15}
              className="text-[#F47C20]"
            />

            021-88106385

          </div>

          <span className="text-[#555]">|</span>

          <div className="flex items-center gap-2">

            <Smartphone
              size={15}
              className="text-[#F47C20]"
            />

            +989121404927

          </div>

        </div>

      </div>

    </div>
  );
}