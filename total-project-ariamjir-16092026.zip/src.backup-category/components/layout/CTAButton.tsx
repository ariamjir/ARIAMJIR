"use client";

import Link from "next/link";

import { Plus } from "lucide-react";

import { useHeaderConfig } from "./useHeaderConfig";

/* ============================================================
   دکمهٔ CTA هدر — متن و لینک از تنظیمات پنل
============================================================ */

export default function CTAButton() {
  const cfg = useHeaderConfig();

  if (!cfg.cta.visible) return null;

  return (
    <Link
      href={cfg.cta.href}
      className="
        inline-flex
        items-center
        gap-2
        rounded-full
        bg-[#F58220]
        px-5
        py-2.5
        text-sm
        font-black
        text-white
        shadow-lg
        shadow-orange-500/25
        transition
        hover:bg-orange-600
      "
    >
      {cfg.cta.text}
      <Plus className="h-4 w-4" />
    </Link>
  );
}