"use client";

import Link from "next/link";

import {
  ChevronDown,
  ChevronLeft,
  ExternalLink,
} from "lucide-react";

import {
  useEffect,
  useMemo,
  useState,
} from "react";

import { getMenuHref } from "@/features/home/navigation/menuUrl";

/* ============================================================
   MENU TYPES
============================================================ */

type MenuCategory = {
  id: string;
  name: string;
  slug: string;
  link: string | null;
};

type MenuItem = {
  id: string;
  title: string;
  href: string | null;

  parentId: string | null;

  type: string;

  icon: string | null;

  categoryId: string | null;

  sortOrder: number;

  active: boolean;

  showDesktop: boolean;
  showMobile: boolean;

  openInNewTab: boolean;

  megaMenu: boolean;

  category?: MenuCategory | null;
};

/* ============================================================
   CATEGORY TYPES
============================================================ */

type MegaMenuCategory = {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  image: string | null;
  parentId: string | null;
  sortOrder: number;
  active: boolean;
  showInMenu: boolean;
};

/* ============================================================
   COMPONENT
============================================================ */

export default function NavMenu() {
  const [items, setItems] =
    useState<MenuItem[]>([]);

  const [categories, setCategories] =
    useState<MegaMenuCategory[]>([]);

  const [loading, setLoading] =
    useState(true);

  const [categoriesLoading, setCategoriesLoading] =
    useState(true);

  /* ==========================================================
     LOAD MENU
  ========================================================== */

  useEffect(() => {
    let mounted = true;

    async function loadMenu() {
      try {
        const response = await fetch(
          "/api/menu",
          {
            method: "GET",
            cache: "no-store",
          },
        );

        if (!response.ok) {
          throw new Error(
            "Failed to load menu",
          );
        }

        const data =
          await response.json();

        if (!mounted) return;

        setItems(
          Array.isArray(data?.items)
            ? data.items
            : [],
        );
      } catch (error) {
        console.error(
          "[NavMenu] Failed to load menu:",
          error,
        );

        if (mounted) {
          setItems([]);
        }
      } finally {
        if (mounted) {
          setLoading(false);
        }
      }
    }

    loadMenu();

    return () => {
      mounted = false;
    };
  }, []);

  /* ==========================================================
     LOAD CATEGORY TREE
  ========================================================== */

  useEffect(() => {
    let mounted = true;

    async function loadCategories() {
      try {
        const response =
          await fetch(
            "/api/menu/categories",
            {
              method: "GET",
              cache: "no-store",
            },
          );

        if (!response.ok) {
          throw new Error(
            "Failed to load menu categories",
          );
        }

        const data =
          await response.json();

        if (!mounted) return;

        setCategories(
          Array.isArray(data?.items)
            ? data.items
            : [],
        );
      } catch (error) {
        console.error(
          "[NavMenu] Failed to load categories:",
          error,
        );

        if (mounted) {
          setCategories([]);
        }
      } finally {
        if (mounted) {
          setCategoriesLoading(false);
        }
      }
    }

    loadCategories();

    return () => {
      mounted = false;
    };
  }, []);

  /* ==========================================================
     ROOT MENUS
  ========================================================== */

  const rootMenus = useMemo(() => {
    return items
      .filter(
        (item) =>
          item.active &&
          item.showDesktop &&
          !item.parentId,
      )
      .sort(
        (a, b) =>
          a.sortOrder -
          b.sortOrder,
      );
  }, [items]);

  /* ==========================================================
     MENU CHILDREN
  ========================================================== */

  const getChildren = (
    parentId: string,
  ): MenuItem[] => {
    return items
      .filter(
        (item) =>
          item.active &&
          item.showDesktop &&
          item.parentId === parentId,
      )
      .sort(
        (a, b) =>
          a.sortOrder -
          b.sortOrder,
      );
  };

  /* ==========================================================
     CATEGORY CHILDREN
  ========================================================== */

  const getCategoryChildren = (
    parentId: string,
  ): MegaMenuCategory[] => {
    return categories
      .filter(
        (category) =>
          category.active &&
          category.showInMenu &&
          category.parentId === parentId,
      )
      .sort(
        (a, b) =>
          a.sortOrder -
          b.sortOrder,
      );
  };

  /* ==========================================================
     ROOT CATEGORIES
     
     فقط دسته‌هایی که parent ندارند.
     برای سایر منوها قابل استفاده است.
  ========================================================== */

  const rootCategories = useMemo(() => {
    return categories
      .filter(
        (category) =>
          category.active &&
          category.showInMenu &&
          !category.parentId,
      )
      .sort(
        (a, b) =>
          a.sortOrder -
          b.sortOrder,
      );
  }, [categories]);

  /* ==========================================================
     HEAVY MACHINERY ROOT
     
     پیدا کردن خود heavy-machinery
  ========================================================== */

  const heavyMachineryRoot =
    useMemo(() => {
      return categories.find(
        (category) =>
          category.active &&
          category.showInMenu &&
          category.slug ===
            "heavy-machinery",
      );
    }, [categories]);

  /* ==========================================================
     MACHINE MEGA MENU CATEGORIES
     
     اینجا مهم‌ترین اصلاح انجام شده است:

     heavy-machinery
          ↓
     فرزندان مستقیم آن

     مثال:

     heavy-machinery
       ├── road-construction
       ├── earthmoving
       ├── mining
       ├── oil-gas
       ├── concrete
       └── industrial
  ========================================================== */

  const machineRootCategories =
    useMemo(() => {
      if (!heavyMachineryRoot) {
        return [];
      }

      return categories
        .filter(
          (category) =>
            category.active &&
            category.showInMenu &&
            category.parentId ===
              heavyMachineryRoot.id,
        )
        .sort(
          (a, b) =>
            a.sortOrder -
            b.sortOrder,
        );
    }, [
      categories,
      heavyMachineryRoot,
    ]);

  /* ==========================================================
     HREF
  ========================================================== */

  const getHref = (
    item: MenuItem,
  ): string => {
    return getMenuHref(item);
  };

  /* ==========================================================
     LOADING
  ========================================================== */

  if (loading) {
    return (
      <nav
        aria-label="منوی اصلی"
        className="
          flex
          items-center
          gap-8
        "
      >
        <div className="h-5 w-20 animate-pulse rounded bg-white/10" />

        <div className="h-5 w-24 animate-pulse rounded bg-white/10" />

        <div className="h-5 w-16 animate-pulse rounded bg-white/10" />

        <div className="h-5 w-20 animate-pulse rounded bg-white/10" />
      </nav>
    );
  }

  /* ==========================================================
     EMPTY
  ========================================================== */

  if (!rootMenus.length) {
    return null;
  }

  /* ==========================================================
     NAVIGATION
  ========================================================== */

  return (
    <nav
      aria-label="منوی اصلی"
      className="
        relative
        flex
        h-full
        items-center
        gap-7
        lg:gap-8
        2xl:gap-10
      "
    >
      {rootMenus.map((item) => {
        /* ====================================================
           MENU CHILDREN
        ==================================================== */

        const children =
          getChildren(item.id);

        const hasChildren =
          children.length > 0;

        /* ====================================================
           HREF
        ==================================================== */

        const href =
          getHref(item);

        /* ====================================================
           MEGA MENU
        ==================================================== */

        const isMega =
          item.megaMenu ||
          item.type === "MEGA";

        /* ====================================================
           MACHINE MEGA MENU
           
           فقط منوی «بازار ماشین‌آلات»
           از Category Tree ماشین‌آلات استفاده می‌کند.
        ==================================================== */

        const isMachineMega =
          isMega &&
          (
            href === "/machines" ||
            item.category?.slug ===
              "heavy-machinery"
          );

        /* ====================================================
           CATEGORY MEGA MENU
        ==================================================== */

        const hasCategoryMegaMenu =
          isMachineMega &&
          machineRootCategories.length >
            0;

        /* ====================================================
           NORMAL DROPDOWN
        ==================================================== */

        const hasDropdown =
          !isMachineMega &&
          hasChildren;

        /* ====================================================
           PANEL
        ==================================================== */

        const shouldShowPanel =
          hasCategoryMegaMenu ||
          hasDropdown;

        return (
          <div
            key={item.id}
            className="
              group
              relative
              flex
              h-20
              items-center
            "
          >
            {/* ==================================================
                MAIN MENU ITEM
            ================================================== */}

            <Link
              href={href}
              target={
                item.openInNewTab
                  ? "_blank"
                  : undefined
              }
              rel={
                item.openInNewTab
                  ? "noopener noreferrer"
                  : undefined
              }
              className="
                relative
                flex
                h-full
                items-center
                gap-1.5
                whitespace-nowrap
                text-[15px]
                font-semibold
                text-white
                transition
                duration-200
                hover:text-orange-400
              "
            >
              <span>
                {item.title}
              </span>

              {shouldShowPanel && (
                <ChevronDown
                  size={15}
                  strokeWidth={2}
                  className="
                    mt-0.5
                    transition-transform
                    duration-200
                    group-hover:rotate-180
                  "
                />
              )}

              {/* UNDERLINE */}

              <span
                className="
                  absolute
                  bottom-5
                  right-0
                  h-[2px]
                  w-0
                  rounded-full
                  bg-orange-500
                  transition-all
                  duration-200
                  group-hover:w-full
                "
              />
            </Link>

            {/* ==================================================
                PANEL
            ================================================== */}

            {shouldShowPanel && (
              <div
                className="
                  invisible
                  absolute
                  top-[calc(100%-1px)]
                  right-1/2
                  z-[500]
                  w-[min(1080px,calc(100vw-48px))]
                  translate-x-1/2
                  translate-y-3
                  rounded-3xl
                  border
                  border-white/10
                  bg-zinc-950/98
                  p-5
                  opacity-0
                  shadow-[0_25px_80px_rgba(0,0,0,.55)]
                  backdrop-blur-2xl
                  transition-all
                  duration-200
                  group-hover:visible
                  group-hover:translate-y-0
                  group-hover:opacity-100
                "
              >
                {/* =================================================
                    ORANGE TOP LINE
                ================================================= */}

                <div
                  className="
                    absolute
                    -top-[1px]
                    left-10
                    right-10
                    h-[2px]
                    rounded-full
                    bg-orange-500
                  "
                />

                {/* =================================================
                    MEGA MENU
                ================================================= */}

                {isMachineMega ? (
                  <MegaMenuContent
                    item={item}
                    categories={
                      machineRootCategories
                    }
                    getCategoryChildren={
                      getCategoryChildren
                    }
                    categoriesLoading={
                      categoriesLoading
                    }
                    getHref={getHref}
                  />
                ) : (
                  /* =================================================
                     NORMAL DROPDOWN
                  ================================================= */

                  <div className="space-y-1">
                    {children.map(
                      (child) => (
                        <DropdownItem
                          key={
                            child.id
                          }
                          item={child}
                          getHref={
                            getHref
                          }
                          getChildren={
                            getChildren
                          }
                        />
                      ),
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
        );
      })}
    </nav>
  );
}

/* ============================================================
   NORMAL DROPDOWN ITEM
============================================================ */

function DropdownItem({
  item,
  getHref,
  getChildren,
}: {
  item: MenuItem;

  getHref: (
    item: MenuItem,
  ) => string;

  getChildren: (
    parentId: string,
  ) => MenuItem[];
}) {
  const children =
    getChildren(item.id);

  const hasChildren =
    children.length > 0;

  return (
    <div className="group/sub relative">
      <Link
        href={getHref(item)}
        target={
          item.openInNewTab
            ? "_blank"
            : undefined
        }
        rel={
          item.openInNewTab
            ? "noopener noreferrer"
            : undefined
        }
        className="
          flex
          items-center
          justify-between
          gap-3
          rounded-xl
          px-4
          py-3
          text-sm
          font-medium
          text-zinc-200
          transition
          duration-200
          hover:bg-orange-500/10
          hover:text-orange-400
        "
      >
        <span className="truncate">
          {item.title}
        </span>

        {hasChildren ? (
          <ChevronLeft
            size={15}
            className="
              shrink-0
              text-zinc-500
              transition
              group-hover/sub:text-orange-400
            "
          />
        ) : item.openInNewTab ? (
          <ExternalLink
            size={13}
            className="
              shrink-0
              text-zinc-600
            "
          />
        ) : (
          <span
            className="
              h-1.5
              w-1.5
              shrink-0
              rounded-full
              bg-zinc-600
            "
          />
        )}
      </Link>

      {/* ======================================================
          LEVEL 3
      ====================================================== */}

      {hasChildren && (
        <div
          className="
            invisible
            absolute
            right-full
            top-0
            z-[510]
            mr-1
            w-[250px]
            translate-x-2
            rounded-2xl
            border
            border-white/10
            bg-zinc-950/98
            p-2
            opacity-0
            shadow-[0_20px_60px_rgba(0,0,0,.45)]
            backdrop-blur-2xl
            transition-all
            duration-200
            group-hover/sub:visible
            group-hover/sub:translate-x-0
            group-hover/sub:opacity-100
          "
        >
          {children.map(
            (child) => (
              <DropdownItem
                key={child.id}
                item={child}
                getHref={getHref}
                getChildren={
                  getChildren
                }
              />
            ),
          )}
        </div>
      )}
    </div>
  );
}

/* ============================================================
   MEGA MENU CONTENT
============================================================ */

function MegaMenuContent({
  item,
  categories,
  getCategoryChildren,
  categoriesLoading,
  getHref,
}: {
  item: MenuItem;

  categories: MegaMenuCategory[];

  getCategoryChildren: (
    parentId: string,
  ) => MegaMenuCategory[];

  categoriesLoading: boolean;

  getHref: (
    item: MenuItem,
  ) => string;
}) {
  /* ==========================================================
     LOADING
  ========================================================== */

  if (categoriesLoading) {
    return (
      <div className="py-8">
        <div
          className="
            grid
            grid-cols-2
            gap-6
            lg:grid-cols-3
            xl:grid-cols-4
          "
        >
          {Array.from({
            length: 4,
          }).map((_, index) => (
            <div
              key={index}
              className="space-y-3"
            >
              <div className="h-10 animate-pulse rounded-xl bg-white/5" />

              <div className="h-7 animate-pulse rounded-lg bg-white/5" />

              <div className="h-7 animate-pulse rounded-lg bg-white/5" />

              <div className="h-7 animate-pulse rounded-lg bg-white/5" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  /* ==========================================================
     EMPTY
  ========================================================== */

  if (!categories.length) {
    return (
      <div className="py-8 text-center">
        <p className="text-sm text-zinc-500">
          دسته‌بندی‌ای برای نمایش در منو
          وجود ندارد.
        </p>
      </div>
    );
  }

  /* ==========================================================
     CONTENT
  ========================================================== */

  return (
    <>
      {/* ======================================================
          HEADER
      ====================================================== */}

      <div
        className="
          mb-5
          flex
          items-center
          justify-between
          border-b
          border-white/10
          pb-4
        "
      >
        <div>
          <h3
            className="
              text-lg
              font-black
              text-white
            "
          >
            {item.title}
          </h3>

          <p
            className="
              mt-1
              text-xs
              text-zinc-500
            "
          >
            انتخاب دسته ماشین‌آلات
          </p>
        </div>

        {item.href && (
          <Link
            href={getHref(item)}
            target={
              item.openInNewTab
                ? "_blank"
                : undefined
            }
            rel={
              item.openInNewTab
                ? "noopener noreferrer"
                : undefined
            }
            className="
              flex
              items-center
              gap-1
              rounded-lg
              px-3
              py-2
              text-xs
              font-semibold
              text-orange-400
              transition
              hover:bg-orange-500/10
            "
          >
            مشاهده همه

            <ChevronLeft
              size={14}
            />
          </Link>
        )}
      </div>

      {/* ======================================================
          CATEGORY COLUMNS
      ====================================================== */}

      <div
        className="
          grid
          grid-cols-2
          gap-x-6
          gap-y-7
          lg:grid-cols-3
          xl:grid-cols-4
        "
      >
        {categories.map(
          (category) => {
            const children =
              getCategoryChildren(
                category.id,
              );

            return (
              <MegaCategoryColumn
                key={category.id}
                category={category}
                children={children}
              />
            );
          },
        )}
      </div>

      {/* ======================================================
          FOOTER
      ====================================================== */}

      <div
        className="
          mt-6
          flex
          items-center
          justify-between
          border-t
          border-white/10
          pt-4
        "
      >
        <span
          className="
            text-[11px]
            text-zinc-600
          "
        >
          ARIA MJ
        </span>

        <span
          className="
            text-[11px]
            text-zinc-600
          "
        >
          Industrial Marketplace
        </span>
      </div>
    </>
  );
}

/* ============================================================
   MEGA CATEGORY COLUMN
============================================================ */

function MegaCategoryColumn({
  category,
  children,
}: {
  category: MegaMenuCategory;

  children: MegaMenuCategory[];
}) {
  const href =
    `/machines/category/${category.slug}`;

  return (
    <div className="min-w-0">
      {/* ======================================================
          CATEGORY TITLE
      ====================================================== */}

      <Link
        href={href}
        className="
          group/category
          mb-2
          flex
          items-center
          justify-between
          gap-2
          rounded-xl
          px-3
          py-2.5
          transition
          hover:bg-white/5
        "
      >
        <span
          className="
            truncate
            text-sm
            font-bold
            text-white
            transition
            group-hover/category:text-orange-400
          "
        >
          {category.name}
        </span>

        <ChevronLeft
          size={14}
          className="
            shrink-0
            text-zinc-600
            transition
            group-hover/category:-translate-x-0.5
            group-hover/category:text-orange-400
          "
        />
      </Link>

      {/* ======================================================
          SUB CATEGORIES
      ====================================================== */}

      {children.length > 0 && (
        <div className="space-y-0.5">
          {children.map(
            (child) => (
              <MegaCategoryLink
                key={child.id}
                category={child}
              />
            ),
          )}
        </div>
      )}

      {/* ======================================================
          NO CHILDREN
      ====================================================== */}

      {children.length === 0 && (
        <div
          className="
            px-3
            text-[11px]
            text-zinc-700
          "
        >
          مشاهده ماشین‌آلات
        </div>
      )}
    </div>
  );
}

/* ============================================================
   CATEGORY LINK
============================================================ */

function MegaCategoryLink({
  category,
}: {
  category: MegaMenuCategory;
}) {
  return (
    <Link
      href={`/machines/category/${category.slug}`}
      className="
        group/category-link
        flex
        items-center
        justify-between
        gap-2
        rounded-lg
        px-3
        py-2
        text-xs
        text-zinc-400
        transition
        hover:bg-orange-500/10
        hover:text-orange-400
      "
    >
      <span className="truncate">
        {category.name}
      </span>

      <span
        className="
          h-1
          w-1
          shrink-0
          rounded-full
          bg-zinc-700
          transition
          group-hover/category-link:bg-orange-500
        "
      />
    </Link>
  );
}