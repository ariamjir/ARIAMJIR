"use client";

import Link from "next/link";
import {
  Phone,
  Smartphone,
  Mail,
  MapPin,
  Clock,
  ArrowUp,
} from "lucide-react";

import { useSiteSettings } from "@/hooks/useSiteSettings";
import { SOCIAL_ICON_MAP } from "@/components/icons/SocialIcons";

function resolveIcon(key: string, iconName?: string) {
  const k = (iconName || key).toLowerCase();
  return SOCIAL_ICON_MAP[k] || null;
}

export default function Footer() {
  const { settings: s, loading } = useSiteSettings();

  if (loading || !s) {
    return (
      <footer className="bg-[#080808] py-16" dir="rtl">
        <div className="mx-auto max-w-[1440px] px-6 lg:px-10">
          <div className="grid gap-12 lg:grid-cols-12">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="space-y-3 lg:col-span-3">
                <div className="h-4 w-24 animate-pulse rounded bg-white/10" />
                <div className="h-3 w-full animate-pulse rounded bg-white/5" />
                <div className="h-3 w-3/4 animate-pulse rounded bg-white/5" />
              </div>
            ))}
          </div>
        </div>
      </footer>
    );
  }

  const activeSocials = s.socials.filter((x) => x.active && x.url);

  return (
    <footer className="relative border-t border-white/[0.06] bg-[#080808]" dir="rtl">
      {/* ===== بدنهٔ اصلی ===== */}
      <div className="mx-auto max-w-[1440px] px-6 pb-14 pt-16 lg:px-10">
        <div className="grid gap-12 lg:grid-cols-12 lg:gap-8">
          {/* ---- ستون برند ---- */}
          <div className="lg:col-span-4">
            <div className="flex items-center gap-3">
              {s.logoUrl ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={s.logoUrl}
                  alt={s.brandName}
                  className="h-10 w-auto max-w-[180px] object-contain"
                />
              ) : (
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-[#F58220] text-lg font-black text-white">
                  A
                </div>
              )}
              <div>
                <div className="text-base font-black text-white">{s.brandName}</div>
                <div className="mt-0.5 text-[9px] font-bold uppercase tracking-[0.3em] text-[#F58220]">
                  Industrial Marketplace
                </div>
              </div>
            </div>

            <p className="mt-5 max-w-sm text-[13px] leading-6 text-white/45">
              {s.about || s.tagline}
            </p>

            {/* شبکه‌های اجتماعی */}
            {activeSocials.length > 0 && (
              <div className="mt-6 flex flex-wrap gap-2.5">
                {activeSocials.map((soc) => {
                  const Icon = resolveIcon(soc.key, soc.iconName);
                  return (
                    <a
                      key={soc.key}
                      href={soc.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      title={soc.name}
                      className="flex h-9 w-9 items-center justify-center rounded-full border border-white/10 text-white/50 transition-all duration-300 hover:border-transparent hover:text-white"
                      onMouseEnter={(e) => {
                        e.currentTarget.style.backgroundColor = soc.color || "#F58220";
                        e.currentTarget.style.borderColor = soc.color || "#F58220";
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.backgroundColor = "transparent";
                        e.currentTarget.style.borderColor = "rgba(255,255,255,0.1)";
                      }}
                    >
                      {Icon ? (
                        <Icon className="h-4 w-4" />
                      ) : (
                        <span className="text-[11px] font-black">{soc.name.charAt(0)}</span>
                      )}
                    </a>
                  );
                })}
              </div>
            )}

            {/* نمادهای اعتماد */}
            {s.trustBadges.length > 0 && (
              <div className="mt-7 flex items-center gap-3">
                {s.trustBadges.map((b, i) => (
                  <a
                    key={i}
                    href={b.url || "#"}
                    target="_blank"
                    rel="noopener noreferrer"
                    title={b.name}
                    className="flex h-14 w-14 items-center justify-center rounded-lg border border-white/[0.08] bg-white/[0.03] p-1.5 transition hover:border-white/20"
                  >
                    {b.imageUrl ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img
                        src={b.imageUrl}
                        alt={b.name}
                        className="h-full w-full object-contain"
                      />
                    ) : (
                      <span className="text-[8px] font-bold text-white/35">{b.name}</span>
                    )}
                  </a>
                ))}
              </div>
            )}
          </div>

          {/* ---- ستون‌های لینک ---- */}
          {s.customColumns.map((col, idx) => (
            <div key={idx} className="lg:col-span-2">
              <h3 className="mb-5 text-[13px] font-black text-white">{col.title}</h3>
              <ul className="space-y-3">
                {col.links.map((link, i) => (
                  <li key={i}>
                    <Link
                      href={link.href}
                      className="text-[13px] text-white/45 transition-colors hover:text-[#F58220]"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}

          {/* ---- ستون تماس + خبرنامه ---- */}
          <div className="lg:col-span-4">
            <h3 className="mb-5 text-[13px] font-black text-white">تماس با ما</h3>

            <ul className="space-y-3.5">
              {s.phones.map((phone, i) => (
                <li key={i} className="flex items-center gap-3">
                  <Phone className="h-3.5 w-3.5 shrink-0 text-[#F58220]" />
                  <a
                    href={`tel:${phone.replace(/\s/g, "")}`}
                    dir="ltr"
                    className="text-[13px] text-white/55 transition-colors hover:text-[#F58220]"
                  >
                    {phone}
                  </a>
                </li>
              ))}

              {/* موبایل‌ها */}
              {(s.mobiles ?? []).map((mobile, i) => (
                <li key={i} className="flex items-center gap-3">
                  <Smartphone className="h-3.5 w-3.5 shrink-0 text-[#F58220]" />
                  <a
                    href={`tel:${mobile.replace(/\s/g, "")}`}
                    dir="ltr"
                    className="text-[13px] text-white/55 transition-colors hover:text-[#F58220]"
                  >
                    {mobile}
                  </a>
                </li>
              ))}

              {s.emails.map((email, i) => (
                <li key={i} className="flex items-center gap-3">
                  <Mail className="h-3.5 w-3.5 shrink-0 text-[#F58220]" />
                  <a
                    href={`mailto:${email}`}
                    dir="ltr"
                    className="text-[13px] text-white/55 transition-colors hover:text-[#F58220]"
                  >
                    {email}
                  </a>
                </li>
              ))}
              {s.address && (
                <li className="flex items-start gap-3">
                  <MapPin className="mt-0.5 h-3.5 w-3.5 shrink-0 text-[#F58220]" />
                  <span className="text-[13px] leading-6 text-white/55">{s.address}</span>
                </li>
              )}
              {s.workingHours && (
                <li className="flex items-start gap-3">
                  <Clock className="mt-0.5 h-3.5 w-3.5 shrink-0 text-[#F58220]" />
                  <span className="text-[13px] leading-6 text-white/55">{s.workingHours}</span>
                </li>
              )}
            </ul>

            {/* خبرنامه */}
            {s.newsletterEnabled && (
              <div className="mt-7">
                <div className="text-[13px] font-black text-white">{s.newsletterTitle}</div>
                <p className="mt-1.5 text-[11px] leading-5 text-white/40">{s.newsletterDesc}</p>
                <form
                  className="mt-3 flex overflow-hidden rounded-lg border border-white/10 bg-white/[0.04] focus-within:border-[#F58220]/60"
                  onSubmit={(e) => {
                    e.preventDefault();
                    alert("عضویت شما ثبت شد!");
                  }}
                >
                  <input
                    type="email"
                    required
                    placeholder="ایمیل شما"
                    dir="ltr"
                    className="flex-1 bg-transparent px-4 py-2.5 text-[12px] text-white outline-none placeholder:text-white/25"
                  />
                  <button
                    type="submit"
                    className="shrink-0 bg-[#F58220] px-5 text-[12px] font-black text-white transition hover:bg-orange-600"
                  >
                    عضویت
                  </button>
                </form>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* ===== نوار پایینی ===== */}
      <div className="border-t border-white/[0.06]">
        <div className="mx-auto flex max-w-[1440px] flex-col items-center justify-between gap-4 px-6 py-5 md:flex-row lg:px-10">
          <div className="text-[11px] text-white/35">{s.copyright}</div>

          <nav className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2">
            {s.footerLinks.map((link, i) => (
              <Link
                key={i}
                href={link.href}
                className="text-[11px] text-white/40 transition-colors hover:text-[#F58220]"
              >
                {link.label}
              </Link>
            ))}
          </nav>

          <button
            onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
            className="flex h-9 w-9 items-center justify-center rounded-full border border-white/10 text-white/40 transition hover:border-[#F58220] hover:text-[#F58220]"
            aria-label="بازگشت به بالا"
          >
            <ArrowUp className="h-4 w-4" />
          </button>
        </div>
      </div>
    </footer>
  );
}