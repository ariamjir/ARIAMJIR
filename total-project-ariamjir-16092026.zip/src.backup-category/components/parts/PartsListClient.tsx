"use client";

import { useEffect, useState } from "react";

import { Search, Loader2, ChevronLeft, ChevronRight, Package } from "lucide-react";

import PartCard from "@/components/parts/PartCard";

export default function PartsListClient() {
  const [data, setData] = useState<any>(null);
  const [page, setPage] = useState(1);
  const [cat, setCat] = useState("");
  const [brand, setBrand] = useState("");
  const [q, setQ] = useState("");

  useEffect(() => {
    const params = new URLSearchParams({ page: String(page) });
    if (cat) params.set("category", cat);
    if (brand) params.set("brand", brand);
    if (q.trim()) params.set("q", q.trim());

    fetch(`/api/parts?${params.toString()}`)
      .then((r) => r.json())
      .then((j) => {
        if (j.success) setData(j.data);
      });
  }, [page, cat, brand, q]);

  return (
    <div className="mx-auto max-w-[1440px] px-5 pt-32 pb-16 lg:px-10">
      <div className="mb-10 text-center">
        <div className="text-xs font-black tracking-[0.3em] text-[#F58220]">GENUINE PARTS</div>
        <h1 className="mt-3 text-3xl font-black text-white lg:text-4xl">بازار قطعات یدکی</h1>
        <p className="mt-3 text-sm text-white/50">
          قطعات اصلی و اورجینال ماشین‌آلات سنگین — با ضمانت اصالت آریا ماشین جم
        </p>
      </div>

      {/* فیلترها */}
      <div className="mb-8 flex flex-wrap items-center justify-center gap-3">
        <div className="relative">
          <Search className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-white/30" />
          <input
            value={q}
            onChange={(e) => { setQ(e.target.value); setPage(1); }}
            placeholder="جستجو: نام قطعه، OEM، SKU..."
            className="h-11 w-72 rounded-xl border border-white/10 bg-white/[0.05] pr-9 pl-3 text-xs text-white outline-none focus:border-[#F58220]/60"
          />
        </div>

        <select
          value={brand}
          onChange={(e) => { setBrand(e.target.value); setPage(1); }}
          className="h-11 rounded-xl border border-white/10 bg-[#141414] px-3 text-xs text-white outline-none"
        >
          <option value="">همه برندها</option>
          {(data?.brands ?? []).map((b: any) => (
            <option key={b.id} value={b.slug}>{b.name}</option>
          ))}
        </select>

        <button
          onClick={() => { setCat(""); setPage(1); }}
          className={`rounded-full px-4 py-2 text-[11px] font-bold transition ${!cat ? "bg-[#F58220] text-white" : "border border-white/10 text-white/60 hover:text-white"}`}
        >
          همه
        </button>

        {(data?.categories ?? []).map((c: any) => (
          <button
            key={c.id}
            onClick={() => { setCat(c.slug); setPage(1); }}
            className={`rounded-full px-4 py-2 text-[11px] font-bold transition ${cat === c.slug ? "bg-[#F58220] text-white" : "border border-white/10 text-white/60 hover:text-white"}`}
          >
            {c.name}
          </button>
        ))}
      </div>

      {!data ? (
        <div className="flex h-64 items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-orange-500" />
        </div>
      ) : data.items.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-white/15 bg-white/[0.02] p-12 text-center">
          <Package className="mx-auto h-12 w-12 text-white/20" />
          <p className="mt-4 text-sm font-bold text-white/50">هنوز قطعه‌ای ثبت نشده است.</p>
          <p className="mt-2 text-xs text-white/35">به‌زودی اولین قطعات با ضمانت اصالت در این بخش قرار می‌گیرند.</p>
        </div>
      ) : (
        <>
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {data.items.map((p: any) => (
              <PartCard key={p.id} part={p} />
            ))}
          </div>

          {data.pages > 1 && (
            <div className="mt-10 flex items-center justify-center gap-3">
              <button disabled={page <= 1} onClick={() => setPage((p) => p - 1)} className="flex h-9 w-9 items-center justify-center rounded-lg border border-white/10 text-white disabled:opacity-40">
                <ChevronRight className="h-4 w-4" />
              </button>
              <span className="text-sm font-bold text-white/60">{page} / {data.pages}</span>
              <button disabled={page >= data.pages} onClick={() => setPage((p) => p + 1)} className="flex h-9 w-9 items-center justify-center rounded-lg border border-white/10 text-white disabled:opacity-40">
                <ChevronLeft className="h-4 w-4" />
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
}