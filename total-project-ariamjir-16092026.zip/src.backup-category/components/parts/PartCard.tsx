import Link from "next/link";

import { Package, Boxes } from "lucide-react";

/* ============================================================
   کارت قطعه — تم تیره هم‌خانواده با سایت
============================================================ */

export function priceLabel(price: any) {
  if (!price?.price) return "تماس بگیرید";
  return `${Number(price.price).toLocaleString("fa-IR")} تومان`;
}

export default function PartCard({ part }: { part: any }) {
  const image = part.images?.[0]?.url ?? "/images/machines/default.svg";

  return (
    <Link
      href={`/parts/${part.slug}`}
      className="group flex h-full flex-col overflow-hidden rounded-2xl border border-white/10 bg-[#141414] transition hover:border-[#F58220]/40"
    >
      <div className="relative aspect-[4/3] overflow-hidden bg-white/[0.03]">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={image}
          alt={part.title}
          loading="lazy"
          className="h-full w-full object-contain p-6 transition duration-500 group-hover:scale-105"
        />
        {part.category && (
          <span className="absolute top-3 right-3 rounded-full bg-[#F58220] px-2.5 py-1 text-[9px] font-black text-white">
            {part.category.name}
          </span>
        )}
      </div>

      <div className="flex flex-1 flex-col gap-2 p-4">
        <h3 className="line-clamp-2 text-sm font-black text-white transition group-hover:text-[#F58220]">
          {part.title}
        </h3>

        <div className="flex items-center gap-2 text-[10px] text-white/40">
          <Package className="h-3 w-3" />
          {part.brand?.name ?? "بدون برند"}
          {part.oemNumber && <span className="mr-auto" dir="ltr">OEM: {part.oemNumber}</span>}
        </div>

        <div className="mt-auto flex items-center justify-between pt-2">
          <span className="text-sm font-black text-[#F58220]">{priceLabel(part.price)}</span>
          {part.price?.stock > 0 ? (
            <span className="inline-flex items-center gap-1 rounded-full bg-green-500/15 px-2 py-0.5 text-[9px] font-bold text-green-400">
              <Boxes className="h-3 w-3" />
              موجود ({part.price.stock.toLocaleString("fa-IR")})
            </span>
          ) : (
            <span className="rounded-full bg-white/5 px-2 py-0.5 text-[9px] font-bold text-white/40">
              ناموجود
            </span>
          )}
        </div>
      </div>
    </Link>
  );
}