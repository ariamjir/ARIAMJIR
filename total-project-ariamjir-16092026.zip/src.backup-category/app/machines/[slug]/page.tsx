import Link from "next/link";
import { notFound } from "next/navigation";

import { prisma } from "@/lib/prisma";

/* ============================================================
   TYPES
============================================================ */

type Props = {
  params: Promise<{
    slug: string;
  }>;
};

/* ============================================================
   GET CATEGORY
============================================================ */

async function getCategory(slug: string) {
  return prisma.category.findUnique({
    where: {
      slug,
    },

    select: {
      id: true,
      name: true,
      slug: true,
      description: true,

      parent: {
        select: {
          id: true,
          name: true,
          slug: true,
        },
      },
    },
  });
}

/* ============================================================
   GET CATEGORY TREE IDS
============================================================ */

async function getCategoryTreeIds(
  rootCategoryId: string,
): Promise<string[]> {
  const categories =
    await prisma.category.findMany({
      select: {
        id: true,
        parentId: true,
      },
    });

  const ids = new Set<string>();

  ids.add(rootCategoryId);

  let changed = true;

  while (changed) {
    changed = false;

    for (const category of categories) {
      if (
        category.parentId &&
        ids.has(category.parentId) &&
        !ids.has(category.id)
      ) {
        ids.add(category.id);
        changed = true;
      }
    }
  }

  return Array.from(ids);
}

/* ============================================================
   GET MACHINES
============================================================ */

async function getMachines(
  categoryIds: string[],
) {
  return prisma.machine.findMany({
    where: {
      categoryId: {
        in: categoryIds,
      },
    },

    orderBy: {
      createdAt: "desc",
    },

    select: {
      id: true,
      title: true,
      slug: true,
      shortDescription: true,
      listingType: true,
      status: true,

      brand: {
        select: {
          id: true,
          name: true,
        },
      },

      images: {
        orderBy: {
          sortOrder: "asc",
        },

        select: {
          id: true,
          url: true,
          alt: true,
        },
      },
    },
  });
}

/* ============================================================
   GET CHILD CATEGORIES
============================================================ */

async function getChildCategories(
  parentId: string,
) {
  return prisma.category.findMany({
    where: {
      parentId,
    },

    orderBy: {
      sortOrder: "asc",
    },

    select: {
      id: true,
      name: true,
      slug: true,
      description: true,
    },
  });
}

/* ============================================================
   PAGE
============================================================ */

export default async function CategoryPage({
  params,
}: Props) {
  const { slug } = await params;

  /* ==========================================================
     CATEGORY
  ========================================================== */

  const category =
    await getCategory(slug);

  if (!category) {
    notFound();
  }

  /* ==========================================================
     CATEGORY TREE
  ========================================================== */

  const categoryIds =
    await getCategoryTreeIds(
      category.id,
    );

  /* ==========================================================
     MACHINES
  ========================================================== */

  const machines =
    await getMachines(
      categoryIds,
    );

  /* ==========================================================
     DIRECT CHILDREN
  ========================================================== */

  const children =
    await getChildCategories(
      category.id,
    );

  /* ==========================================================
     PAGE
  ========================================================== */

  return (
    <main
      dir="rtl"
      className="
        min-h-screen
        w-full
        overflow-x-hidden
        bg-white
        pb-20
        pt-32
      "
    >
      <div
        className="
          mx-auto
          w-full
          max-w-7xl
          px-4
          sm:px-6
          lg:px-8
        "
      >

        {/* ==================================================
            BREADCRUMB
        ================================================== */}

        <nav
          aria-label="مسیر صفحه"
          className="
            mb-6
            flex
            min-w-0
            flex-wrap
            items-center
            gap-2
            text-sm
            text-gray-400
          "
        >
          <Link
            href="/"
            className="
              shrink-0
              transition
              hover:text-orange-500
            "
          >
            صفحه اصلی
          </Link>

          <span>/</span>

          <Link
            href="/machines"
            className="
              shrink-0
              transition
              hover:text-orange-500
            "
          >
            ماشین‌آلات
          </Link>

          {category.parent && (
            <>
              <span>/</span>

              <Link
                href={`/machines/category/${category.parent.slug}`}
                className="
                  shrink-0
                  transition
                  hover:text-orange-500
                "
              >
                {category.parent.name}
              </Link>
            </>
          )}

          <span>/</span>

          <span
            className="
              min-w-0
              truncate
              font-medium
              text-gray-700
            "
          >
            {category.name}
          </span>
        </nav>

        {/* ==================================================
            HEADER
        ================================================== */}

        <header
          className="
            mb-10
            flex
            min-w-0
            flex-col
            gap-4
            lg:flex-row
            lg:items-end
            lg:justify-between
          "
        >
          <div className="min-w-0">

            <div
              className="
                mb-2
                text-sm
                font-bold
                text-orange-500
              "
            >
              بازار ماشین‌آلات
            </div>

            <h1
              className="
                break-words
                text-3xl
                font-black
                leading-tight
                text-gray-950
                sm:text-4xl
                lg:text-5xl
              "
            >
              {category.name}
            </h1>

            {category.description && (
              <p
                className="
                  mt-4
                  max-w-3xl
                  text-sm
                  leading-8
                  text-gray-500
                  sm:text-base
                "
              >
                {category.description}
              </p>
            )}
          </div>

          <div
            className="
              shrink-0
              text-sm
              font-semibold
              text-gray-500
            "
          >
            {machines.length} مورد
          </div>
        </header>

        {/* ==================================================
            SUB CATEGORIES
        ================================================== */}

        {children.length > 0 && (
          <section
            aria-label="زیر دسته‌ها"
            className="mb-10"
          >
            <div
              className="
                mb-4
                flex
                items-center
                justify-between
              "
            >
              <h2
                className="
                  text-lg
                  font-black
                  text-gray-900
                "
              >
                دسته‌بندی‌های این بخش
              </h2>
            </div>

            <div
              className="
                grid
                grid-cols-1
                gap-3
                sm:grid-cols-2
                lg:grid-cols-3
                xl:grid-cols-4
              "
            >
              {children.map(
                (child) => (
                  <Link
                    key={child.id}
                    href={`/machines/category/${child.slug}`}
                    className="
                      group
                      rounded-2xl
                      border
                      border-gray-200
                      bg-white
                      p-4
                      transition
                      duration-200
                      hover:-translate-y-0.5
                      hover:border-orange-300
                      hover:shadow-lg
                    "
                  >
                    <div
                      className="
                        flex
                        items-center
                        justify-between
                        gap-3
                      "
                    >
                      <span
                        className="
                          text-sm
                          font-bold
                          text-gray-900
                          transition
                          group-hover:text-orange-500
                        "
                      >
                        {child.name}
                      </span>

                      <span
                        className="
                          text-orange-500
                        "
                      >
                        ←
                      </span>
                    </div>

                    {child.description && (
                      <p
                        className="
                          mt-2
                          line-clamp-2
                          text-xs
                          leading-6
                          text-gray-500
                        "
                      >
                        {child.description}
                      </p>
                    )}
                  </Link>
                ),
              )}
            </div>
          </section>
        )}

        {/* ==================================================
            MACHINES
        ================================================== */}

        {machines.length === 0 ? (
          <EmptyState
            categoryName={category.name}
          />
        ) : (
          <section
            aria-label="ماشین‌آلات"
            className="
              grid
              w-full
              min-w-0
              grid-cols-1
              gap-6
              sm:grid-cols-2
              xl:grid-cols-3
            "
          >
            {machines.map(
              (machine) => (
                <MachineCard
                  key={machine.id}
                  machine={machine}
                />
              ),
            )}
          </section>
        )}
      </div>
    </main>
  );
}

/* ============================================================
   MACHINE CARD
============================================================ */

function MachineCard({
  machine,
}: {
  machine: Awaited<
    ReturnType<typeof getMachines>
  >[number];
}) {
  const image =
    machine.images.find(
      (item) => Boolean(item.url),
    );

  return (
    <article
      className="
        group
        min-w-0
        overflow-hidden
        rounded-3xl
        border
        border-gray-200
        bg-white
        shadow-sm
        transition
        duration-300
        hover:-translate-y-1
        hover:border-orange-200
        hover:shadow-xl
      "
    >
      <Link
        href={`/machines/${machine.slug}`}
        className="block min-w-0"
      >
        <div
          className="
            relative
            aspect-[16/10]
            w-full
            overflow-hidden
            bg-gray-100
          "
        >
          {image?.url ? (
            <img
              src={image.url}
              alt={
                image.alt ||
                machine.title
              }
              className="
                h-full
                w-full
                object-cover
                transition
                duration-500
                group-hover:scale-105
              "
            />
          ) : (
            <div
              className="
                flex
                h-full
                w-full
                items-center
                justify-center
                bg-gradient-to-br
                from-gray-100
                to-gray-200
              "
            >
              <div
                className="
                  text-center
                  text-gray-400
                "
              >
                <div className="text-5xl">
                  🚜
                </div>

                <div className="mt-2 text-xs">
                  بدون تصویر
                </div>
              </div>
            </div>
          )}

          {isActiveStatus(
            machine.status,
          ) && (
            <span
              className="
                absolute
                right-4
                top-4
                rounded-full
                bg-orange-500
                px-3
                py-1.5
                text-[11px]
                font-bold
                text-white
                shadow-lg
              "
            >
              موجود
            </span>
          )}
        </div>
      </Link>

      <div className="min-w-0 p-5">

        {machine.brand && (
          <div
            className="
              mb-2
              truncate
              text-xs
              font-bold
              text-orange-500
            "
          >
            {machine.brand.name}
          </div>
        )}

        <Link
          href={`/machines/${machine.slug}`}
          className="block min-w-0"
        >
          <h2
            className="
              line-clamp-2
              text-lg
              font-black
              leading-8
              text-gray-950
              transition
              group-hover:text-orange-500
            "
          >
            {machine.title}
          </h2>
        </Link>

        {machine.shortDescription && (
          <p
            className="
              mt-3
              line-clamp-2
              text-sm
              leading-7
              text-gray-500
            "
          >
            {machine.shortDescription}
          </p>
        )}

        <div
          className="
            mt-5
            flex
            min-w-0
            items-center
            justify-between
            gap-3
            border-t
            border-gray-100
            pt-4
          "
        >
          <span
            className="
              truncate
              text-xs
              text-gray-400
            "
          >
            {formatListingType(
              machine.listingType,
            )}
          </span>

          <Link
            href={`/machines/${machine.slug}`}
            className="
              shrink-0
              text-xs
              font-bold
              text-orange-500
              transition
              hover:text-orange-600
            "
          >
            مشاهده
          </Link>
        </div>
      </div>
    </article>
  );
}

/* ============================================================
   EMPTY STATE
============================================================ */

function EmptyState({
  categoryName,
}: {
  categoryName: string;
}) {
  return (
    <section
      className="
        flex
        min-h-[360px]
        w-full
        flex-col
        items-center
        justify-center
        rounded-3xl
        border
        border-dashed
        border-gray-200
        bg-gray-50
        px-6
        text-center
      "
    >
      <div className="text-5xl">
        🚜
      </div>

      <h2
        className="
          mt-5
          text-xl
          font-black
          text-gray-900
        "
      >
        هنوز ماشینی در این دسته ثبت نشده است
      </h2>

      <p
        className="
          mt-3
          max-w-md
          text-sm
          leading-7
          text-gray-500
        "
      >
        در حال حاضر برای دسته
        «{categoryName}»
        آگهی فعالی وجود ندارد.
      </p>

      <Link
        href="/machines"
        className="
          mt-6
          inline-flex
          h-11
          items-center
          justify-center
          rounded-xl
          bg-orange-500
          px-6
          text-sm
          font-bold
          text-white
          shadow-lg
          shadow-orange-500/20
          transition
          hover:bg-orange-600
        "
      >
        مشاهده همه ماشین‌آلات
      </Link>
    </section>
  );
}

/* ============================================================
   ACTIVE STATUS
============================================================ */

function isActiveStatus(
  value: unknown,
): boolean {
  if (typeof value !== "string") {
    return false;
  }

  const normalized =
    value.trim().toLowerCase();

  return (
    normalized === "active" ||
    normalized === "published" ||
    normalized === "available"
  );
}

/* ============================================================
   LISTING TYPE
============================================================ */

function formatListingType(
  value:
    | string
    | null
    | undefined,
): string {
  if (!value) {
    return "نامشخص";
  }

  switch (
    value.toUpperCase()
  ) {
    case "SALE":
      return "فروش";

    case "RENT":
      return "اجاره";

    case "AUCTION":
      return "مزایده";

    default:
      return value;
  }
}