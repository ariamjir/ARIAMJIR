import Link from "next/link";
import { notFound } from "next/navigation";

import { prisma } from "@/lib/prisma";

/* ============================================================
   TYPES
============================================================ */

type Props = {
  params: Promise<{
    slug: string;
  }>;
};

/* ============================================================
   CATEGORY
============================================================ */

async function getCategory(
  slug: string,
) {
  return prisma.category.findUnique({
    where: {
      slug,
    },
    select: {
      id: true,
      name: true,
      slug: true,
      description: true,
      image: true,
      banner: true,
      parentId: true,
      active: true,
    },
  });
}

/* ============================================================
   CATEGORY TREE
============================================================ */

async function getCategoryTree() {
  return prisma.category.findMany({
    where: {
      active: true,
    },
    select: {
      id: true,
      parentId: true,
    },
  });
}

/* ============================================================
   COLLECT CATEGORY IDS
============================================================ */

function collectCategoryIds(
  rootId: string,
  categories: Array<{
    id: string;
    parentId: string | null;
  }>,
): string[] {
  const ids = new Set<string>();

  ids.add(rootId);

  let changed = true;

  while (changed) {
    changed = false;

    for (const category of categories) {
      if (
        category.parentId &&
        ids.has(category.parentId) &&
        !ids.has(category.id)
      ) {
        ids.add(category.id);
        changed = true;
      }
    }
  }

  return Array.from(ids);
}

/* ============================================================
   MACHINES
============================================================ */

async function getMachines(
  categoryIds: string[],
) {
  if (!categoryIds.length) {
    return [];
  }

  return prisma.machine.findMany({
    where: {
      active: true,

      categoryId: {
        in: categoryIds,
      },
    },

    orderBy: [
      {
        featured: "desc",
      },
      {
        createdAt: "desc",
      },
    ],

    select: {
      id: true,
      title: true,
      slug: true,
      shortDescription: true,
      featured: true,

      brand: {
        select: {
          id: true,
          name: true,
        },
      },

      category: {
        select: {
          id: true,
          name: true,
          slug: true,
        },
      },

      images: {
        orderBy: {
          sortOrder: "asc",
        },

        take: 1,

        select: {
          url: true,
          alt: true,
        },
      },
    },
  });
}

/* ============================================================
   PAGE
============================================================ */

export default async function MachineCategoryPage({
  params,
}: Props) {
  const { slug } = await params;

  /*
   * مهم:
   * این صفحه مستقیماً Prisma را صدا می‌زند.
   *
   * هیچ fetch به:
   * /api/categories/...
   * /api/machines/...
   * نداریم.
   */

  const category =
    await getCategory(slug);

  if (
    !category ||
    !category.active
  ) {
    notFound();
  }

  const allCategories =
    await getCategoryTree();

  const categoryIds =
    collectCategoryIds(
      category.id,
      allCategories,
    );

  const machines =
    await getMachines(
      categoryIds,
    );

  return (
    <main
      dir="rtl"
      className="
        min-h-screen
        bg-zinc-50
      "
    >
      {/* ======================================================
          HERO
      ====================================================== */}

      <section
        className="
          relative
          overflow-hidden
          bg-zinc-950
        "
      >
        {category.banner && (
          <img
            src={category.banner}
            alt={category.name}
            className="
              absolute
              inset-0
              h-full
              w-full
              object-cover
              opacity-30
            "
          />
        )}

        <div
          className="
            absolute
            inset-0
            bg-gradient-to-l
            from-black
            via-black/80
            to-black/40
          "
        />

        <div
          className="
            relative
            mx-auto
            max-w-7xl
            px-6
            pb-16
            pt-36
            lg:px-8
            lg:pb-20
            lg:pt-40
          "
        >
          <div className="max-w-3xl">
            <div
              className="
                mb-4
                text-sm
                font-bold
                text-orange-400
              "
            >
              بازار ماشین‌آلات
            </div>

            <h1
              className="
                text-4xl
                font-black
                tracking-tight
                text-white
                md:text-5xl
              "
            >
              {category.name}
            </h1>

            {category.description && (
              <p
                className="
                  mt-5
                  max-w-2xl
                  text-base
                  leading-8
                  text-zinc-300
                  md:text-lg
                "
              >
                {category.description}
              </p>
            )}

            <div
              className="
                mt-7
                inline-flex
                rounded-full
                border
                border-white/10
                bg-white/5
                px-4
                py-2
                text-sm
                text-zinc-300
                backdrop-blur
              "
            >
              {machines.length} ماشین در این
              دسته‌بندی
            </div>
          </div>
        </div>
      </section>

      {/* ======================================================
          CONTENT
      ====================================================== */}

      <section
        className="
          mx-auto
          max-w-7xl
          px-6
          py-12
          lg:px-8
          lg:py-16
        "
      >
        {machines.length === 0 ? (
          <div
            className="
              rounded-3xl
              border
              border-zinc-200
              bg-white
              p-12
              text-center
              shadow-sm
            "
          >
            <div
              className="
                mx-auto
                flex
                h-16
                w-16
                items-center
                justify-center
                rounded-2xl
                bg-orange-50
                text-2xl
              "
            >
              🚜
            </div>

            <h2
              className="
                mt-5
                text-xl
                font-black
                text-zinc-900
              "
            >
              هنوز ماشینی در این دسته ثبت نشده است
            </h2>

            <p
              className="
                mx-auto
                mt-3
                max-w-xl
                text-sm
                leading-7
                text-zinc-500
              "
            >
              به‌زودی ماشین‌آلات این دسته در
              آریا ام‌جی نمایش داده خواهند شد.
            </p>

            <Link
              href="/machines"
              className="
                mt-7
                inline-flex
                items-center
                rounded-xl
                bg-orange-500
                px-6
                py-3
                text-sm
                font-bold
                text-white
                transition
                hover:bg-orange-600
              "
            >
              مشاهده همه ماشین‌آلات
            </Link>
          </div>
        ) : (
          <>
            {/* ==================================================
                HEADER
            ================================================== */}

            <div
              className="
                mb-8
                flex
                items-end
                justify-between
                gap-4
              "
            >
              <div>
                <div
                  className="
                    text-sm
                    font-bold
                    text-orange-500
                  "
                >
                  ماشین‌آلات موجود
                </div>

                <h2
                  className="
                    mt-1
                    text-2xl
                    font-black
                    text-zinc-900
                    md:text-3xl
                  "
                >
                  {category.name}
                </h2>
              </div>

              <span
                className="
                  hidden
                  rounded-full
                  bg-zinc-100
                  px-4
                  py-2
                  text-sm
                  font-semibold
                  text-zinc-600
                  sm:block
                "
              >
                {machines.length} مورد
              </span>
            </div>

            {/* ==================================================
                MACHINE GRID
            ================================================== */}

            <div
              className="
                grid
                gap-6
                sm:grid-cols-2
                lg:grid-cols-3
                xl:grid-cols-4
              "
            >
              {machines.map(
                (machine) => {
                  const image =
                    machine.images[0];

                  return (
                    <Link
                      key={machine.id}
                      href={`/machines/${machine.slug}`}
                      className="
                        group
                        overflow-hidden
                        rounded-3xl
                        border
                        border-zinc-200
                        bg-white
                        shadow-sm
                        transition
                        duration-300
                        hover:-translate-y-1
                        hover:border-orange-200
                        hover:shadow-xl
                      "
                    >
                      {/* IMAGE */}

                      <div
                        className="
                          relative
                          h-56
                          overflow-hidden
                          bg-zinc-100
                        "
                      >
                        {image?.url ? (
                          <img
                            src={image.url}
                            alt={
                              image.alt ||
                              machine.title
                            }
                            className="
                              h-full
                              w-full
                              object-cover
                              transition
                              duration-500
                              group-hover:scale-105
                            "
                          />
                        ) : (
                          <div
                            className="
                              flex
                              h-full
                              items-center
                              justify-center
                              text-sm
                              text-zinc-400
                            "
                          >
                            بدون تصویر
                          </div>
                        )}

                        {machine.featured && (
                          <span
                            className="
                              absolute
                              right-3
                              top-3
                              rounded-full
                              bg-orange-500
                              px-3
                              py-1
                              text-xs
                              font-black
                              text-white
                              shadow-lg
                            "
                          >
                            ویژه
                          </span>
                        )}
                      </div>

                      {/* CONTENT */}

                      <div className="p-5">
                        <div
                          className="
                            text-xs
                            font-bold
                            text-orange-600
                          "
                        >
                          {machine.brand?.name ||
                            "برند نامشخص"}
                        </div>

                        <h2
                          className="
                            mt-2
                            line-clamp-2
                            text-lg
                            font-black
                            leading-7
                            text-zinc-900
                            transition
                            group-hover:text-orange-600
                          "
                        >
                          {machine.title}
                        </h2>

                        {machine.shortDescription && (
                          <p
                            className="
                              mt-2
                              line-clamp-2
                              text-sm
                              leading-6
                              text-zinc-500
                            "
                          >
                            {
                              machine.shortDescription
                            }
                          </p>
                        )}

                        <div
                          className="
                            mt-5
                            flex
                            items-center
                            justify-between
                            border-t
                            border-zinc-100
                            pt-4
                          "
                        >
                          <span
                            className="
                              truncate
                              text-xs
                              text-zinc-500
                            "
                          >
                            {
                              machine
                                .category
                                ?.name
                            }
                          </span>

                          <span
                            className="
                              text-sm
                              font-black
                              text-orange-600
                            "
                          >
                            مشاهده
                          </span>
                        </div>
                      </div>
                    </Link>
                  );
                },
              )}
            </div>
          </>
        )}
      </section>
    </main>
  );
}