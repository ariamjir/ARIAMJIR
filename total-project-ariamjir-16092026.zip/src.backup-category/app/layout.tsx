import "./globals.css";

import SiteChrome from "@/components/layout/SiteChrome";

import CompareBar from "@/modules/compare/components/CompareBar";

import ChatWidget from "@/components/chatbot/ChatWidget";

import { SearchProvider } from "@/features/home/search";

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="fa" dir="rtl" data-scroll-behavior="smooth">
      <body className="bg-black text-gray-900">
        <SearchProvider>
          <SiteChrome>{children}</SiteChrome>
          <CompareBar />
          <ChatWidget />
        </SearchProvider>
      </body>
    </html>
  );
}