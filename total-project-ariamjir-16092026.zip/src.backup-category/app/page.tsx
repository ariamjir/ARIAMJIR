import { prisma } from "@/lib/prisma";

import { getHomeHero } from "@/modules/home";

import HomepageSectionsRenderer from "@/features/home/HomepageSectionsRenderer";

export default async function HomePage() {
  const [hero, sections] = await Promise.all([
    getHomeHero(),

    prisma.homePageSection.findMany({
      orderBy: {
        order: "asc",
      },
    }),
  ]);

  return (
        <main
      className="
        site-theme
        min-h-screen
        overflow-hidden
        bg-[#111111]
      "
    >
      <HomepageSectionsRenderer
        hero={hero}
        sections={sections}
      />
    </main>
  );
}