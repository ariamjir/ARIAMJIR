import type { Metadata } from "next";

import PriceEstimatorClient from "@/features/price-estimator/PriceEstimatorClient";

export default function PriceEstimatorPage() {
  return <PriceEstimatorClient />;
}

export const metadata: Metadata = {
  title: "تخمین قیمت هوشمند ماشین‌آلات | آریا ماشین جم",
  description:
    "با استفاده از هوش مصنوعی و بررسی دقیق قطعات، قیمت واقعی ماشین‌آلات سنگین خود را تخمین بزنید.",
};
