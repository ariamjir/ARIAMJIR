import Link from "next/link";

import { prisma } from "@/lib/prisma";

import MachineTable from "@/components/admin/MachineTable";

export default async function MachinesPage() {
  const machines = await prisma.machine.findMany({
    include: {
      brand: {
        select: {
          name: true,
        },
      },

      category: {
        select: {
          name: true,
        },
      },

      specification: true,

      price: true,

      images: {
        where: {
          isPrimary: true,
        },
        take: 1,
      },

      _count: {
        select: {
          views: true,
        },
      },
    },

    orderBy: {
      createdAt: "desc",
    },
  });

  async function deleteMachine(id: string) {
    "use server";

    await prisma.machine.delete({
      where: {
        id,
      },
    });
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">
            مدیریت ماشین‌آلات
          </h1>

          <p className="mt-2 text-gray-500">
            لیست ماشین‌آلات ثبت شده
          </p>
        </div>

        <Link
          href="/admin/machines/new"
          className="rounded-lg bg-orange-500 px-5 py-3 font-bold text-white hover:bg-orange-600"
        >
          + ثبت ماشین
        </Link>
      </div>

      <MachineTable
        machines={machines.map((item) => ({
          id: item.id,

          title: item.title,

          slug: item.slug,

          model: item.specification?.model ?? null,

          image: item.images[0]?.url ?? null,

          manufactureYear:
            item.specification?.manufactureYear ?? null,

          province:
            item.specification?.provinceId ?? null,

          city:
            item.specification?.cityId ?? null,

          price:
            item.price?.price == null
              ? null
              : Number(item.price.price),

          views: item._count.views,

          featured: item.featured,

          active: item.active,

          createdAt: item.createdAt.toISOString(),

          brand: item.brand,

          category: item.category,
        }))}
      />
    </div>
  );
}