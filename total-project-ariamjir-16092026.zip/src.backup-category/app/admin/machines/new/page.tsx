"use client";

import NewMachineWizard from "@/modules/machine/components/NewMachineWizard";

export default function NewMachinePage() {
  return (
    <div className="mx-auto max-w-5xl p-6">
      <NewMachineWizard />
    </div>
  );
}