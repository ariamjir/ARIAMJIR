import MachineWizard from "@/modules/machine/components/MachineWizard";

export default async function EditMachinePage() {
  return <MachineWizard />;
}
