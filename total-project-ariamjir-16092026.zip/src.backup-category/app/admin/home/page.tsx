import {
  Image,
  Building2,
  Wrench,
  Newspaper,
  ShieldCheck,
  BarChart3,
  PanelBottom,
  LayoutGrid,
  Menu,
  PanelTop,
} from "lucide-react";

import SectionCard from "@/features/home-builder/SectionCard";
import Sidebar from "@/features/home-builder/Sidebar";

const sections = [
  {
    title: "هیرو و اسلایدر",
    description: "مدیریت اسلایدر صفحه اصلی",
    href: "/admin/home/hero",
    icon: Image,
    color: "bg-orange-500",
  },
  {
    title: "هدر سایت",
    description: "لوگو، متون، دکمه و حالت‌های هدر",
    href: "/admin/home/header",
    icon: PanelTop,
    color: "bg-slate-500",
  },
  {
    title: "برندها",
    description: "مدیریت برندها",
    href: "/admin/home/brands",
    icon: Building2,
    color: "bg-blue-500",
  },
  {
    title: "خدمات",
    description: "مدیریت خدمات",
    href: "/admin/home/services",
    icon: Wrench,
    color: "bg-green-500",
  },
  {
    title: "اخبار",
    description: "مدیریت اخبار",
    href: "/admin/home/news",
    icon: Newspaper,
    color: "bg-purple-500",
  },
  {
    title: "چرا آریا ماشین جم",
    description: "مدیریت مزیت‌ها",
    href: "/admin/home/why-us",
    icon: ShieldCheck,
    color: "bg-emerald-500",
  },
  {
    title: "آمار",
    description: "مدیریت آمار",
    href: "/admin/home/stats",
    icon: BarChart3,
    color: "bg-yellow-500",
  },
  {
    title: "فوتر",
    description: "مدیریت فوتر",
    href: "/admin/home/footer",
    icon: PanelBottom,
    color: "bg-zinc-700",
  },
  {
    title: "چیدمان صفحه اول",
    description: "ترتیب و فعال‌سازی بخش‌های صفحه",
    href: "/admin/homepage-layout",
    icon: LayoutGrid,
    color: "bg-indigo-500",
  },
  {
    title: "منوی سایت",
    description: "مدیریت ناوبری هدر و لینک‌ها",
    href: "/admin/menu",
    icon: Menu,
    color: "bg-sky-500",
  },
];

export default function HomeManagerPage() {
  return (
    <div className="flex gap-8">

      <Sidebar />

      <div className="flex-1">

        <h1 className="mb-2 text-3xl font-bold text-zinc-800">
          مدیریت صفحه اصلی
        </h1>

        <p className="mb-8 text-zinc-500">
          تمام بخش‌های صفحه اصلی از این قسمت مدیریت می‌شوند.
        </p>

        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">

          {sections.map((item) => (
            <SectionCard
              key={item.href}
              title={item.title}
              description={item.description}
              href={item.href}
              color={item.color}
              icon={item.icon}
            />
          ))}

        </div>

      </div>

    </div>
  );
}