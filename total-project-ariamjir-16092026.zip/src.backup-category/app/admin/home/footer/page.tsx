"use client";

import { useEffect, useRef, useState } from "react";

import {
  Save,
  Loader2,
  CheckCircle2,
  Plus,
  Trash2,
  Share2,
  LayoutGrid,
  ShieldCheck,
  FileText,
  Building2,
  Phone,
  ExternalLink,
  Upload,
} from "lucide-react";

/* ============================================================
   ادیتور فوتر و تنظیمات سایت — بدون نیاز به کدنویسی
============================================================ */

const TABS = [
  { key: "brand", label: "برند و معرفی", icon: Building2 },
  { key: "contact", label: "اطلاعات تماس", icon: Phone },
  { key: "socials", label: "شبکه‌های اجتماعی", icon: Share2 },
  { key: "columns", label: "ستون‌های لینک", icon: LayoutGrid },
  { key: "trust", label: "نمادها و خبرنامه", icon: ShieldCheck },
  { key: "footer", label: "کپی‌رایت و قانونی", icon: FileText },
] as const;

const SOCIAL_PRESETS = [
  { key: "instagram", name: "اینستاگرام", color: "#E1306C" },
  { key: "telegram", name: "تلگرام", color: "#0088CC" },
  { key: "whatsapp", name: "واتساپ", color: "#25D366" },
  { key: "linkedin", name: "لینکدین", color: "#0A66C2" },
  { key: "youtube", name: "یوتیوب", color: "#FF0000" },
  { key: "x", name: "ایکس (توییتر)", color: "#000000" },
  { key: "facebook", name: "فیسبوک", color: "#1877F2" },
  { key: "aparat", name: "آپارات", color: "#ED145B" },
  { key: "bale", name: "بله", color: "#00D0FF" },
  { key: "rubika", name: "روبیکا", color: "#9C27B0" },
  { key: "eitaa", name: "ایتا", color: "#EF6C00" },
];

/* resize خودکار لوگو — حفظ نسبت + شفافیت PNG */
async function resizeLogo(file: File, maxH = 120): Promise<File> {
  try {
    const bitmap = await createImageBitmap(file);
    const ratio = bitmap.width / bitmap.height;
    const h = Math.min(maxH, bitmap.height);
    const w = Math.round(h * ratio);
    const canvas = document.createElement("canvas");
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext("2d")!;
    ctx.drawImage(bitmap, 0, 0, w, h);
    bitmap.close();
    const blob = await new Promise<Blob | null>((res) =>
      canvas.toBlob((b) => res(b), "image/png")
    );
    if (!blob) return file;
    return new File([blob], "logo.png", { type: "image/png" });
  } catch {
    return file;
  }
}

export default function FooterSettingsPage() {
  const [form, setForm] = useState<any>(null);
  const [tab, setTab] = useState<string>("brand");
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [loading, setLoading] = useState(true);
  const [preset, setPreset] = useState("instagram");
  const [uploading, setUploading] = useState(false);
  const logoInput = useRef<HTMLInputElement>(null);

  useEffect(() => {
    fetch("/api/admin/site-settings")
      .then((r) => r.json())
      .then((j) => {
        if (j.success) setForm(j.data);
      })
      .finally(() => setLoading(false));
  }, []);

  const set = (key: string, value: any) => {
    setForm((f: any) => ({ ...f, [key]: value }));
    setSaved(false);
  };

  const uploadLogo = async (file: File) => {
    setUploading(true);
    try {
      const resized = await resizeLogo(file);
      const fd = new FormData();
      fd.append("file", resized);
      fd.append("folder", "site");
      const res = await fetch("/api/upload/image", { method: "POST", body: fd });
      if (!res.ok) throw new Error("آپلود ناموفق بود.");
      const json = await res.json();
      const url = json.url || json.path || json.src || "";
      if (url) set("logoUrl", url);
      else throw new Error("مسیر فایل بازگردانده نشد.");
    } catch (e: any) {
      alert(e?.message || "خطا در آپلود لوگو");
    } finally {
      setUploading(false);
    }
  };

  const save = async () => {
    setSaving(true);
    try {
      const res = await fetch("/api/admin/site-settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const j = await res.json();
      if (j.success) {
        setSaved(true);
        setTimeout(() => setSaved(false), 2500);
      } else {
        alert("خطا در ذخیره: " + (j.message || ""));
      }
    } finally {
      setSaving(false);
    }
  };

  if (loading || !form) {
    return (
      <div className="flex h-96 items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-orange-500" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* ===== نوار بالا ===== */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-zinc-800">
            فوتر و تنظیمات سایت
          </h1>
          <p className="mt-1 text-sm text-zinc-500">
            همهٔ موارد فوتر (تماس، شبکه‌ها، ستون‌ها، نمادها) بدون کدنویسی قابل
            ویرایش‌اند.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <a
            href="/"
            target="_blank"
            className="inline-flex items-center gap-2 rounded-xl border border-zinc-200 bg-white px-4 py-2.5 text-sm font-bold text-zinc-600 transition hover:border-orange-300"
          >
            <ExternalLink className="h-4 w-4" />
            مشاهدهٔ سایت
          </a>
          <button
            onClick={save}
            disabled={saving}
            className="inline-flex items-center gap-2 rounded-xl bg-orange-500 px-6 py-2.5 text-sm font-black text-white shadow transition hover:bg-orange-600 disabled:opacity-60"
          >
            {saving ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : saved ? (
              <CheckCircle2 className="h-4 w-4" />
            ) : (
              <Save className="h-4 w-4" />
            )}
            {saved ? "ذخیره شد" : "ذخیرهٔ تغییرات"}
          </button>
        </div>
      </div>

      {/* ===== تب‌ها ===== */}
      <div className="flex flex-wrap gap-2">
        {TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-bold transition ${
              tab === t.key
                ? "bg-zinc-800 text-white shadow"
                : "border border-zinc-200 bg-white text-zinc-600 hover:border-orange-300"
            }`}
          >
            <t.icon className="h-4 w-4" />
            {t.label}
          </button>
        ))}
      </div>

      {/* ================= تب برند ================= */}
      {tab === "brand" && (
        <Card title="برند و معرفی">
          <div className="grid gap-5 md:grid-cols-2">
            <Field label="نام برند">
              <Input value={form.brandName} onChange={(v) => set("brandName", v)} />
            </Field>
            <Field label="لوگو (آپلود یا URL)">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => logoInput.current?.click()}
                  disabled={uploading}
                  className="inline-flex shrink-0 items-center gap-2 rounded-lg bg-zinc-800 px-3 py-2 text-xs font-bold text-white transition hover:bg-zinc-700 disabled:opacity-60"
                >
                  {uploading ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Upload className="h-4 w-4" />
                  )}
                  {uploading ? "..." : "آپلود"}
                </button>
                <input
                  ref={logoInput}
                  type="file"
                  accept="image/*"
                  hidden
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (f) uploadLogo(f);
                    e.target.value = "";
                  }}
                />
                <Input
                  value={form.logoUrl ?? ""}
                  onChange={(v) => set("logoUrl", v)}
                  placeholder="/uploads/site/logo.png"
                  ltr
                />
              </div>
              <p className="mt-1.5 text-[11px] text-zinc-400">
                لوگو هنگام آپلود خودکار به ارتفاع ۱۲۰px تبدیل و در فوتر فیکس نمایش داده می‌شود.
              </p>
              {form.logoUrl && (
                <div className="mt-3 flex h-16 items-center rounded-lg border border-zinc-200 bg-white px-4">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={form.logoUrl}
                    alt="پیش‌نمایش لوگو"
                    className="max-h-12 max-w-[240px] object-contain"
                  />
                </div>
              )}
            </Field>
            <div className="md:col-span-2">
              <Field label="شعار / تگ‌لاین">
                <Input value={form.tagline} onChange={(v) => set("tagline", v)} />
              </Field>
            </div>
            <div className="md:col-span-2">
              <Field label="دربارهٔ ما (متن کوتاه فوتر)">
                <TextArea value={form.about ?? ""} onChange={(v) => set("about", v)} />
              </Field>
            </div>
          </div>
        </Card>
      )}

      {/* ================= تب تماس ================= */}
      {tab === "contact" && (
        <Card title="اطلاعات تماس">
          <div className="space-y-6">
            <ListEditor
              label="شماره‌های ثابت (تلفن)"
              items={form.phones}
              placeholder="021-12345678"
              onChange={(v) => set("phones", v)}
              ltr
            />
            <ListEditor
              label="شماره‌های موبایل"
              items={form.mobiles ?? []}
              placeholder="09121234567"
              onChange={(v) => set("mobiles", v)}
              ltr
            />
            <ListEditor
              label="ایمیل‌ها"
              items={form.emails}
              placeholder="info@ariamj.com"
              onChange={(v) => set("emails", v)}
              ltr
            />
            <Field label="آدرس">
              <TextArea value={form.address ?? ""} onChange={(v) => set("address", v)} />
            </Field>
            <Field label="ساعات کاری">
              <Input value={form.workingHours ?? ""} onChange={(v) => set("workingHours", v)} />
            </Field>
          </div>
        </Card>
      )}

      {/* ================= تب شبکه‌ها ================= */}
      {tab === "socials" && (
        <Card title="شبکه‌های اجتماعی (افزودن / حذف / فعال‌سازی)">
          <div className="space-y-3">
            {form.socials.map((soc: any, i: number) => (
              <div
                key={i}
                className="grid items-center gap-3 rounded-xl border border-zinc-200 bg-zinc-50 p-3 md:grid-cols-[auto_1fr_1.4fr_auto_auto_auto]"
              >
                <label className="flex cursor-pointer items-center gap-2 text-xs font-bold text-zinc-600">
                  <input
                    type="checkbox"
                    checked={!!soc.active}
                    onChange={(e) =>
                      set(
                        "socials",
                        form.socials.map((x: any, k: number) =>
                          k === i ? { ...x, active: e.target.checked } : x
                        )
                      )
                    }
                    className="h-4 w-4 accent-orange-500"
                  />
                  فعال
                </label>

                <Input
                  value={soc.name}
                  onChange={(v) =>
                    set(
                      "socials",
                      form.socials.map((x: any, k: number) =>
                        k === i ? { ...x, name: v } : x
                      )
                    )
                  }
                  placeholder="نام شبکه"
                />

                <Input
                  value={soc.url}
                  onChange={(v) =>
                    set(
                      "socials",
                      form.socials.map((x: any, k: number) =>
                        k === i ? { ...x, url: v } : x
                      )
                    )
                  }
                  placeholder="https://..."
                  ltr
                />

                <input
                  type="color"
                  value={soc.color || "#F58220"}
                  onChange={(e) =>
                    set(
                      "socials",
                      form.socials.map((x: any, k: number) =>
                        k === i ? { ...x, color: e.target.value } : x
                      )
                    )
                  }
                  className="h-9 w-12 cursor-pointer rounded-lg border border-zinc-200 bg-white p-1"
                  title="رنگ آیکون"
                />

                <span className="hidden text-[10px] text-zinc-400 md:block" dir="ltr">
                  {soc.key}
                </span>

                <IconBtn
                  onClick={() =>
                    set("socials", form.socials.filter((_: any, k: number) => k !== i))
                  }
                />
              </div>
            ))}

            <div className="flex flex-wrap items-center gap-3 rounded-xl border border-dashed border-orange-300 bg-orange-50 p-3">
              <select
                value={preset}
                onChange={(e) => setPreset(e.target.value)}
                className="rounded-lg border border-zinc-200 bg-white px-3 py-2 text-sm outline-none"
              >
                {SOCIAL_PRESETS.map((p) => (
                  <option key={p.key} value={p.key}>
                    {p.name}
                  </option>
                ))}
                <option value="custom">سفارشی (هر شبکهٔ دیگر)</option>
              </select>
              <button
                onClick={() => {
                  const p = SOCIAL_PRESETS.find((x) => x.key === preset);
                  const key = p ? p.key : `custom-${Date.now()}`;
                  if (form.socials.some((s: any) => s.key === key)) {
                    alert("این شبکه قبلاً اضافه شده است.");
                    return;
                  }
                  set("socials", [
                    ...form.socials,
                    {
                      key,
                      name: p ? p.name : "شبکهٔ جدید",
                      url: "",
                      color: p ? p.color : "#F58220",
                      active: true,
                    },
                  ]);
                }}
                className="inline-flex items-center gap-2 rounded-lg bg-orange-500 px-4 py-2 text-sm font-bold text-white transition hover:bg-orange-600"
              >
                <Plus className="h-4 w-4" />
                افزودن شبکه
              </button>
              <span className="text-[11px] text-zinc-500">
                بله، روبیکا، ایتا و هر شبکهٔ دیگر را بدون کدنویسی اضافه کن.
              </span>
            </div>
          </div>
        </Card>
      )}

      {/* ================= تب ستون‌ها ================= */}
      {tab === "columns" && (
        <div className="space-y-6">
          {form.customColumns.map((col: any, ci: number) => (
            <Card
              key={ci}
              title={`ستون: ${col.title || "بدون عنوان"}`}
              action={
                <IconBtn
                  onClick={() =>
                    set(
                      "customColumns",
                      form.customColumns.filter((_: any, k: number) => k !== ci)
                    )
                  }
                  label="حذف ستون"
                />
              }
            >
              <div className="space-y-4">
                <Field label="عنوان ستون">
                  <Input
                    value={col.title}
                    onChange={(v) =>
                      set(
                        "customColumns",
                        form.customColumns.map((c: any, k: number) =>
                          k === ci ? { ...c, title: v } : c
                        )
                      )
                    }
                  />
                </Field>

                <div className="space-y-2">
                  {col.links.map((link: any, li: number) => (
                    <div key={li} className="grid gap-2 md:grid-cols-[1fr_1.2fr_auto]">
                      <Input
                        value={link.label}
                        onChange={(v) =>
                          set(
                            "customColumns",
                            form.customColumns.map((c: any, k: number) =>
                              k === ci
                                ? {
                                    ...c,
                                    links: c.links.map((l: any, m: number) =>
                                      m === li ? { ...l, label: v } : l
                                    ),
                                  }
                                : c
                            )
                          )
                        }
                        placeholder="عنوان لینک"
                      />
                      <Input
                        value={link.href}
                        onChange={(v) =>
                          set(
                            "customColumns",
                            form.customColumns.map((c: any, k: number) =>
                              k === ci
                                ? {
                                    ...c,
                                    links: c.links.map((l: any, m: number) =>
                                      m === li ? { ...l, href: v } : l
                                    ),
                                  }
                                : c
                            )
                          )
                        }
                        placeholder="/machines"
                        ltr
                      />
                      <IconBtn
                        onClick={() =>
                          set(
                            "customColumns",
                            form.customColumns.map((c: any, k: number) =>
                              k === ci
                                ? { ...c, links: c.links.filter((_: any, m: number) => m !== li) }
                                : c
                            )
                          )
                        }
                      />
                    </div>
                  ))}

                  <button
                    onClick={() =>
                      set(
                        "customColumns",
                        form.customColumns.map((c: any, k: number) =>
                          k === ci
                            ? { ...c, links: [...c.links, { label: "", href: "/" }] }
                            : c
                        )
                      )
                    }
                    className="inline-flex items-center gap-1.5 rounded-lg border border-zinc-200 bg-white px-3 py-1.5 text-xs font-bold text-zinc-600 transition hover:border-orange-300"
                  >
                    <Plus className="h-3.5 w-3.5" />
                    افزودن لینک
                  </button>
                </div>
              </div>
            </Card>
          ))}

          <button
            onClick={() =>
              set("customColumns", [
                ...form.customColumns,
                { title: "ستون جدید", links: [] },
              ])
            }
            className="inline-flex items-center gap-2 rounded-xl bg-zinc-800 px-5 py-2.5 text-sm font-bold text-white transition hover:bg-zinc-700"
          >
            <Plus className="h-4 w-4" />
            افزودن ستون جدید
          </button>
        </div>
      )}

      {/* ================= تب نمادها ================= */}
      {tab === "trust" && (
        <Card title="نمادهای اعتماد و خبرنامه">
          <div className="space-y-6">
            <div className="space-y-2">
              <div className="text-sm font-bold text-zinc-700">نمادهای اعتماد</div>
              {form.trustBadges.map((b: any, i: number) => (
                <div key={i} className="grid gap-2 md:grid-cols-[1fr_1fr_1fr_auto]">
                  <Input
                    value={b.name}
                    onChange={(v) =>
                      set(
                        "trustBadges",
                        form.trustBadges.map((x: any, k: number) =>
                          k === i ? { ...x, name: v } : x
                        )
                      )
                    }
                    placeholder="نام نماد"
                  />
                  <Input
                    value={b.imageUrl}
                    onChange={(v) =>
                      set(
                        "trustBadges",
                        form.trustBadges.map((x: any, k: number) =>
                          k === i ? { ...x, imageUrl: v } : x
                        )
                      )
                    }
                    placeholder="/images/badges/enamad.png"
                    ltr
                  />
                  <Input
                    value={b.url ?? ""}
                    onChange={(v) =>
                      set(
                        "trustBadges",
                        form.trustBadges.map((x: any, k: number) =>
                          k === i ? { ...x, url: v } : x
                        )
                      )
                    }
                    placeholder="https://enamad.ir"
                    ltr
                  />
                  <IconBtn
                    onClick={() =>
                      set("trustBadges", form.trustBadges.filter((_: any, k: number) => k !== i))
                    }
                  />
                </div>
              ))}
              <button
                onClick={() =>
                  set("trustBadges", [
                    ...form.trustBadges,
                    { name: "", imageUrl: "", url: "" },
                  ])
                }
                className="inline-flex items-center gap-1.5 rounded-lg border border-zinc-200 bg-white px-3 py-1.5 text-xs font-bold text-zinc-600 transition hover:border-orange-300"
              >
                <Plus className="h-3.5 w-3.5" />
                افزودن نماد
              </button>
            </div>

            <div className="space-y-4 border-t border-zinc-100 pt-5">
              <label className="flex cursor-pointer items-center gap-2 text-sm font-bold text-zinc-700">
                <input
                  type="checkbox"
                  checked={!!form.newsletterEnabled}
                  onChange={(e) => set("newsletterEnabled", e.target.checked)}
                  className="h-4 w-4 accent-orange-500"
                />
                خبرنامه فعال باشد
              </label>
              <Field label="عنوان خبرنامه">
                <Input value={form.newsletterTitle} onChange={(v) => set("newsletterTitle", v)} />
              </Field>
              <Field label="توضیح خبرنامه">
                <Input value={form.newsletterDesc} onChange={(v) => set("newsletterDesc", v)} />
              </Field>
            </div>
          </div>
        </Card>
      )}

      {/* ================= تب کپی‌رایت ================= */}
      {tab === "footer" && (
        <Card title="کپی‌رایت و لینک‌های قانونی">
          <div className="space-y-5">
            <Field label="متن کپی‌رایت">
              <Input value={form.copyright ?? ""} onChange={(v) => set("copyright", v)} />
            </Field>

            <div className="space-y-2">
              <div className="text-sm font-bold text-zinc-700">لینک‌های پاورقی</div>
              {form.footerLinks.map((l: any, i: number) => (
                <div key={i} className="grid gap-2 md:grid-cols-[1fr_1.2fr_auto]">
                  <Input
                    value={l.label}
                    onChange={(v) =>
                      set(
                        "footerLinks",
                        form.footerLinks.map((x: any, k: number) =>
                          k === i ? { ...x, label: v } : x
                        )
                      )
                    }
                    placeholder="حریم خصوصی"
                  />
                  <Input
                    value={l.href}
                    onChange={(v) =>
                      set(
                        "footerLinks",
                        form.footerLinks.map((x: any, k: number) =>
                          k === i ? { ...x, href: v } : x
                        )
                      )
                    }
                    placeholder="/legal/privacy"
                    ltr
                  />
                  <IconBtn
                    onClick={() =>
                      set("footerLinks", form.footerLinks.filter((_: any, k: number) => k !== i))
                    }
                  />
                </div>
              ))}
              <button
                onClick={() =>
                  set("footerLinks", [...form.footerLinks, { label: "", href: "/" }])
                }
                className="inline-flex items-center gap-1.5 rounded-lg border border-zinc-200 bg-white px-3 py-1.5 text-xs font-bold text-zinc-600 transition hover:border-orange-300"
              >
                <Plus className="h-3.5 w-3.5" />
                افزودن لینک
              </button>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}

function Card({
  title,
  action,
  children,
}: {
  title: string;
  action?: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <div className="rounded-2xl border border-zinc-200 bg-white p-6 shadow-sm">
      <div className="mb-5 flex items-center justify-between">
        <h2 className="text-base font-black text-zinc-800">{title}</h2>
        {action}
      </div>
      {children}
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="mb-1.5 text-xs font-bold text-zinc-600">{label}</div>
      {children}
    </div>
  );
}

function Input({
  value,
  onChange,
  placeholder,
  ltr,
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  ltr?: boolean;
}) {
  return (
    <input
      value={value ?? ""}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      dir={ltr ? "ltr" : "rtl"}
      className="w-full rounded-lg border border-zinc-200 bg-white px-3 py-2 text-sm outline-none transition focus:border-orange-400"
    />
  );
}

function TextArea({
  value,
  onChange,
}: {
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <textarea
      value={value ?? ""}
      onChange={(e) => onChange(e.target.value)}
      rows={3}
      className="w-full resize-none rounded-lg border border-zinc-200 bg-white px-3 py-2 text-sm outline-none transition focus:border-orange-400"
    />
  );
}

function IconBtn({ onClick, label }: { onClick: () => void; label?: string }) {
  return (
    <button
      onClick={onClick}
      title={label || "حذف"}
      className="flex h-9 w-9 items-center justify-center rounded-lg border border-red-100 bg-red-50 text-red-500 transition hover:bg-red-100"
    >
      <Trash2 className="h-4 w-4" />
    </button>
  );
}

function ListEditor({
  label,
  items,
  onChange,
  placeholder,
  ltr,
}: {
  label: string;
  items: string[];
  onChange: (v: string[]) => void;
  placeholder?: string;
  ltr?: boolean;
}) {
  return (
    <div className="space-y-2">
      <div className="text-sm font-bold text-zinc-700">{label}</div>
      {(items ?? []).map((item, i) => (
        <div key={i} className="grid gap-2 md:grid-cols-[1fr_auto]">
          <Input
            value={item}
            onChange={(v) => onChange(items.map((x, k) => (k === i ? v : x)))}
            placeholder={placeholder}
            ltr={ltr}
          />
          <IconBtn onClick={() => onChange(items.filter((_, k) => k !== i))} />
        </div>
      ))}
      <button
        onClick={() => onChange([...(items ?? []), ""])}
        className="inline-flex items-center gap-1.5 rounded-lg border border-zinc-200 bg-white px-3 py-1.5 text-xs font-bold text-zinc-600 transition hover:border-orange-300"
      >
        <Plus className="h-3.5 w-3.5" />
        افزودن
      </button>
    </div>
  );
}