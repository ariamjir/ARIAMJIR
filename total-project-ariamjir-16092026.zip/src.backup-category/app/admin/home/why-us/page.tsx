"use client";

import { useEffect, useState } from "react";

import {
  Plus,
  Pencil,
  Trash2,
  Loader2,
  Database,
  CheckCircle2,
  Wand2,
  GripVertical,
  X,
} from "lucide-react";

const INP = "w-full rounded-lg border border-zinc-200 bg-white px-3 py-2 text-sm outline-none focus:border-orange-400";
const TA = "w-full resize-y rounded-lg border border-zinc-200 bg-white px-3 py-2 text-sm leading-7 outline-none focus:border-orange-400";

const ICON_OPTIONS = [
  { k: "shield", svg: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>` },
  { k: "clock", svg: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>` },
  { k: "award", svg: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="8" r="6"/><path d="M15.477 12.89 17 22l-5-3-5 3 1.523-9.11"/></svg>` },
  { k: "zap", svg: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>` },
  { k: "truck", svg: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="3" width="15" height="13"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>` },
  { k: "dollar", svg: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>` },
  { k: "phone", svg: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>` },
  { k: "star", svg: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>` },
];

export default function AdminWhyUsPage() {
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [edit, setEdit] = useState<any>(null);
  const [saving, setSaving] = useState(false);
  const [genBusy, setGenBusy] = useState(false);

  const load = () => {
    setLoading(true);
    fetch("/api/admin/why-us")
      .then((r) => r.json())
      .then((j) => {
        if (j.success) setItems(j.data ?? []);
      })
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    load();
  }, []);

  const seed = async () => {
    if (!confirm("تمام آیتم‌های فعلی حذف و نمونه‌های پیش‌فرض بارگذاری شوند؟")) return;
    await fetch("/api/admin/why-us", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ seed: true }),
    });
    await fetch("/api/admin/why-us/seed", { method: "POST" });
    load();
  };

  const gen = async () => {
    setGenBusy(true);
    const topic = prompt("موضوع مزیت جدید را وارد کن:", "خدمات پس از فروش");
    if (!topic) { setGenBusy(false); return; }
    await fetch(`/api/cron/generate-whyus?topic=${encodeURIComponent(topic)}`, { method: "POST" });
    setGenBusy(false);
    load();
  };

  const del = async (id: string) => {
    if (!confirm("حذف شود؟")) return;
    await fetch("/api/admin/why-us", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id }),
    });
    load();
  };

  const save = async () => {
    if (!edit) return;
    setSaving(true);
    try {
      await fetch("/api/admin/why-us", {
        method: edit.id ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(edit),
      });
      setEdit(null);
      load();
    } finally {
      setSaving(false);
    }
  };

  const move = async (id: string, dir: -1 | 1) => {
    const idx = items.findIndex((x) => x.id === id);
    if (idx < 0) return;
    const newIdx = idx + dir;
    if (newIdx < 0 || newIdx >= items.length) return;
    const next = [...items];
    [next[idx], next[newIdx]] = [next[newIdx], next[idx]];
    setItems(next);
    await Promise.all(
      next.map((x, i) =>
        fetch("/api/admin/why-us", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id: x.id, sortOrder: i }),
        })
      )
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-zinc-800">چرا ARIA MJ؟</h1>
          <p className="mt-1 text-sm text-zinc-500">مزیت‌های رقابتی برند — Bento-Grid صفحهٔ اول.</p>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <button onClick={gen} disabled={genBusy} className="inline-flex items-center gap-2 rounded-xl bg-violet-600 px-4 py-2.5 text-sm font-black text-white transition hover:bg-violet-700 disabled:opacity-60">
            {genBusy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Wand2 className="h-4 w-4" />}
            تولید مزیت با AI
          </button>
          <button onClick={seed} className="inline-flex items-center gap-2 rounded-xl border border-orange-300 bg-orange-50 px-4 py-2.5 text-sm font-bold text-orange-700 transition hover:bg-orange-100">
            <Database className="h-4 w-4" />
            نمونه‌های پیش‌فرض
          </button>
          <button
            onClick={() => setEdit({ title: "", subtitle: "", description: "", icon: ICON_OPTIONS[0].svg, stat: "", statLabel: "", active: true })}
            className="inline-flex items-center gap-2 rounded-xl bg-orange-500 px-5 py-2.5 text-sm font-black text-white shadow transition hover:bg-orange-600"
          >
            <Plus className="h-4 w-4" />
            مزیت جدید
          </button>
        </div>
      </div>

      {loading ? (
        <div className="flex h-64 items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-orange-500" />
        </div>
      ) : (
        <div className="space-y-3">
          {items.map((it, i) => (
            <div key={it.id} className="flex items-center gap-4 rounded-2xl border border-zinc-200 bg-white p-4 shadow-sm">
              <div className="flex shrink-0 flex-col gap-1">
                <button onClick={() => move(it.id, -1)} disabled={i === 0} className="flex h-7 w-7 items-center justify-center rounded-lg border border-zinc-200 text-zinc-500 disabled:opacity-30">▲</button>
                <button onClick={() => move(it.id, 1)} disabled={i === items.length - 1} className="flex h-7 w-7 items-center justify-center rounded-lg border border-zinc-200 text-zinc-500 disabled:opacity-30">▼</button>
              </div>

              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-orange-500/20 to-orange-500/5 text-orange-600" dangerouslySetInnerHTML={{ __html: it.icon ?? "" }} />

              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-black text-zinc-800">{it.title}</span>
                  {it.stat && (
                    <span className="rounded-full bg-orange-100 px-2 py-0.5 text-[10px] font-black text-orange-700">
                      {it.stat} {it.statLabel}
                    </span>
                  )}
                  {!it.active && (
                    <span className="rounded-full bg-zinc-100 px-2 py-0.5 text-[10px] font-bold text-zinc-500">غیرفعال</span>
                  )}
                </div>
                <div className="mt-0.5 line-clamp-1 text-[11px] text-zinc-500">{it.description}</div>
              </div>

              <button onClick={() => setEdit(it)} className="flex h-9 w-9 items-center justify-center rounded-lg border border-zinc-200 text-zinc-600 transition hover:border-orange-300 hover:text-orange-600">
                <Pencil className="h-4 w-4" />
              </button>
              <button onClick={() => del(it.id)} className="flex h-9 w-9 items-center justify-center rounded-lg border border-red-100 bg-red-50 text-red-500 transition hover:bg-red-100">
                <Trash2 className="h-4 w-4" />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Modal ویرایش */}
      {edit && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="w-full max-w-2xl rounded-2xl bg-white p-6 shadow-2xl">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-lg font-black text-zinc-800">{edit.id ? "ویرایش مزیت" : "مزیت جدید"}</h2>
              <button onClick={() => setEdit(null)} className="flex h-8 w-8 items-center justify-center rounded-lg hover:bg-zinc-100">
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="space-y-4">
              <Field label="عنوان *">
                <input value={edit.title} onChange={(e) => setEdit({ ...edit, title: e.target.value })} className={INP} />
              </Field>
              <Field label="زیرعنوان (اختیاری)">
                <input value={edit.subtitle ?? ""} onChange={(e) => setEdit({ ...edit, subtitle: e.target.value })} className={INP} />
              </Field>
              <Field label="توضیح *">
                <textarea value={edit.description} onChange={(e) => setEdit({ ...edit, description: e.target.value })} rows={4} className={TA} />
              </Field>

              <div className="grid gap-4 md:grid-cols-2">
                <Field label="آمار (مثلاً ۹۸٪ یا ۲۴/۷)">
                  <input value={edit.stat ?? ""} onChange={(e) => setEdit({ ...edit, stat: e.target.value })} className={INP} />
                </Field>
                <Field label="برچسب آمار (مثلاً رضایت مشتری)">
                  <input value={edit.statLabel ?? ""} onChange={(e) => setEdit({ ...edit, statLabel: e.target.value })} className={INP} />
                </Field>
              </div>

              <Field label="آیکون">
                <div className="flex flex-wrap gap-2">
                  {ICON_OPTIONS.map((opt) => (
                    <button
                      key={opt.k}
                      onClick={() => setEdit({ ...edit, icon: opt.svg })}
                      className={`flex h-12 w-12 items-center justify-center rounded-xl border-2 transition ${
                        edit.icon === opt.svg ? "border-orange-500 bg-orange-50" : "border-zinc-200 text-zinc-500"
                      }`}
                      dangerouslySetInnerHTML={{ __html: opt.svg }}
                    />
                  ))}
                </div>
              </Field>

              <label className="flex cursor-pointer items-center gap-2 text-sm font-bold text-zinc-600">
                <input type="checkbox" checked={!!edit.active} onChange={(e) => setEdit({ ...edit, active: e.target.checked })} className="h-4 w-4 accent-orange-500" />
                فعال و نمایش در صفحهٔ اول
              </label>
            </div>

            <div className="mt-6 flex justify-end gap-3">
              <button onClick={() => setEdit(null)} className="rounded-xl border border-zinc-200 px-5 py-2.5 text-sm font-bold text-zinc-600 transition hover:bg-zinc-50">
                انصراف
              </button>
              <button onClick={save} disabled={saving} className="inline-flex items-center gap-2 rounded-xl bg-orange-500 px-6 py-2.5 text-sm font-black text-white shadow transition hover:bg-orange-600 disabled:opacity-60">
                {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <CheckCircle2 className="h-4 w-4" />}
                ذخیره
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="mb-1.5 text-xs font-bold text-zinc-600">{label}</div>
      {children}
    </div>
  );
}