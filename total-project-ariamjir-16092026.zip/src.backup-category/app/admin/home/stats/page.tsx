"use client";

import { useEffect, useState } from "react";

import {
  Save,
  Loader2,
  CheckCircle2,
  Plus,
  Trash2,
  BarChart3,
} from "lucide-react";

const SOURCES = [
  { key: "machines", label: "ماشین‌آلات (واقعی)" },
  { key: "adsPublished", label: "آگهی‌های منتشرشده (واقعی)" },
  { key: "brands", label: "برندها (واقعی)" },
  { key: "categories", label: "دسته‌بندی‌ها (واقعی)" },
  { key: "users", label: "کاربران (واقعی)" },
  { key: "services", label: "خدمات (واقعی)" },
  { key: "manual", label: "متن دستی" },
];

export default function AdminHomeStatsPage() {
  const [items, setItems] = useState<any[]>([]);
  const [real, setReal] = useState<any>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    fetch("/api/admin/home-stats")
      .then((r) => r.json())
      .then((j) => {
        if (j.success) {
          setItems(j.data.items ?? []);
          setReal(j.data.real ?? {});
        }
      })
      .finally(() => setLoading(false));
  }, []);

  const set = (i: number, patch: any) => {
    setItems(items.map((x, k) => (k === i ? { ...x, ...patch } : x)));
    setSaved(false);
  };

  const save = async () => {
    setSaving(true);
    try {
      const res = await fetch("/api/admin/home-stats", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ items }),
      });
      const j = await res.json();
      if (j.success) {
        setSaved(true);
        setTimeout(() => setSaved(false), 2500);
      }
    } finally {
      setSaving(false);
    }
  };

  const preview = (item: any) =>
    item.source === "manual"
      ? (item.manualText ?? "۰") + (item.suffix ?? "")
      : (real[item.source] ?? 0).toLocaleString("fa-IR") + (item.suffix ?? "");

  if (loading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-orange-500" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-zinc-800">
            مدیریت آمار صفحه اصلی
          </h1>
          <p className="mt-1 text-sm text-zinc-500">
            هر عدد را از یک منبع واقعی در دیتابیس بگیر یا دستی بنویس.
          </p>
        </div>

        <button
          onClick={save}
          disabled={saving}
          className="inline-flex items-center gap-2 rounded-xl bg-orange-500 px-6 py-2.5 text-sm font-black text-white shadow transition hover:bg-orange-600 disabled:opacity-60"
        >
          {saving ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : saved ? (
            <CheckCircle2 className="h-4 w-4" />
          ) : (
            <Save className="h-4 w-4" />
          )}
          {saved ? "ذخیره شد" : "ذخیرهٔ تغییرات"}
        </button>
      </div>

      <div className="space-y-3">
        {items.map((item, i) => (
          <div
            key={i}
            className="grid items-center gap-3 rounded-2xl border border-zinc-200 bg-white p-4 shadow-sm lg:grid-cols-[1.2fr_1fr_auto_auto_auto_auto]"
          >
            <input
              value={item.title ?? ""}
              onChange={(e) => set(i, { title: e.target.value })}
              placeholder="عنوان (مثلاً ماشین‌آلات فعال)"
              className="w-full rounded-lg border border-zinc-200 px-3 py-2 text-sm outline-none focus:border-orange-400"
            />

            <select
              value={item.source ?? "manual"}
              onChange={(e) => set(i, { source: e.target.value })}
              className="w-full rounded-lg border border-zinc-200 bg-white px-3 py-2 text-sm outline-none"
            >
              {SOURCES.map((s) => (
                <option key={s.key} value={s.key}>
                  {s.label}
                </option>
              ))}
            </select>

            {item.source === "manual" && (
              <input
                value={item.manualText ?? ""}
                onChange={(e) => set(i, { manualText: e.target.value })}
                placeholder="متن/عدد دستی"
                className="w-32 rounded-lg border border-zinc-200 px-3 py-2 text-sm outline-none focus:border-orange-400"
              />
            )}

            <input
              value={item.suffix ?? ""}
              onChange={(e) => set(i, { suffix: e.target.value })}
              placeholder="پسوند +"
              className="w-20 rounded-lg border border-zinc-200 px-3 py-2 text-center text-sm outline-none focus:border-orange-400"
            />

            {/* پیش‌نمایش زنده */}
            <span className="rounded-lg bg-orange-50 px-3 py-2 text-sm font-black text-orange-600">
              {preview(item)}
            </span>

            <label className="flex cursor-pointer items-center gap-2 text-xs font-bold text-zinc-600">
              <input
                type="checkbox"
                checked={!!item.active}
                onChange={(e) => set(i, { active: e.target.checked })}
                className="h-4 w-4 accent-orange-500"
              />
              فعال
            </label>

            <button
              onClick={() => setItems(items.filter((_, k) => k !== i))}
              className="flex h-9 w-9 items-center justify-center rounded-lg border border-red-100 bg-red-50 text-red-500 transition hover:bg-red-100"
            >
              <Trash2 className="h-4 w-4" />
            </button>
          </div>
        ))}

        <button
          onClick={() =>
            setItems([
              ...items,
              { title: "", source: "machines", suffix: "+", active: true },
            ])
          }
          className="inline-flex items-center gap-2 rounded-xl bg-zinc-800 px-5 py-2.5 text-sm font-bold text-white transition hover:bg-zinc-700"
        >
          <Plus className="h-4 w-4" />
          افزودن آمار جدید
        </button>
      </div>

      <div className="flex items-start gap-3 rounded-2xl border border-blue-200 bg-blue-50 p-4 text-[12px] leading-6 text-blue-700">
        <BarChart3 className="mt-1 h-4 w-4 shrink-0" />
        <p>
          منابع «واقعی» همیشه عدد زندهٔ دیتابیس را نشان می‌دهند — بدون نیاز
          به ویرایش دستی. پیش‌نمایش نارنجی، مقدار فعلی هر منبع است.
        </p>
      </div>
    </div>
  );
}