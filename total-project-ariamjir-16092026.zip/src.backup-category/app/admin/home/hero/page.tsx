"use client";

import { useEffect, useState } from "react";

import {
  Save,
  Loader2,
  CheckCircle2,
  Plus,
  Trash2,
  Upload,
  ArrowUp,
  ArrowDown,
} from "lucide-react";

const TABS = [
  { key: "content", label: "متن و دکمه‌ها" },
  { key: "background", label: "پس‌زمینه" },
  { key: "cards", label: "کارت‌ها" },
  { key: "search", label: "سرچ" },
  { key: "stats", label: "پنل آمار" },
];

const CARD_KEYS = [
  { key: "exclusive", label: "کارت راست (EXCLUSIVE)" },
  { key: "featured", label: "کارت وسط (FEATURED)" },
  { key: "services", label: "کارت چپ (SERVICES)" },
];

export default function HeroBuilderPage() {
  const [form, setForm] = useState<any>(null);
  const [tab, setTab] = useState("content");
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/admin/hero")
      .then((r) => r.json())
      .then((j) => {
        const h = j.data;

        if (!h) {
          setForm({
            id: null,
            badge: "Industrial Marketplace",
            title: "ARIA MJ",
            subtitle: "",
            description: "",
            buttonText: "مشاهده آگهی‌ها",
            buttonLink: "/machines",
            secondButtonText: "",
            secondButtonLink: "",
            config: {},
            slides: [],
          });
          return;
        }

        const rawItems = h.config?.cards?.items ?? {};
        const fill = (key: string, def: any) => ({
          ...def,
          ...(rawItems[key] ?? {}),
        });

        setForm({
          id: h.id,
          badge: h.badge ?? "",
          title: h.title ?? "",
          subtitle: h.subtitle ?? "",
          description: h.description ?? "",
          buttonText: h.buttonText ?? "",
          buttonLink: h.buttonLink ?? "",
          secondButtonText: h.secondButtonText ?? "",
          secondButtonLink: h.secondButtonLink ?? "",
          config: {
            ...(h.config ?? {}),
            cards: {
              ...(h.config?.cards ?? {}),
              items: {
                exclusive: fill("exclusive", {
                  tag: "EXCLUSIVE",
                  title: h.title ?? "",
                  desc: h.description ?? "",
                  href: h.buttonLink ?? "/machines",
                  img: h.slides?.[0]?.image ?? "",
                  active: true,
                }),
                featured: fill("featured", {
                  tag: "FEATURED",
                  title: "آگهی ویژه",
                  desc: "ویژه‌ترین ماشین‌آلات منتخب آریا MJ",
                  href: "/machines?featured=true",
                  img: h.slides?.[1]?.image ?? "",
                  active: true,
                }),
                services: fill("services", {
                  tag: "SERVICES",
                  title: "خدمات",
                  desc: "هر آنچه برای ماشین‌آلات سنگین نیاز دارید.",
                  href: "/services",
                  img: h.slides?.[2]?.image ?? "",
                  active: true,
                }),
              },
            },
          },
          slides: h.slides ?? [],
        });
      })
      .finally(() => setLoading(false));
  }, []);

  const set = (k: string, v: any) => {
    setForm((f: any) => ({ ...f, [k]: v }));
    setSaved(false);
  };

  const setCfg = (path: string, v: any) => {
    setForm((f: any) => {
      const cfg = JSON.parse(JSON.stringify(f.config ?? {}));
      const parts = path.split(".");
      let cur = cfg;
      for (let i = 0; i < parts.length - 1; i++) {
        cur[parts[i]] = cur[parts[i]] ?? {};
        cur = cur[parts[i]];
      }
      cur[parts[parts.length - 1]] = v;
      return { ...f, config: cfg };
    });
    setSaved(false);
  };

  const getCfg = (path: string, def: any) => {
    let cur = form?.config;
    for (const p of path.split(".")) {
      cur = cur?.[p];
      if (cur === undefined) return def;
    }
    return cur ?? def;
  };

  const setSlide = (i: number, patch: any) =>
    set(
      "slides",
      form.slides.map((s: any, k: number) => (k === i ? { ...s, ...patch } : s))
    );

  const moveSlide = (i: number, dir: number) => {
    const arr = [...form.slides];
    const j = i + dir;
    if (j < 0 || j >= arr.length) return;
    [arr[i], arr[j]] = [arr[j], arr[i]];
    set("slides", arr);
  };

  const setQuick = (i: number, patch: any) => {
    const arr = [...(getCfg("search.quickLinks", []))];
    arr[i] = { ...arr[i], ...patch };
    setCfg("search.quickLinks", arr);
  };

  const upload = async (file: File, cb: (url: string) => void) => {
    const fd = new FormData();
    fd.append("file", file);
    fd.append("folder", "hero");
    const res = await fetch("/api/upload/image", { method: "POST", body: fd });
    const j = await res.json();
    const url = j.url || j.path || j.src || "";
    if (url) cb(url);
  };

  const save = async () => {
    setSaving(true);
    try {
      const res = await fetch("/api/admin/hero", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const j = await res.json();
      if (j.success) {
        setForm((f: any) => ({ ...f, id: j.id ?? f.id }));
        setSaved(true);
        setTimeout(() => setSaved(false), 2500);
      }
    } finally {
      setSaving(false);
    }
  };

  if (loading || !form) {
    return (
      <div className="flex h-96 items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-orange-500" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* هدر */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-zinc-800">
            هیرو و اسلایدر — Hero Builder
          </h1>
          <p className="mt-1 text-sm text-zinc-500">
            همهٔ اجزای هیرو: متن، پس‌زمینه، کارت‌ها، سرچ، آمار.
          </p>
        </div>
        <button
          onClick={save}
          disabled={saving}
          className="inline-flex items-center gap-2 rounded-xl bg-orange-500 px-6 py-2.5 text-sm font-black text-white shadow transition hover:bg-orange-600 disabled:opacity-60"
        >
          {saving ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : saved ? (
            <CheckCircle2 className="h-4 w-4" />
          ) : (
            <Save className="h-4 w-4" />
          )}
          {saved ? "ذخیره شد" : "ذخیرهٔ تغییرات"}
        </button>
      </div>

      {/* تب‌ها */}
      <div className="flex flex-wrap gap-2">
        {TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`rounded-xl px-4 py-2.5 text-sm font-bold transition ${
              tab === t.key
                ? "bg-zinc-800 text-white shadow"
                : "border border-zinc-200 bg-white text-zinc-600 hover:border-orange-300"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* ===== تب محتوا ===== */}
      {tab === "content" && (
        <div className="grid gap-5 rounded-2xl border border-zinc-200 bg-white p-6 shadow-sm md:grid-cols-2">
          <Field label="بج بالای عنوان">
            <Input value={form.badge} onChange={(v) => set("badge", v)} />
          </Field>
          <Field label="عنوان اصلی">
            <Input value={form.title} onChange={(v) => set("title", v)} />
          </Field>

          {/* ✅ زیرعنوان — همان متنی که روی سایت دیده می‌شود */}
          <div className="md:col-span-2">
            <Field label="زیرعنوان / توضیح کوتاه (نمایش در هیرو)">
              <TextArea value={form.subtitle} onChange={(v) => set("subtitle", v)} />
            </Field>
          </div>

          <div className="md:col-span-2">
            <Field label="توضیحات (متن کارت EXCLUSIVE)">
              <TextArea value={form.description} onChange={(v) => set("description", v)} />
            </Field>
          </div>

          <Field label="فاصلهٔ بین اجزا (پیکسل)">
            <Input
              value={String(getCfg("content.gap", 24))}
              onChange={(v) => setCfg("content.gap", Number(v) || 24)}
              ltr
            />
          </Field>
          <Field label="فاصلهٔ خطوط عنوان (پیکسل)">
            <Input
              value={String(getCfg("content.lineGap", 16))}
              onChange={(v) => setCfg("content.lineGap", Number(v) || 16)}
              ltr
            />
          </Field>
          <Field label="چینش افقی متن">
            <select
              value={getCfg("content.align", "right")}
              onChange={(e) => setCfg("content.align", e.target.value)}
              className="w-full rounded-lg border border-zinc-200 bg-white px-3 py-2 text-sm outline-none"
            >
              <option value="right">راست</option>
              <option value="center">وسط</option>
              <option value="left">چپ</option>
            </select>
          </Field>
          <Field label="موقعیت عمودی اجزا در هیرو">
            <select
              value={getCfg("content.vertical", "middle")}
              onChange={(e) => setCfg("content.vertical", e.target.value)}
              className="w-full rounded-lg border border-zinc-200 bg-white px-3 py-2 text-sm outline-none"
            >
              <option value="top">بالا</option>
              <option value="middle">وسط</option>
              <option value="bottom">پایین</option>
            </select>
          </Field>

          <Field label="متن دکمهٔ اصلی">
            <Input value={form.buttonText} onChange={(v) => set("buttonText", v)} />
          </Field>
          <Field label="لینک دکمهٔ اصلی">
            <Input value={form.buttonLink} onChange={(v) => set("buttonLink", v)} ltr />
          </Field>
          <Field label="متن دکمهٔ دوم (اختیاری)">
            <Input
              value={form.secondButtonText}
              onChange={(v) => set("secondButtonText", v)}
            />
          </Field>
          <Field label="لینک دکمهٔ دوم">
            <Input
              value={form.secondButtonLink}
              onChange={(v) => set("secondButtonLink", v)}
              ltr
            />
          </Field>
        </div>
      )}

      {/* ===== تب پس‌زمینه ===== */}
      {tab === "background" && (
        <div className="space-y-6 rounded-2xl border border-zinc-200 bg-white p-6 shadow-sm">
          <div className="grid gap-5 md:grid-cols-4">
            <Field label="حالت پس‌زمینه">
              <select
                value={getCfg("background.mode", "single")}
                onChange={(e) => setCfg("background.mode", e.target.value)}
                className="w-full rounded-lg border border-zinc-200 bg-white px-3 py-2 text-sm outline-none"
              >
                <option value="single">تک‌تصویر</option>
                <option value="slider">اسلایدر</option>
              </select>
            </Field>
            <Field label="فاصلهٔ اسلایدر (ثانیه)">
              <Input
                value={String(getCfg("background.interval", 5))}
                onChange={(v) => setCfg("background.interval", Number(v) || 5)}
                ltr
              />
            </Field>
            <Field label="انیمیشن زوم">
              <Toggle
                checked={!!getCfg("background.zoom", true)}
                onChange={(v) => setCfg("background.zoom", v)}
              />
            </Field>
            <Field label={`تاری تصویر: ${getCfg("background.overlay", 30)}٪`}>
              <input
                type="range"
                min={5}
                max={90}
                value={getCfg("background.overlay", 30)}
                onChange={(e) => setCfg("background.overlay", Number(e.target.value))}
                className="w-full accent-orange-500"
              />
            </Field>
          </div>

          <div className="space-y-3">
            <div className="text-sm font-bold text-zinc-700">
              تصاویر پس‌زمینه (به ترتیب اسلاید)
            </div>

            {form.slides.map((s: any, i: number) => (
              <div
                key={i}
                className="grid items-center gap-3 rounded-xl border border-zinc-200 bg-zinc-50 p-3 md:grid-cols-[auto_1fr_auto_auto_auto_auto]"
              >
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={s.image} alt="" className="h-14 w-24 rounded-lg object-cover" />

                <Input value={s.image} onChange={(v) => setSlide(i, { image: v })} ltr />

                <UploadBtn onPick={(f) => upload(f, (url) => setSlide(i, { image: url }))} />

                <label className="flex items-center gap-1.5 text-xs font-bold text-zinc-600">
                  <input
                    type="checkbox"
                    checked={s.active !== false}
                    onChange={(e) => setSlide(i, { active: e.target.checked })}
                    className="h-4 w-4 accent-orange-500"
                  />
                  فعال
                </label>

                <div className="flex gap-1">
                  <IconMini onClick={() => moveSlide(i, -1)}>
                    <ArrowUp className="h-3.5 w-3.5" />
                  </IconMini>
                  <IconMini onClick={() => moveSlide(i, 1)}>
                    <ArrowDown className="h-3.5 w-3.5" />
                  </IconMini>
                </div>

                <IconBtn
                  onClick={() =>
                    set("slides", form.slides.filter((_: any, k: number) => k !== i))
                  }
                />
              </div>
            ))}

            <button
              onClick={() =>
                set("slides", [
                  ...form.slides,
                  { image: "/images/hero/hero-1.jpg", active: true },
                ])
              }
              className="inline-flex items-center gap-2 rounded-lg border border-zinc-200 bg-white px-3 py-1.5 text-xs font-bold text-zinc-600 transition hover:border-orange-300"
            >
              <Plus className="h-3.5 w-3.5" />
              افزودن اسلاید
            </button>
          </div>
        </div>
      )}

      {/* ===== تب کارت‌ها ===== */}
      {tab === "cards" && (
        <div className="space-y-6">
          <div className="grid gap-5 rounded-2xl border border-zinc-200 bg-white p-6 shadow-sm md:grid-cols-3">
            <Field label="نمایش کارت‌ها">
              <Toggle
                checked={!!getCfg("cards.visible", true)}
                onChange={(v) => setCfg("cards.visible", v)}
              />
            </Field>

            <Field label="حالت سایز">
              <select
                value={getCfg("cards.sizeMode", "preset")}
                onChange={(e) => setCfg("cards.sizeMode", e.target.value)}
                className="w-full rounded-lg border border-zinc-200 bg-white px-3 py-2 text-sm outline-none"
              >
                <option value="preset">واکنش‌گرا (کوچک/متوسط/بزرگ)</option>
                <option value="custom">سفارشی (پیکسل)</option>
              </select>
            </Field>

            <Field label="چرخش کارت‌ها (tilt)">
              <Toggle
                checked={!!getCfg("cards.tilt", true)}
                onChange={(v) => setCfg("cards.tilt", v)}
              />
            </Field>

            {getCfg("cards.sizeMode", "preset") === "preset" ? (
              <Field label="سایز پیش‌فرض">
                <select
                  value={getCfg("cards.size", "md")}
                  onChange={(e) => setCfg("cards.size", e.target.value)}
                  className="w-full rounded-lg border border-zinc-200 bg-white px-3 py-2 text-sm outline-none"
                >
                  <option value="sm">کوچک</option>
                  <option value="md">متوسط</option>
                  <option value="lg">بزرگ</option>
                </select>
              </Field>
            ) : (
              <>
                <Field label="عرض کارت کناری (px)">
                  <Input
                    value={String(getCfg("cards.custom.sideW", 265))}
                    onChange={(v) => setCfg("cards.custom.sideW", Number(v) || 265)}
                    ltr
                  />
                </Field>
                <Field label="ارتفاع کارت کناری (px)">
                  <Input
                    value={String(getCfg("cards.custom.sideH", 500))}
                    onChange={(v) => setCfg("cards.custom.sideH", Number(v) || 500)}
                    ltr
                  />
                </Field>
                <Field label="عرض کارت وسط (px)">
                  <Input
                    value={String(getCfg("cards.custom.midW", 285))}
                    onChange={(v) => setCfg("cards.custom.midW", Number(v) || 285)}
                    ltr
                  />
                </Field>
                <Field label="ارتفاع کارت وسط (px)">
                  <Input
                    value={String(getCfg("cards.custom.midH", 540))}
                    onChange={(v) => setCfg("cards.custom.midH", Number(v) || 540)}
                    ltr
                  />
                </Field>
              </>
            )}
          </div>

          {CARD_KEYS.map(({ key, label }) => (
            <div key={key} className="rounded-2xl border border-zinc-200 bg-white p-6 shadow-sm">
              <div className="mb-4 flex items-center justify-between">
                <h2 className="text-sm font-black text-zinc-800">{label}</h2>
                <label className="flex items-center gap-1.5 text-xs font-bold text-zinc-600">
                  <input
                    type="checkbox"
                    checked={!!getCfg(`cards.items.${key}.active`, true)}
                    onChange={(e) => setCfg(`cards.items.${key}.active`, e.target.checked)}
                    className="h-4 w-4 accent-orange-500"
                  />
                  نمایش این کارت
                </label>
              </div>

              {getCfg(`cards.items.${key}.img`, "") && (
                <div className="mb-4 flex items-center gap-3">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={getCfg(`cards.items.${key}.img`, "")}
                    alt=""
                    className="h-20 w-32 rounded-xl border border-zinc-200 object-cover"
                  />
                  <span className="text-[11px] text-zinc-500">تصویر فعلی کارت</span>
                </div>
              )}

              <div className="grid gap-4 md:grid-cols-2">
                <Field label="برچسب (TAG)">
                  <Input
                    value={getCfg(`cards.items.${key}.tag`, "")}
                    onChange={(v) => setCfg(`cards.items.${key}.tag`, v)}
                    ltr
                  />
                </Field>
                <Field label="عنوان کارت">
                  <Input
                    value={getCfg(`cards.items.${key}.title`, "")}
                    onChange={(v) => setCfg(`cards.items.${key}.title`, v)}
                  />
                </Field>
                <div className="md:col-span-2">
                  <Field label="توضیح کارت">
                    <Input
                      value={getCfg(`cards.items.${key}.desc`, "")}
                      onChange={(v) => setCfg(`cards.items.${key}.desc`, v)}
                    />
                  </Field>
                </div>
                <Field label="لینک کارت">
                  <Input
                    value={getCfg(`cards.items.${key}.href`, "")}
                    onChange={(v) => setCfg(`cards.items.${key}.href`, v)}
                    ltr
                  />
                </Field>
                <Field label="تصویر کارت (URL یا آپلود)">
                  <div className="flex items-center gap-2">
                    <Input
                      value={getCfg(`cards.items.${key}.img`, "")}
                      onChange={(v) => setCfg(`cards.items.${key}.img`, v)}
                      ltr
                    />
                    <UploadBtn
                      onPick={(f) => upload(f, (url) => setCfg(`cards.items.${key}.img`, url))}
                    />
                  </div>
                </Field>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* ===== تب سرچ ===== */}
      {tab === "search" && (
        <div className="space-y-6">
          <div className="grid gap-5 rounded-2xl border border-zinc-200 bg-white p-6 shadow-sm md:grid-cols-2">
            <Field label="نمایش سرچ زیر هیرو">
              <Toggle
                checked={!!getCfg("search.visible", true)}
                onChange={(v) => setCfg("search.visible", v)}
              />
            </Field>
            <Field label="متن دکمهٔ سرچ">
              <Input
                value={getCfg("search.buttonText", "جستجو")}
                onChange={(v) => setCfg("search.buttonText", v)}
              />
            </Field>
            <Field label="عنوان سرچ">
              <Input
                value={getCfg("search.title", "")}
                onChange={(v) => setCfg("search.title", v)}
              />
            </Field>
            <Field label="زیرعنوان سرچ">
              <Input
                value={getCfg("search.subtitle", "")}
                onChange={(v) => setCfg("search.subtitle", v)}
              />
            </Field>

            <div className="md:col-span-2 grid gap-4 md:grid-cols-4">
              <Field label="فیلد دسته‌بندی">
                <Toggle
                  checked={!!getCfg("search.showCategory", true)}
                  onChange={(v) => setCfg("search.showCategory", v)}
                />
              </Field>
              <Field label="فیلد برند">
                <Toggle
                  checked={!!getCfg("search.showBrand", true)}
                  onChange={(v) => setCfg("search.showBrand", v)}
                />
              </Field>
              <Field label="فیلد سال">
                <Toggle
                  checked={!!getCfg("search.showYear", true)}
                  onChange={(v) => setCfg("search.showYear", v)}
                />
              </Field>
              <Field label="فیلد قیمت">
                <Toggle
                  checked={!!getCfg("search.showPrice", true)}
                  onChange={(v) => setCfg("search.showPrice", v)}
                />
              </Field>
            </div>
          </div>

          {/* لینک‌های سریع */}
          <div className="rounded-2xl border border-zinc-200 bg-white p-6 shadow-sm">
            <div className="mb-4 text-sm font-black text-zinc-800">
              لینک‌های سریع (جستجوهای پربازدید)
            </div>

            <div className="space-y-3">
              {(getCfg("search.quickLinks", []) as any[]).map((l: any, i: number) => (
                <div key={i} className="grid gap-2 md:grid-cols-[1fr_1.4fr_auto]">
                  <Input
                    value={l.label ?? ""}
                    onChange={(v) => setQuick(i, { label: v })}
                    placeholder="عنوان (بیل مکانیکی)"
                  />
                  <Input
                    value={l.href ?? ""}
                    onChange={(v) => setQuick(i, { href: v })}
                    placeholder="/machines?category=excavator"
                    ltr
                  />
                  <IconBtn
                    onClick={() =>
                      setCfg(
                        "search.quickLinks",
                        (getCfg("search.quickLinks", []) as any[]).filter(
                          (_, k) => k !== i
                        )
                      )
                    }
                  />
                </div>
              ))}

              <button
                onClick={() =>
                  setCfg("search.quickLinks", [
                    ...(getCfg("search.quickLinks", []) as any[]),
                    { label: "", href: "/machines" },
                  ])
                }
                className="inline-flex items-center gap-2 rounded-lg border border-zinc-200 bg-white px-3 py-1.5 text-xs font-bold text-zinc-600 transition hover:border-orange-300"
              >
                <Plus className="h-3.5 w-3.5" />
                افزودن لینک سریع
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===== تب آمار ===== */}
      {tab === "stats" && (
        <div className="rounded-2xl border border-zinc-200 bg-white p-6 shadow-sm">
          <Field label="نمایش پنل آمار لحظه‌ای در هیرو">
            <Toggle
              checked={!!getCfg("stats.visible", true)}
              onChange={(v) => setCfg("stats.visible", v)}
            />
          </Field>
          <p className="mt-3 text-[11px] text-zinc-500">
            محتوای اعداد از «صفحه اصلی ▸ آمار» مدیریت می‌شود.
          </p>
        </div>
      )}
    </div>
  );
}

/* ---------- کامپوننت‌های کمکی ---------- */

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="mb-1.5 text-xs font-bold text-zinc-600">{label}</div>
      {children}
    </div>
  );
}

function Input({
  value,
  onChange,
  ltr,
  placeholder,
}: {
  value: string;
  onChange: (v: string) => void;
  ltr?: boolean;
  placeholder?: string;
}) {
  return (
    <input
      value={value ?? ""}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      dir={ltr ? "ltr" : "rtl"}
      className="w-full rounded-lg border border-zinc-200 bg-white px-3 py-2 text-sm outline-none focus:border-orange-400"
    />
  );
}

function TextArea({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  return (
    <textarea
      value={value ?? ""}
      onChange={(e) => onChange(e.target.value)}
      rows={3}
      className="w-full resize-none rounded-lg border border-zinc-200 bg-white px-3 py-2 text-sm outline-none focus:border-orange-400"
    />
  );
}

function Toggle({ checked, onChange }: { checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      type="button"
      onClick={() => onChange(!checked)}
      className={`flex items-center rounded-full px-1 transition ${
        checked ? "bg-orange-500" : "bg-zinc-300"
      }`}
      style={{ width: 52, height: 28 }}
    >
      <span
        className={`h-5 w-5 rounded-full bg-white shadow transition-transform ${
          checked ? "-translate-x-6" : ""
        }`}
      />
    </button>
  );
}

function IconBtn({ onClick }: { onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="flex h-9 w-9 items-center justify-center rounded-lg border border-red-100 bg-red-50 text-red-500 transition hover:bg-red-100"
    >
      <Trash2 className="h-4 w-4" />
    </button>
  );
}

function IconMini({ onClick, children }: { onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className="flex h-8 w-8 items-center justify-center rounded-lg border border-zinc-200 bg-white text-zinc-500 transition hover:border-orange-300"
    >
      {children}
    </button>
  );
}

function UploadBtn({ onPick }: { onPick: (f: File) => void }) {
  return (
    <label className="inline-flex h-9 w-9 shrink-0 cursor-pointer items-center justify-center rounded-lg border border-zinc-200 bg-white text-zinc-600 transition hover:border-orange-300 hover:text-orange-600">
      <Upload className="h-4 w-4" />
      <input
        type="file"
        accept="image/*"
        hidden
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) onPick(f);
          e.target.value = "";
        }}
      />
    </label>
  );
}