"use client";

import { useEffect, useState } from "react";

import {
  Save,
  Loader2,
  CheckCircle2,
  Upload,
} from "lucide-react";

export default function AdminHeaderPage() {
  const [cfg, setCfg] = useState<any>(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/admin/header")
      .then((r) => r.json())
      .then((j) => {
        if (j.success) setCfg(j.data);
      })
      .finally(() => setLoading(false));
  }, []);

  const set = (path: string, v: any) => {
    setCfg((c: any) => {
      const next = JSON.parse(JSON.stringify(c));
      const parts = path.split(".");
      let cur = next;
      for (let i = 0; i < parts.length - 1; i++) cur = cur[parts[i]];
      cur[parts[parts.length - 1]] = v;
      return next;
    });
    setSaved(false);
  };

  const upload = async (file: File) => {
    const fd = new FormData();
    fd.append("file", file);
    fd.append("folder", "branding");
    const res = await fetch("/api/upload/image", { method: "POST", body: fd });
    const j = await res.json();
    const url = j.url || j.path || j.src || "";
    if (url) set("logo.url", url);
  };

  const save = async () => {
    setSaving(true);
    try {
      const res = await fetch("/api/admin/header", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(cfg),
      });
      const j = await res.json();
      if (j.success) {
        setSaved(true);
        setTimeout(() => setSaved(false), 2500);
      }
    } finally {
      setSaving(false);
    }
  };

  if (loading || !cfg) {
    return (
      <div className="flex h-64 items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-orange-500" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-zinc-800">مدیریت هدر سایت</h1>
          <p className="mt-1 text-sm text-zinc-500">
            لوگو، متون، دکمه و حالت‌های هدر صفحهٔ اول.
          </p>
        </div>
        <button
          onClick={save}
          disabled={saving}
          className="inline-flex items-center gap-2 rounded-xl bg-orange-500 px-6 py-2.5 text-sm font-black text-white shadow transition hover:bg-orange-600 disabled:opacity-60"
        >
          {saving ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : saved ? (
            <CheckCircle2 className="h-4 w-4" />
          ) : (
            <Save className="h-4 w-4" />
          )}
          {saved ? "ذخیره شد" : "ذخیرهٔ تغییرات"}
        </button>
      </div>

      {/* ===== لوگو ===== */}
      <div className="rounded-2xl border border-zinc-200 bg-white p-6 shadow-sm">
        <h2 className="mb-4 text-sm font-black text-zinc-800">لوگو</h2>

        <div className="grid gap-5 md:grid-cols-[auto_1fr]">
          {/* پیش‌نمایش */}
          <div className="flex h-28 w-44 items-center justify-center rounded-xl border border-dashed border-zinc-300 bg-zinc-50">
            {cfg.logo.visible && (
              /* eslint-disable-next-line @next/next/no-img-element */
              <img
                src={cfg.logo.url}
                alt={cfg.logo.alt}
                style={{ width: cfg.logo.width, height: cfg.logo.height }}
                className="object-contain"
              />
            )}
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="sm:col-span-2 flex items-center gap-2">
              <input
                value={cfg.logo.url}
                onChange={(e) => set("logo.url", e.target.value)}
                dir="ltr"
                className="w-full rounded-lg border border-zinc-200 px-3 py-2 text-sm outline-none focus:border-orange-400"
              />
              <label className="inline-flex h-9 w-9 shrink-0 cursor-pointer items-center justify-center rounded-lg border border-zinc-200 bg-white text-zinc-600 transition hover:border-orange-300 hover:text-orange-600">
                <Upload className="h-4 w-4" />
                <input
                  type="file"
                  accept="image/*"
                  hidden
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (f) upload(f);
                    e.target.value = "";
                  }}
                />
              </label>
            </div>

            <Field label="عرض (px)">
              <NumInput value={cfg.logo.width} onChange={(v) => set("logo.width", v)} />
            </Field>
            <Field label="ارتفاع (px)">
              <NumInput value={cfg.logo.height} onChange={(v) => set("logo.height", v)} />
            </Field>
            <Field label="متن جایگزین (alt)">
              <input
                value={cfg.logo.alt}
                onChange={(e) => set("logo.alt", e.target.value)}
                className="w-full rounded-lg border border-zinc-200 px-3 py-2 text-sm outline-none focus:border-orange-400"
              />
            </Field>
            <Field label="نمایش لوگو">
              <Toggle checked={!!cfg.logo.visible} onChange={(v) => set("logo.visible", v)} />
            </Field>
          </div>
        </div>
      </div>

      {/* ===== متون ===== */}
      <div className="rounded-2xl border border-zinc-200 bg-white p-6 shadow-sm">
        <h2 className="mb-4 text-sm font-black text-zinc-800">متون هدر</h2>

        <div className="grid gap-4 md:grid-cols-2">
          <Field label="نام برند">
            <input
              value={cfg.brand.text}
              onChange={(e) => set("brand.text", e.target.value)}
              className="w-full rounded-lg border border-zinc-200 px-3 py-2 text-sm outline-none focus:border-orange-400"
            />
          </Field>
          <Field label="نمایش نام برند">
            <Toggle checked={!!cfg.brand.visible} onChange={(v) => set("brand.visible", v)} />
          </Field>

          <Field label="تگ‌لاین (زیر برند)">
            <input
              value={cfg.tagline.text}
              onChange={(e) => set("tagline.text", e.target.value)}
              dir="ltr"
              className="w-full rounded-lg border border-zinc-200 px-3 py-2 text-sm outline-none focus:border-orange-400"
            />
          </Field>
          <Field label="نمایش تگ‌لاین">
            <Toggle checked={!!cfg.tagline.visible} onChange={(v) => set("tagline.visible", v)} />
          </Field>
        </div>
      </div>

      {/* ===== دکمهٔ CTA ===== */}
      <div className="rounded-2xl border border-zinc-200 bg-white p-6 shadow-sm">
        <h2 className="mb-4 text-sm font-black text-zinc-800">دکمهٔ اقدام (CTA)</h2>

        <div className="grid gap-4 md:grid-cols-3">
          <Field label="متن دکمه">
            <input
              value={cfg.cta.text}
              onChange={(e) => set("cta.text", e.target.value)}
              className="w-full rounded-lg border border-zinc-200 px-3 py-2 text-sm outline-none focus:border-orange-400"
            />
          </Field>
          <Field label="لینک دکمه">
            <input
              value={cfg.cta.href}
              onChange={(e) => set("cta.href", e.target.value)}
              dir="ltr"
              className="w-full rounded-lg border border-zinc-200 px-3 py-2 text-sm outline-none focus:border-orange-400"
            />
          </Field>
          <Field label="نمایش دکمه">
            <Toggle checked={!!cfg.cta.visible} onChange={(v) => set("cta.visible", v)} />
          </Field>
        </div>
      </div>

      {/* ===== حالت‌ها ===== */}
      <div className="rounded-2xl border border-zinc-200 bg-white p-6 shadow-sm">
        <h2 className="mb-4 text-sm font-black text-zinc-800">حالت‌های هدر</h2>

        <div className="grid gap-4 md:grid-cols-2">
          <Field label="هدر چسبان (Sticky)">
            <Toggle checked={!!cfg.layout.sticky} onChange={(v) => set("layout.sticky", v)} />
          </Field>
          <Field label="هدر شفاف روی هیرو">
            <Toggle checked={!!cfg.layout.transparent} onChange={(v) => set("layout.transparent", v)} />
          </Field>
        </div>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="mb-1.5 text-xs font-bold text-zinc-600">{label}</div>
      {children}
    </div>
  );
}

function NumInput({ value, onChange }: { value: number; onChange: (v: number) => void }) {
  return (
    <input
      value={String(value ?? 0)}
      onChange={(e) => onChange(Number(e.target.value) || 0)}
      dir="ltr"
      className="w-full rounded-lg border border-zinc-200 px-3 py-2 text-sm outline-none focus:border-orange-400"
    />
  );
}

function Toggle({ checked, onChange }: { checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      type="button"
      onClick={() => onChange(!checked)}
      className={`flex items-center rounded-full px-1 transition ${
        checked ? "bg-orange-500" : "bg-zinc-300"
      }`}
      style={{ width: 52, height: 28 }}
    >
      <span
        className={`h-5 w-5 rounded-full bg-white shadow transition-transform ${
          checked ? "-translate-x-6" : ""
        }`}
      />
    </button>
  );
}