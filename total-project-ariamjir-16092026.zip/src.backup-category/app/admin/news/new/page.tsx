import NewsEditorForm from "@/components/admin/news/NewsEditorForm";

export default function NewNewsPage() {
  return <NewsEditorForm />;
}