import NewsEditorForm from "@/components/admin/news/NewsEditorForm";

export default async function EditNewsPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  return <NewsEditorForm id={id} />;
}