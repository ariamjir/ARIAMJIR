import Link from "next/link";

import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export default async function HeroPage() {
  const heroes = await prisma.hero.findMany({
    include: {
      slides: {
        orderBy: {
          sortOrder: "asc",
        },
      },
      stats: {
        orderBy: {
          sortOrder: "asc",
        },
      },
    },
    orderBy: {
      createdAt: "desc",
    },
  });

  return (
    <div className="mx-auto max-w-7xl p-8">

      <div className="mb-8 flex items-center justify-between">

        <div>

          <h1 className="text-3xl font-black">
            مدیریت Hero
          </h1>

          <p className="mt-2 text-gray-500">
            مدیریت اسلایدر صفحه اصلی سایت
          </p>

        </div>

        <Link
          href="/admin/hero/new"
          className="
            rounded-xl
            bg-orange-500
            px-6
            py-3
            font-bold
            text-white
            transition
            hover:bg-orange-600
          "
        >
          ایجاد Hero جدید
        </Link>

      </div>

      <div className="overflow-hidden rounded-2xl border border-gray-200 bg-white shadow">

        <table className="min-w-full">

          <thead className="bg-gray-100">

            <tr>

              <th className="px-6 py-4 text-right font-bold">
                عنوان
              </th>

              <th className="px-6 py-4 text-center font-bold">
                Badge
              </th>

              <th className="px-6 py-4 text-center font-bold">
                اسلایدها
              </th>

              <th className="px-6 py-4 text-center font-bold">
                آمار
              </th>

              <th className="px-6 py-4 text-center font-bold">
                وضعیت
              </th>

              <th className="px-6 py-4 text-center font-bold">
                عملیات
              </th>

            </tr>

          </thead>

          <tbody>

            {heroes.length === 0 && (

              <tr>

                <td
                  colSpan={6}
                  className="py-16 text-center text-gray-400"
                >
                  هنوز Hero ثبت نشده است.
                </td>

              </tr>

            )}

            {heroes.map((hero) => (

              <tr
                key={hero.id}
                className="border-t hover:bg-gray-50"
              >

                <td className="px-6 py-5">

                  <div className="font-bold">
                    {hero.title}
                  </div>

                  {hero.subtitle && (

                    <div className="mt-1 text-sm text-gray-500">
                      {hero.subtitle}
                    </div>

                  )}

                </td>

                <td className="px-6 py-5 text-center">

                  {hero.badge ?? "-"}

                </td>

                <td className="px-6 py-5 text-center">

                  {hero.slides.length}

                </td>

                <td className="px-6 py-5 text-center">

                  {hero.stats.length}

                </td>

                <td className="px-6 py-5 text-center">

                  {hero.active ? (
                    <span className="rounded-full bg-green-100 px-3 py-1 text-sm font-semibold text-green-700">
                      فعال
                    </span>
                  ) : (
                    <span className="rounded-full bg-red-100 px-3 py-1 text-sm font-semibold text-red-700">
                      غیرفعال
                    </span>
                  )}

                </td>

                <td className="px-6 py-5">

                                    <div className="flex items-center justify-center gap-2">

                    <Link
                      href={`/admin/hero/edit/${hero.id}`}
                      className="
                        rounded-lg
                        bg-amber-500
                        px-4
                        py-2
                        text-sm
                        font-semibold
                        text-white
                        transition
                        hover:bg-amber-600
                      "
                    >
                      ویرایش
                    </Link>

                    <Link
                      href={`/admin/home/hero?id=${hero.id}`}
                      className="
                        rounded-lg
                        bg-sky-600
                        px-4
                        py-2
                        text-sm
                        font-semibold
                        text-white
                        transition
                        hover:bg-sky-700
                      "
                    >
                      مدیریت محتوا
                    </Link>

                  </div>

                </td>

              </tr>

            ))}

          </tbody>

        </table>

      </div>

      {heroes.length > 0 && (

        <div className="mt-8 rounded-2xl border border-orange-200 bg-orange-50 p-6">

          <h2 className="text-lg font-bold text-orange-700">
            خلاصه وضعیت
          </h2>

          <div className="mt-4 grid grid-cols-1 gap-4 md:grid-cols-3">

            <div className="rounded-xl bg-white p-5 shadow-sm">

              <div className="text-sm text-gray-500">
                تعداد Hero
              </div>

              <div className="mt-2 text-3xl font-black text-orange-600">
                {heroes.length}
              </div>

            </div>

            <div className="rounded-xl bg-white p-5 shadow-sm">

              <div className="text-sm text-gray-500">
                مجموع اسلایدها
              </div>

              <div className="mt-2 text-3xl font-black text-orange-600">
                {heroes.reduce(
                  (total, hero) => total + hero.slides.length,
                  0
                )}
              </div>

            </div>

            <div className="rounded-xl bg-white p-5 shadow-sm">

              <div className="text-sm text-gray-500">
                مجموع آمار
              </div>

              <div className="mt-2 text-3xl font-black text-orange-600">
                {heroes.reduce(
                  (total, hero) => total + hero.stats.length,
                  0
                )}
              </div>

            </div>

          </div>

        </div>

      )}

    </div>
  );
}