import { notFound } from "next/navigation";

import { prisma } from "@/lib/prisma";

import HeroEditor from "@/components/admin/hero/HeroEditor";

interface Props {
  params: Promise<{
    id: string;
  }>;
}

export default async function EditHeroPage({
  params,
}: Props) {
  const { id } = await params;

  const hero = await prisma.hero.findUnique({
    where: {
      id,
    },

    include: {
      slides: {
        orderBy: {
          sortOrder: "asc",
        },
      },

      stats: {
        orderBy: {
          sortOrder: "asc",
        },
      },
    },
  });

  if (!hero) {
    notFound();
  }

  return (
    <div className="mx-auto max-w-7xl p-10">

      <div className="mb-8">

        <h1 className="text-3xl font-bold">
          ویرایش Hero
        </h1>

        <p className="mt-2 text-gray-500">
          در این بخش می‌توانید اطلاعات Hero،
          اسلایدها و آمار صفحه اصلی را مدیریت کنید.
        </p>

      </div>

            <HeroEditor hero={hero} />

    </div>
  );
}