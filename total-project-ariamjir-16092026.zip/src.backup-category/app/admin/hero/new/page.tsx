import type { Metadata } from "next";

import HeroForm from "@/components/admin/HeroForm";

export const metadata: Metadata = {
  title: "ایجاد Hero",
};

export default function NewHeroPage() {
  return (
    <div className="mx-auto max-w-5xl p-8">

      <div className="mb-8">

        <h1 className="text-3xl font-black">
          ایجاد Hero جدید
        </h1>

        <p className="mt-2 text-gray-500">
          اطلاعات Hero صفحه اصلی را وارد کنید.
        </p>

      </div>

      <div className="rounded-2xl bg-white shadow-sm">

        <HeroForm />

      </div>

    </div>
  );
}