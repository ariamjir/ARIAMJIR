"use client";

import ProductForm from "@/components/admin/ProductForm";

export default function NewProductPage() {
  return (
    <main className="space-y-6">

      <div>
        <h1 className="text-3xl font-bold text-gray-900">
          افزودن محصول جدید
        </h1>

        <p className="mt-2 text-sm text-gray-500">
          اطلاعات محصول را تکمیل کرده و ذخیره کنید.
        </p>
      </div>

      <ProductForm />

    </main>
  );
}

