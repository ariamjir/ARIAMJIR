"use client";

import { use } from "react";
import ProductForm from "@/components/admin/ProductForm";

type Props = {
  params: Promise<{
    id: string;
  }>;
};

export default function EditProductPage({
  params,
}: Props) {
  const { id } = use(params);

  return (
    <main className="space-y-6">

      <div>
        <h1 className="text-3xl font-bold text-gray-900">
          ویرایش محصول
        </h1>

        <p className="mt-2 text-sm text-gray-500">
          اطلاعات محصول را ویرایش و ذخیره کنید.
        </p>
      </div>

      <ProductForm productId={id} />

    </main>
  );
}