"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";

export default function EditProductPage() {
  const params = useParams();
  const router = useRouter();

  const id = params.id as string;

  const [loading, setLoading] = useState(true);

  const [form, setForm] = useState({
    title: "",
    slug: "",
    description: "",
    category: "",
    brand: "",
    price: "",
    stock: "0",
    image: "",
    featured: false,
    active: true,
  });

  useEffect(() => {
    loadProduct();
  }, []);

  async function loadProduct() {
    const res = await fetch("/api/admin/products");

    const list = await res.json();

    const product = list.find((x: any) => x.id === id);

    if (!product) return;

    setForm({
      title: product.title ?? "",
      slug: product.slug ?? "",
      description: product.description ?? "",
      category: product.category ?? "",
      brand: product.brand ?? "",
      price: product.price?.toString() ?? "",
      stock: product.stock?.toString() ?? "0",
      image: product.image ?? "",
      featured: product.featured,
      active: product.active,
    });

    setLoading(false);
  }

  function updateField(
    key: string,
    value: string | boolean
  ) {
    setForm((prev) => ({
      ...prev,
      [key]: value,
    }));
  }

  async function submitForm(
    e: React.FormEvent
  ) {
    e.preventDefault();

    await fetch("/api/admin/products/" + id, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(form),
    });

    router.push("/admin/products");
    router.refresh();
  }

  if (loading) {
    return <div className="p-10">در حال بارگذاری...</div>;
  }

  return (
    <div className="mx-auto max-w-3xl space-y-6">

      <h1 className="text-2xl font-bold">
        ویرایش محصول
      </h1>

      <form
        onSubmit={submitForm}
        className="space-y-5 rounded-2xl border bg-white p-6"
      >

        <input
          className="w-full rounded-lg border p-3"
          value={form.title}
          onChange={(e) =>
            updateField("title", e.target.value)
          }
        />

        <input
          className="w-full rounded-lg border p-3"
          value={form.slug}
          onChange={(e) =>
            updateField("slug", e.target.value)
          }
        />

        <textarea
          className="w-full rounded-lg border p-3"
          value={form.description}
          onChange={(e) =>
            updateField("description", e.target.value)
          }
        />

        <input
          className="w-full rounded-lg border p-3"
          value={form.category}
          onChange={(e) =>
            updateField("category", e.target.value)
          }
        />

        <input
          className="w-full rounded-lg border p-3"
          value={form.brand}
          onChange={(e) =>
            updateField("brand", e.target.value)
          }
        />

        <input
          className="w-full rounded-lg border p-3"
          value={form.price}
          onChange={(e) =>
            updateField("price", e.target.value)
          }
        />

        <input
          className="w-full rounded-lg border p-3"
          value={form.stock}
          onChange={(e) =>
            updateField("stock", e.target.value)
          }
        />

        <input
          className="w-full rounded-lg border p-3"
          value={form.image}
          onChange={(e) =>
            updateField("image", e.target.value)
          }
        />

        <label className="flex gap-3">
          <input
            type="checkbox"
            checked={form.featured}
            onChange={(e) =>
              updateField("featured", e.target.checked)
            }
          />
          محصول ویژه
        </label>
        <label className="flex gap-3">
          <input
            type="checkbox"
            checked={form.active}
            onChange={(e) =>
              updateField("active", e.target.checked)
            }
          />
          فعال
        </label>

        <button className="rounded-xl bg-[#F47C20] px-6 py-3 text-white">
          ذخیره تغییرات
        </button>

      </form>

    </div>
  );
}