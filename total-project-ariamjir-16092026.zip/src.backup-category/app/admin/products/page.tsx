"use client";

import { useEffect, useState } from "react";
import Link from "next/link";

type Product = {
  id: string;
  title: string;
  slug: string;
  category: string | null;
  brand: string | null;
  price: number | null;
  stock: number;
  image: string | null;
  active: boolean;
  featured: boolean;
};

export default function ProductsPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");

  async function loadProducts() {
    setLoading(true);

    const res = await fetch("/api/admin/products");

    const data = await res.json();

    setProducts(data);

    setLoading(false);
  }

  useEffect(() => {
    loadProducts();
  }, []);

  async function deleteProduct(id: string) {
    if (!confirm("آیا از حذف این محصول مطمئن هستید؟")) return;

    await fetch(`/api/admin/products/${id}`, {
      method: "DELETE",
    });

    loadProducts();
  }

  const filtered = products.filter((p) => {
    return (
      p.title.toLowerCase().includes(search.toLowerCase()) ||
      p.slug.toLowerCase().includes(search.toLowerCase()) ||
      (p.brand ?? "")
        .toLowerCase()
        .includes(search.toLowerCase())
    );
  });

  return (
    <div className="space-y-6">

      <div className="flex items-center justify-between">

        <h1 className="text-3xl font-bold">
          مدیریت محصولات
        </h1>

        <Link
          href="/admin/products/new"
          className="rounded-lg bg-orange-500 px-5 py-3 text-white hover:bg-orange-600"
        >
          افزودن محصول
        </Link>

      </div>

      <input
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        placeholder="جستجوی محصول..."
        className="w-full rounded-lg border p-3"
      />

      <div className="overflow-x-auto rounded-xl border">

        <table className="w-full">

          <thead className="bg-gray-100">

            <tr>
              <th className="p-4">تصویر</th>
              <th className="p-4">عنوان</th>
              <th className="p-4">برند</th>
              <th className="p-4">دسته</th>
              <th className="p-4">قیمت</th>
              <th className="p-4">موجودی</th>
              <th className="p-4">فعال</th>
              <th className="p-4">ویژه</th>
              <th className="p-4">عملیات</th>
            </tr>

          </thead>

          <tbody>

         {loading ? (
  <tr>
    <td colSpan={9} className="p-10 text-center">
      در حال بارگذاری...
    </td>
  </tr>
) : filtered.length === 0 ? (
  <tr>
    <td colSpan={9} className="p-10 text-center">
      محصولی یافت نشد.
    </td>
  </tr>
) : (
  filtered.map((product) => (
    <tr key={product.id} className="border-t">

      <td className="p-4">
        {product.image ? (
          <img
            src={product.image}
            alt={product.title}
            className="h-16 w-28 rounded-lg object-cover"
          />
        ) : (
          <div className="flex h-16 w-28 items-center justify-center rounded-lg bg-gray-200 text-xs">
            بدون تصویر
          </div>
        )}
      </td>

      <td className="p-4 font-medium">
        {product.title}
      </td>

      <td className="p-4">
        {product.brand ?? "-"}
      </td>

      <td className="p-4">
        {product.category ?? "-"}
      </td>

      <td className="p-4">
        {product.price != null
          ? Number(product.price).toLocaleString("fa-IR")
          : "-"}
      </td>

      <td className="p-4">
        {product.stock}
      </td>

      <td className="p-4">
        {product.active ? "✅" : "❌"}
      </td>

      <td className="p-4">
        {product.featured ? "⭐" : "-"}
      </td>

      <td className="p-4">
        <div className="flex gap-2">

          <Link
            href={`/admin/products/${product.id}`}
            className="rounded bg-orange-500 px-3 py-2 text-white hover:bg-orange-600"
          >
            ویرایش
          </Link>

          <button
            onClick={() => deleteProduct(product.id)}
            className="rounded bg-red-600 px-3 py-2 text-white hover:bg-red-700"
          >
            حذف
          </button>

        </div>
      </td>

    </tr>
  ))
)}
          </tbody>
        </table>
      </div>
    </div>
  );
}

