import KnowledgeEditorForm from "@/components/admin/knowledge/KnowledgeEditorForm";

export default async function EditKnowledgePage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  return <KnowledgeEditorForm id={id} />;
}