"use client";

import { useEffect, useState } from "react";

import Link from "next/link";

import {
  Plus,
  Pencil,
  Trash2,
  Star,
  Loader2,
  Search,
  Database,
  ExternalLink,
  BookOpen,
  Bot,
  Wand2,
} from "lucide-react";

import { NEWS_STATUS, faDate } from "@/lib/news";

export default function AdminKnowledgePage() {
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState("");
  const [status, setStatus] = useState("all");
  const [enabled, setEnabled] = useState(true);
  const [genBusy, setGenBusy] = useState(false);

  const load = () => {
    setLoading(true);
    fetch("/api/admin/knowledge")
      .then((r) => r.json())
      .then((j) => {
        if (j.success) setItems(j.data ?? []);
      })
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    load();
    fetch("/api/admin/ai-knowledge")
      .then((r) => r.json())
      .then((j) => {
        if (j.success) setEnabled(j.data.enabled !== false);
      });

    const onReload = () => load();
    window.addEventListener("knowledge:reload", onReload);
    return () => window.removeEventListener("knowledge:reload", onReload);
  }, []);

  const toggleAuto = async () => {
    const next = !enabled;
    setEnabled(next);
    await fetch("/api/admin/ai-knowledge", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ enabled: next }),
    });
  };

  const generate = async () => {
    setGenBusy(true);
    try {
      const res = await fetch("/api/cron/generate-knowledge?force=1", { method: "POST" });
      const j = await res.json().catch(() => ({}));
      if (j.skipped && j.message) alert(j.message);
      load();
    } finally {
      setGenBusy(false);
    }
  };

  /* ✅ پاکسازی از طریق POST — دور زدن بلاک DELETE */
  const cleanup = async () => {
    if (!confirm("مقالات خالی (آسیب‌دیده) برای همیشه حذف شوند؟")) return;
    const res = await fetch("/api/admin/knowledge", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ cleanupEmpty: true }),
    });
    const j = await res.json().catch(() => ({}));
    if (j.success) {
      alert(`${j.deleted ?? 0} مقالهٔ خالی حذف شد.`);
    } else {
      alert("پاکسازی ناموفق: " + (j.message ?? "خطای ناشناخته"));
    }
    load();
  };

  const filtered = items.filter((x) => {
    const okQ = !q.trim() || x.title.includes(q.trim());
    const okS = status === "all" || x.status === status;
    return okQ && okS;
  });

  const stats = {
    total: items.length,
    published: items.filter((x) => x.status === "PUBLISHED").length,
    pending: items.filter((x) => x.status === "PENDING").length,
    views: items.reduce((s, x) => s + (x.viewCount ?? 0), 0),
  };

  const patch = async (id: string, p: any) => {
    await fetch("/api/admin/knowledge", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id, ...p }),
    });
    load();
  };

  /* ✅ حذف تکی از طریق POST */
  const remove = async (id: string) => {
    if (!confirm("این مقاله حذف شود؟")) return;
    const res = await fetch("/api/admin/knowledge", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ deleteId: id }),
    });
    const j = await res.json().catch(() => ({}));
    if (!j.success) alert("حذف ناموفق: " + (j.message ?? "خطای ناشناخته"));
    load();
  };

  const seed = async () => {
    await fetch("/api/admin/knowledge/seed", { method: "POST" });
    load();
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-zinc-800">مرکز دانش</h1>
          <p className="mt-1 text-sm text-zinc-500">مقالات آموزشی — تولید با AI، تأیید با شما.</p>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={cleanup}
            className="inline-flex items-center gap-2 rounded-xl border border-red-200 bg-red-50 px-4 py-2.5 text-sm font-bold text-red-600 transition hover:bg-red-100"
          >
            <Trash2 className="h-4 w-4" />
            پاکسازی مقالات خالی
          </button>
          <button
            onClick={seed}
            className="inline-flex items-center gap-2 rounded-xl border border-emerald-300 bg-emerald-50 px-4 py-2.5 text-sm font-bold text-emerald-700 transition hover:bg-emerald-100"
          >
            <Database className="h-4 w-4" />
            بارگذاری نمونه
          </button>
          <Link
            href="/admin/knowledge/new"
            className="inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-5 py-2.5 text-sm font-black text-white shadow transition hover:bg-emerald-700"
          >
            <Plus className="h-4 w-4" />
            مقالهٔ جدید
          </Link>
        </div>
      </div>

      {/* آمار */}
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {[
          { l: "کل مقالات", v: stats.total, c: "text-zinc-800" },
          { l: "منتشر شده", v: stats.published, c: "text-green-600" },
          { l: "در انتظار تأیید", v: stats.pending, c: "text-yellow-600" },
          { l: "مجموع بازدید", v: stats.views.toLocaleString("fa-IR"), c: "text-blue-600" },
        ].map((s) => (
          <div key={s.l} className="rounded-2xl border border-zinc-200 bg-white p-4 shadow-sm">
            <div className="text-[11px] font-bold text-zinc-500">{s.l}</div>
            <div className={`mt-1 text-2xl font-black ${s.c}`}>{s.v.toLocaleString("fa-IR")}</div>
          </div>
        ))}
      </div>

      {/* نویسندهٔ AI */}
      <div className="flex flex-wrap items-center gap-3 rounded-2xl border border-violet-200 bg-violet-50 p-3">
        <span className="inline-flex items-center gap-2 text-sm font-black text-violet-700">
          <Bot className="h-4 w-4" />
          نویسندهٔ هوش مصنوعی دانش
        </span>
        <button
          onClick={generate}
          disabled={genBusy}
          className="inline-flex items-center gap-2 rounded-lg bg-violet-600 px-4 py-2 text-xs font-bold text-white transition hover:bg-violet-700 disabled:opacity-60"
        >
          {genBusy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Wand2 className="h-3.5 w-3.5" />}
          تولید مقاله (پیش‌نویس + تصویر)
        </button>
        <label className="mr-auto flex cursor-pointer items-center gap-2 text-xs font-bold text-zinc-600">
          <input type="checkbox" checked={enabled} onChange={toggleAuto} className="h-4 w-4 accent-violet-600" />
          تولید خودکار هفتگی (cron)
        </label>
      </div>

      {/* نوار ابزار */}
      <div className="flex flex-wrap items-center gap-3 rounded-2xl border border-zinc-200 bg-white p-3 shadow-sm">
        <div className="relative min-w-[220px] flex-1">
          <Search className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-400" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="جستجو در عنوان..."
            className="w-full rounded-xl border border-zinc-200 bg-zinc-50 py-2.5 pr-9 pl-3 text-sm outline-none focus:border-emerald-400"
          />
        </div>
        <select
          value={status}
          onChange={(e) => setStatus(e.target.value)}
          className="rounded-xl border border-zinc-200 bg-white px-3 py-2.5 text-sm outline-none"
        >
          <option value="all">همه وضعیت‌ها</option>
          <option value="PUBLISHED">منتشر شده</option>
          <option value="PENDING">در انتظار تأیید</option>
          <option value="DRAFT">پیش‌نویس</option>
        </select>
      </div>

      {/* لیست */}
      {loading ? (
        <div className="flex h-64 items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-emerald-500" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-emerald-300 bg-emerald-50 p-10 text-center">
          <BookOpen className="mx-auto h-10 w-10 text-emerald-400" />
          <p className="mt-3 text-sm font-bold text-zinc-600">مقاله‌ای ثبت نشده است.</p>
          <button
            onClick={seed}
            className="mt-4 inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-6 py-2.5 text-sm font-bold text-white transition hover:bg-emerald-700"
          >
            <Plus className="h-4 w-4" />
            بارگذاری مقالات نمونه
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((n) => {
            const st = NEWS_STATUS[n.status] ?? NEWS_STATUS.DRAFT;
            const isAI = (n.authorName ?? "").includes("هوش مصنوعی");
            return (
              <div key={n.id} className="flex flex-wrap items-center gap-4 rounded-2xl border border-zinc-200 bg-white p-4 shadow-sm">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={n.coverImage ?? "/images/blog/news-1.jpg"} alt="" className="h-16 w-24 rounded-xl object-cover" />

                <div className="min-w-[220px] flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-sm font-black text-zinc-800">{n.title}</span>
                    <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${st.cls}`}>{st.label}</span>
                    {isAI && (
                      <span className="inline-flex items-center gap-1 rounded-full bg-violet-100 px-2 py-0.5 text-[10px] font-bold text-violet-700">
                        <Bot className="h-3 w-3" />
                        AI
                      </span>
                    )}
                  </div>
                  <div className="mt-1.5 flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px] text-zinc-500">
                    <span className="text-blue-600">👁 {n.viewCount.toLocaleString("fa-IR")}</span>
                    <span>⏱ {n.readMinutes} دقیقه</span>
                    <span>{faDate(n.publishedAt ?? n.createdAt)}</span>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    title="ویژه"
                    onClick={() => patch(n.id, { featured: !n.featured, title: n.title, slug: n.slug })}
                    className={`flex h-9 w-9 items-center justify-center rounded-lg border transition ${
                      n.featured ? "border-emerald-300 bg-emerald-100 text-emerald-600" : "border-zinc-200 bg-white text-zinc-400 hover:border-emerald-300"
                    }`}
                  >
                    <Star className="h-4 w-4" />
                  </button>

                  {(n.status === "PENDING" || n.status === "DRAFT") && (
                    <button
                      onClick={() => patch(n.id, { status: "PUBLISHED", title: n.title, slug: n.slug })}
                      className="flex h-9 items-center rounded-lg border border-zinc-200 bg-white px-3 text-[11px] font-bold text-zinc-600 transition hover:border-green-300 hover:text-green-600"
                    >
                      تأیید و انتشار
                    </button>
                  )}

                  <Link href={`/knowledge/${n.slug}`} target="_blank" title="مشاهده در سایت" className="flex h-9 w-9 items-center justify-center rounded-lg border border-zinc-200 bg-white text-zinc-600 transition hover:border-blue-300 hover:text-blue-600">
                    <ExternalLink className="h-4 w-4" />
                  </Link>

                  <Link href={`/admin/knowledge/edit/${n.id}`} title="ویرایش" className="flex h-9 w-9 items-center justify-center rounded-lg border border-zinc-200 bg-white text-zinc-600 transition hover:border-emerald-300 hover:text-emerald-600">
                    <Pencil className="h-4 w-4" />
                  </Link>

                  <button title="حذف" onClick={() => remove(n.id)} className="flex h-9 w-9 items-center justify-center rounded-lg border border-red-100 bg-red-50 text-red-500 transition hover:bg-red-100">
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}