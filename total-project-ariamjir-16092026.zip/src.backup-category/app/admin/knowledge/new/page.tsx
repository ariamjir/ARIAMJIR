import KnowledgeEditorForm from "@/components/admin/knowledge/KnowledgeEditorForm";

export default function NewKnowledgePage() {
  return <KnowledgeEditorForm />;
}