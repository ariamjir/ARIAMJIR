"use client";

import { useEffect, useState } from "react";

import {
  Save,
  Loader2,
  CheckCircle2,
  Plus,
  Trash2,
  Database,
} from "lucide-react";

import {
  ICON_MAP,
  ICON_OPTIONS,
} from "@/features/home/services/constants/serviceIcons";

export default function AdminServicesPage() {
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const load = () => {
    fetch("/api/admin/services")
      .then((r) => r.json())
      .then((j) => {
        if (j.success) setItems(j.data ?? []);
      })
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    load();
  }, []);

  const seed = async () => {
    setSaving(true);
    try {
      const res = await fetch("/api/admin/services/seed", { method: "POST" });
      const j = await res.json();
      if (j.success) setItems(j.data ?? []);
    } finally {
      setSaving(false);
    }
  };

  const set = (i: number, patch: any) => {
    setItems(items.map((x, k) => (k === i ? { ...x, ...patch } : x)));
    setSaved(false);
  };

  const save = async () => {
    setSaving(true);
    try {
      const res = await fetch("/api/admin/services", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(items),
      });
      const j = await res.json();
      if (j.success) {
        setSaved(true);
        setTimeout(() => setSaved(false), 2500);
      }
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex h-96 items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-orange-500" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-zinc-800">مدیریت خدمات</h1>
          <p className="mt-1 text-sm text-zinc-500">
            کارت‌های سکشن «خدمات ARIA MJ» را بدون کدنویسی مدیریت کنید.
          </p>
        </div>
        <button
          onClick={save}
          disabled={saving || items.length === 0}
          className="inline-flex items-center gap-2 rounded-xl bg-orange-500 px-6 py-2.5 text-sm font-black text-white shadow transition hover:bg-orange-600 disabled:opacity-60"
        >
          {saving ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : saved ? (
            <CheckCircle2 className="h-4 w-4" />
          ) : (
            <Save className="h-4 w-4" />
          )}
          {saved ? "ذخیره شد" : "ذخیرهٔ تغییرات"}
        </button>
      </div>

      {items.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-orange-300 bg-orange-50 p-10 text-center">
          <Database className="mx-auto h-10 w-10 text-orange-400" />
          <p className="mt-3 text-sm font-bold text-zinc-600">
            هنوز خدمتی ثبت نشده است.
          </p>
          <button
            onClick={seed}
            disabled={saving}
            className="mt-4 inline-flex items-center gap-2 rounded-xl bg-orange-500 px-6 py-2.5 text-sm font-bold text-white transition hover:bg-orange-600 disabled:opacity-60"
          >
            <Plus className="h-4 w-4" />
            بارگذاری خدمات پیش‌فرض
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {items.map((item, i) => {
            const Icon = ICON_MAP[item.icon];
            return (
              <div
                key={item.id ?? i}
                className="grid items-center gap-3 rounded-2xl border border-zinc-200 bg-white p-4 shadow-sm md:grid-cols-[auto_auto_1fr_1.4fr_auto_auto]"
              >
                {/* پیش‌نمایش + انتخاب آیکون */}
                <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-orange-100 text-orange-600">
                  {Icon ? <Icon className="h-5 w-5" /> : <span className="text-lg">{item.icon}</span>}
                </div>

                <select
                  value={item.icon}
                  onChange={(e) => set(i, { icon: e.target.value })}
                  className="rounded-lg border border-zinc-200 bg-white px-2 py-2 text-xs outline-none"
                >
                  {ICON_OPTIONS.map((o) => (
                    <option key={o.key} value={o.key}>
                      {o.label}
                    </option>
                  ))}
                </select>

                <input
                  value={item.title ?? ""}
                  onChange={(e) => set(i, { title: e.target.value })}
                  placeholder="عنوان خدمت"
                  className="w-full rounded-lg border border-zinc-200 px-3 py-2 text-sm outline-none focus:border-orange-400"
                />

                <input
                  value={item.description ?? ""}
                  onChange={(e) => set(i, { description: e.target.value })}
                  placeholder="توضیح"
                  className="w-full rounded-lg border border-zinc-200 px-3 py-2 text-sm outline-none focus:border-orange-400"
                />

                <label className="flex cursor-pointer items-center gap-1.5 text-xs font-bold text-zinc-600">
                  <input
                    type="checkbox"
                    checked={!!item.active}
                    onChange={(e) => set(i, { active: e.target.checked })}
                    className="h-4 w-4 accent-orange-500"
                  />
                  فعال
                </label>

                <button
                  onClick={() => setItems(items.filter((_, k) => k !== i))}
                  className="flex h-9 w-9 items-center justify-center rounded-lg border border-red-100 bg-red-50 text-red-500 transition hover:bg-red-100"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            );
          })}

          <button
            onClick={() =>
              setItems([
                ...items,
                { title: "خدمت جدید", description: "", icon: "wrench", active: true },
              ])
            }
            className="inline-flex items-center gap-2 rounded-xl bg-zinc-800 px-5 py-2.5 text-sm font-bold text-white transition hover:bg-zinc-700"
          >
            <Plus className="h-4 w-4" />
            افزودن خدمت
          </button>
        </div>
      )}
    </div>
  );
}