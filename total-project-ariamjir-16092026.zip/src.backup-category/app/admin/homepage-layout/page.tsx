"use client";

import { useEffect, useState } from "react";
import {
  GripVertical,
  Eye,
  EyeOff,
  Save,
  Loader2,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Edit3,
  X,
} from "lucide-react";

interface Section {
  id: string;
  key: string;
  title: string;
  subtitle: string | null;
  description: string | null;
  order: number;
  active: boolean;
  type: string;  // ✅ اضافه شد
  config: any;
}

export default function HomePageLayoutPage() {
  const [sections, setSections] = useState<Section[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [dragIdx, setDragIdx] = useState<number | null>(null);
  const [overIdx, setOverIdx] = useState<number | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [expandedId, setExpandedId] = useState<string | null>(null);

  useEffect(() => {
    fetchSections();
  }, []);

  const fetchSections = async () => {
    try {
      const res = await fetch("/api/admin/homepage-sections");
      const json = await res.json();
      if (json.success) {
        setSections(json.data);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const updateSection = (id: string, patch: Partial<Section>) => {
    setSections((prev) =>
      prev.map((s) => (s.id === id ? { ...s, ...patch } : s))
    );
    setSaved(false);
  };

  const updateConfig = (id: string, key: string, value: any) => {
    setSections((prev) =>
      prev.map((s) =>
        s.id === id ? { ...s, config: { ...s.config, [key]: value } } : s
      )
    );
    setSaved(false);
  };

  const toggleActive = (id: string) => {
    setSections((prev) =>
      prev.map((s) => (s.id === id ? { ...s, active: !s.active } : s))
    );
    setSaved(false);
  };

  const onDragStart = (idx: number) => setDragIdx(idx);
  const onDragOver = (e: React.DragEvent, idx: number) => {
    e.preventDefault();
    setOverIdx(idx);
  };
  const onDrop = (idx: number) => {
    if (dragIdx === null || dragIdx === idx) {
      setDragIdx(null);
      setOverIdx(null);
      return;
    }
    const newSections = [...sections];
    const [moved] = newSections.splice(dragIdx, 1);
    newSections.splice(idx, 0, moved);
    const reordered = newSections.map((s, i) => ({ ...s, order: i + 1 }));
    setSections(reordered);
    setDragIdx(null);
    setOverIdx(null);
    setSaved(false);
  };

  const save = async () => {
    setSaving(true);
    try {
      const payload = sections.map((s, i) => ({
        id: s.id,
        order: i + 1,
        active: s.active,
        title: s.title,
        subtitle: s.subtitle,
        description: s.description,
        config: s.config,
      }));
      const res = await fetch("/api/admin/homepage-sections", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const json = await res.json();
      if (json.success) {
        setSaved(true);
        setTimeout(() => setSaved(false), 3000);
      }
    } catch (e) {
      console.error(e);
      alert("خطا در ذخیره.");
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex h-96 items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-orange-500" />
      </div>
    );
  }

  const editing = sections.find((s) => s.id === editingId);

  return (
    <div className="mx-auto max-w-5xl space-y-6 p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-black">مدیریت صفحه اول (CMS)</h1>
          <p className="mt-2 text-sm text-gray-500">
            ترتیب، فعال‌بودن، عنوان، زیرعنوان، توضیحات و پیکربندی هر سکشن را کنترل کنید.
          </p>
        </div>
        <button
          onClick={save}
          disabled={saving || saved}
          className="inline-flex items-center gap-2 rounded-xl bg-orange-500 px-6 py-3 font-bold text-white shadow-lg shadow-orange-500/25 transition hover:bg-orange-600 disabled:opacity-60"
        >
          {saving ? (
            <Loader2 className="h-5 w-5 animate-spin" />
          ) : saved ? (
            <CheckCircle2 className="h-5 w-5" />
          ) : (
            <Save className="h-5 w-5" />
          )}
          {saving ? "در حال ذخیره..." : saved ? "ذخیره شد!" : "ذخیره تغییرات"}
        </button>
      </div>

      {/* Info */}
      <div className="rounded-2xl border border-blue-200 bg-blue-50 p-5">
        <p className="text-sm text-blue-800">
          💡 <strong>راهنما:</strong> سکشن‌ها را با کشیدن جابجا کنید. روی آیکون ویرایش کلیک کنید تا عنوان، زیرعنوان، توضیحات و پیکربندی خاص هر سکشن را تغییر دهید.
        </p>
      </div>

      {/* List */}
      <div className="space-y-3">
        {sections.map((section, idx) => (
          <div
            key={section.id}
            draggable
            onDragStart={() => onDragStart(idx)}
            onDragOver={(e) => onDragOver(e, idx)}
            onDrop={() => onDrop(idx)}
            className={`rounded-2xl border bg-white shadow-sm transition-all duration-200 ${
              overIdx === idx
                ? "border-orange-500 bg-orange-50"
                : dragIdx === idx
                ? "opacity-50"
                : "border-gray-200 hover:border-orange-300"
            }`}
          >
            {/* Main row */}
            <div className="flex items-center gap-4 p-5">
              {/* Drag handle */}
              <div className="flex h-10 w-10 cursor-grab items-center justify-center rounded-lg bg-gray-100 text-gray-500 hover:bg-gray-200">
                <GripVertical className="h-5 w-5" />
              </div>

              {/* Order badge */}
              <span className="flex h-8 w-8 items-center justify-center rounded-full bg-orange-100 text-sm font-black text-orange-700">
                {idx + 1}
              </span>

              {/* Title + key */}
              <div className="flex-1">
                <div className="font-bold">{section.title}</div>
                <div className="text-xs text-gray-400" dir="ltr">
                  {section.key} · {section.type}
                </div>
              </div>

              {/* Toggle */}
              <button
                onClick={() => toggleActive(section.id)}
                className={`flex items-center gap-2 rounded-xl px-4 py-2 text-sm font-semibold transition ${
                  section.active
                    ? "bg-green-100 text-green-700 hover:bg-green-200"
                    : "bg-gray-100 text-gray-500 hover:bg-gray-200"
                }`}
              >
                {section.active ? (
                  <>
                    <Eye className="h-4 w-4" />
                    فعال
                  </>
                ) : (
                  <>
                    <EyeOff className="h-4 w-4" />
                    غیرفعال
                  </>
                )}
              </button>

              {/* Edit button */}
              <button
                onClick={() => setEditingId(section.id)}
                className="flex items-center gap-2 rounded-xl bg-orange-100 px-4 py-2 text-sm font-semibold text-orange-700 transition hover:bg-orange-200"
              >
                <Edit3 className="h-4 w-4" />
                ویرایش
              </button>

              {/* Expand config */}
              <button
                onClick={() =>
                  setExpandedId(expandedId === section.id ? null : section.id)
                }
                className="rounded-xl p-2 text-gray-400 hover:bg-gray-100"
              >
                {expandedId === section.id ? (
                  <ChevronUp className="h-4 w-4" />
                ) : (
                  <ChevronDown className="h-4 w-4" />
                )}
              </button>
            </div>

            {/* Expanded config preview */}
            {expandedId === section.id && (
              <div className="border-t bg-gray-50 p-5">
                <div className="grid gap-3 md:grid-cols-2">
                  <div>
                    <div className="text-xs font-bold text-gray-500">زیرعنوان</div>
                    <div className="text-sm text-gray-700">{section.subtitle || "—"}</div>
                  </div>
                  <div>
                    <div className="text-xs font-bold text-gray-500">توضیحات</div>
                    <div className="text-sm text-gray-700">{section.description || "—"}</div>
                  </div>
                </div>
                {Object.keys(section.config || {}).length > 0 && (
                  <div className="mt-3">
                    <div className="text-xs font-bold text-gray-500">پیکربندی</div>
                    <pre className="mt-1 overflow-auto rounded-lg bg-white p-3 text-xs text-gray-600">
                      {JSON.stringify(section.config, null, 2)}
                    </pre>
                  </div>
                )}
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Edit Modal */}
      {editing && (
        <EditModal
          section={editing}
          onClose={() => setEditingId(null)}
          onUpdate={(patch) => updateSection(editing.id, patch)}
          onUpdateConfig={(key, value) => updateConfig(editing.id, key, value)}
        />
      )}
    </div>
  );
}

/* ============================================================
   EDIT MODAL
============================================================ */
function EditModal({
  section,
  onClose,
  onUpdate,
  onUpdateConfig,
}: {
  section: Section;
  onClose: () => void;
  onUpdate: (patch: Partial<Section>) => void;
  onUpdateConfig: (key: string, value: any) => void;
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm">
      <div className="max-h-[92vh] w-full max-w-3xl overflow-y-auto rounded-2xl bg-white shadow-2xl">
        {/* Header */}
        <div className="sticky top-0 z-10 flex items-center justify-between border-b bg-white px-6 py-4">
          <h2 className="flex items-center gap-2 text-lg font-black">
            <Edit3 className="h-5 w-5 text-orange-500" />
            ویرایش: {section.title}
          </h2>
          <button onClick={onClose} className="rounded-lg p-1.5 text-gray-400 transition hover:bg-gray-100">
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Body */}
        <div className="space-y-6 p-6">
          {/* Common fields */}
          <SectionTitle>اطلاعات اصلی</SectionTitle>
          <Field
            label="عنوان سکشن"
            value={section.title}
            onChange={(v) => onUpdate({ title: v })}
            placeholder="مثلاً: ماشین‌آلات تأییدشدهٔ آریا"
          />
          <Field
            label="زیرعنوان (معمولاً انگلیسی کوچک)"
            value={section.subtitle ?? ""}
            onChange={(v) => onUpdate({ subtitle: v })}
            placeholder="ARIA VERIFIED MACHINES"
            ltr
          />
          <TextArea
            label="توضیحات"
            value={section.description ?? ""}
            onChange={(v) => onUpdate({ description: v })}
            placeholder="توضیح کوتاه برای زیر عنوان..."
          />

          {/* Dynamic config fields based on section key */}
          <SectionTitle>پیکربندی اختصاصی</SectionTitle>
          <ConfigFields
            sectionKey={section.key}
            config={section.config || {}}
            onUpdate={onUpdateConfig}
          />
        </div>

        {/* Footer */}
        <div className="flex gap-3 border-t bg-gray-50 px-6 py-4">
          <button
            onClick={onClose}
            className="flex-1 rounded-xl bg-orange-500 py-3 font-bold text-white transition hover:bg-orange-600"
          >
            بستن
          </button>
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   CONFIG FIELDS
============================================================ */
function ConfigFields({
  sectionKey,
  config,
  onUpdate,
}: {
  sectionKey: string;
  config: any;
  onUpdate: (key: string, value: any) => void;
}) {
  switch (sectionKey) {
    case "hero":
      return (
        <>
          <Field label="عنوان اصلی Hero" value={config.headline || ""} onChange={(v) => onUpdate("headline", v)} />
          <TextArea label="زیرمتن Hero" value={config.subheadline || ""} onChange={(v) => onUpdate("subheadline", v)} />
          <Field label="متن دکمه اصلی" value={config.primaryCta?.text || ""} onChange={(v) => onUpdate("primaryCta", { ...config.primaryCta, text: v })} />
          <Field label="لینک دکمه اصلی" value={config.primaryCta?.url || ""} onChange={(v) => onUpdate("primaryCta", { ...config.primaryCta, url: v })} ltr />
          <Field label="متن دکمه دوم" value={config.secondaryCta?.text || ""} onChange={(v) => onUpdate("secondaryCta", { ...config.secondaryCta, text: v })} />
          <Field label="لینک دکمه دوم" value={config.secondaryCta?.url || ""} onChange={(v) => onUpdate("secondaryCta", { ...config.secondaryCta, url: v })} ltr />
        </>
      );

    case "exclusive-sale":
      return (
        <>
          <Field label="متن دکمه CTA" value={config.ctaText || ""} onChange={(v) => onUpdate("ctaText", v)} />
          <Field label="لینک دکمه CTA" value={config.ctaUrl || ""} onChange={(v) => onUpdate("ctaUrl", v)} ltr />
          <div>
            <label className="mb-1.5 block text-sm font-bold text-gray-700">
              نشان‌های اعتماد (با کاما جدا کنید)
            </label>
            <input
              value={(config.trustChips || []).join(", ")}
              onChange={(e) =>
                onUpdate(
                  "trustChips",
                  e.target.value.split(",").map((s: string) => s.trim()).filter(Boolean)
                )
              }
              className="w-full rounded-xl border border-gray-200 bg-gray-50 p-3 outline-none focus:border-orange-400 focus:bg-white"
              placeholder="کارشناسی فنی, کارشناسی حقوقی, ..."
            />
          </div>
        </>
      );

    case "verified-machines":
    case "latest-ads":
    case "brands":
      return (
        <Field
          label="تعداد نمایش"
          type="number"
          value={String(config.limit ?? 8)}
          onChange={(v) => onUpdate("limit", parseInt(v) || 8)}
        />
      );

    case "categories":
      return (
        <Field
          label="حداکثر تعداد در حلقه"
          type="number"
          value={String(config.ringMax ?? 18)}
          onChange={(v) => onUpdate("ringMax", parseInt(v) || 18)}
        />
      );

    case "latest-news":
      return (
        <Field
          label="تعداد نمایش"
          type="number"
          value={String(config.limit ?? 3)}
          onChange={(v) => onUpdate("limit", parseInt(v) || 3)}
        />
      );

    default:
      return (
        <div className="rounded-xl bg-gray-50 p-4 text-sm text-gray-500">
          این سکشن پیکربندی اختصاصی ندارد.
        </div>
      );
  }
}

/* ============================================================
   SUB COMPONENTS
============================================================ */
function SectionTitle({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex items-center gap-3 pt-2">
      <span className="text-sm font-black text-gray-800">{children}</span>
      <span className="h-px flex-1 bg-gray-200" />
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  placeholder,
  type = "text",
  ltr,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  type?: string;
  ltr?: boolean;
}) {
  return (
    <div>
      <label className="mb-1.5 block text-sm font-bold text-gray-700">{label}</label>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        dir={ltr ? "ltr" : "rtl"}
        className="w-full rounded-xl border border-gray-200 bg-gray-50 p-3 outline-none transition focus:border-orange-400 focus:bg-white"
      />
    </div>
  );
}

function TextArea({
  label,
  value,
  onChange,
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
}) {
  return (
    <div>
      <label className="mb-1.5 block text-sm font-bold text-gray-700">{label}</label>
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        rows={3}
        className="w-full resize-none rounded-xl border border-gray-200 bg-gray-50 p-3 outline-none transition focus:border-orange-400 focus:bg-white"
      />
    </div>
  );
}