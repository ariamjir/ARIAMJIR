"use client";

import {
  ArrowRight,
  FolderTree,
} from "lucide-react";

import Link from "next/link";

import CategoryForm from "@/components/admin/category/CategoryForm";

export default function NewCategoryPage() {
  return (
    <main className="space-y-8">

      <div className="flex items-center justify-between">

        <div>

          <div className="flex items-center gap-3">

            <div className="rounded-xl bg-orange-100 p-3">

              <FolderTree className="h-6 w-6 text-[#F58220]" />

            </div>

            <div>

              <h1 className="text-3xl font-black text-zinc-900">
                افزودن دسته‌بندی جدید
              </h1>

              <p className="mt-2 text-sm text-zinc-500">
                اطلاعات دسته‌بندی را وارد کرده و درخت دسته‌بندی سایت را مدیریت کنید.
              </p>

            </div>

          </div>

        </div>

        <Link
          href="/admin/categories"
          className="
            inline-flex
            items-center
            gap-2
            rounded-xl
            border
            bg-white
            px-5
            py-3
            text-sm
            font-semibold
            transition
            hover:bg-zinc-100
          "
        >
          <ArrowRight className="h-4 w-4" />

          بازگشت
        </Link>

      </div>

      <CategoryForm />

    </main>
  );
}