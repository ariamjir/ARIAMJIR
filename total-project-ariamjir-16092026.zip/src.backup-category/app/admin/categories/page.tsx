"use client";

import { useMemo, useRef, useState } from "react";

import {
  Plus,
  Pencil,
  Trash2,
  ChevronDown,
  ChevronRight,
  ArrowUp,
  ArrowDown,
  Star,
  EyeOff,
  Home,
  Menu,
  Search,
  FolderPlus,
  X,
  Layers,
  FolderTree,
  ListTree,
  UnfoldVertical,
  FoldVertical,
  Image as ImageIcon,
  Link2,
  Upload,
  Loader2,
} from "lucide-react";

import { useCategories, type Category } from "@/modules/category";

/* ============================================================
   آپلود تصویر — مستقیم به endpoint آپلود پروژه
============================================================ */

async function uploadImage(file: File, folder: string): Promise<string> {
  const fd = new FormData();
  fd.append("file", file);
  fd.append("folder", folder);

  const res = await fetch("/api/upload/image", {
    method: "POST",
    body: fd,
  });

  if (!res.ok) throw new Error("آپلود تصویر ناموفق بود.");

  const json = await res.json();
  return json.url || json.path || json.src || "";
}

/* ایموجی‌های پیشنهادی برای آیکون */
const EMOJI_CHOICES = [
  "🚜", "🏗️", "⛏️", "🚧", "🚛", "🛞", "🔧", "⚙️",
  "💧", "🔌", "🔩", "📦", "🏭", "🌾", "🛢️", "🧱",
];

/* ============================================================
   صفحهٔ مدیریت دسته‌بندی‌ها
============================================================ */

export default function AdminCategoriesPage() {
  const cat = useCategories();

  const [expanded, setExpanded] = useState<Set<string>>(
    () => new Set(cat.rootCategories.map((r) => r.id))
  );
  const [query, setQuery] = useState("");

  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<Category | null>(null);
  const [parentId, setParentId] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);

  const [name, setName] = useState("");
  const [slug, setSlug] = useState("");
  const [icon, setIcon] = useState("");
  const [image, setImage] = useState("");
  const [description, setDescription] = useState("");
  const [linkUrl, setLinkUrl] = useState("");
  const [featured, setFeatured] = useState(false);
  const [showInMenu, setShowInMenu] = useState(true);
  const [showOnHomepage, setShowOnHomepage] = useState(false);
  const [active, setActive] = useState(true);

  const fileRef = useRef<HTMLInputElement>(null);

  /* ---------------- helpers ---------------- */

  const toggleExpand = (id: string) =>
    setExpanded((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });

  const expandAll = () => setExpanded(new Set(cat.categories.map((c) => c.id)));
  const collapseAll = () => setExpanded(new Set());

  const openCreate = (parent: Category | null) => {
    setEditing(null);
    setParentId(parent?.id ?? null);
    setName("");
    setSlug("");
    setIcon("");
    setImage("");
    setDescription("");
    setLinkUrl("");
    setFeatured(false);
    setShowInMenu(true);
    setShowOnHomepage(false);
    setActive(true);
    setFormOpen(true);
  };

  const openEdit = (c: Category) => {
    setEditing(c);
    setParentId(c.parentId);
    setName(c.name);
    setSlug(c.slug);
    setIcon(c.icon ?? "");
    setImage(c.image ?? "");
    setDescription(c.description ?? "");
    setLinkUrl((c as any).link ?? "");
    setFeatured(!!c.featured);
    setShowInMenu(!!c.showInMenu);
    setShowOnHomepage(!!c.showOnHomepage);
    setActive(!!c.active);
    setFormOpen(true);
  };

  /* آپلود تصویر */
  const handleFile = async (file: File) => {
    try {
      setUploading(true);
      const url = await uploadImage(file, "categories");
      setImage(url);
    } catch (e) {
      alert(e instanceof Error ? e.message : "خطا در آپلود.");
    } finally {
      setUploading(false);
    }
  };

  /* ✅ save با تصویر، آیکون و لینک */
  const save = async () => {
    if (!name.trim()) return alert("نام دسته الزامی است.");
    const finalSlug = slugify(slug.trim() || name);
    if (!finalSlug) return alert("اسلاگ معتبر نیست.");

    const payload: any = {
      name: name.trim(),
      slug: finalSlug,
      featured,
      showInMenu,
      showOnHomepage,
      active,
    };

    if (icon.trim()) payload.icon = icon.trim();
    if (image.trim()) payload.image = image.trim();
    if (description.trim()) payload.description = description.trim();
    if (linkUrl.trim()) payload.link = linkUrl.trim();
    if (parentId) payload.parentId = parentId;

    try {
      setSaving(true);
      if (editing) {
        await cat.update(editing.id, payload);
      } else {
        const last = cat.sortedCategories[cat.sortedCategories.length - 1];
        payload.sortOrder = (last?.sortOrder ?? 0) + 1;
        await cat.create(payload);
      }
      setFormOpen(false);
    } catch (e) {
      alert(e instanceof Error ? e.message : "خطا در ذخیره دسته.");
    } finally {
      setSaving(false);
    }
  };

  const remove = async (c: Category) => {
    const children = cat.getChildren(c.id);
    if (children.length > 0)
      return alert(`این دسته ${children.length} زیرمجموعه دارد؛ ابتدا آن‌ها را حذف یا جابه‌جا کنید.`);
    if ((c.machinesCount ?? 0) > 0) return alert("این دسته دارای آگهی است و قابل حذف نیست.");
    if (!confirm(`دستهٔ «${c.name}» حذف شود؟`)) return;
    await cat.remove(c.id);
  };

  const move = async (c: Category, dir: -1 | 1) => {
    const siblings = (c.parentId ? cat.getChildren(c.parentId) : cat.rootCategories)
      .slice()
      .sort((a, b) => (a.sortOrder ?? 0) - (b.sortOrder ?? 0));
    const idx = siblings.findIndex((s) => s.id === c.id);
    const target = siblings[idx + dir];
    if (!target) return;
    await cat.update(c.id, { sortOrder: target.sortOrder } as any);
    await cat.update(target.id, { sortOrder: c.sortOrder } as any);
  };

  /* ---------------- render ---------------- */

  const filteredRoots = useMemo(() => {
    const roots = [...cat.rootCategories].sort(
      (a, b) => (a.sortOrder ?? 0) - (b.sortOrder ?? 0)
    );
    if (!query.trim()) return roots;
    return cat.search(query).filter((c) => !c.parentId);
  }, [cat, query]);

  return (
    <div className="mx-auto max-w-6xl space-y-6 p-6">
      {/* Header */}
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div className="flex items-center gap-3">
          <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-orange-500 text-white shadow-lg shadow-orange-500/25">
            <FolderTree className="h-6 w-6" />
          </span>
          <div>
            <h1 className="text-2xl font-black">مدیریت دسته‌بندی‌ها</h1>
            <p className="mt-1 text-sm text-gray-500">
              ریشه و زیرمجموعه بسازید، تصویر و آیکون بدهید؛ تغییرات برخط در سایت اعمال می‌شود.
            </p>
          </div>
        </div>
        <button
          onClick={() => openCreate(null)}
          className="inline-flex items-center gap-2 rounded-xl bg-orange-500 px-5 py-3 font-bold text-white shadow-md shadow-orange-500/20 transition hover:bg-orange-600"
        >
          <FolderPlus className="h-5 w-5" /> ریشهٔ جدید
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        <StatCard icon={<Layers className="h-5 w-5" />} label="کل دسته‌ها" value={cat.totalCount} />
        <StatCard icon={<FolderTree className="h-5 w-5" />} label="ریشه‌ها" value={cat.rootCount} />
        <StatCard icon={<EyeOff className="h-5 w-5" />} label="فعال" value={cat.activeCount} tone="green" />
        <StatCard icon={<Star className="h-5 w-5" />} label="ویژه" value={cat.featuredCount} tone="orange" />
      </div>

      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-3 rounded-2xl border bg-white p-3">
        <div className="relative min-w-[200px] flex-1">
          <Search className="absolute right-4 top-1/2 h-5 w-5 -translate-y-1/2 text-gray-400" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="جستجوی دسته..."
            className="w-full rounded-xl border border-gray-200 bg-gray-50 py-2.5 pr-12 pl-4 outline-none transition focus:border-orange-400 focus:bg-white"
          />
        </div>
        <button onClick={expandAll} className="inline-flex items-center gap-2 rounded-xl border px-4 py-2.5 text-sm font-semibold text-gray-600 transition hover:bg-gray-50">
          <UnfoldVertical className="h-4 w-4" /> باز کردن همه
        </button>
        <button onClick={collapseAll} className="inline-flex items-center gap-2 rounded-xl border px-4 py-2.5 text-sm font-semibold text-gray-600 transition hover:bg-gray-50">
          <FoldVertical className="h-4 w-4" /> جمع کردن همه
        </button>
      </div>

      {/* Tree */}
      <div className="rounded-2xl border bg-white p-3">
        {filteredRoots.length === 0 ? (
          <div className="p-10 text-center text-gray-400">
            <ListTree className="mx-auto mb-3 h-10 w-10" />
            دسته‌ای یافت نشد.
          </div>
        ) : (
          <div className="space-y-1">
            {filteredRoots.map((root) => (
              <TreeNode
                key={root.id}
                node={root}
                depth={0}
                expanded={expanded}
                onToggle={toggleExpand}
                onEdit={openEdit}
                onAddChild={openCreate}
                onRemove={remove}
                onMove={move}
                cat={cat}
              />
            ))}
          </div>
        )}
      </div>

      {/* ============ Form Modal ============ */}
      {formOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm">
          <div className="max-h-[92vh] w-full max-w-xl overflow-y-auto rounded-2xl bg-white shadow-2xl">
            <div className="sticky top-0 z-10 flex items-center justify-between border-b bg-white px-6 py-4">
              <h2 className="flex items-center gap-2 text-lg font-black">
                <FolderTree className="h-5 w-5 text-orange-500" />
                {editing ? "ویرایش دسته" : parentId ? "زیرمجموعهٔ جدید" : "ریشهٔ جدید"}
              </h2>
              <button onClick={() => setFormOpen(false)} className="rounded-lg p-1.5 text-gray-400 transition hover:bg-gray-100 hover:text-gray-700">
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="space-y-6 p-6">
              {/* --- والد --- */}
              <div>
                <label className="mb-1.5 block text-sm font-bold text-gray-700">دستهٔ والد</label>
                <select
                  value={parentId ?? ""}
                  onChange={(e) => setParentId(e.target.value || null)}
                  className="w-full rounded-xl border border-gray-200 bg-gray-50 p-3 outline-none focus:border-orange-400 focus:bg-white"
                >
                  <option value="">— بدون والد (ریشه) —</option>
                  {cat.sortedCategories
                    .filter((c) => c.id !== editing?.id)
                    .map((c) => (
                      <option key={c.id} value={c.id}>
                        {"— ".repeat(cat.getLevel(c.id))}
                        {c.name}
                      </option>
                    ))}
                </select>
              </div>

              {/* --- اطلاعات پایه --- */}
              <SectionTitleRow>اطلاعات پایه</SectionTitleRow>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="mb-1.5 block text-sm font-bold text-gray-700">
                    نام <span className="text-red-500">*</span>
                  </label>
                  <input
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="مثلاً ماشین‌آلات سنگین"
                    className="w-full rounded-xl border border-gray-200 bg-gray-50 p-3 outline-none focus:border-orange-400 focus:bg-white"
                  />
                </div>
                <div>
                  <label className="mb-1.5 block text-sm font-bold text-gray-700">Slug</label>
                  <input
                    value={slug}
                    onChange={(e) => setSlug(e.target.value)}
                    dir="ltr"
                    placeholder="heavy-machinery"
                    className="w-full rounded-xl border border-gray-200 bg-gray-50 p-3 text-left outline-none focus:border-orange-400 focus:bg-white"
                  />
                </div>
              </div>
              <div>
                <label className="mb-1.5 block text-sm font-bold text-gray-700">توضیحات</label>
                <input
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full rounded-xl border border-gray-200 bg-gray-50 p-3 outline-none focus:border-orange-400 focus:bg-white"
                />
              </div>

              {/* --- ظاهر: تصویر + آیکون --- */}
              <SectionTitleRow>ظاهر (برای نمایش در صفحهٔ اول)</SectionTitleRow>

              <div className="grid grid-cols-[140px_1fr] gap-4">
                {/* تصویر */}
                <div>
                  <label className="mb-1.5 block text-sm font-bold text-gray-700">تصویر</label>
                  <button
                    type="button"
                    onClick={() => fileRef.current?.click()}
                    className="relative flex h-32 w-full flex-col items-center justify-center overflow-hidden rounded-xl border-2 border-dashed border-gray-300 bg-gray-50 transition hover:border-orange-400"
                  >
                    {uploading ? (
                      <Loader2 className="h-6 w-6 animate-spin text-orange-500" />
                    ) : image ? (
                      <>
                        {/* eslint-disable-next-line @next/next/no-img-element */}
                        <img src={image} alt="" className="absolute inset-0 h-full w-full object-cover" />
                        <span className="absolute inset-0 flex items-center justify-center bg-black/40 text-xs font-bold text-white opacity-0 transition hover:opacity-100">
                          تغییر
                        </span>
                      </>
                    ) : (
                      <>
                        <ImageIcon className="h-6 w-6 text-gray-400" />
                        <span className="mt-1 text-xs text-gray-500">آپلود تصویر</span>
                      </>
                    )}
                  </button>
                  <input
                    ref={fileRef}
                    type="file"
                    accept="image/*"
                    hidden
                    onChange={(e) => {
                      const f = e.target.files?.[0];
                      if (f) handleFile(f);
                      e.target.value = "";
                    }}
                  />
                  {image && (
                    <button onClick={() => setImage("")} className="mt-1 text-xs text-red-500 hover:underline">
                      حذف تصویر
                    </button>
                  )}
                </div>

                {/* آیکون */}
                <div>
                  <label className="mb-1.5 block text-sm font-bold text-gray-700">آیکون</label>
                  <div className="flex flex-wrap gap-2">
                    {EMOJI_CHOICES.map((e) => (
                      <button
                        key={e}
                        type="button"
                        onClick={() => setIcon(e)}
                        className={`flex h-9 w-9 items-center justify-center rounded-lg border text-lg transition ${
                          icon === e ? "border-orange-500 bg-orange-50" : "border-gray-200 hover:bg-gray-50"
                        }`}
                      >
                        {e}
                      </button>
                    ))}
                  </div>
                  <input
                    value={icon}
                    onChange={(e) => setIcon(e.target.value)}
                    placeholder="یا ایموجی دلخواه را تایپ کنید..."
                    className="mt-2 w-full rounded-xl border border-gray-200 bg-gray-50 p-3 outline-none focus:border-orange-400 focus:bg-white"
                  />
                </div>
              </div>

              {/* --- لینک سفارشی --- */}
              <SectionTitleRow>لینک (اختیاری، برای صفحات آینده)</SectionTitleRow>
              <div className="relative">
                <Link2 className="absolute right-4 top-1/2 h-5 w-5 -translate-y-1/2 text-gray-400" />
                <input
                  value={linkUrl}
                  onChange={(e) => setLinkUrl(e.target.value)}
                  dir="ltr"
                  placeholder="/categories/heavy-machinery  یا  https://..."
                  className="w-full rounded-xl border border-gray-200 bg-gray-50 py-3 pr-12 pl-4 text-left outline-none focus:border-orange-400 focus:bg-white"
                />
              </div>
              <p className="mt-1 text-xs text-gray-400">
                اگر خالی باشد، از آدرس پیش‌فرض <span dir="ltr">/categories/{slugify(slug || name) || "…"}</span> استفاده می‌شود.
              </p>

              {/* --- پرچم‌ها --- */}
              <SectionTitleRow>تنظیمات نمایش</SectionTitleRow>
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <Toggle label="فعال" hint="نمایش در سایت" value={active} onChange={setActive} />
                <Toggle label="ویژه ⭐" hint="اولویت در صفحه اول" value={featured} onChange={setFeatured} />
                <Toggle label="نمایش در منو" hint="منوی اصلی سایت" value={showInMenu} onChange={setShowInMenu} />
                <Toggle label="نمایش در صفحه اول" hint="بخش دسته‌بندی‌ها" value={showOnHomepage} onChange={setShowOnHomepage} />
              </div>
            </div>

            <div className="flex gap-3 border-t bg-gray-50 px-6 py-4">
              <button
                onClick={save}
                disabled={saving || uploading}
                className="flex-1 rounded-xl bg-orange-500 py-3 font-bold text-white transition hover:bg-orange-600 disabled:opacity-60"
              >
                {saving ? "در حال ذخیره..." : editing ? "ذخیره تغییرات" : "ایجاد دسته"}
              </button>
              <button onClick={() => setFormOpen(false)} className="rounded-xl border bg-white px-6 py-3 font-semibold text-gray-600 transition hover:bg-gray-100">
                انصراف
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ============================================================
   Sub-components
============================================================ */

function SectionTitleRow({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex items-center gap-3">
      <span className="text-sm font-black text-gray-800">{children}</span>
      <span className="h-px flex-1 bg-gray-200" />
    </div>
  );
}

function StatCard({ icon, label, value, tone }: { icon: React.ReactNode; label: string; value: number; tone?: "green" | "orange" }) {
  const toneCls =
    tone === "green"
      ? "text-emerald-600 bg-emerald-50"
      : tone === "orange"
      ? "text-orange-600 bg-orange-50"
      : "text-gray-600 bg-gray-100";
  return (
    <div className="flex items-center gap-3 rounded-2xl border bg-white p-4">
      <span className={`flex h-10 w-10 items-center justify-center rounded-xl ${toneCls}`}>{icon}</span>
      <div>
        <div className="text-2xl font-black leading-none">{value}</div>
        <div className="mt-1 text-xs font-semibold text-gray-500">{label}</div>
      </div>
    </div>
  );
}

function Badge({ children, tone }: { children: React.ReactNode; tone: "orange" | "gray" | "blue" }) {
  const cls = {
    orange: "bg-orange-50 text-orange-600 border-orange-200",
    gray: "bg-gray-100 text-gray-500 border-gray-200",
    blue: "bg-blue-50 text-blue-600 border-blue-200",
  }[tone];
  return <span className={`inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[11px] font-bold ${cls}`}>{children}</span>;
}

function TreeNode({ node, depth, expanded, onToggle, onEdit, onAddChild, onRemove, onMove, cat }: {
  node: Category;
  depth: number;
  expanded: Set<string>;
  onToggle: (id: string) => void;
  onEdit: (c: Category) => void;
  onAddChild: (c: Category) => void;
  onRemove: (c: Category) => void;
  onMove: (c: Category, dir: -1 | 1) => void;
  cat: ReturnType<typeof useCategories>;
}) {
  const children = cat.getChildren(node.id).slice().sort((a, b) => (a.sortOrder ?? 0) - (b.sortOrder ?? 0));
  const isOpen = expanded.has(node.id);
  const hasChildren = children.length > 0;

  return (
    <div>
      <div
        className={`group flex items-center gap-2 rounded-xl border border-transparent px-2 py-2.5 transition ${
          node.active ? "hover:border-gray-200 hover:bg-gray-50" : "bg-gray-50/60 opacity-70 hover:bg-gray-100"
        }`}
        style={{ paddingRight: depth * 28 + 8 }}
      >
        <button onClick={() => onToggle(node.id)} className="flex h-6 w-6 items-center justify-center text-gray-400">
          {hasChildren ? (
            isOpen ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />
          ) : (
            <span className="h-1 w-1 rounded-full bg-gray-300" />
          )}
        </button>

        {/* تصویر یا آیکون */}
        {node.image ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={node.image} alt="" className="h-9 w-9 rounded-lg object-cover" />
        ) : (
          <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-gray-100 text-lg">
            {node.icon || (depth === 0 ? "📁" : "📄")}
          </span>
        )}

        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <span className="truncate font-bold">{node.name}</span>
            {node.featured && <Badge tone="orange"><Star className="h-3 w-3 fill-current" /> ویژه</Badge>}
            {node.showOnHomepage && <Badge tone="blue"><Home className="h-3 w-3" /> صفحه اول</Badge>}
            {!node.active && <Badge tone="gray"><EyeOff className="h-3 w-3" /> غیرفعال</Badge>}
          </div>
          <div className="mt-0.5 flex items-center gap-2 text-xs text-gray-400">
            <span dir="ltr">/{node.slug}</span>
            <span>•</span>
            <span>{node.machinesCount ?? 0} آگهی</span>
            {hasChildren && (<><span>•</span><span>{children.length} زیرمجموعه</span></>)}
          </div>
        </div>

        <div className="ms-auto flex items-center gap-1 opacity-60 transition group-hover:opacity-100">
          <IconBtn title="بالا" onClick={() => onMove(node, -1)}><ArrowUp className="h-4 w-4" /></IconBtn>
          <IconBtn title="پایین" onClick={() => onMove(node, 1)}><ArrowDown className="h-4 w-4" /></IconBtn>
          <IconBtn title="زیرمجموعه جدید" onClick={() => onAddChild(node)} tone="green"><Plus className="h-4 w-4" /></IconBtn>
          <IconBtn title="ویرایش" onClick={() => onEdit(node)} tone="blue"><Pencil className="h-4 w-4" /></IconBtn>
          <IconBtn title="حذف" onClick={() => onRemove(node)} tone="red"><Trash2 className="h-4 w-4" /></IconBtn>
        </div>
      </div>

      {isOpen && hasChildren && (
        <div className="relative">
          <span className="absolute bottom-2 top-0 w-px bg-gray-200" style={{ right: depth * 28 + 20 }} aria-hidden />
          {children.map((child) => (
            <TreeNode key={child.id} node={child} depth={depth + 1} expanded={expanded} onToggle={onToggle} onEdit={onEdit} onAddChild={onAddChild} onRemove={onRemove} onMove={onMove} cat={cat} />
          ))}
        </div>
      )}
    </div>
  );
}

function IconBtn({ children, onClick, title, tone = "gray" }: { children: React.ReactNode; onClick: () => void; title: string; tone?: "gray" | "green" | "blue" | "red" }) {
  const toneCls = {
    gray: "text-gray-500 hover:bg-gray-100 hover:text-gray-800",
    green: "text-emerald-600 hover:bg-emerald-50",
    blue: "text-blue-600 hover:bg-blue-50",
    red: "text-red-500 hover:bg-red-50",
  }[tone];
  return (
    <button title={title} onClick={onClick} className={`rounded-lg p-1.5 transition ${toneCls}`}>
      {children}
    </button>
  );
}

function Toggle({ label, hint, value, onChange }: { label: string; hint?: string; value: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      type="button"
      onClick={() => onChange(!value)}
      className={`flex w-full items-center justify-between rounded-xl border p-3 text-right transition ${
        value ? "border-orange-300 bg-orange-50" : "border-gray-200 bg-white hover:bg-gray-50"
      }`}
    >
      <span>
        <span className="block text-sm font-bold text-gray-800">{label}</span>
        {hint && <span className="block text-xs text-gray-500">{hint}</span>}
      </span>
      <span className={`relative inline-block h-6 w-11 rounded-full transition-colors ${value ? "bg-orange-500" : "bg-gray-300"}`}>
        <span className={`absolute top-1 h-4 w-4 rounded-full bg-white shadow transition-all ${value ? "right-6" : "right-1"}`} />
      </span>
    </button>
  );
}

function slugify(text: string) {
  return text.toLowerCase().trim().replace(/[^\w\s-]/g, "").replace(/\s+/g, "-").replace(/-+/g, "-").replace(/^-+|-+$/g, "");
}