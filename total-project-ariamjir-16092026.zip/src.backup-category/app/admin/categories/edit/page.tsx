"use client";

import { use } from "react";
import CategoryForm from "@/components/admin/CategoryForm";

type Props = {
  params: Promise<{
    id: string;
  }>;
};

export default function EditCategoryPage({
  params,
}: Props) {

  const { id } = use(params);

  return (
    <main className="space-y-6">

      <div>
        <h1 className="text-3xl font-bold text-gray-900">
          ویرایش دسته‌بندی
        </h1>

        <p className="mt-2 text-sm text-gray-500">
          اطلاعات دسته‌بندی را ویرایش کنید.
        </p>
      </div>

      <CategoryForm categoryId={id} />

    </main>
  );
}