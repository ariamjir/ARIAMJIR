"use client";

import { use } from "react";

import {
  ArrowRight,
  FolderTree,
} from "lucide-react";

import Link from "next/link";

import CategoryForm from "@/components/admin/category/CategoryForm";

interface PageProps {
  params: Promise<{
    id: string;
  }>;
}

export default function EditCategoryPage({
  params,
}: PageProps) {
  const { id } = use(params);

  return (
    <main className="space-y-8">

      <div className="flex items-center justify-between">

        <div>

          <div className="flex items-center gap-3">

            <div className="rounded-xl bg-orange-100 p-3">

              <FolderTree className="h-6 w-6 text-[#F58220]" />

            </div>

            <div>

              <h1 className="text-3xl font-black text-zinc-900">
                ویرایش دسته‌بندی
              </h1>

              <p className="mt-2 text-sm text-zinc-500">
                اطلاعات دسته‌بندی را ویرایش و ذخیره کنید.
              </p>

            </div>

          </div>

        </div>

        <Link
          href="/admin/categories"
          className="
            inline-flex
            items-center
            gap-2
            rounded-xl
            border
            bg-white
            px-5
            py-3
            text-sm
            font-semibold
            transition
            hover:bg-zinc-100
          "
        >
          <ArrowRight className="h-4 w-4" />

          بازگشت
        </Link>

      </div>

      <CategoryForm categoryId={id} />

    </main>
  );
}