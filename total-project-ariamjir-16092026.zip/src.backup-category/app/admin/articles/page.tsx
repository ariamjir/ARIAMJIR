export default function Page() {
  return <h1>در حال توسعه...</h1>;
}

