import {
  ExclusiveSaleSection,
  FeaturedMachinesSection,
  LatestAdsSection,
  CategoriesSection,
  ServicesSection,
  BrandsSection,
  LatestNewsSection,
  KnowledgeSection,
  WhyUsSection,
} from "@/features/home";


export default function AdminPage() {

  return (

    <main
      className="
        min-h-screen
        bg-[#111111]
      "
    >

      <ExclusiveSaleSection />

      <FeaturedMachinesSection />

      <LatestAdsSection />

      <CategoriesSection />

      <ServicesSection />

      <BrandsSection />

      <LatestNewsSection />

      <KnowledgeSection />

      <WhyUsSection />

    </main>

  );

}