"use client";

import { useCallback, useEffect, useState } from "react";

import {
  Plus,
  Pencil,
  Trash2,
  ChevronDown,
  ChevronLeft,
  ChevronUp,
  Save,
  X,
  Eye,
  EyeOff,
  GripVertical,
  Menu as MenuIcon,
  ExternalLink,
} from "lucide-react";

type MenuItem = {
  id: string;
  title: string;
  href: string | null;
  parentId: string | null;
  type: string;
  icon: string | null;
  categoryId: string | null;
  sortOrder: number;
  active: boolean;
  showDesktop: boolean;
  showMobile: boolean;
  openInNewTab: boolean;
  megaMenu: boolean;
  createdAt?: string;
  updatedAt?: string;
  children?: MenuItem[];
};

type FormState = {
  title: string;
  href: string;
  parentId: string;
  type: string;
  icon: string;
  sortOrder: number;
  active: boolean;
  showDesktop: boolean;
  showMobile: boolean;
  openInNewTab: boolean;
  megaMenu: boolean;
};

const emptyForm: FormState = {
  title: "",
  href: "",
  parentId: "",
  type: "LINK",
  icon: "",
  sortOrder: 0,
  active: true,
  showDesktop: true,
  showMobile: true,
  openInNewTab: false,
  megaMenu: false,
};

export default function AdminMenuPage() {
  const [items, setItems] = useState<MenuItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [editorOpen, setEditorOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState<FormState>(emptyForm);
  const [saving, setSaving] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [expanded, setExpanded] = useState<Record<string, boolean>>({});

  const loadItems = useCallback(async () => {
    try {
      setLoading(true);
      const response = await fetch("/api/admin/menu", {
        method: "GET",
        cache: "no-store",
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data?.error || "خطا در دریافت منوها");
      }
      setItems(Array.isArray(data?.items) ? data.items : []);
    } catch (error) {
      console.error("[Admin Menu]", error);
      alert(error instanceof Error ? error.message : "دریافت اطلاعات منو با خطا مواجه شد.");
      setItems([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadItems();
  }, [loadItems]);

  const flatItems = items;

  const openCreate = () => {
    setEditingId(null);
    setForm({ ...emptyForm, sortOrder: items.length + 1 });
    setEditorOpen(true);
  };

  const openEdit = (item: MenuItem) => {
    setEditingId(item.id);
    setForm({
      title: item.title,
      href: item.href ?? "",
      parentId: item.parentId ?? "",
      type: item.type || "LINK",
      icon: item.icon ?? "",
      sortOrder: item.sortOrder ?? 0,
      active: item.active,
      showDesktop: item.showDesktop,
      showMobile: item.showMobile,
      openInNewTab: item.openInNewTab,
      megaMenu: item.megaMenu,
    });
    setEditorOpen(true);
  };

  const closeEditor = () => {
    if (saving) return;
    setEditorOpen(false);
    setEditingId(null);
    setForm(emptyForm);
  };

  const updateForm = <K extends keyof FormState>(key: K, value: FormState[K]) => {
    setForm((current) => ({ ...current, [key]: value }));
  };

  const saveItem = async () => {
    if (!form.title.trim()) {
      alert("عنوان منو را وارد کنید.");
      return;
    }
    if (form.type === "LINK" && !form.href.trim()) {
      alert("برای منوی نوع لینک، آدرس را وارد کنید.");
      return;
    }

    try {
      setSaving(true);
      const payload = {
        title: form.title.trim(),
        href: form.href.trim() || null,
        parentId: form.parentId || null,
        type: form.type,
        icon: form.icon.trim() || null,
        sortOrder: Number(form.sortOrder) || 0,
        active: form.active,
        showDesktop: form.showDesktop,
        showMobile: form.showMobile,
        openInNewTab: form.openInNewTab,
        megaMenu: form.megaMenu,
      };
      const url = editingId ? `/api/admin/menu/${editingId}` : "/api/admin/menu";
      const method = editingId ? "PATCH" : "POST";
      const response = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data?.error || "خطا در ذخیره منو");
      }
      await loadItems();
      setEditorOpen(false);
      setEditingId(null);
      setForm(emptyForm);
    } catch (error) {
      console.error("[Save Menu]", error);
      alert(error instanceof Error ? error.message : "ذخیره منو با خطا مواجه شد.");
    } finally {
      setSaving(false);
    }
  };

  const deleteItem = async (item: MenuItem) => {
    const confirmed = window.confirm(
      `آیا از حذف «${item.title}» مطمئن هستید؟\n\nاگر این منو زیرمنو داشته باشد، زیرمنوهای آن نیز باید مدیریت شوند.`,
    );
    if (!confirmed) return;

    try {
      setDeletingId(item.id);
      const response = await fetch(`/api/admin/menu/${item.id}`, { method: "DELETE" });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data?.error || "حذف منو انجام نشد.");
      }
      await loadItems();
    } catch (error) {
      console.error("[Delete Menu]", error);
      alert(error instanceof Error ? error.message : "حذف منو با خطا مواجه شد.");
    } finally {
      setDeletingId(null);
    }
  };

  const toggleExpanded = (id: string) => {
    setExpanded((current) => ({ ...current, [id]: !current[id] }));
  };

  /* ✅ جابجایی آیتم — سازگار با همهٔ مرورگرها */
  const moveItem = async (item: MenuItem, direction: "up" | "down") => {
    const siblings = items
      .filter((x) => x.parentId === item.parentId)
      .sort((a, b) => a.sortOrder - b.sortOrder);

    const idx = siblings.findIndex((x) => x.id === item.id);
    if (idx < 0) return;

    const swapIdx = direction === "up" ? idx - 1 : idx + 1;
    if (swapIdx < 0 || swapIdx >= siblings.length) return;

    const other = siblings[swapIdx];
    const tempOrder = item.sortOrder;

    try {
      await Promise.all([
        fetch(`/api/admin/menu/${item.id}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ sortOrder: other.sortOrder }),
        }),
        fetch(`/api/admin/menu/${other.id}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ sortOrder: tempOrder }),
        }),
      ]);
      await loadItems();
    } catch (error) {
      console.error("[Move Menu]", error);
      alert("جابجایی با خطا مواجه شد.");
    }
  };

  const renderItem = (item: MenuItem, level = 0): React.ReactNode => {
    const children = items
      .filter((child) => child.parentId === item.id)
      .sort((a, b) => a.sortOrder - b.sortOrder);

    const hasChildren = children.length > 0;
    const isExpanded = expanded[item.id] ?? true;

    const siblings = items
      .filter((x) => x.parentId === item.parentId)
      .sort((a, b) => a.sortOrder - b.sortOrder);
    const canMoveUp = siblings.findIndex((x) => x.id === item.id) > 0;
    const canMoveDown =
      siblings.findIndex((x) => x.id === item.id) < siblings.length - 1;

    return (
      <div key={item.id}>
        <div
          className="group flex items-center gap-3 border-b border-zinc-200 bg-white px-5 py-4 transition hover:bg-zinc-50"
          style={{ paddingRight: `${20 + level * 42}px` }}
        >
          {/* Drag / hierarchy indicator */}
          <div className="text-zinc-300">
            <GripVertical size={18} />
          </div>

          {/* ✅ Move up/down — سازگار با همهٔ مرورگرها */}
          <div className="flex flex-col gap-0.5">
            <button
              type="button"
              onClick={() => moveItem(item, "up")}
              disabled={!canMoveUp}
              className="flex h-5 w-5 items-center justify-center rounded text-zinc-400 transition hover:bg-zinc-100 hover:text-zinc-700 disabled:opacity-20 disabled:cursor-not-allowed"
              title="انتقال به بالا"
            >
              <ChevronUp size={14} />
            </button>
            <button
              type="button"
              onClick={() => moveItem(item, "down")}
              disabled={!canMoveDown}
              className="flex h-5 w-5 items-center justify-center rounded text-zinc-400 transition hover:bg-zinc-100 hover:text-zinc-700 disabled:opacity-20 disabled:cursor-not-allowed"
              title="انتقال به پایین"
            >
              <ChevronDown size={14} />
            </button>
          </div>

          {/* Expand */}
          <div className="w-6">
            {hasChildren ? (
              <button
                type="button"
                onClick={() => toggleExpanded(item.id)}
                className="flex h-6 w-6 items-center justify-center rounded-md text-zinc-500 hover:bg-zinc-200"
              >
                {isExpanded ? <ChevronDown size={16} /> : <ChevronLeft size={16} />}
              </button>
            ) : null}
          </div>

          {/* Icon */}
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-zinc-100 text-zinc-600">
            <MenuIcon size={18} />
          </div>

          {/* Title */}
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <span
                className={`truncate font-semibold ${
                  item.active ? "text-zinc-900" : "text-zinc-400 line-through"
                }`}
              >
                {item.title}
              </span>
              {level > 0 && (
                <span className="rounded-md bg-orange-50 px-2 py-0.5 text-[10px] font-bold text-orange-600">
                  زیرمنو
                </span>
              )}
              {item.megaMenu && (
                <span className="rounded-md bg-purple-50 px-2 py-0.5 text-[10px] font-bold text-purple-600">
                  Mega
                </span>
              )}
            </div>
            <div className="mt-1 flex items-center gap-3 text-xs text-zinc-400">
              <span>{item.href || "بدون لینک"}</span>
              <span>ترتیب: {item.sortOrder}</span>
              {item.openInNewTab && (
                <span className="flex items-center gap-1">
                  <ExternalLink size={12} />
                  تب جدید
                </span>
              )}
            </div>
          </div>

          {/* Desktop/Mobile */}
          <div className="hidden items-center gap-1 lg:flex">
            <span
              className={`rounded-lg px-2.5 py-1 text-[11px] font-medium ${
                item.showDesktop ? "bg-green-50 text-green-700" : "bg-zinc-100 text-zinc-400"
              }`}
            >
              دسکتاپ
            </span>
            <span
              className={`rounded-lg px-2.5 py-1 text-[11px] font-medium ${
                item.showMobile ? "bg-blue-50 text-blue-700" : "bg-zinc-100 text-zinc-400"
              }`}
            >
              موبایل
            </span>
          </div>

          {/* Status */}
          <div className="hidden sm:block">
            {item.active ? (
              <span className="flex items-center gap-1.5 rounded-lg bg-green-50 px-3 py-1.5 text-xs font-semibold text-green-700">
                <Eye size={14} />
                فعال
              </span>
            ) : (
              <span className="flex items-center gap-1.5 rounded-lg bg-zinc-100 px-3 py-1.5 text-xs font-semibold text-zinc-400">
                <EyeOff size={14} />
                غیرفعال
              </span>
            )}
          </div>

          {/* Actions */}
          <div className="flex items-center gap-1 opacity-100 transition lg:opacity-0 lg:group-hover:opacity-100">
            <button
              type="button"
              onClick={() => openEdit(item)}
              className="flex h-9 w-9 items-center justify-center rounded-lg text-zinc-500 hover:bg-orange-50 hover:text-orange-600"
              title="ویرایش"
            >
              <Pencil size={16} />
            </button>
            <button
              type="button"
              onClick={() => deleteItem(item)}
              disabled={deletingId === item.id}
              className="flex h-9 w-9 items-center justify-center rounded-lg text-zinc-500 hover:bg-red-50 hover:text-red-600 disabled:opacity-40"
              title="حذف"
            >
              <Trash2 size={16} />
            </button>
          </div>
        </div>

        {hasChildren && isExpanded && (
          <div>{children.map((child) => renderItem(child, level + 1))}</div>
        )}
      </div>
    );
  };

  const rootItems = items
    .filter((item) => !item.parentId)
    .sort((a, b) => a.sortOrder - b.sortOrder);

  return (
    <div className="space-y-6">
      {/* HEADER */}
      <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
        <div>
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-orange-500 text-white shadow-lg shadow-orange-500/20">
              <MenuIcon size={24} />
            </div>
            <div>
              <h1 className="text-2xl font-black text-zinc-900">مدیریت منوی سایت</h1>
              <p className="mt-1 text-sm text-zinc-500">
                ساختار منوی اصلی و زیرمنوهای ARIA MJ را مدیریت کنید.
              </p>
            </div>
          </div>
        </div>
        <button
          type="button"
          onClick={openCreate}
          className="flex items-center justify-center gap-2 rounded-xl bg-orange-500 px-5 py-3 text-sm font-bold text-white shadow-lg shadow-orange-500/20 transition hover:bg-orange-600"
        >
          <Plus size={19} />
          افزودن آیتم منو
        </button>
      </div>

      {/* INFO */}
      <div className="grid gap-4 sm:grid-cols-3">
        <div className="rounded-2xl border border-zinc-200 bg-white p-5">
          <div className="text-xs text-zinc-400">تعداد کل آیتم‌ها</div>
          <div className="mt-2 text-3xl font-black text-zinc-900">{items.length}</div>
        </div>
        <div className="rounded-2xl border border-zinc-200 bg-white p-5">
          <div className="text-xs text-zinc-400">آیتم‌های فعال</div>
          <div className="mt-2 text-3xl font-black text-green-600">
            {items.filter((item) => item.active).length}
          </div>
        </div>
        <div className="rounded-2xl border border-zinc-200 bg-white p-5">
          <div className="text-xs text-zinc-400">زیرمنوها</div>
          <div className="mt-2 text-3xl font-black text-orange-500">
            {items.filter((item) => item.parentId).length}
          </div>
        </div>
      </div>

      {/* MENU LIST */}
      <div className="overflow-hidden rounded-2xl border border-zinc-200 bg-white shadow-sm">
        <div className="border-b border-zinc-200 bg-zinc-50 px-5 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="font-bold text-zinc-900">ساختار منو</h2>
              <p className="mt-1 text-xs text-zinc-500">
                با دکمه‌های ▲ ▼ کنار هر آیتم، ترتیب نمایش را تنظیم کنید. برای ایجاد زیرمنو، هنگام افزودن یا ویرایش آیتم، منوی والد را انتخاب کنید.
              </p>
            </div>
          </div>
        </div>

        {loading ? (
          <div className="space-y-3 p-6">
            {Array.from({ length: 6 }).map((_, index) => (
              <div key={index} className="h-16 animate-pulse rounded-xl bg-zinc-100" />
            ))}
          </div>
        ) : rootItems.length === 0 ? (
          <div className="flex min-h-[300px] flex-col items-center justify-center px-6 text-center">
            <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-zinc-100 text-zinc-400">
              <MenuIcon size={30} />
            </div>
            <h3 className="mt-4 text-lg font-bold text-zinc-800">هنوز آیتمی در منو وجود ندارد.</h3>
            <p className="mt-2 text-sm text-zinc-500">اولین آیتم منوی سایت را اضافه کنید.</p>
            <button
              type="button"
              onClick={openCreate}
              className="mt-5 flex items-center gap-2 rounded-xl bg-orange-500 px-5 py-3 text-sm font-bold text-white hover:bg-orange-600"
            >
              <Plus size={18} />
              افزودن اولین آیتم
            </button>
          </div>
        ) : (
          <div>{rootItems.map((item) => renderItem(item))}</div>
        )}
      </div>

      {/* EDITOR */}
      {editorOpen && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm">
          <div className="flex max-h-[90vh] w-full max-w-2xl flex-col overflow-hidden rounded-3xl bg-white shadow-2xl">
            <div className="flex items-center justify-between border-b border-zinc-200 px-6 py-5">
              <div>
                <h2 className="text-xl font-black text-zinc-900">
                  {editingId ? "ویرایش آیتم منو" : "افزودن آیتم منو"}
                </h2>
                <p className="mt-1 text-xs text-zinc-500">
                  اطلاعات آیتم منوی سایت را تنظیم کنید.
                </p>
              </div>
              <button
                type="button"
                onClick={closeEditor}
                className="flex h-10 w-10 items-center justify-center rounded-xl text-zinc-400 hover:bg-zinc-100 hover:text-zinc-700"
              >
                <X size={20} />
              </button>
            </div>

            <div className="overflow-y-auto p-6">
              <div className="grid gap-5 sm:grid-cols-2">
                <div className="sm:col-span-2">
                  <label className="mb-2 block text-sm font-bold text-zinc-700">عنوان منو</label>
                  <input
                    value={form.title}
                    onChange={(event) => updateForm("title", event.target.value)}
                    placeholder="مثلاً ماشین‌آلات"
                    className="w-full rounded-xl border border-zinc-300 bg-white px-4 py-3 text-sm outline-none transition focus:border-orange-500 focus:ring-2 focus:ring-orange-500/10"
                  />
                </div>

                <div>
                  <label className="mb-2 block text-sm font-bold text-zinc-700">نوع</label>
                  <select
                    value={form.type}
                    onChange={(event) => updateForm("type", event.target.value)}
                    className="w-full rounded-xl border border-zinc-300 bg-white px-4 py-3 text-sm outline-none focus:border-orange-500"
                  >
                    <option value="LINK">لینک</option>
                    <option value="CATEGORY">دسته‌بندی</option>
                    <option value="MEGA">مگامنو</option>
                    <option value="CUSTOM">سفارشی</option>
                  </select>
                </div>

                <div>
                  <label className="mb-2 block text-sm font-bold text-zinc-700">منوی والد</label>
                  <select
                    value={form.parentId}
                    onChange={(event) => updateForm("parentId", event.target.value)}
                    className="w-full rounded-xl border border-zinc-300 bg-white px-4 py-3 text-sm outline-none focus:border-orange-500"
                  >
                    <option value="">منوی اصلی</option>
                    {flatItems
                      .filter((item) => item.id !== editingId)
                      .filter((item) => !item.parentId)
                      .sort((a, b) => a.sortOrder - b.sortOrder)
                      .map((item) => (
                        <option key={item.id} value={item.id}>
                          {item.title}
                        </option>
                      ))}
                  </select>
                </div>

                <div className="sm:col-span-2">
                  <label className="mb-2 block text-sm font-bold text-zinc-700">آدرس لینک</label>
                  <input
                    dir="ltr"
                    value={form.href}
                    onChange={(event) => updateForm("href", event.target.value)}
                    placeholder="/machines"
                    className="w-full rounded-xl border border-zinc-300 bg-white px-4 py-3 text-left text-sm outline-none focus:border-orange-500"
                  />
                </div>

                <div>
                  <label className="mb-2 block text-sm font-bold text-zinc-700">آیکون</label>
                  <input
                    value={form.icon}
                    onChange={(event) => updateForm("icon", event.target.value)}
                    placeholder="Wrench"
                    className="w-full rounded-xl border border-zinc-300 bg-white px-4 py-3 text-sm outline-none focus:border-orange-500"
                  />
                </div>

                <div>
                  <label className="mb-2 block text-sm font-bold text-zinc-700">ترتیب نمایش</label>
                  <input
                    type="number"
                    value={form.sortOrder}
                    onChange={(event) => updateForm("sortOrder", Number(event.target.value))}
                    className="w-full rounded-xl border border-zinc-300 bg-white px-4 py-3 text-sm outline-none focus:border-orange-500"
                  />
                </div>
              </div>

              <div className="mt-6 rounded-2xl bg-zinc-50 p-5">
                <h3 className="mb-4 font-bold text-zinc-800">تنظیمات نمایش</h3>
                <div className="grid gap-3 sm:grid-cols-2">
                  <Toggle label="فعال باشد" checked={form.active} onChange={(v) => updateForm("active", v)} />
                  <Toggle label="نمایش در دسکتاپ" checked={form.showDesktop} onChange={(v) => updateForm("showDesktop", v)} />
                  <Toggle label="نمایش در موبایل" checked={form.showMobile} onChange={(v) => updateForm("showMobile", v)} />
                  <Toggle label="باز شدن در تب جدید" checked={form.openInNewTab} onChange={(v) => updateForm("openInNewTab", v)} />
                  <Toggle label="استفاده به عنوان Mega Menu" checked={form.megaMenu} onChange={(v) => updateForm("megaMenu", v)} />
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 border-t border-zinc-200 bg-zinc-50 px-6 py-4">
              <button
                type="button"
                onClick={closeEditor}
                disabled={saving}
                className="rounded-xl border border-zinc-300 bg-white px-5 py-3 text-sm font-semibold text-zinc-700 hover:bg-zinc-100"
              >
                انصراف
              </button>
              <button
                type="button"
                onClick={saveItem}
                disabled={saving}
                className="flex items-center gap-2 rounded-xl bg-orange-500 px-6 py-3 text-sm font-bold text-white shadow-lg shadow-orange-500/20 hover:bg-orange-600 disabled:opacity-50"
              >
                <Save size={18} />
                {saving ? "در حال ذخیره..." : "ذخیره منو"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Toggle({
  label,
  checked,
  onChange,
}: {
  label: string;
  checked: boolean;
  onChange: (value: boolean) => void;
}) {
  return (
    <button
      type="button"
      onClick={() => onChange(!checked)}
      className="flex items-center justify-between rounded-xl border border-zinc-200 bg-white px-4 py-3 text-right"
    >
      <span className="text-sm font-medium text-zinc-700">{label}</span>
      <span className={`relative h-6 w-11 rounded-full transition ${checked ? "bg-orange-500" : "bg-zinc-300"}`}>
        <span
          className={`absolute top-1 h-4 w-4 rounded-full bg-white shadow transition ${
            checked ? "right-1" : "right-6"
          }`}
        />
      </span>
    </button>
  );
}