import { redirect } from "next/navigation";
import Link from "next/link";

import { LogOut } from "lucide-react";

import { isAuthenticated } from "@/lib/session";
import { logoutAction } from "@/app/login/logout";

import NotificationsBell from "@/components/admin/NotificationsBell";
import AdminSidebarNav from "@/components/admin/AdminSidebarNav";
import Breadcrumbs from "@/components/admin/Breadcrumbs";

/* =========================================================
   ADMIN LAYOUT
========================================================= */

export default async function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const authenticated = await isAuthenticated();

  if (!authenticated) {
    redirect("/login");
  }

  return (
    <div
      dir="rtl"
      className="min-h-screen bg-zinc-100 text-zinc-900"
      style={
        {
          "--admin-sidebar-width": "18rem",
        } as React.CSSProperties
      }
    >
      <div className="min-h-screen">

        {/* =====================================================
            SIDEBAR
        ====================================================== */}

        <aside
          className="
            fixed
            inset-y-0
            right-0
            z-[100]
            flex
            flex-col
            bg-zinc-950
            text-white
            shadow-2xl
          "
          style={{
            width: "var(--admin-sidebar-width)",
          }}
        >

          {/* Logo */}

          <div className="shrink-0 border-b border-zinc-800 px-5 py-5">

            <div className="flex items-center gap-3">

              <div
                className="
                  flex
                  h-11
                  w-11
                  shrink-0
                  items-center
                  justify-center
                  rounded-xl
                  bg-orange-500
                  text-sm
                  font-black
                  text-white
                  shadow-lg
                  shadow-orange-500/20
                "
              >
                AMJ
              </div>

              <div className="min-w-0">

                <h1 className="truncate text-xl font-black">
                  ARIA MJ
                </h1>

                <p className="mt-1 text-xs text-zinc-500">
                  پنل مدیریت
                </p>

              </div>

            </div>

          </div>

          {/* Navigation — منوی گروه‌بندی‌شده */}

          <nav className="min-h-0 flex-1 overflow-y-auto px-3 py-4">
            <AdminSidebarNav />
          </nav>

          {/* Logout */}

          <div className="shrink-0 border-t border-zinc-800 p-3">

            <form action={logoutAction}>

              <button
                type="submit"
                className="
                  flex
                  w-full
                  items-center
                  justify-center
                  gap-2
                  rounded-xl
                  bg-red-600
                  px-4
                  py-3
                  text-sm
                  font-bold
                  text-white
                  transition
                  hover:bg-red-700
                "
              >
                <LogOut size={18} />

                <span>
                  خروج از پنل
                </span>
              </button>

            </form>

          </div>

        </aside>

        {/* =====================================================
            MAIN AREA
        ====================================================== */}

        <div
          className="
            flex
            min-h-screen
            min-w-0
            flex-col
          "
          style={{
            marginRight: "var(--admin-sidebar-width)",
          }}
        >

          {/* ===================================================
              TOP BAR
          ================================================== */}

          <header
            className="
              sticky
              top-0
              z-40
              flex
              min-h-20
              shrink-0
              items-center
              justify-between
              border-b
              border-zinc-200
              bg-white/95
              px-6
              shadow-sm
              backdrop-blur
              lg:px-8
            "
          >

            <div className="min-w-0">

              <h2 className="truncate text-xl font-black text-zinc-900">
                پنل مدیریت ARIA MJ
              </h2>

              <p className="mt-1 truncate text-xs text-zinc-500">
                مدیریت محتوای وب‌سایت آریا ماشین جم
              </p>

            </div>

            <div className="mr-4 flex shrink-0 items-center gap-3">

              <NotificationsBell />

              <Link
                href="/"
                target="_blank"
                rel="noopener noreferrer"
                className="
                  inline-flex
                  items-center
                  justify-center
                  rounded-xl
                  border
                  border-zinc-200
                  bg-white
                  px-4
                  py-2
                  text-sm
                  font-semibold
                  text-zinc-700
                  transition
                  hover:border-orange-500
                  hover:text-orange-500
                "
              >
                مشاهده سایت
              </Link>

            </div>

          </header>

          {/* ===================================================
              PAGE CONTENT
          ================================================== */}

          <main
            className="
              min-w-0
              flex-1
              overflow-x-hidden
              p-4
              sm:p-6
              lg:p-8
            "
          >
            {/* ✅ مسیر یاب */}
            <Breadcrumbs />

            {children}
          </main>

        </div>

      </div>
    </div>
  );
}