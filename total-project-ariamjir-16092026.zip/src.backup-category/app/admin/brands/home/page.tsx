"use client";

import { useEffect, useState } from "react";

import {
  Loader2,
  Search,
  Sparkles,
  Wand2,
  CheckCheck,
  XCircle,
} from "lucide-react";

export default function AdminBrandsHomePage() {
  const [brands, setBrands] = useState<any[]>([]);
  const [selected, setSelected] = useState<string[]>([]);
  const [q, setQ] = useState("");
  const [loading, setLoading] = useState(true);
  const [genBusy, setGenBusy] = useState<"" | "bulk" | string>("");
  const [msg, setMsg] = useState("");

  const load = () => {
    setLoading(true);
    fetch("/api/admin/brands/home")
      .then((r) => r.json())
      .then((j) => {
        if (j.success) {
          setBrands(j.data.brands ?? []);
          setSelected(j.data.selected ?? []);
        }
      })
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    load();
  }, []);

  const save = async (ids: string[]) => {
    await fetch("/api/admin/brands/home", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ids }),
    });
  };

  const toggle = async (id: string) => {
    const next = selected.includes(id)
      ? selected.filter((x) => x !== id)
      : [...selected, id];
    setSelected(next);
    await save(next);
  };

  /* ✅ انتخاب همه / حذف انتخاب‌ها */
  const selectAll = async () => {
    const ids = brands.map((b) => b.id);
    setSelected(ids);
    await save(ids);
  };

  const clearAll = async () => {
    setSelected([]);
    await save([]);
  };

  const genOne = async (id: string) => {
    setGenBusy(id);
    try {
      await fetch("/api/admin/brands/home", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ids: [id] }),
      });
      load();
    } finally {
      setGenBusy("");
    }
  };

  const genBulk = async () => {
    setGenBusy("bulk");
    setMsg("");
    try {
      const res = await fetch("/api/admin/brands/home", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ limit: 6 }),
      });
      const j = await res.json();
      setMsg(
        `✅ ${j.updated ?? 0} لوگو دریافت شد${
          j.total === 0 ? " — برندی بدون لوگو نمانده" : " — برای ادامه دوباره بزن"
        }`
      );
      load();
    } finally {
      setGenBusy("");
    }
  };

  const filtered = brands.filter(
    (b) => !q.trim() || b.name.toLowerCase().includes(q.toLowerCase())
  );

  const withoutLogo = brands.filter((b) => !b.logo).length;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-zinc-800">برندهای صفحه اول</h1>
          <p className="mt-1 text-sm text-zinc-500">
            انتخاب کن کدام برندها در نوار صفحه اول نمایش داده شوند — لوگوها خودکار دریافت می‌شوند.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={selectAll}
            className="inline-flex items-center gap-2 rounded-xl bg-orange-500 px-4 py-2.5 text-sm font-black text-white shadow transition hover:bg-orange-600"
          >
            <CheckCheck className="h-4 w-4" />
            انتخاب همهٔ برندها
          </button>
          <button
            onClick={clearAll}
            className="inline-flex items-center gap-2 rounded-xl border border-zinc-200 bg-white px-4 py-2.5 text-sm font-bold text-zinc-600 transition hover:border-red-300 hover:text-red-600"
          >
            <XCircle className="h-4 w-4" />
            حذف انتخاب‌ها
          </button>
          <button
            onClick={genBulk}
            disabled={!!genBusy}
            className="inline-flex items-center gap-2 rounded-xl bg-violet-600 px-4 py-2.5 text-sm font-black text-white shadow transition hover:bg-violet-700 disabled:opacity-60"
          >
            {genBusy === "bulk" ? <Loader2 className="h-4 w-4 animate-spin" /> : <Wand2 className="h-4 w-4" />}
            دریافت لوگوی واقعی (۶تایی)
          </button>
        </div>
      </div>

      {msg && (
        <div className="rounded-xl border border-green-200 bg-green-50 p-3 text-sm font-bold text-green-700">
          {msg}
        </div>
      )}

      {/* آمار سریع */}
      <div className="grid gap-4 sm:grid-cols-3">
        {[
          { l: "کل برندها", v: brands.length },
          { l: "انتخاب‌شده برای صفحه اول", v: selected.length },
          { l: "بدون لوگو", v: withoutLogo },
        ].map((s) => (
          <div key={s.l} className="rounded-2xl border border-zinc-200 bg-white p-4 shadow-sm">
            <div className="text-[11px] font-bold text-zinc-500">{s.l}</div>
            <div className="mt-1 text-2xl font-black text-zinc-800">{s.v.toLocaleString("fa-IR")}</div>
          </div>
        ))}
      </div>

      {/* جستجو */}
      <div className="relative">
        <Search className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-400" />
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="جستجوی برند..."
          className="w-full rounded-xl border border-zinc-200 bg-white py-2.5 pr-9 pl-3 text-sm outline-none focus:border-orange-400"
        />
      </div>

      {/* لیست */}
      {loading ? (
        <div className="flex h-64 items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-orange-500" />
        </div>
      ) : (
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
          {filtered.map((b) => (
            <div
              key={b.id}
              className={`flex items-center gap-3 rounded-2xl border p-3 shadow-sm transition ${
                selected.includes(b.id) ? "border-orange-300 bg-orange-50" : "border-zinc-200 bg-white"
              }`}
            >
                            <div className="flex h-14 w-14 shrink-0 items-center justify-center overflow-hidden rounded-xl border border-zinc-100 bg-white">
                {b.logo ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={b.logo} alt={b.name} className="h-full w-full object-contain" />
                ) : (
                  <span className="text-lg font-black text-zinc-300">{b.name?.[0]}</span>
                )}
              </div>

              <div className="min-w-0 flex-1">
                <div className="truncate text-sm font-black text-zinc-800">{b.name}</div>
                <div className="mt-0.5 text-[10px] text-zinc-500">
                  {b.machines.toLocaleString("fa-IR")} دستگاه ثبت‌شده
                </div>
              </div>

              <button
                title="دریافت/بازدریافت لوگوی واقعی با AI"
                onClick={() => genOne(b.id)}
                disabled={!!genBusy}
                className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-violet-200 bg-violet-50 text-violet-600 transition hover:bg-violet-100 disabled:opacity-50"
              >
                {genBusy === b.id ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
              </button>

              <label className="flex shrink-0 cursor-pointer items-center gap-1.5 text-[10px] font-bold text-zinc-600">
                <input
                  type="checkbox"
                  checked={selected.includes(b.id)}
                  onChange={() => toggle(b.id)}
                  className="h-4 w-4 accent-orange-500"
                />
                نمایش
              </label>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}