"use client";

import { use } from "react";
import BrandForm from "@/components/admin/BrandForm";

type Props = {
  params: Promise<{
    id: string;
  }>;
};

export default function EditBrandPage({
  params,
}: Props) {

  const { id } = use(params);

  return (
    <main className="space-y-6">

      <div>
        <h1 className="text-3xl font-bold">
          ویرایش برند
        </h1>

        <p className="mt-2 text-sm text-gray-500">
          اطلاعات برند را ویرایش کنید.
        </p>
      </div>

      <BrandForm brandId={id} />

    </main>
  );
}