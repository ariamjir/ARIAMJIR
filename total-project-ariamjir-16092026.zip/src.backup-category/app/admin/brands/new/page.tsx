"use client";

import BrandForm from "@/components/admin/BrandForm";

export default function NewBrandPage() {
  return (
    <main className="space-y-6">

      <div>
        <h1 className="text-3xl font-bold">
          افزودن برند جدید
        </h1>

        <p className="mt-2 text-sm text-gray-500">
          اطلاعات برند را تکمیل و ذخیره کنید.
        </p>
      </div>

      <BrandForm />

    </main>
  );
}

