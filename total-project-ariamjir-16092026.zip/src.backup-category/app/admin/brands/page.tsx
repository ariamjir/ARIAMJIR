"use client";

import { useMemo, useRef, useState } from "react";
import {
  Plus, Pencil, Trash2, Search, Building2, Star, EyeOff,
  X, Loader2, Image as ImageIcon, Link2, Globe2,
} from "lucide-react";
import { useBrands, type Brand } from "@/modules/brand";
import { countries } from "@/data/countries";

async function uploadImage(file: File, folder: string): Promise<string> {
  const fd = new FormData();
  fd.append("file", file);
  fd.append("folder", folder);
  const res = await fetch("/api/upload/image", { method: "POST", body: fd });
  if (!res.ok) throw new Error("آپلود ناموفق بود.");
  const json = await res.json();
  return json.url || json.path || json.src || "";
}

/* کد کشور را از برند استخراج می‌کند (relation/scalar را هر دو پوشش می‌دهد) */
function getCountryCode(b: Brand): string {
  const x = b as any;
  if (typeof x.countryId === "string" && x.countryId) return x.countryId;
  if (x.country && typeof x.country === "object" && x.country.id) return x.country.id;
  if (typeof x.country === "string") return x.country;
  return "";
}

/* کد کشور → نام نمایشی */
function countryLabel(code: string): string {
  return countries.find((c) => c.value === code)?.label ?? code;
}

export default function AdminBrandsPage() {
  const { brands, loading, saving, create, update, remove } = useBrands();
  const [query, setQuery] = useState("");
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<Brand | null>(null);
  const [uploading, setUploading] = useState(false);

  const [name, setName] = useState("");
  const [slug, setSlug] = useState("");
  const [logo, setLogo] = useState("");
  const [icon, setIcon] = useState("");
  const [description, setDescription] = useState("");
  const [link, setLink] = useState("");
  const [country, setCountry] = useState("");
  const [featured, setFeatured] = useState(false);
  const [active, setActive] = useState(true);

  const fileRef = useRef<HTMLInputElement>(null);

  const filtered = useMemo(() => {
    const list = [...brands].sort((a, b) => (a.sortOrder ?? 0) - (b.sortOrder ?? 0));
    if (!query.trim()) return list;
    const q = query.toLowerCase();
    return list.filter((b) => b.name.toLowerCase().includes(q) || b.slug?.toLowerCase().includes(q));
  }, [brands, query]);

  const openCreate = () => {
    setEditing(null);
    setName(""); setSlug(""); setLogo(""); setIcon(""); setDescription("");
    setLink(""); setCountry(""); setFeatured(false); setActive(true);
    setFormOpen(true);
  };

  const openEdit = (b: Brand) => {
    setEditing(b);
    setName(b.name); setSlug(b.slug ?? ""); setLogo(b.logo ?? ""); setIcon(b.icon ?? "");
    setDescription(b.description ?? ""); setLink(b.link ?? "");
    setCountry(getCountryCode(b));
    setFeatured(!!b.featured); setActive(!!b.active);
    setFormOpen(true);
  };

  const handleFile = async (f: File) => {
    try { setUploading(true); setLogo(await uploadImage(f, "brands")); }
    catch (e) { alert(e instanceof Error ? e.message : "خطا"); }
    finally { setUploading(false); }
  };

  const save = async () => {
    if (!name.trim()) return alert("نام برند الزامی است.");
    const payload: any = {
      name: name.trim(),
      slug: slugify(slug.trim() || name),
      featured, active,
    };
    if (logo) payload.logo = logo;
    if (icon) payload.icon = icon;
    if (description) payload.description = description;
    if (link) payload.link = link;
    if (country) payload.country = country;

    try {
      if (editing) await update(editing.id, payload);
      else {
        payload.sortOrder = brands.length;
        await create(payload);
      }
      setFormOpen(false);
    } catch (e) { alert(e instanceof Error ? e.message : "خطا"); }
  };

  const del = async (b: Brand) => {
    if (!confirm(`برند «${b.name}» حذف شود؟`)) return;
    await remove(b.id);
  };

  return (
    <div className="mx-auto max-w-6xl space-y-6 p-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div className="flex items-center gap-3">
          <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-orange-500 text-white shadow-lg shadow-orange-500/25">
            <Building2 className="h-6 w-6" />
          </span>
          <div>
            <h1 className="text-2xl font-black">مدیریت برندها</h1>
            <p className="mt-1 text-sm text-gray-500">لوگو، آیکون و لینک بدهید؛ تغییرات برخط در سایت اعمال می‌شود.</p>
          </div>
        </div>
        <button onClick={openCreate} className="inline-flex items-center gap-2 rounded-xl bg-orange-500 px-5 py-3 font-bold text-white transition hover:bg-orange-600">
          <Plus className="h-5 w-5" /> برند جدید
        </button>
      </div>

      <div className="relative">
        <Search className="absolute right-4 top-1/2 h-5 w-5 -translate-y-1/2 text-gray-400" />
        <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="جستجوی برند..."
          className="w-full rounded-xl border border-gray-200 bg-white py-3 pr-12 pl-4 outline-none focus:border-orange-400" />
      </div>

      <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
        {loading ? (
          Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="h-40 animate-pulse rounded-2xl border bg-white" />
          ))
        ) : filtered.length === 0 ? (
          <p className="col-span-full p-10 text-center text-gray-400">برندی یافت نشد.</p>
        ) : (
          filtered.map((b) => {
            const code = getCountryCode(b);
            return (
              <div key={b.id} className="group relative flex flex-col items-center rounded-2xl border bg-white p-5 text-center transition hover:border-orange-300 hover:shadow-md">
                {b.featured && <Star className="absolute right-3 top-3 h-4 w-4 fill-orange-400 text-orange-400" />}
                {!b.active && <EyeOff className="absolute left-3 top-3 h-4 w-4 text-gray-400" />}
                {b.logo ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={b.logo} alt={b.name} className="h-16 w-16 rounded-xl object-contain" />
                ) : (
                  <span className="flex h-16 w-16 items-center justify-center rounded-xl bg-gray-100 text-2xl">{b.icon || "🏭"}</span>
                )}
                <div className="mt-3 font-bold">{b.name}</div>
                <div className="mt-0.5 text-xs text-gray-400" dir="ltr">/{b.slug}</div>
                {code && (
                  <div className="mt-1 flex items-center gap-1 text-xs text-gray-500">
                    <Globe2 className="h-3 w-3" />
                    {countryLabel(code)}
                  </div>
                )}
                <div className="mt-4 flex items-center gap-1 opacity-60 transition group-hover:opacity-100">
                  <button onClick={() => openEdit(b)} className="rounded-lg p-1.5 text-blue-600 hover:bg-blue-50"><Pencil className="h-4 w-4" /></button>
                  <button onClick={() => del(b)} className="rounded-lg p-1.5 text-red-500 hover:bg-red-50"><Trash2 className="h-4 w-4" /></button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {formOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm">
          <div className="max-h-[92vh] w-full max-w-xl overflow-y-auto rounded-2xl bg-white shadow-2xl">
            <div className="sticky top-0 z-10 flex items-center justify-between border-b bg-white px-6 py-4">
              <h2 className="text-lg font-black">{editing ? "ویرایش برند" : "برند جدید"}</h2>
              <button onClick={() => setFormOpen(false)} className="rounded-lg p-1.5 text-gray-400 hover:bg-gray-100"><X className="h-5 w-5" /></button>
            </div>

            <div className="space-y-5 p-6">
              <div className="grid grid-cols-[140px_1fr] gap-4">
                <div>
                  <label className="mb-1.5 block text-sm font-bold">لوگو</label>
                  <button type="button" onClick={() => fileRef.current?.click()}
                    className="relative flex h-28 w-full items-center justify-center overflow-hidden rounded-xl border-2 border-dashed border-gray-300 bg-gray-50 hover:border-orange-400">
                    {uploading ? <Loader2 className="h-6 w-6 animate-spin text-orange-500" /> :
                      logo ? (
                        <>
                          {/* eslint-disable-next-line @next/next/no-img-element */}
                          <img src={logo} alt="" className="absolute inset-0 h-full w-full object-contain p-2" />
                          <span className="absolute inset-0 flex items-center justify-center bg-black/40 text-xs font-bold text-white opacity-0 hover:opacity-100">تغییر</span>
                        </>
                      ) : (
                        <><ImageIcon className="h-6 w-6 text-gray-400" /><span className="mt-1 text-xs text-gray-500">آپلود لوگو</span></>
                      )}
                  </button>
                  <input ref={fileRef} type="file" accept="image/*" hidden onChange={(e) => { const f = e.target.files?.[0]; if (f) handleFile(f); e.target.value = ""; }} />
                  {logo && <button onClick={() => setLogo("")} className="mt-1 text-xs text-red-500 hover:underline">حذف لوگو</button>}
                </div>
                <div>
                  <label className="mb-1.5 block text-sm font-bold">آیکون (ایموجی)</label>
                  <input value={icon} onChange={(e) => setIcon(e.target.value)} placeholder="🏭"
                    className="w-full rounded-xl border border-gray-200 bg-gray-50 p-3 outline-none focus:border-orange-400" />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div><label className="mb-1.5 block text-sm font-bold">نام *</label>
                  <input value={name} onChange={(e) => setName(e.target.value)} className="w-full rounded-xl border p-3" /></div>
                <div><label className="mb-1.5 block text-sm font-bold">Slug</label>
                  <input value={slug} onChange={(e) => setSlug(e.target.value)} dir="ltr" className="w-full rounded-xl border p-3 text-left" /></div>
              </div>

              <div><label className="mb-1.5 block text-sm font-bold">توضیحات</label>
                <input value={description} onChange={(e) => setDescription(e.target.value)} className="w-full rounded-xl border p-3" /></div>

              <div className="grid grid-cols-2 gap-4">
                {/* ✅ کشور حالا select است و کد کشور را می‌فرستد (برای relation) */}
                <div>
                  <label className="mb-1.5 block text-sm font-bold">کشور</label>
                  <select value={country} onChange={(e) => setCountry(e.target.value)}
                    className="w-full rounded-xl border border-gray-200 bg-gray-50 p-3 outline-none focus:border-orange-400">
                    <option value="">— بدون کشور —</option>
                    {countries.map((c) => (
                      <option key={c.value} value={c.value}>{c.label}</option>
                    ))}
                  </select>
                </div>
                <div><label className="mb-1.5 flex items-center gap-1 text-sm font-bold"><Link2 className="h-4 w-4" />لینک سفارشی</label>
                  <input value={link} onChange={(e) => setLink(e.target.value)} dir="ltr" className="w-full rounded-xl border p-3 text-left" /></div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <Toggle label="فعال" value={active} onChange={setActive} />
                <Toggle label="ویژه ⭐" value={featured} onChange={setFeatured} />
              </div>
            </div>

            <div className="flex gap-3 border-t bg-gray-50 px-6 py-4">
              <button onClick={save} disabled={saving || uploading} className="flex-1 rounded-xl bg-orange-500 py-3 font-bold text-white hover:bg-orange-600 disabled:opacity-60">
                {saving ? "در حال ذخیره..." : editing ? "ذخیره تغییرات" : "ایجاد برند"}
              </button>
              <button onClick={() => setFormOpen(false)} className="rounded-xl border bg-white px-6 py-3 text-gray-600">انصراف</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Toggle({ label, value, onChange }: { label: string; value: boolean; onChange: (v: boolean) => void }) {
  return (
    <button type="button" onClick={() => onChange(!value)}
      className={`flex w-full items-center justify-between rounded-xl border p-3 text-right transition ${value ? "border-orange-300 bg-orange-50" : "border-gray-200 bg-white"}`}>
      <span className="text-sm font-bold">{label}</span>
      <span className={`relative inline-block h-6 w-11 rounded-full transition-colors ${value ? "bg-orange-500" : "bg-gray-300"}`}>
        <span className={`absolute top-1 h-4 w-4 rounded-full bg-white shadow transition-all ${value ? "right-6" : "right-1"}`} />
      </span>
    </button>
  );
}

function slugify(t: string) {
  return t.toLowerCase().trim().replace(/[^\w\s-]/g, "").replace(/\s+/g, "-").replace(/-+/g, "-").replace(/^-+|-+$/g, "");
}