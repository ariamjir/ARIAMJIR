"use client";

import { useEffect, useState } from "react";

import {
  Wrench,
  FolderTree,
  Building2,
  Newspaper,
  BookOpen,
  Users,
  Briefcase,
  Megaphone,
  Loader2,
} from "lucide-react";

export default function DashboardPage() {
  const [d, setD] = useState<any>(null);

  /* ✅ اعداد زنده از دیتابیس */
  useEffect(() => {
    fetch("/api/admin/stats")
      .then((r) => r.json())
      .then((j) => {
        if (j.success) setD(j.data);
      })
      .catch(() => setD({}));
  }, []);

  const stats = [
    {
      title: "ماشین‌آلات",
      value: d?.machines,
      icon: Wrench,
      color: "text-orange-500",
    },
    {
      title: "دسته‌بندی‌ها",
      value: d?.categories,
      icon: FolderTree,
      color: "text-blue-500",
    },
    {
      title: "برندها",
      value: d?.brands,
      icon: Building2,
      color: "text-violet-500",
    },
    {
      title: "خدمات",
      value: d?.services,
      icon: Briefcase,
      color: "text-emerald-500",
    },
    {
      title: "اخبار",
      value: d?.news,
      icon: Newspaper,
      color: "text-red-500",
    },
    {
      title: "مرکز دانش",
      value: d?.knowledge,
      icon: BookOpen,
      color: "text-cyan-500",
    },
    {
      title: "کاربران",
      value: d?.users,
      icon: Users,
      color: "text-pink-500",
    },
    {
      title: "آگهی‌های منتشر",
      value: d?.adsPublished,
      icon: Megaphone,
      color: "text-amber-500",
    },
  ];

  return (
    <div className="space-y-10">

      <div>

        <h1 className="text-4xl font-black text-zinc-900">
          داشبورد مدیریت
        </h1>

        <p className="mt-3 text-zinc-500">
          مدیریت کامل پلتفرم ARIA MJ
        </p>

      </div>

      <div
        className="
          grid
          gap-6
          sm:grid-cols-2
          lg:grid-cols-3
          xl:grid-cols-4
        "
      >
        {stats.map((item) => {
          const Icon = item.icon;

          return (
            <div
              key={item.title}
              className="
                rounded-2xl
                border
                bg-white
                p-6
                shadow-sm
                transition
                hover:-translate-y-1
                hover:shadow-xl
              "
            >
              <div className="flex items-center justify-between">

                <div>

                  <p className="text-sm text-zinc-500">
                    {item.title}
                  </p>

                  {d ? (
                    <h2 className="mt-4 text-4xl font-black">
                      {Number(item.value ?? 0).toLocaleString("fa-IR")}
                    </h2>
                  ) : (
                    <Loader2
                      className="mt-4 h-8 w-8 animate-spin text-zinc-300"
                    />
                  )}

                </div>

                <div
                  className="
                    flex
                    h-16
                    w-16
                    items-center
                    justify-center
                    rounded-2xl
                    bg-zinc-100
                  "
                >
                  <Icon
                    className={item.color}
                    size={30}
                  />
                </div>

              </div>

            </div>
          );
        })}
      </div>

    </div>
  );
}