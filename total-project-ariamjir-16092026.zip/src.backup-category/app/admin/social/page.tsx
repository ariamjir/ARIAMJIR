"use client";

import { useCallback, useEffect, useState } from "react";
import {
  Send, Share2, Loader2, CheckCircle2, ExternalLink, MessageCircle,
  Megaphone, History, BarChart3, Settings, Globe, RefreshCw
} from "lucide-react";

export default function AdminSocialPage() {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<"queue" | "history" | "settings">("queue");

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/admin/social/queue");
      const j = await res.json();
      if (j.success) setData(j.data);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const publishTelegram = async (id: string) => {
    setBusyId(id);
    try {
      const res = await fetch("/api/admin/social/publish", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ machineId: id, network: "telegram" }),
      });
      const j = await res.json();
      if (!j.success) alert(j.message);
      await load();
    } finally { setBusyId(null); }
  };

  const markPublished = async (id: string, network: string) => {
    setBusyId(id + network);
    try {
      await fetch("/api/admin/social/publish", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ machineId: id, network, markOnly: true }),
      });
      await load();
    } finally { setBusyId(null); }
  };

  return (
    <div className="space-y-6">
      {/* هدر و آمار */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-zinc-800">مدیریت شبکه‌های اجتماعی</h1>
          <p className="mt-1 text-sm text-zinc-500">انتشار خودکار، اشتراک‌گذاری و رصد بازخورد آگهی‌ها</p>
        </div>
        <button onClick={load} className="inline-flex items-center gap-2 rounded-xl border border-zinc-200 bg-white px-4 py-2.5 text-sm font-bold text-zinc-600 transition hover:bg-zinc-50">
          <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
          بروزرسانی
        </button>
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard icon={<Megaphone className="h-5 w-5 text-blue-500" />} label="در صف انتشار" value={data?.queue?.length ?? 0} />
        <StatCard icon={<CheckCircle2 className="h-5 w-5 text-green-500" />} label="منتشرشده (کل)" value={data?.history?.length ?? 0} />
        <StatCard icon={<Globe className="h-5 w-5 text-purple-500" />} label="شبکه‌های فعال" value="۵ شبکه" />
      </div>

      {/* تب‌ها */}
      <div className="flex gap-2 border-b border-zinc-200">
        <TabButton active={activeTab === "queue"} onClick={() => setActiveTab("queue")} icon={<Megaphone className="h-4 w-4" />} label="صف انتشار" />
        <TabButton active={activeTab === "history"} onClick={() => setActiveTab("history")} icon={<History className="h-4 w-4" />} label="تاریخچه" />
        <TabButton active={activeTab === "settings"} onClick={() => setActiveTab("settings")} icon={<Settings className="h-4 w-4" />} label="تنظیمات خودکار" />
      </div>

      {loading ? (
        <div className="flex h-64 items-center justify-center"><Loader2 className="h-8 w-8 animate-spin text-orange-500" /></div>
      ) : (
        <>
          {activeTab === "queue" && (
            <div className="overflow-hidden rounded-2xl border border-zinc-200 bg-white shadow-sm">
              {data?.queue?.length === 0 ? (
                <div className="p-10 text-center text-sm text-zinc-500">
                  <CheckCircle2 className="mx-auto mb-2 h-8 w-8 text-green-500" />
                  همهٔ آگهی‌های تأییدشده منتشر شده‌اند.
                </div>
              ) : (
                <div className="divide-y divide-zinc-100">
                  {data?.queue?.map((m: any) => {
                    const url = `${typeof window !== "undefined" ? window.location.origin : ""}/machines/${m.slug}`;
                    const text = `🚜 ${m.title}\n💰 ${m.price?.price ? `${Number(m.price.price).toLocaleString("fa-IR")} تومان` : "تماس"}\n🔗 ${url}`;
                    const e = encodeURIComponent;
                    return (
                      <div key={m.id} className="flex flex-wrap items-center gap-4 p-4">
                        <div className="h-16 w-16 shrink-0 overflow-hidden rounded-xl bg-zinc-100">
                          {/* eslint-disable-next-line @next/next/no-img-element */}
                          <img src={m.images?.[0]?.url ?? "/images/machines/default.svg"} alt="" className="h-full w-full object-cover" />
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="truncate text-sm font-bold text-zinc-800">{m.title}</div>
                          <div className="mt-0.5 text-xs text-zinc-400">{m.brand?.name ?? "—"} · {m.price?.price ? `${Number(m.price.price).toLocaleString("fa-IR")} تومان` : "تماس"}</div>
                        </div>
                        
                        <div className="flex flex-wrap items-center gap-2">
                          <button onClick={() => publishTelegram(m.id)} disabled={busyId === m.id} className="inline-flex items-center gap-2 rounded-xl bg-sky-500 px-4 py-2 text-xs font-black text-white transition hover:bg-sky-600 disabled:opacity-50">
                            {busyId === m.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Send className="h-3.5 w-3.5" />}
                            تلگرام
                          </button>
                          <ShareDropdown id={m.id} text={text} url={url} busyId={busyId} onMark={markPublished} />
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {activeTab === "history" && (
            <div className="overflow-hidden rounded-2xl border border-zinc-200 bg-white shadow-sm">
              <div className="border-b border-zinc-200 bg-zinc-50 px-5 py-4">
                <h2 className="flex items-center gap-2 font-bold text-zinc-900"><History className="h-4 w-4 text-orange-500" /> تاریخچهٔ انتشار</h2>
              </div>
              {data?.history?.length === 0 ? (
                <div className="p-8 text-center text-sm text-zinc-400">هنوز انتشاری ثبت نشده.</div>
              ) : (
                <div className="divide-y divide-zinc-100">
                  {data?.history?.map((p: any) => (
                    <div key={p.id} className="flex items-center gap-3 px-5 py-3 text-xs">
                      <span className="rounded-full bg-zinc-100 px-2 py-0.5 font-bold text-zinc-500">{p.network}</span>
                      <span className="flex-1 truncate text-zinc-600">{p.caption.split("\n")[0]}</span>
                      <span className="text-zinc-400">{p.publishedAt ? new Date(p.publishedAt).toLocaleDateString("fa-IR") : ""}</span>
                      <span className="rounded-full bg-green-50 px-2 py-0.5 font-bold text-green-600">موفق</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeTab === "settings" && (
            <div className="rounded-2xl border border-zinc-200 bg-white p-6 shadow-sm">
              <h2 className="mb-4 flex items-center gap-2 font-bold text-zinc-900"><Settings className="h-4 w-4 text-orange-500" /> تنظیمات انتشار خودکار</h2>
              <div className="space-y-4 text-sm text-zinc-600">
                <p>✅ <strong>تلگرام:</strong> به‌صورت خودکار هر ساعت بررسی و منتشر می‌شود (نیاز به تنظیم TELEGRAM_BOT_TOKEN در .env).</p>
                <p>💡 <strong>اینستاگرام / یوتیوب / آپارات:</strong> برای انتشار خودکار در این شبکه‌ها، پیشنهاد می‌شود از سرویس‌های واسط مانند <strong>Zapier</strong> یا <strong>Make.com</strong> استفاده کنید. کافیست Trigger را روی "New Message in Telegram Channel" تنظیم کنید تا به‌محض انتشار در تلگرام، به‌صورت خودکار در سایر شبکه‌ها نیز کپی شود.</p>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}

function StatCard({ icon, label, value }: { icon: React.ReactNode; label: string; value: string | number }) {
  return (
    <div className="flex items-center gap-4 rounded-2xl border border-zinc-200 bg-white p-5 shadow-sm">
      <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-zinc-50">{icon}</div>
      <div>
        <div className="text-xs font-medium text-zinc-500">{label}</div>
        <div className="text-2xl font-black text-zinc-900">{value}</div>
      </div>
    </div>
  );
}

function TabButton({ active, onClick, icon, label }: { active: boolean; onClick: () => void; icon: React.ReactNode; label: string }) {
  return (
    <button onClick={onClick} className={`flex items-center gap-2 border-b-2 px-4 py-3 text-sm font-bold transition ${active ? "border-orange-500 text-orange-600" : "border-transparent text-zinc-500 hover:text-zinc-700"}`}>
      {icon} {label}
    </button>
  );
}

function ShareDropdown({ id, text, url, busyId, onMark }: { id: string; text: string; url: string; busyId: string | null; onMark: (id: string, net: string) => void }) {
  const e = encodeURIComponent;
  const links = {
    eitaa: `https://eitaa.com/share/url?url=${e(url)}&text=${e(text)}`,
    bale: `https://ble.ir/share?url=${e(url)}&text=${e(text)}`,
    rubika: `https://rubika.ir/share?url=${e(url)}`,
    whatsapp: `https://wa.me/?text=${e(text)}`,
  };

  return (
    <div className="relative group">
      <button className="flex h-9 w-9 items-center justify-center rounded-xl border border-zinc-200 text-zinc-500 transition hover:border-orange-500 hover:text-orange-500">
        <Share2 className="h-4 w-4" />
      </button>
      <div className="absolute right-0 top-full z-10 mt-2 hidden w-48 flex-col rounded-xl border border-zinc-200 bg-white py-1 shadow-xl group-hover:flex">
        <a href={links.eitaa} target="_blank" rel="noopener" className="flex items-center gap-2 px-4 py-2 text-xs text-zinc-700 hover:bg-zinc-50"><MessageCircle className="h-3.5 w-3.5" /> ایتا</a>
        <a href={links.bale} target="_blank" rel="noopener" className="flex items-center gap-2 px-4 py-2 text-xs text-zinc-700 hover:bg-zinc-50"><Send className="h-3.5 w-3.5" /> بله</a>
        <a href={links.rubika} target="_blank" rel="noopener" className="flex items-center gap-2 px-4 py-2 text-xs text-zinc-700 hover:bg-zinc-50"><Globe className="h-3.5 w-3.5" /> روبیکا</a>
        <a href={links.whatsapp} target="_blank" rel="noopener" className="flex items-center gap-2 px-4 py-2 text-xs text-zinc-700 hover:bg-zinc-50"><MessageCircle className="h-3.5 w-3.5" /> واتساپ</a>
        <div className="my-1 border-t border-zinc-100" />
        <button onClick={() => onMark(id, "manual")} disabled={busyId === id + "manual"} className="flex items-center gap-2 px-4 py-2 text-xs text-green-600 hover:bg-green-50 disabled:opacity-50">
          <CheckCircle2 className="h-3.5 w-3.5" /> ثبت دستی انتشار
        </button>
      </div>
    </div>
  );
}