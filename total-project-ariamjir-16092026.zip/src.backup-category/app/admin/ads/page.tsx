"use client";

import { useEffect, useMemo, useState } from "react";

import Link from "next/link";

import {
  Plus,
  Pencil,
  Trash2,
  Star,
  Eye,
  EyeOff,
  Loader2,
  Database,
  RefreshCw,
  Search,
  Copy,
  ExternalLink,
  ChevronLeft,
  ChevronRight,
  BarChart3,
  FileDown,
  Clock,
  XCircle,
  CheckCircle2,
  Ban,
} from "lucide-react";

import RejectDialog from "@/components/admin/RejectDialog";

const PAGE_SIZE = 8;

export default function AdminAdsPage() {
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const [q, setQ] = useState("");
  const [status, setStatus] = useState("all");
  const [sort, setSort] = useState("newest");
  const [page, setPage] = useState(0);
  const [selected, setSelected] = useState<string[]>([]);

  const [rejectTarget, setRejectTarget] = useState<any>(null);

  const load = () => {
    setLoading(true);
    fetch("/api/admin/ads")
      .then((r) => r.json())
      .then((j) => {
        if (j.success) setItems(j.data ?? []);
      })
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    load();
  }, []);

  /* آمار */
  const stats = useMemo(
    () => ({
      total: items.length,
      published: items.filter((x) => x.status === "PUBLISHED").length,
      draft: items.filter((x) => x.status === "DRAFT").length,
      rejected: items.filter((x) => x.status === "REJECTED").length,
      featured: items.filter((x) => x.featured).length,
      views: items.reduce((s, x) => s + (x.views ?? 0), 0),
      expiringSoon: items.filter((x) => {
        if (!x.expiresAt || x.status !== "PUBLISHED") return false;
        const days = Math.ceil(
          (new Date(x.expiresAt).getTime() - Date.now()) / 86400000
        );
        return days >= 0 && days <= 7;
      }).length,
    }),
    [items]
  );

  /* جستجو + فیلتر + مرتب‌سازی */
  const filtered = useMemo(() => {
    let list = [...items];

    if (q.trim()) {
      const t = q.trim().toLowerCase();
      list = list.filter(
        (x) =>
          x.title.toLowerCase().includes(t) ||
          (x.brand ?? "").toLowerCase().includes(t)
      );
    }

    if (status === "expiring") {
      list = list.filter((x) => {
        if (!x.expiresAt || x.status !== "PUBLISHED") return false;
        const days = Math.ceil(
          (new Date(x.expiresAt).getTime() - Date.now()) / 86400000
        );
        return days >= 0 && days <= 7;
      });
    } else if (status === "expired") {
      /* ✅ بایگانی هوشمند: آگهی‌های منقضی */
      list = list.filter(
        (x) =>
          x.expiresAt && new Date(x.expiresAt).getTime() < Date.now()
      );
    } else if (status !== "all") {
      list = list.filter((x) => x.status === status);
    }

    switch (sort) {
      case "priceDesc":
        list.sort((a, b) => b.priceValue - a.priceValue);
        break;
      case "priceAsc":
        list.sort((a, b) => a.priceValue - b.priceValue);
        break;
      case "views":
        list.sort((a, b) => (b.views ?? 0) - (a.views ?? 0));
        break;
      case "expiry":
        list.sort(
          (a, b) =>
            new Date(a.expiresAt ?? "9999").getTime() -
            new Date(b.expiresAt ?? "9999").getTime()
        );
        break;
      default:
        list.sort(
          (a, b) =>
            new Date(b.createdAt).getTime() -
            new Date(a.createdAt).getTime()
        );
    }

    return list;
  }, [items, q, status, sort]);

  const pages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const pageItems = filtered.slice(
    page * PAGE_SIZE,
    (page + 1) * PAGE_SIZE
  );

  useEffect(() => {
    setPage(0);
  }, [q, status, sort]);

  /* اکشن‌ها */
  const patch = async (id: string, p: any) => {
    await fetch("/api/admin/ads", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id, patch: p }),
    });
    load();
  };

  const bulk = async (p: any) => {
    for (const id of selected) {
      await fetch("/api/admin/ads", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, patch: p }),
      });
    }
    setSelected([]);
    load();
  };

  const bulkDelete = async () => {
    if (!confirm(`${selected.length} آگهی حذف شود؟`)) return;
    for (const id of selected) {
      await fetch("/api/admin/ads", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id }),
      });
    }
    setSelected([]);
    load();
  };

  const remove = async (id: string) => {
    if (!confirm("این آگهی حذف شود؟")) return;
    await fetch("/api/admin/ads", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id }),
    });
    load();
  };

  const duplicate = async (id: string) => {
    await fetch("/api/admin/ads", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id }),
    });
    load();
  };

  const seed = async () => {
    await fetch("/api/admin/ads/seed", { method: "POST" });
    load();
  };

  const exportCsv = () => {
    window.open("/api/admin/ads/export", "_blank");
  };

  const toggleSelect = (id: string) =>
    setSelected((s) =>
      s.includes(id) ? s.filter((x) => x !== id) : [...s, id]
    );

  const statusLabel = (s: string) =>
    s === "PUBLISHED"
      ? { t: "منتشر شده", c: "bg-green-100 text-green-700" }
      : s === "PENDING"
        ? { t: "در انتظار بررسی", c: "bg-yellow-100 text-yellow-700" }
        : s === "REJECTED"
          ? { t: "رد شده", c: "bg-red-100 text-red-700" }
          : { t: "پیش‌نویس", c: "bg-zinc-100 text-zinc-600" };

  const daysLeft = (d?: string | null) => {
    if (!d) return null;
    return Math.ceil((new Date(d).getTime() - Date.now()) / 86400000);
  };

  return (
    <div className="space-y-6">
      {/* هدر */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-zinc-800">مدیریت آگهی‌ها</h1>
          <p className="mt-1 text-sm text-zinc-500">
            منتشرشده‌ها ۳۰ روز فعال‌اند؛ پس از انقضا خودکار غیرفعال می‌شوند.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* ✅ گزارش ماهانه */}
          <Link
            href="/admin/ads/report"
            className="inline-flex items-center gap-2 rounded-xl border border-zinc-200 bg-white px-4 py-2.5 text-sm font-bold text-zinc-600 transition hover:border-orange-300 hover:text-orange-600"
          >
            <BarChart3 className="h-4 w-4" />
            گزارش ماهانه
          </Link>

          <button
            onClick={exportCsv}
            className="inline-flex items-center gap-2 rounded-xl border border-blue-300 bg-blue-50 px-4 py-2.5 text-sm font-bold text-blue-700 transition hover:bg-blue-100"
          >
            <FileDown className="h-4 w-4" />
            خروجی Excel
          </button>
          <button
            onClick={seed}
            className="inline-flex items-center gap-2 rounded-xl border border-orange-300 bg-orange-50 px-4 py-2.5 text-sm font-bold text-orange-600 transition hover:bg-orange-100"
          >
            <Database className="h-4 w-4" />
            بارگذاری نمونه
          </button>
          <button
            onClick={load}
            className="inline-flex items-center gap-2 rounded-xl border border-zinc-200 bg-white px-4 py-2.5 text-sm font-bold text-zinc-600 transition hover:border-orange-300"
          >
            <RefreshCw className="h-4 w-4" />
            تازه‌سازی
          </button>
          <Link
            href="/admin/machines/new"
            className="inline-flex items-center gap-2 rounded-xl bg-orange-500 px-5 py-2.5 text-sm font-black text-white shadow transition hover:bg-orange-600"
          >
            <Plus className="h-4 w-4" />
            آگهی جدید
          </Link>
        </div>
      </div>

      {/* آمار */}
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-7">
        {[
          { l: "کل", v: stats.total, c: "text-zinc-800" },
          { l: "منتشر", v: stats.published, c: "text-green-600" },
          { l: "پیش‌نویس", v: stats.draft, c: "text-zinc-500" },
          { l: "رد شده", v: stats.rejected, c: "text-red-600" },
          { l: "ویژه", v: stats.featured, c: "text-orange-600" },
          { l: "در حال انقضا", v: stats.expiringSoon, c: "text-amber-600" },
          { l: "بازدید کل", v: stats.views.toLocaleString("fa-IR"), c: "text-blue-600" },
        ].map((s) => (
          <div
            key={s.l}
            className="rounded-2xl border border-zinc-200 bg-white p-4 shadow-sm"
          >
            <div className="text-[11px] font-bold text-zinc-500">{s.l}</div>
            <div className={`mt-1 text-2xl font-black ${s.c}`}>{s.v}</div>
          </div>
        ))}
      </div>

      {/* نوار ابزار */}
      <div className="flex flex-wrap items-center gap-3 rounded-2xl border border-zinc-200 bg-white p-3 shadow-sm">
        <div className="relative min-w-[220px] flex-1">
          <Search className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-400" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="جستجو در عنوان یا برند..."
            className="w-full rounded-xl border border-zinc-200 bg-zinc-50 py-2.5 pr-9 pl-3 text-sm outline-none focus:border-orange-400"
          />
        </div>

        <select
          value={status}
          onChange={(e) => setStatus(e.target.value)}
          className="rounded-xl border border-zinc-200 bg-white px-3 py-2.5 text-sm outline-none"
        >
          <option value="all">همه وضعیت‌ها</option>
          <option value="PUBLISHED">منتشر شده</option>
          <option value="DRAFT">پیش‌نویس</option>
          <option value="PENDING">در انتظار بررسی</option>
          <option value="REJECTED">رد شده</option>
          <option value="expiring">در حال انقضا (۷ روز)</option>
          <option value="expired">بایگانی (منقضی)</option>
        </select>

        <select
          value={sort}
          onChange={(e) => setSort(e.target.value)}
          className="rounded-xl border border-zinc-200 bg-white px-3 py-2.5 text-sm outline-none"
        >
          <option value="newest">جدیدترین</option>
          <option value="expiry">نزدیک‌ترین به انقضا</option>
          <option value="views">پربازدیدترین</option>
          <option value="priceDesc">گران‌ترین</option>
          <option value="priceAsc">ارزان‌ترین</option>
        </select>
      </div>

      {/* عملیات گروهی */}
      {selected.length > 0 && (
        <div className="flex flex-wrap items-center gap-3 rounded-2xl border border-orange-300 bg-orange-50 p-3">
          <span className="text-sm font-black text-orange-700">
            {selected.length.toLocaleString("fa-IR")} مورد انتخاب شد:
          </span>
          <button onClick={() => bulk({ status: "PUBLISHED" })} className="rounded-lg bg-green-600 px-4 py-2 text-xs font-bold text-white hover:bg-green-700">
            انتشار
          </button>
          <button onClick={() => bulk({ featured: true })} className="rounded-lg bg-orange-500 px-4 py-2 text-xs font-bold text-white hover:bg-orange-600">
            ویژه
          </button>
          <button onClick={() => bulk({ extend: true })} className="rounded-lg bg-blue-600 px-4 py-2 text-xs font-bold text-white hover:bg-blue-700">
            تمدید ۳۰ روزه
          </button>
          <button onClick={() => bulk({ active: false })} className="rounded-lg bg-zinc-600 px-4 py-2 text-xs font-bold text-white hover:bg-zinc-700">
            غیرفعال
          </button>
          <button onClick={bulkDelete} className="rounded-lg bg-red-600 px-4 py-2 text-xs font-bold text-white hover:bg-red-700">
            حذف
          </button>
        </div>
      )}

      {/* لیست */}
      {loading ? (
        <div className="flex h-64 items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-orange-500" />
        </div>
      ) : pageItems.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-orange-300 bg-orange-50 p-10 text-center">
          <BarChart3 className="mx-auto h-10 w-10 text-orange-400" />
          <p className="mt-3 text-sm font-bold text-zinc-600">
            آگهی‌ای با این مشخصات پیدا نشد.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {pageItems.map((ad) => {
            const st = statusLabel(ad.status);
            const days = daysLeft(ad.expiresAt);
            const expired =
              ad.status === "PUBLISHED" && days !== null && days <= 0;
            const expiringSoon =
              ad.status === "PUBLISHED" && days !== null && days > 0 && days <= 7;

            return (
              <div
                key={ad.id}
                className={`flex flex-wrap items-center gap-4 rounded-2xl border bg-white p-4 shadow-sm ${
                  expired
                    ? "border-red-300 bg-red-50/40"
                    : expiringSoon
                      ? "border-amber-300 bg-amber-50/40"
                      : "border-zinc-200"
                }`}
              >
                <input
                  type="checkbox"
                  checked={selected.includes(ad.id)}
                  onChange={() => toggleSelect(ad.id)}
                  className="h-4 w-4 accent-orange-500"
                />

                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={ad.image}
                  alt={ad.title}
                  className="h-16 w-24 rounded-xl object-cover"
                />

                <div className="min-w-[220px] flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-sm font-black text-zinc-800">
                      {ad.title}
                    </span>
                    <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${st.c}`}>
                      {st.t}
                    </span>

                    {/* نشان انقضا */}
                    {ad.status === "PUBLISHED" && days !== null && (
                      <span
                        className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-bold ${
                          expired
                            ? "bg-red-100 text-red-700"
                            : expiringSoon
                              ? "bg-amber-100 text-amber-700"
                              : "bg-blue-100 text-blue-700"
                        }`}
                      >
                        <Clock className="h-3 w-3" />
                        {expired
                          ? "منقضی"
                          : days === 1
                            ? "۱ روز مانده"
                            : `${days.toLocaleString("fa-IR")} روز مانده`}
                      </span>
                    )}
                  </div>

                  <div className="mt-1.5 flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px] text-zinc-500">
                    <span>{ad.brand}</span>
                    <span>{ad.price}</span>
                    {ad.year && <span>{ad.year}</span>}
                    <span className="text-blue-600">
                      👁 {ad.views.toLocaleString("fa-IR")}
                    </span>
                    <span className="text-red-500">
                      ♥ {ad.favorites.toLocaleString("fa-IR")}
                    </span>
                    <span className="text-zinc-400">
                      🖼 {ad.galleryCount.toLocaleString("fa-IR")}
                    </span>
                    <span className="text-zinc-400">
                      {new Date(ad.createdAt).toLocaleDateString("fa-IR")}
                    </span>
                  </div>

                  {/* دلیل رد */}
                  {ad.rejectionReason && (
                    <div className="mt-2 flex items-start gap-1.5 rounded-lg bg-red-50 px-2 py-1 text-[11px] text-red-700">
                      <XCircle className="mt-0.5 h-3 w-3 shrink-0" />
                      <span>دلیل رد: {ad.rejectionReason}</span>
                    </div>
                  )}
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    title="ویژه"
                    onClick={() => patch(ad.id, { featured: !ad.featured })}
                    className={`flex h-9 w-9 items-center justify-center rounded-lg border transition ${
                      ad.featured
                        ? "border-orange-300 bg-orange-100 text-orange-600"
                        : "border-zinc-200 bg-white text-zinc-400 hover:border-orange-300"
                    }`}
                  >
                    <Star className="h-4 w-4" />
                  </button>

                  <button
                    title="فعال/غیرفعال"
                    onClick={() => patch(ad.id, { active: !ad.active })}
                    className={`flex h-9 w-9 items-center justify-center rounded-lg border transition ${
                      ad.active
                        ? "border-green-300 bg-green-50 text-green-600"
                        : "border-zinc-200 bg-white text-zinc-400"
                    }`}
                  >
                    {ad.active ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
                  </button>

                  {/* تأیید (برای pending / rejected) */}
                  {(ad.status === "PENDING" || ad.status === "REJECTED") && (
                    <button
                      onClick={() => patch(ad.id, { status: "PUBLISHED" })}
                      title="تأیید و انتشار"
                      className="flex h-9 w-9 items-center justify-center rounded-lg border border-green-300 bg-green-50 text-green-600 transition hover:bg-green-100"
                    >
                      <CheckCircle2 className="h-4 w-4" />
                    </button>
                  )}

                  {/* تمدید / بازیابی از بایگانی */}
                  <button
                    onClick={() => patch(ad.id, { extend: true })}
                    title="تمدید ۳۰ روزه / بازیابی"
                    className="flex h-9 w-9 items-center justify-center rounded-lg border border-blue-300 bg-blue-50 text-blue-600 transition hover:bg-blue-100"
                  >
                    <Clock className="h-4 w-4" />
                  </button>

                  {/* رد */}
                  {ad.status !== "REJECTED" && (
                    <button
                      onClick={() => setRejectTarget(ad)}
                      title="رد با دلیل"
                      className="flex h-9 w-9 items-center justify-center rounded-lg border border-red-200 bg-white text-red-500 transition hover:bg-red-50"
                    >
                      <Ban className="h-4 w-4" />
                    </button>
                  )}

                  <Link
                    href={`/machines/${ad.slug}`}
                    target="_blank"
                    title="مشاهده در سایت"
                    className="flex h-9 w-9 items-center justify-center rounded-lg border border-zinc-200 bg-white text-zinc-600 transition hover:border-blue-300 hover:text-blue-600"
                  >
                    <ExternalLink className="h-4 w-4" />
                  </Link>

                  <button
                    title="کپی آگهی"
                    onClick={() => duplicate(ad.id)}
                    className="flex h-9 w-9 items-center justify-center rounded-lg border border-zinc-200 bg-white text-zinc-600 transition hover:border-purple-300 hover:text-purple-600"
                  >
                    <Copy className="h-4 w-4" />
                  </button>

                  <Link
                    href={`/admin/machines/edit/${ad.id}`}
                    title="ویرایش"
                    className="flex h-9 w-9 items-center justify-center rounded-lg border border-zinc-200 bg-white text-zinc-600 transition hover:border-orange-300 hover:text-orange-600"
                  >
                    <Pencil className="h-4 w-4" />
                  </Link>

                  <button
                    title="حذف"
                    onClick={() => remove(ad.id)}
                    className="flex h-9 w-9 items-center justify-center rounded-lg border border-red-100 bg-red-50 text-red-500 transition hover:bg-red-100"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* صفحه‌بندی */}
      {pages > 1 && (
        <div className="flex items-center justify-center gap-3">
          <button
            disabled={page === 0}
            onClick={() => setPage((p) => p - 1)}
            className="flex h-9 w-9 items-center justify-center rounded-lg border border-zinc-200 bg-white disabled:opacity-40"
          >
            <ChevronRight className="h-4 w-4" />
          </button>
          <span className="text-sm font-bold text-zinc-600">
            {(page + 1).toLocaleString("fa-IR")} / {pages.toLocaleString("fa-IR")}
          </span>
          <button
            disabled={page >= pages - 1}
            onClick={() => setPage((p) => p + 1)}
            className="flex h-9 w-9 items-center justify-center rounded-lg border border-zinc-200 bg-white disabled:opacity-40"
          >
            <ChevronLeft className="h-4 w-4" />
          </button>
        </div>
      )}

      {/* مودال رد */}
      <RejectDialog
        open={!!rejectTarget}
        title={rejectTarget?.title ?? ""}
        onClose={() => setRejectTarget(null)}
        onConfirm={async (reason) => {
          await patch(rejectTarget.id, { reject: true, reason });
        }}
      />
    </div>
  );
}