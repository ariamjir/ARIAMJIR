"use client";

import { useEffect, useMemo, useState } from "react";

import Link from "next/link";

import { Printer, ArrowRight, BarChart3 } from "lucide-react";

export default function AdsReportPage() {
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/admin/ads")
      .then((r) => r.json())
      .then((j) => {
        if (j.success) setItems(j.data ?? []);
      })
      .finally(() => setLoading(false));
  }, []);

  const now = new Date();
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
  const monthName = now.toLocaleDateString("fa-IR", {
    month: "long",
    year: "numeric",
  });

  const stats = useMemo(() => {
    const inMonth = items.filter(
      (x) => new Date(x.createdAt) >= monthStart
    );
    return {
      newAds: inMonth.length,
      published: items.filter((x) => x.status === "PUBLISHED").length,
      rejected: items.filter((x) => x.status === "REJECTED").length,
      expired: items.filter(
        (x) => x.expiresAt && new Date(x.expiresAt) < now
      ).length,
      views: items.reduce((s, x) => s + (x.views ?? 0), 0),
      favorites: items.reduce((s, x) => s + (x.favorites ?? 0), 0),
      totalValue: items
        .filter((x) => x.status === "PUBLISHED")
        .reduce((s, x) => s + (x.priceValue ?? 0), 0),
    };
  }, [items]);

  const brandStats = useMemo(() => {
    const m: Record<string, number> = {};
    items.forEach((x) => {
      m[x.brand] = (m[x.brand] ?? 0) + 1;
    });
    return Object.entries(m)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 8);
  }, [items]);

  return (
    <div className="space-y-6">
      {/* کنترل‌ها — در چاپ مخفی */}
      <div className="flex flex-wrap items-center justify-between gap-4 print:hidden">
        <div>
          <h1 className="text-2xl font-black text-zinc-800">
            گزارش ماهانهٔ آگهی‌ها
          </h1>
          <p className="mt-1 text-sm text-zinc-500">
            دورهٔ گزارش: {monthName}
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Link
            href="/admin/ads"
            className="inline-flex items-center gap-2 rounded-xl border border-zinc-200 bg-white px-4 py-2.5 text-sm font-bold text-zinc-600 transition hover:border-orange-300"
          >
            <ArrowRight className="h-4 w-4" />
            بازگشت
          </Link>
          <button
            onClick={() => window.print()}
            className="inline-flex items-center gap-2 rounded-xl bg-blue-600 px-5 py-2.5 text-sm font-black text-white shadow transition hover:bg-blue-700"
          >
            <Printer className="h-4 w-4" />
            چاپ / ذخیره PDF
          </button>
        </div>
      </div>

      {loading ? (
        <div className="py-20 text-center text-sm font-bold text-zinc-500">
          در حال آماده‌سازی گزارش...
        </div>
      ) : (
        <>
          {/* سربرگ چاپ */}
          <div className="hidden text-center print:block">
            <div className="text-xl font-black">ARIA MJ — گزارش آگهی‌ها</div>
            <div className="mt-1 text-xs text-zinc-500">
              دوره: {monthName} · تاریخ تهیه:{" "}
              {now.toLocaleDateString("fa-IR")}
            </div>
          </div>

          {/* کارت‌های آماری */}
          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
            {[
              { l: "آگهی‌های جدید این ماه", v: stats.newAds.toLocaleString("fa-IR") },
              { l: "منتشر شده (فعال)", v: stats.published.toLocaleString("fa-IR") },
              { l: "رد شده", v: stats.rejected.toLocaleString("fa-IR") },
              { l: "منقضی / بایگانی", v: stats.expired.toLocaleString("fa-IR") },
              { l: "مجموع بازدید", v: stats.views.toLocaleString("fa-IR") },
              { l: "مجموع علاقه‌مندی", v: stats.favorites.toLocaleString("fa-IR") },
              {
                l: "ارزش کل آگهی‌های فعال",
                v: stats.totalValue
                  ? stats.totalValue.toLocaleString("fa-IR") + " تومان"
                  : "-",
              },
            ].map((s) => (
              <div
                key={s.l}
                className="rounded-2xl border border-zinc-200 bg-white p-4 shadow-sm"
              >
                <div className="text-[11px] font-bold text-zinc-500">{s.l}</div>
                <div className="mt-1 text-xl font-black text-zinc-800">
                  {s.v}
                </div>
              </div>
            ))}
          </div>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* سهم برندها */}
            <div className="rounded-2xl border border-zinc-200 bg-white p-6 shadow-sm">
              <h2 className="mb-4 flex items-center gap-2 text-sm font-black text-zinc-800">
                <BarChart3 className="h-4 w-4 text-orange-500" />
                پرتکرارترین برندها
              </h2>
              <div className="space-y-3">
                {brandStats.map(([brand, count]) => {
                  const pct = Math.round((count / items.length) * 100);
                  return (
                    <div key={brand}>
                      <div className="mb-1 flex justify-between text-[11px] font-bold text-zinc-600">
                        <span>{brand}</span>
                        <span>{count.toLocaleString("fa-IR")} آگهی</span>
                      </div>
                      <div className="h-2 rounded-full bg-zinc-100">
                        <div
                          className="h-2 rounded-full bg-orange-500"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* جدول آگهی‌ها */}
            <div className="overflow-hidden rounded-2xl border border-zinc-200 bg-white shadow-sm">
              <table className="w-full text-right text-[11px]">
                <thead className="bg-zinc-50 text-zinc-500">
                  <tr>
                    <th className="px-4 py-3 font-bold">آگهی</th>
                    <th className="px-4 py-3 font-bold">برند</th>
                    <th className="px-4 py-3 font-bold">قیمت</th>
                    <th className="px-4 py-3 font-bold">بازدید</th>
                    <th className="px-4 py-3 font-bold">وضعیت</th>
                  </tr>
                </thead>
                <tbody>
                  {items.slice(0, 15).map((ad) => (
                    <tr key={ad.id} className="border-t border-zinc-100">
                      <td className="px-4 py-2.5 font-bold text-zinc-800">
                        {ad.title}
                      </td>
                      <td className="px-4 py-2.5 text-zinc-600">{ad.brand}</td>
                      <td className="px-4 py-2.5 text-zinc-600">{ad.price}</td>
                      <td className="px-4 py-2.5 text-zinc-600">
                        {(ad.views ?? 0).toLocaleString("fa-IR")}
                      </td>
                      <td className="px-4 py-2.5 text-zinc-600">{ad.status}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
}