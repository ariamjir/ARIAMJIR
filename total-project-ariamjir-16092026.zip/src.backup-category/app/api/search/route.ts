import { NextRequest, NextResponse } from "next/server";

import { SearchService } from "@/server/search/search.service";

import { validateSearch } from "@/server/search/search.validator";

import { mapMachines } from "@/server/search/search.mapper";

const service = new SearchService();

export async function GET(

request: NextRequest

) {

try {

const { searchParams } =

new URL(request.url);

const input = validateSearch({

search:

searchParams.get("q") ?? undefined,

brands:

searchParams

.get("brands")

?.split(",")

.filter(Boolean) ?? [],

categories:

searchParams

.get("categories")

?.split(",")

.filter(Boolean) ?? [],

conditions:

searchParams

.get("conditions")

?.split(",")

.filter(Boolean) ?? [],

listingTypes:

searchParams

.get("listingTypes")

?.split(",")

.filter(Boolean) ?? [],

province:

searchParams.get("province") ?? undefined,

city:

searchParams.get("city") ?? undefined,

yearFrom:

searchParams.get("yearFrom")

? Number(searchParams.get("yearFrom"))

: undefined,

yearTo:

searchParams.get("yearTo")

? Number(searchParams.get("yearTo"))

: undefined,

minPrice:

searchParams.get("minPrice")

? Number(searchParams.get("minPrice"))

: undefined,

maxPrice:

searchParams.get("maxPrice")

? Number(searchParams.get("maxPrice"))

: undefined,

currency:

searchParams.get("currency")

?? "تومان",

sort:

searchParams.get("sort")

?? "newest",

});

const machines =

await service.search(

input

);

const data =

mapMachines(

machines

);

return NextResponse.json({

success: true,

count: data.length,

data,

});

} catch (error) {

console.error(error);

return NextResponse.json(

{

success: false,

message:

"Search request failed.",

},

{

status: 400,

}

);

}

}

