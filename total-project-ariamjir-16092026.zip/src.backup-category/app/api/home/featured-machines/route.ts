import { NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";

export async function GET() {
  try {
    const machines =
      await prisma.machine.findMany({
        where: {
          active: true,
          featured: true,
          status: "APPROVED",
        },

        orderBy: {
          createdAt: "desc",
        },

        take: 12,

        include: {
          brand: true,

          category: true,

          price: true,

          specification: true,

          images: {
            orderBy: {
              sortOrder: "asc",
            },

            take: 1,
          },
        },
      });

    return NextResponse.json(
      machines.map((machine) => ({
        id: machine.id,

        title: machine.title,

        slug: machine.slug,

        image:
          machine.images[0]?.url ??
          null,

        brand:
          machine.brand?.name ??
          null,

        category:
          machine.category?.name ??
          null,

        location:
          machine.specification
            ?.location ?? null,

        year:
          machine.specification
            ?.manufactureYear ??
          null,

        hours:
          machine.specification
            ?.workingHours ??
          null,

        price:
          machine.price?.price ??
          null,

        currency:
          machine.price?.currency ??
          null,

        featured:
          machine.featured,
      }))
    );
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      {
        error:
          "Failed to load featured machines",
      },
      {
        status: 500,
      }
    );
  }
}