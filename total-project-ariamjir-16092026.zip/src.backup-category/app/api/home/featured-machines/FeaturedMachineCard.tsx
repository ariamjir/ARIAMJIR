"use client";

import Link from "next/link";

import type {
  FeaturedMachine,
} from "@/modules/machine";

interface Props {
  machine: FeaturedMachine;
}

export default function FeaturedMachineCard({
  machine,
}: Props) {
  return (
    <Link
      href={`/machines/${machine.slug}`}
      className="
        group
        overflow-hidden
        rounded-3xl
        border
        bg-white
        transition
        duration-300
        hover:-translate-y-2
        hover:border-[#F58220]
        hover:shadow-2xl
      "
    >
      <div
        className="
          aspect-[4/3]
          overflow-hidden
          bg-gray-100
        "
      >
        <img
          src={
            machine.image ??
            "/images/no-image.jpg"
          }
          alt={machine.title}
          className="
            h-full
            w-full
            object-cover
            transition
            duration-500
            group-hover:scale-110
          "
        />
      </div>

      <div className="space-y-4 p-6">

        <h3
          className="
            line-clamp-2
            text-xl
            font-bold
          "
        >
          {machine.title}
        </h3>

        <div className="space-y-2 text-sm text-gray-500">

          <p>
            برند:
            {" "}
            {machine.brand ?? "-"}
          </p>

          <p>
            دسته:
            {" "}
            {machine.category ?? "-"}
          </p>

          <p>
            موقعیت:
            {" "}
            {machine.location ?? "-"}
          </p>

        </div>

        <div
          className="
            flex
            items-center
            justify-between
            border-t
            pt-5
          "
        >
          <span
            className="
              text-2xl
              font-black
              text-[#F58220]
            "
          >
            {machine.price
              ? machine.price.toLocaleString()
              : "تماس بگیرید"}
          </span>

          <span
            className="
              rounded-full
              bg-orange-100
              px-4
              py-2
              text-sm
              font-bold
              text-orange-600
            "
          >
            ویژه
          </span>
        </div>

      </div>
    </Link>
  );
}