"use client";

import FeaturedMachineCard from "./FeaturedMachineCard";

import { useFeaturedMachines } from "@/modules/machine";

export default function FeaturedMachinesSection() {
  const {
    machines,
    loading,
  } = useFeaturedMachines();

  if (loading) {
    return (
      <section className="py-24">
        <div className="container mx-auto px-6">

          <div className="mb-14 text-center">

            <h2 className="text-4xl font-black">
              ماشین‌آلات ویژه
            </h2>

            <p className="mt-4 text-gray-500">
              در حال بارگذاری...
            </p>

          </div>

        </div>
      </section>
    );
  }

  if (machines.length === 0) {
    return null;
  }

  return (
    <section
      className="
        bg-[#fafafa]
        py-24
      "
    >
      <div
        className="
          container
          mx-auto
          px-6
        "
      >
        <div className="mb-16 text-center">

          <span
            className="
              rounded-full
              bg-orange-100
              px-4
              py-2
              text-sm
              font-bold
              text-[#F58220]
            "
          >
            Featured
          </span>

          <h2
            className="
              mt-5
              text-4xl
              font-black
            "
          >
            ماشین‌آلات ویژه
          </h2>

          <p
            className="
              mx-auto
              mt-5
              max-w-3xl
              leading-8
              text-gray-500
            "
          >
            جدیدترین ماشین‌آلات ویژه آریا ام جی
          </p>

        </div>

        <div
          className="
            grid
            gap-8
            md:grid-cols-2
            xl:grid-cols-3
          "
        >
          {machines.map((machine) => (
            <FeaturedMachineCard
              key={machine.id}
              machine={machine}
            />
          ))}
        </div>

      </div>
    </section>
  );
}