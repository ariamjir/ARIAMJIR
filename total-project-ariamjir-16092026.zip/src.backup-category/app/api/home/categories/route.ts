import { NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";

export async function GET() {
  try {
    const categories =
      await prisma.category.findMany({
        where: {
          active: true,
          parentId: null,
        },

        orderBy: [
          {
            sortOrder: "asc",
          },
          {
            name: "asc",
          },
        ],

        include: {
          children: {
            where: {
              active: true,
            },

            orderBy: [
              {
                sortOrder: "asc",
              },
              {
                name: "asc",
              },
            ],
          },

          _count: {
            select: {
              machines: {
                where: {
                  active: true,
                  status: "APPROVED",
                },
              },
            },
          },
        },
      });

    return NextResponse.json(
      categories.map((category) => ({
        id: category.id,

        parentId: category.parentId,

        name: category.name,

        slug: category.slug,

        icon: category.icon,

        image: category.image,

        description:
          category.description,

        sortOrder:
          category.sortOrder,

        active: category.active,

        createdAt:
          category.createdAt,

        updatedAt:
          category.updatedAt,

        machinesCount:
          category._count.machines,

        children:
          category.children.map(
            (child) => ({
              id: child.id,

              parentId:
                child.parentId,

              name: child.name,

              slug: child.slug,

              icon: child.icon,

              image: child.image,

              description:
                child.description,

              sortOrder:
                child.sortOrder,

              active:
                child.active,

              createdAt:
                child.createdAt,

              updatedAt:
                child.updatedAt,
            })
          ),
      }))
    );
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      {
        error:
          "Failed to load categories",
      },
      {
        status: 500,
      }
    );
  }
}