import { NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";

export async function GET() {
  try {
    const [
      machines,
      brands,
      categories,
      users,
    ] = await Promise.all([
      prisma.machine.count({
        where: {
          active: true,
        },
      }),

      prisma.brand.count({
        where: {
          active: true,
        },
      }),

      prisma.category.count({
        where: {
          active: true,
        },
      }),

      prisma.user.count(),
    ]);

    return NextResponse.json({
      machines,
      brands,
      categories,
      users,
    });
  } catch (error) {
    console.error(error);

    return NextResponse.json({
      machines: 0,
      brands: 0,
      categories: 0,
      users: 0,
    });
  }
}