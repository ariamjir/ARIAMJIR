import { NextRequest } from "next/server";

import sharp from "sharp";

import { readFile } from "fs/promises";
import path from "path";

/* ============================================================
   دانلود با حک دامنه — ARIA MJ + ariamj.ir
   ✅ پشتیبانی از فایل محلی /images/... و URL دور (تصاویر AI)
============================================================ */

export async function GET(request: NextRequest) {
  try {
    const url = request.nextUrl.searchParams.get("url") ?? "";

    let buf: Buffer;

    if (url.startsWith("http://") || url.startsWith("https://")) {
      const up = await fetch(url);
      if (!up.ok) return new Response("upstream failed", { status: 502 });
      buf = Buffer.from(await up.arrayBuffer());
    } else {
      if (!url.startsWith("/images/")) {
        return new Response("invalid url", { status: 400 });
      }
      buf = await readFile(path.join(process.cwd(), "public", url));
    }

    const meta = await sharp(buf).metadata();
    const w = meta.width ?? 1200;
    const h = meta.height ?? 800;
    const fs = Math.max(18, Math.round(w / 45));

    const svg = Buffer.from(`
      <svg width="${w}" height="${h}">
        <text x="${w - 24}" y="${h - 24}" text-anchor="end"
          font-size="${fs}" font-family="Tahoma, Arial" font-weight="bold"
          fill="rgba(245,130,32,0.95)">ARIA MJ</text>
        <text x="${w - 24}" y="${h - 24 + fs + 6}" text-anchor="end"
          font-size="${Math.round(fs * 0.6)}" font-family="Tahoma, Arial"
          fill="rgba(255,255,255,0.85)">ariamj.ir</text>
      </svg>`);

        const out = await sharp(buf)
  .toColourspace("srgb")
  .composite([{ input: svg, top: 0, left: 0 }])
  .jpeg({ quality: 88 })
  .toBuffer();

    return new Response(out, {
      headers: {
        "Content-Type": "image/jpeg",
        "Content-Disposition": `attachment; filename="ariamj-${Date.now()}.jpg`,
      },
    });
  } catch (error: any) {
    return new Response(error.message, { status: 500 });
  }
}