import { NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";

import { socials as defaultSocials } from "@/config/social";

export const revalidate = 300;
export const dynamic = "force-dynamic";

/* ============================================================
   اطلاعات سایت — استخراج پویا از SiteSettings (JSON fields)
   ✅ سازگار با phones/mobiles/emails/socials (Json arrays)
   ✅ fallback به src/config/social.ts
============================================================ */

function normalizeSocials(arr: any[]): Record<string, string> {
  const map: Record<string, string> = {};
  for (const s of arr) {
    if (!s?.name || !s?.url) continue;
    if (s.active === false) continue;

    const key = String(s.name)
      .toLowerCase()
      .replace(/[\s().',_-]/g, "");

    if (key.includes("whatsapp")) map.whatsapp = s.url;
    else if (key.includes("instagram")) map.instagram = s.url;
    else if (key.includes("telegram")) map.telegram = s.url;
    else if (key.includes("youtube")) map.youtube = s.url;
    else if (key.includes("linkedin")) map.linkedin = s.url;
    else if (key.includes("twitter") || key === "xtwitter" || key === "x")
      map.x = s.url;
    else if (key.includes("aparat")) map.aparat = s.url;
  }
  return map;
}

function firstOf(json: any): string {
  if (Array.isArray(json) && json.length > 0) return String(json[0]);
  if (typeof json === "string") {
    try {
      const parsed = JSON.parse(json);
      if (Array.isArray(parsed) && parsed.length > 0) return String(parsed[0]);
    } catch {}
  }
  return "";
}

export async function GET() {
  try {
    const s = await prisma.siteSettings.findFirst({
      orderBy: { updatedAt: "desc" },
    });

    /* استخراج از Json arrays */
    const phone = firstOf(s?.phones ?? []);
    const mobile = firstOf(s?.mobiles ?? []);
    const email = firstOf(s?.emails ?? []);

    /* شبکه‌های اجتماعی از دیتابیس */
    let dbSocials: any[] = [];
    try {
      if (s?.socials) {
        dbSocials = typeof s.socials === "string"
          ? JSON.parse(s.socials)
          : (s.socials as any[]);
      }
    } catch {
      dbSocials = [];
    }

    /* fallback به فایل default در صورت خالی بودن */
    const socialSource =
      Array.isArray(dbSocials) && dbSocials.length > 0
        ? dbSocials
        : (defaultSocials as any[]);

    const socialMap = normalizeSocials(socialSource);

    /* اگر واتساپ در socials نبود، از mobile استفاده کن */
    if (!socialMap.whatsapp && mobile) {
      const clean = mobile.replace(/[^0-9]/g, "");
      if (clean.length >= 10) {
        socialMap.whatsapp = `https://wa.me/${clean.replace(/^0/, "98")}`;
      }
    }

    return NextResponse.json({
      success: true,
      data: {
        siteName: s?.brandName ?? "آریا ماشین جم",
        tagline: s?.tagline ?? "",
        phone: phone || "۰۲۱-۸۸۱۰۶۳۸۵",
        mobile: mobile || "",
        email: email || "info@ariamj.ir",
        address: s?.address ?? "",
        workingHours: s?.workingHours ?? "شنبه تا پنجشنبه ۹ تا ۱۸",
        about: s?.about ?? "",
        social: socialMap,
      },
    });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, message: error.message },
      { status: 500 }
    );
  }
}