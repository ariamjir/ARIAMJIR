import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export const revalidate = 60;

export async function GET(request: NextRequest) {
  try {
    const sp = request.nextUrl.searchParams;
    const page = Math.max(1, Number(sp.get("page") ?? 1));
    const category = sp.get("category") ?? "";
    const q = sp.get("q") ?? "";
    const limit = 9;

    const where: any = { status: "PUBLISHED" };
    if (category) where.category = { slug: category };
    if (q.trim()) {
      where.OR = [{ title: { contains: q.trim() } }, { excerpt: { contains: q.trim() } }];
    }

    const [items, total, categories] = await Promise.all([
      prisma.knowledgePost.findMany({
        where,
        orderBy: { publishedAt: "desc" },
        skip: (page - 1) * limit,
        take: limit,
        include: { category: true },
      }),
      prisma.knowledgePost.count({ where }),
      prisma.newsCategory.findMany({ where: { active: true }, orderBy: { sortOrder: "asc" } }),
    ]);

    return NextResponse.json({
      success: true,
      data: { items, total, page, pages: Math.max(1, Math.ceil(total / limit)), categories },
    });
  } catch (error: any) {
    return NextResponse.json({ success: false, message: error.message }, { status: 500 });
  }
}