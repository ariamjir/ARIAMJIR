import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(request: NextRequest, { params }: { params: Promise<{ slug: string }> }) {
  try {
    const { slug } = await params;

    const post = await prisma.knowledgePost.findUnique({ where: { slug }, include: { category: true } });
    if (!post || post.status !== "PUBLISHED") {
      return NextResponse.json({ success: false, message: "یافت نشد" }, { status: 404 });
    }

    await prisma.knowledgePost.update({ where: { id: post.id }, data: { viewCount: { increment: 1 } } });

    const related = await prisma.knowledgePost.findMany({
      where: { status: "PUBLISHED", id: { not: post.id } },
      orderBy: { publishedAt: "desc" },
      take: 3,
      include: { category: true },
    });

    return NextResponse.json({ success: true, data: { post: { ...post, viewCount: post.viewCount + 1 }, related } });
  } catch (error: any) {
    return NextResponse.json({ success: false, message: error.message }, { status: 500 });
  }
}