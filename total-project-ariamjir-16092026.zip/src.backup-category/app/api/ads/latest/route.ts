import { NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";

export const revalidate = 60;

export async function GET() {
  try {
    const machines = await prisma.machine.findMany({
      where: { status: "PUBLISHED", active: true },
      orderBy: { publishedAt: "desc" },
      include: {
        brand: true,
        specification: true,
        price: true,
        images: { orderBy: { sortOrder: "asc" } },
      },
    });

    const data = machines.map((m: any) => ({
      id: m.id,
      slug: m.slug,
      title: m.title,
      brand: m.brand?.name ?? null,
      image:
        m.images?.[0]?.url ??
        "/images/machines/ariamjexcavator-1.png",
      price: m.price?.price
        ? `${Number(m.price.price).toLocaleString("fa-IR")} تومان`
        : "تماس بگیرید",
      year: m.specification?.manufactureYear ?? null,
      location:
        m.specification?.location ?? null,
      workingHours:
        m.specification?.workingHours ?? null,
      featured: m.featured,
    }));

    return NextResponse.json({ success: true, data });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, message: error.message },
      { status: 500 }
    );
  }
}