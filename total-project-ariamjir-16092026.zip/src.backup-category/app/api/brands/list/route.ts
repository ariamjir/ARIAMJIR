import { NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";

/* لیست عمومی برندها برای سرچ هیرو */
export const revalidate = 300;

export async function GET() {
  try {
    const brands = await prisma.brand.findMany({
      orderBy: { name: "asc" },
      select: { id: true, name: true, slug: true },
    });

    return NextResponse.json({ success: true, data: brands });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, message: error.message },
      { status: 500 }
    );
  }
}