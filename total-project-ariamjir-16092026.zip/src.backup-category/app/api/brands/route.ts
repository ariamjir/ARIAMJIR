import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export const revalidate = 300;

export async function GET(request: NextRequest) {
  try {
    const sp = request.nextUrl.searchParams;
    const active = sp.get("active") === "true";
    const featured = sp.get("featured") === "true";
    const limit = sp.get("limit");

    const where: any = {};
    if (active) where.active = true;
    if (featured) where.featured = true;

    const brands = await prisma.brand.findMany({
      where,
      orderBy: { name: "asc" },
      take: limit ? parseInt(limit) : undefined,
      select: {
        id: true,
        name: true,
        slug: true,
        logo: true,
        website: true,
        countryId: true,
        description: true,
        featured: true,
        active: true,
        sortOrder: true,
      },
    });

    return NextResponse.json({ success: true, data: brands });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, message: error.message },
      { status: 500 }
    );
  }
}