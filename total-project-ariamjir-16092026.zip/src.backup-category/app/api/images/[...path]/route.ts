import { NextRequest } from "next/server";

import { readFile } from "fs/promises";
import path from "path";

export const revalidate = 3600;

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ path: string[] }> }
) {
  try {
    const { path: segments } = await params;
    const relPath = "/" + segments.join("/");

    try {
      const fullPath = path.join(process.cwd(), "public", relPath);
      const buf = await readFile(fullPath);
      const ext = path.extname(relPath).toLowerCase();
      const types: Record<string, string> = {
        ".png": "image/png",
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".svg": "image/svg+xml",
        ".webp": "image/webp",
      };
      return new Response(buf, {
        headers: {
          "Content-Type": types[ext] ?? "application/octet-stream",
          "Cache-Control": "public, max-age=86400",
        },
      });
    } catch {}

    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="800" viewBox="0 0 1200 800">
      <defs>
        <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stop-color="#1a1a1a"/>
          <stop offset="1" stop-color="#0a0a0a"/>
        </linearGradient>
      </defs>
      <rect width="1200" height="800" fill="url(#bg)"/>
      <circle cx="600" cy="360" r="140" fill="#F58220" opacity="0.12"/>
      <text x="600" y="400" font-family="Arial, sans-serif" font-size="84" font-weight="900" fill="#F58220" text-anchor="middle">ARIA MJ</text>
      <text x="600" y="490" font-family="Arial, sans-serif" font-size="20" font-weight="500" fill="#ffffff" text-anchor="middle" opacity="0.5">${relPath}</text>
    </svg>`;

    return new Response(svg, {
      headers: {
        "Content-Type": "image/svg+xml",
        "Cache-Control": "public, max-age=3600",
      },
    });
  } catch (error: any) {
    return new Response(error.message, { status: 500 });
  }
}