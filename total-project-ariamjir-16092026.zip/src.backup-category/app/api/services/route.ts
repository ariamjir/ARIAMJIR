import { NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";

export const revalidate = 60;

export async function GET() {
  try {
    const items = await prisma.serviceItem.findMany({
      where: { active: true },
      orderBy: { order: "asc" },
    });

    return NextResponse.json({ success: true, data: items });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, message: error.message },
      { status: 500 }
    );
  }
}