import { NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";
import { isAuthenticated } from "@/lib/session";

export const dynamic = "force-dynamic";

/* =========================================================
   AUTH
========================================================= */

async function checkAuth() {
  const authenticated = await isAuthenticated();

  if (!authenticated) {
    return NextResponse.json(
      {
        error: "Unauthorized",
      },
      {
        status: 401,
      },
    );
  }

  return null;
}

/* =========================================================
   PATCH
   ویرایش آیتم منو
========================================================= */

export async function PATCH(
  request: Request,
  context: {
    params: Promise<{
      id: string;
    }>;
  },
) {
  const authError = await checkAuth();

  if (authError) {
    return authError;
  }

  try {
    const { id } = await context.params;

    const body = await request.json();

    /* -------------------------------------------------------
       FIND CURRENT ITEM
    ------------------------------------------------------- */

    const current = await prisma.menuItem.findUnique({
      where: {
        id,
      },

      select: {
        id: true,
        parentId: true,
      },
    });

    if (!current) {
      return NextResponse.json(
        {
          error: "آیتم منو پیدا نشد",
        },
        {
          status: 404,
        },
      );
    }

    /* -------------------------------------------------------
       TITLE
    ------------------------------------------------------- */

    let title: string | undefined;

    if ("title" in body) {
      title =
        typeof body.title === "string"
          ? body.title.trim()
          : "";

      if (!title) {
        return NextResponse.json(
          {
            error: "عنوان منو نمی‌تواند خالی باشد",
          },
          {
            status: 400,
          },
        );
      }
    }

    /* -------------------------------------------------------
       PARENT
    ------------------------------------------------------- */

    const parentId =
      body.parentId === null ||
      body.parentId === ""
        ? null
        : typeof body.parentId === "string"
          ? body.parentId.trim()
          : current.parentId;

    /* -------------------------------------------------------
       SELF PARENT
    ------------------------------------------------------- */

    if (parentId === id) {
      return NextResponse.json(
        {
          error: "یک آیتم نمی‌تواند والد خودش باشد",
        },
        {
          status: 400,
        },
      );
    }

    /* -------------------------------------------------------
       CHECK PARENT + CYCLE
    ------------------------------------------------------- */

    if (parentId) {
      let cursor: string | null = parentId;

      while (cursor) {
        if (cursor === id) {
          return NextResponse.json(
            {
              error:
                "ساختار منو نمی‌تواند دارای چرخه باشد",
            },
            {
              status: 400,
            },
          );
        }

        const parent = await prisma.menuItem.findUnique({
          where: {
            id: cursor,
          },

          select: {
            parentId: true,
          },
        });

        if (!parent) {
          return NextResponse.json(
            {
              error: "آیتم والد پیدا نشد",
            },
            {
              status: 400,
            },
          );
        }

        cursor = parent.parentId;
      }
    }

    /* -------------------------------------------------------
       CATEGORY
    ------------------------------------------------------- */

    if ("categoryId" in body) {
      const categoryId =
        typeof body.categoryId === "string" &&
        body.categoryId.trim()
          ? body.categoryId.trim()
          : null;

      if (categoryId) {
        const category =
          await prisma.category.findUnique({
            where: {
              id: categoryId,
            },

            select: {
              id: true,
            },
          });

        if (!category) {
          return NextResponse.json(
            {
              error:
                "دسته‌بندی انتخاب‌شده پیدا نشد",
            },
            {
              status: 400,
            },
          );
        }
      }
    }

    /* -------------------------------------------------------
       BUILD UPDATE DATA
    ------------------------------------------------------- */

    const data: Record<string, unknown> = {};

    if (title !== undefined) {
      data.title = title;
    }

    if ("href" in body) {
      data.href =
        typeof body.href === "string" &&
        body.href.trim()
          ? body.href.trim()
          : null;
    }

    if ("parentId" in body) {
      data.parentId = parentId;
    }

    if ("type" in body) {
      data.type =
        typeof body.type === "string" &&
        body.type.trim()
          ? body.type.trim()
          : "LINK";
    }

    if ("icon" in body) {
      data.icon =
        typeof body.icon === "string" &&
        body.icon.trim()
          ? body.icon.trim()
          : null;
    }

    if ("categoryId" in body) {
      data.categoryId =
        typeof body.categoryId === "string" &&
        body.categoryId.trim()
          ? body.categoryId.trim()
          : null;
    }

    if ("sortOrder" in body) {
      const sortOrder = Number(body.sortOrder);

      data.sortOrder = Number.isFinite(sortOrder)
        ? sortOrder
        : 0;
    }

    if ("active" in body) {
      data.active = Boolean(body.active);
    }

    if ("showDesktop" in body) {
      data.showDesktop = Boolean(
        body.showDesktop,
      );
    }

    if ("showMobile" in body) {
      data.showMobile = Boolean(
        body.showMobile,
      );
    }

    if ("openInNewTab" in body) {
      data.openInNewTab = Boolean(
        body.openInNewTab,
      );
    }

    if ("megaMenu" in body) {
      data.megaMenu = Boolean(
        body.megaMenu,
      );
    }

    /* -------------------------------------------------------
       UPDATE
    ------------------------------------------------------- */

    const item = await prisma.menuItem.update({
      where: {
        id,
      },

      data,

      include: {
        category: {
          select: {
            id: true,
            name: true,
            slug: true,
          },
        },
      },
    });

    return NextResponse.json(item);
  } catch (error) {
    console.error(
      "[PATCH /api/admin/menu/:id]",
      error,
    );

    return NextResponse.json(
      {
        error: "Failed to update menu item",
      },
      {
        status: 500,
      },
    );
  }
}

/* =========================================================
   DELETE
   حذف آیتم منو
========================================================= */

export async function DELETE(
  _request: Request,
  context: {
    params: Promise<{
      id: string;
    }>;
  },
) {
  const authError = await checkAuth();

  if (authError) {
    return authError;
  }

  try {
    const { id } = await context.params;

    const item = await prisma.menuItem.findUnique({
      where: {
        id,
      },

      select: {
        id: true,
        title: true,
      },
    });

    if (!item) {
      return NextResponse.json(
        {
          error: "آیتم منو پیدا نشد",
        },
        {
          status: 404,
        },
      );
    }

    /*
      طبق schema.prisma:

      parent -> children
      onDelete: Cascade

      بنابراین با حذف یک آیتم والد،
      تمام زیرمنوهای آن نیز حذف می‌شوند.
    */

    await prisma.menuItem.delete({
      where: {
        id,
      },
    });

    return NextResponse.json({
      success: true,
      id,
    });
  } catch (error) {
    console.error(
      "[DELETE /api/admin/menu/:id]",
      error,
    );

    return NextResponse.json(
      {
        error: "Failed to delete menu item",
      },
      {
        status: 500,
      },
    );
  }
}