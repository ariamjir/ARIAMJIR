import { NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";

export async function POST() {
  try {
    /* ۱) پیدا کردن id منوی خدمات */
    const servicesMenu = await prisma.menuItem.findFirst({
      where: { title: "خدمات", parentId: null },
    });

    if (!servicesMenu) {
      return NextResponse.json(
        { success: false, message: "منوی خدمات یافت نشد" },
        { status: 404 }
      );
    }

    const servicesId = servicesMenu.id;
    let updated = 0;
    let created = 0;

    /* ۲) انتقال قطعات یدکی به زیر خدمات */
    const partsMenu = await prisma.menuItem.findFirst({
      where: { href: "/parts", parentId: null },
    });

    if (partsMenu) {
      await prisma.menuItem.update({
        where: { id: partsMenu.id },
        data: { parentId: servicesId, sortOrder: 21 },
      });
      updated++;
    } else {
      await prisma.menuItem.create({
        data: {
          title: "قطعات یدکی",
          href: "/parts",
          parentId: servicesId,
          type: "LINK",
          icon: "Package",
          sortOrder: 21,
          active: true,
          showDesktop: true,
          showMobile: true,
        },
      });
      created++;
    }

    /* ۳) انتقال اجاره ماشین‌آلات به زیر خدمات */
    const rentalMenu = await prisma.menuItem.findFirst({
      where: { href: "/rental", parentId: null },
    });

    if (rentalMenu) {
      await prisma.menuItem.update({
        where: { id: rentalMenu.id },
        data: { parentId: servicesId, sortOrder: 22 },
      });
      updated++;
    } else {
      await prisma.menuItem.create({
        data: {
          title: "اجاره ماشین‌آلات",
          href: "/rental",
          parentId: servicesId,
          type: "LINK",
          icon: "Truck",
          sortOrder: 22,
          active: true,
          showDesktop: true,
          showMobile: true,
        },
      });
      created++;
    }

    return NextResponse.json({
      success: true,
      updated,
      created,
      servicesId,
      message: `${updated} آیتم منتقل شد، ${created} آیتم جدید ساخته شد`,
    });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, message: error.message },
      { status: 500 }
    );
  }
}