import { NextRequest, NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";
import { isAuthenticated } from "@/lib/session";

export const dynamic = "force-dynamic";

/* =========================================================
   AUTH
========================================================= */

async function checkAuth() {
  const authenticated = await isAuthenticated();

  if (!authenticated) {
    return NextResponse.json(
      {
        error: "Unauthorized",
      },
      {
        status: 401,
      },
    );
  }

  return null;
}

/* =========================================================
   GET
   دریافت تمام آیتم‌های منو + دسته‌بندی‌ها
========================================================= */

export async function GET() {
  const authError = await checkAuth();

  if (authError) {
    return authError;
  }

  try {
    const [items, categories] = await Promise.all([
      prisma.menuItem.findMany({
        orderBy: [
          {
            sortOrder: "asc",
          },
          {
            createdAt: "asc",
          },
        ],

        include: {
          category: {
            select: {
              id: true,
              name: true,
              slug: true,
            },
          },
        },
      }),

      prisma.category.findMany({
        where: {
          active: true,
        },

        select: {
          id: true,
          name: true,
          slug: true,
        },

        orderBy: {
          name: "asc",
        },
      }),
    ]);

    return NextResponse.json({
      items,
      categories,
    });
  } catch (error) {
    console.error("[GET /api/admin/menu]", error);

    return NextResponse.json(
      {
        error: "Failed to load menu",
      },
      {
        status: 500,
      },
    );
  }
}

/* =========================================================
   POST
   ایجاد آیتم جدید
========================================================= */

export async function POST(request: NextRequest) {
  const authError = await checkAuth();

  if (authError) {
    return authError;
  }

  try {
    const body = await request.json();

    /* -------------------------------------------------------
       TITLE
    ------------------------------------------------------- */

    const title =
      typeof body.title === "string"
        ? body.title.trim()
        : "";

    if (!title) {
      return NextResponse.json(
        {
          error: "عنوان منو الزامی است",
        },
        {
          status: 400,
        },
      );
    }

    /* -------------------------------------------------------
       BASIC VALUES
    ------------------------------------------------------- */

    const href =
      typeof body.href === "string" &&
      body.href.trim()
        ? body.href.trim()
        : null;

    const parentId =
      typeof body.parentId === "string" &&
      body.parentId.trim()
        ? body.parentId.trim()
        : null;

    const categoryId =
      typeof body.categoryId === "string" &&
      body.categoryId.trim()
        ? body.categoryId.trim()
        : null;

    /* -------------------------------------------------------
       CHECK PARENT
    ------------------------------------------------------- */

    if (parentId) {
      const parent = await prisma.menuItem.findUnique({
        where: {
          id: parentId,
        },

        select: {
          id: true,
        },
      });

      if (!parent) {
        return NextResponse.json(
          {
            error: "آیتم والد پیدا نشد",
          },
          {
            status: 400,
          },
        );
      }
    }

    /* -------------------------------------------------------
       CHECK CATEGORY
    ------------------------------------------------------- */

    if (categoryId) {
      const category = await prisma.category.findUnique({
        where: {
          id: categoryId,
        },

        select: {
          id: true,
        },
      });

      if (!category) {
        return NextResponse.json(
          {
            error: "دسته‌بندی انتخاب‌شده پیدا نشد",
          },
          {
            status: 400,
          },
        );
      }
    }

    /* -------------------------------------------------------
       SORT ORDER
    ------------------------------------------------------- */

    const lastItem = await prisma.menuItem.findFirst({
      where: {
        parentId,
      },

      orderBy: {
        sortOrder: "desc",
      },

      select: {
        sortOrder: true,
      },
    });

    const sortOrder =
      typeof body.sortOrder === "number"
        ? body.sortOrder
        : (lastItem?.sortOrder ?? 0) + 1;

    /* -------------------------------------------------------
       CREATE
    ------------------------------------------------------- */

    const item = await prisma.menuItem.create({
      data: {
        title,

        href,

        parentId,

        type:
          typeof body.type === "string" &&
          body.type.trim()
            ? body.type.trim()
            : "LINK",

        icon:
          typeof body.icon === "string" &&
          body.icon.trim()
            ? body.icon.trim()
            : null,

        categoryId,

        sortOrder,

        active:
          typeof body.active === "boolean"
            ? body.active
            : true,

        showDesktop:
          typeof body.showDesktop === "boolean"
            ? body.showDesktop
            : true,

        showMobile:
          typeof body.showMobile === "boolean"
            ? body.showMobile
            : true,

        openInNewTab:
          typeof body.openInNewTab === "boolean"
            ? body.openInNewTab
            : false,

        megaMenu:
          typeof body.megaMenu === "boolean"
            ? body.megaMenu
            : false,
      },

      include: {
        category: {
          select: {
            id: true,
            name: true,
            slug: true,
          },
        },
      },
    });

    return NextResponse.json(item, {
      status: 201,
    });
  } catch (error) {
    console.error("[POST /api/admin/menu]", error);

    return NextResponse.json(
      {
        error: "Failed to create menu item",
      },
      {
        status: 500,
      },
    );
  }
}