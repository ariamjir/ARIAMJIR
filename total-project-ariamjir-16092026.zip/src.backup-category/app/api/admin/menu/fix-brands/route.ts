import { NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export async function POST() {
  try {
    const machinesMenu = await prisma.menuItem.findFirst({
      where: { title: "بازار ماشین‌آلات", parentId: null },
    });

    if (!machinesMenu) {
      return NextResponse.json(
        { success: false, message: "منوی بازار ماشین‌آلات یافت نشد" },
        { status: 404 }
      );
    }

    /* حذف نسخه‌های قبلی برندها */
    await prisma.menuItem.deleteMany({ where: { title: "برندها" } });

    const lastChild = await prisma.menuItem.findFirst({
      where: { parentId: machinesMenu.id },
      orderBy: { sortOrder: "desc" },
      select: { sortOrder: true },
    });
    const nextOrder = (lastChild?.sortOrder ?? 20) + 1;

    const created = await prisma.menuItem.create({
      data: {
        title: "برندها",
        href: "/brands",
        parentId: machinesMenu.id,
        type: "LINK",
        icon: "Building2",
        sortOrder: nextOrder,
        active: true,
        showDesktop: true,
        showMobile: true,
        openInNewTab: false,
        megaMenu: false,
      },
    });

    return NextResponse.json({
      success: true,
      created,
      parentTitle: machinesMenu.title,
      nextOrder,
    });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, message: error.message },
      { status: 500 }
    );
  }
}