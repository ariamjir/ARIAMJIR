import { NextRequest, NextResponse } from "next/server";

import { Prisma } from "@prisma/client";

import { prisma } from "@/lib/prisma";

import { machineSchema } from "@/modules/machine/schema";

/* ============================================================
   HELPERS
   ------------------------------------------------------------
   سه نقطهٔ سمیِ create/update را یک‌جا خنثی می‌کنند:
   - slug ناتمیز        → cleanSlug
   - enum به حروف بزرگ  → upper (ایمن در برابر null/تهی)
   - تاریخ شمسیِ غیرقابل parse → resolvePublishedAt
============================================================ */

function cleanSlug(s?: string): string {
  const cleaned = (s ?? "")
    .trim()
    .toLowerCase()
    .replace(/^-+|-+$/g, "")
    .replace(/-+/g, "-");

  return cleaned || `machine-${Date.now()}`;
}

function upper(v: string | null | undefined): string | null {
  return typeof v === "string" && v.length > 0
    ? v.toUpperCase()
    : null;
}

/* تاریخِ Step11 شمسی است (1403/05/15) و new Date() روی آن
   Invalid می‌سازد. پس publishedAt فقط هنگامِ انتشار = «الان»
   میلادی؛ در غیر این صورت null. */
function resolvePublishedAt(statusUpper: string | null): Date | null {
  return statusUpper === "PUBLISHED" ? new Date() : null;
}

/* ✅ اسلاگ یکتا — جلوگیری از خطای Unique constraint
   اگر اسلاگ قبلاً ثبت شده باشد، -2 / -3 / ... اضافه می‌کند
   و در نهایت یک fallback با timestamp دارد (هرگز loop نمی‌شود). */
async function uniqueMachineSlug(
  tx: any,
  base?: string
): Promise<string> {
  const clean = cleanSlug(base);

  for (let i = 0; i < 25; i++) {
    const candidate = i === 0 ? clean : `${clean}-${i + 1}`;

    const exists = await tx.machine.findUnique({
      where: { slug: candidate },
      select: { id: true },
    });

    if (!exists) return candidate;
  }

  return `${clean}-${Date.now()}`;
}

/* ============================================================
   GET — لیست ماشین‌آلات
============================================================ */

export async function GET() {
  try {
    const machines = await prisma.machine.findMany({
      orderBy: {
        createdAt: "desc",
      },

      include: {
        brand: true,
        category: true,
        specification: true,
        price: true,
        seo: true,
        images: {
          orderBy: {
            sortOrder: "asc",
          },
        },
        videos: {
          orderBy: {
            sortOrder: "asc",
          },
        },
        documents: true,
        features: {
          orderBy: {
            sortOrder: "asc",
          },
        },
      },
    });

    return NextResponse.json({
      success: true,
      data: machines,
    });
  } catch (error: any) {
    return NextResponse.json(
      {
        success: false,
        message: error.message,
      },
      {
        status: 500,
      }
    );
  }
}

/* ============================================================
   POST — ثبت ماشین جدید
   ------------------------------------------------------------
   کلِ عملیات داخل یک interactive transaction است.
   options انتهایی ({ timeout, maxWait }) صبرِ گرفتنِ
   connection را بیشتر می‌کند تا روی هاردِ کند، «Unable to
   start a transaction» نگیریم.
============================================================ */

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    const form = machineSchema.parse(body);

    const statusUpper = upper(form.status);

    const result = await prisma.$transaction(
      async (tx) => {
        /* ✅ اسلاگ یکتا — قبل از create بررسی می‌شود */
        const finalSlug = await uniqueMachineSlug(
          tx,
          form.slug || form.title
        );

        /* ========================================================
           MACHINE
        ======================================================== */
        const machine = await tx.machine.create({
          data: {
            title: form.title,

            slug: finalSlug,

            shortDescription: form.shortDescription ?? null,

            description: form.description ?? null,

            listingType: upper(form.listingType) as any,

            status: statusUpper as any,

            featured: form.featured,

            active: form.active,

            /* ✅ تاریخ شمسی هرگز به Date نمی‌رسد */
            publishedAt: resolvePublishedAt(statusUpper),

            /* ✅ connectها شرطی — undefined هرگز به Prisma نمی‌رسد */
            ...(form.sellerId
              ? { seller: { connect: { id: form.sellerId } } }
              : {}),

            ...(form.brandId
              ? { brand: { connect: { id: form.brandId } } }
              : {}),

            ...(form.categoryId
              ? { category: { connect: { id: form.categoryId } } }
              : {}),
          },
        });

        /* ========================================================
           SPECIFICATION
        ======================================================== */
        await tx.machineSpecification.create({
          data: {
            machineId: machine.id,

            model: form.model ?? null,

            serialNumber: form.serialNumber ?? null,

            manufactureYear: form.manufactureYear ?? null,

            condition: upper(form.condition) as any,

            engine: form.engine ?? null,

            enginePower: form.enginePower ?? null,

            operatingWeight: form.operatingWeight ?? null,

            bucketCapacity: form.bucketCapacity ?? null,

            workingHours: form.workingHours ?? null,

            fuelType: upper(form.fuelType) as any,

            /* ✅ یکدست با فرم و با PUT */
            transmission: upper(form.transmission) as any,

            driveType: upper(form.driveType) as any,

            color: form.color ?? null,

            countryId: form.country ?? null,

            provinceId: form.provinceId ?? null,

            cityId: form.cityId ?? null,

            location: form.address ?? null,
          },
        });

        /* ========================================================
           PRICE
        ======================================================== */
        await tx.machinePrice.create({
          data: {
            machineId: machine.id,

            price:
              form.price != null
                ? new Prisma.Decimal(form.price)
                : null,

            currency: upper(form.currency) as any,

            priceType: upper(form.priceType) as any,

            installment: form.installment,
          },
        });

        /* ========================================================
           SEO
        ======================================================== */
        await tx.machineSEO.create({
          data: {
            machineId: machine.id,

            metaTitle: form.metaTitle ?? null,

            metaDescription: form.metaDescription ?? null,

            keywords:
              form.metaKeywords.length > 0
                ? form.metaKeywords.join(",")
                : null,

            canonicalUrl: form.canonicalUrl ?? null,

            ogImage: form.openGraphImage ?? null,
          },
        });

        /* ========================================================
           FEATURES
        ======================================================== */
        for (let i = 0; i < form.features.length; i++) {
          await tx.machineFeature.create({
            data: {
              machineId: machine.id,

              title: form.features[i],

              value: null,

              sortOrder: i,
            },
          });
        }

        /* ========================================================
           IMAGES
        ======================================================== */
        for (let i = 0; i < form.gallery.length; i++) {
          await tx.machineImage.create({
            data: {
              machineId: machine.id,

              url: form.gallery[i],

              alt: form.title,

              sortOrder: i,

              isPrimary: i === 0,
            },
          });
        }

        /* ========================================================
           VIDEOS
        ======================================================== */
        for (let i = 0; i < form.videos.length; i++) {
          await tx.machineVideo.create({
            data: {
              machineId: machine.id,

              url: form.videos[i],

              sortOrder: i,
            },
          });
        }

        /* ========================================================
           DOCUMENTS
        ======================================================== */
        for (const file of form.documents) {
          await tx.machineDocument.create({
            data: {
              machineId: machine.id,

              title: "Document",

              fileUrl: file,

              fileType: "file",
            },
          });
        }

        return machine;
      },
      /* ✅ options transaction — بعد از callback، نه وسط آن */
      { timeout: 60000, maxWait: 30000 }
    );

    return NextResponse.json(
      {
        success: true,

        data: result,
      },
      {
        status: 201,
      }
    );
  } catch (error: any) {
    return NextResponse.json(
      {
        success: false,

        message: error.message,
      },
      {
        status: 400,
      }
    );
  }
}