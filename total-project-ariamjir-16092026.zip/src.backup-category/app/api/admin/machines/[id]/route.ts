import { NextRequest, NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";

import { Prisma } from "@prisma/client";

import { machineSchema } from "@/modules/machine/schema";

/* ============================================================
   HELPERS  (همان قراردادِ route اصلی)
============================================================ */

function cleanSlug(s?: string): string {
  const cleaned = (s ?? "")
    .trim()
    .toLowerCase()
    .replace(/^-+|-+$/g, "")
    .replace(/-+/g, "-");

  return cleaned || `machine-${Date.now()}`;
}

function upper(v: string | null | undefined): string | null {
  return typeof v === "string" && v.length > 0
    ? v.toUpperCase()
    : null;
}

function resolvePublishedAt(statusUpper: string | null): Date | null {
  return statusUpper === "PUBLISHED" ? new Date() : null;
}

type Context = {
  params: Promise<{
    id: string;
  }>;
};

/* ============================================================
   GET
============================================================ */

export async function GET(
  request: NextRequest,
  { params }: Context
) {
  try {
    const { id } = await params;

    const machine = await prisma.machine.findUnique({
      where: {
        id,
      },

      include: {
        brand: true,

        category: true,

        specification: true,

        price: true,

        seo: true,

        features: {
          orderBy: {
            sortOrder: "asc",
          },
        },

        images: {
          orderBy: {
            sortOrder: "asc",
          },
        },

        videos: {
          orderBy: {
            sortOrder: "asc",
          },
        },

        documents: true,
      },
    });

    if (!machine) {
      return NextResponse.json(
        {
          success: false,
          message: "Machine not found",
        },
        {
          status: 404,
        }
      );
    }

    return NextResponse.json(machine);
  } catch (error: any) {
    return NextResponse.json(
      {
        success: false,
        message: error.message,
      },
      {
        status: 500,
      }
    );
  }
}

/* ============================================================
   PUT
   ------------------------------------------------------------
   کلِ عملیات داخل یک interactive transaction است.
   options انتهایی ({ timeout, maxWait }) صبرِ گرفتنِ
   connection را بیشتر می‌کند.
============================================================ */

export async function PUT(
  request: NextRequest,
  { params }: Context
) {
  try {
    const { id } = await params;

    const body = await request.json();

    const form = machineSchema.parse(body);

    const statusUpper = upper(form.status);

    const result = await prisma.$transaction(
      async (tx) => {
        /* ========================================================
           UPDATE MACHINE
        ======================================================== */
        const machine = await tx.machine.update({
          where: {
            id,
          },

          data: {
            title: form.title,

            slug: cleanSlug(form.slug),

            shortDescription: form.shortDescription ?? null,

            description: form.description ?? null,

            listingType: upper(form.listingType) as any,

            status: statusUpper as any,

            featured: form.featured,

            active: form.active,

            /* ✅ تاریخ شمسی هرگز به Date نمی‌رسد */
            publishedAt: resolvePublishedAt(statusUpper),

            /* ✅ connectها شرطی */
            ...(form.sellerId
              ? { seller: { connect: { id: form.sellerId } } }
              : {}),

            ...(form.brandId
              ? { brand: { connect: { id: form.brandId } } }
              : {}),

            ...(form.categoryId
              ? { category: { connect: { id: form.categoryId } } }
              : {}),
          },
        });

        /* ========================================================
           SPECIFICATION
        ======================================================== */
        await tx.machineSpecification.upsert({
          where: {
            machineId: machine.id,
          },

          update: {
            model: form.model ?? null,

            serialNumber: form.serialNumber ?? null,

            manufactureYear: form.manufactureYear ?? null,

            condition: upper(form.condition) as any,

            engine: form.engine ?? null,

            enginePower: form.enginePower ?? null,

            operatingWeight: form.operatingWeight ?? null,

            bucketCapacity: form.bucketCapacity ?? null,

            workingHours: form.workingHours ?? null,

            fuelType: upper(form.fuelType) as any,

            transmission: upper(form.transmission) as any,

            driveType: upper(form.driveType) as any,

            color: form.color ?? null,

            /* ✅ کشور حالا واقعاً ذخیره می‌شود (قبلاً null قفل بود) */
            countryId: form.country ?? null,

            provinceId: form.provinceId ?? null,

            cityId: form.cityId ?? null,

            location: form.address ?? null,
          },

          create: {
            machineId: machine.id,

            model: form.model ?? null,

            serialNumber: form.serialNumber ?? null,

            manufactureYear: form.manufactureYear ?? null,

            condition: upper(form.condition) as any,

            engine: form.engine ?? null,

            enginePower: form.enginePower ?? null,

            operatingWeight: form.operatingWeight ?? null,

            bucketCapacity: form.bucketCapacity ?? null,

            workingHours: form.workingHours ?? null,

            fuelType: upper(form.fuelType) as any,

            transmission: upper(form.transmission) as any,

            driveType: upper(form.driveType) as any,

            color: form.color ?? null,

            countryId: form.country ?? null,

            provinceId: form.provinceId ?? null,

            cityId: form.cityId ?? null,

            location: form.address ?? null,
          },
        });

        /* ========================================================
           PRICE
        ======================================================== */
        await tx.machinePrice.upsert({
          where: {
            machineId: machine.id,
          },

          update: {
            price:
              form.price != null
                ? new Prisma.Decimal(form.price)
                : null,

            currency: upper(form.currency) as any,

            priceType: upper(form.priceType) as any,

            installment: form.installment,
          },

          create: {
            machineId: machine.id,

            price:
              form.price != null
                ? new Prisma.Decimal(form.price)
                : null,

            currency: upper(form.currency) as any,

            priceType: upper(form.priceType) as any,

            installment: form.installment,
          },
        });

        /* ========================================================
           SEO
        ======================================================== */
        await tx.machineSEO.upsert({
          where: {
            machineId: machine.id,
          },

          update: {
            metaTitle: form.metaTitle ?? null,

            metaDescription: form.metaDescription ?? null,

            keywords: form.metaKeywords.length
              ? form.metaKeywords.join(",")
              : null,

            canonicalUrl: form.canonicalUrl ?? null,

            ogImage: form.openGraphImage ?? null,

            schemaMarkup: Prisma.JsonNull,
          },

          create: {
            machineId: machine.id,

            metaTitle: form.metaTitle ?? null,

            metaDescription: form.metaDescription ?? null,

            keywords: form.metaKeywords.length
              ? form.metaKeywords.join(",")
              : null,

            canonicalUrl: form.canonicalUrl ?? null,

            ogImage: form.openGraphImage ?? null,

            schemaMarkup: Prisma.JsonNull,
          },
        });

        /* ========================================================
           FEATURES
        ======================================================== */
        await tx.machineFeature.deleteMany({
          where: {
            machineId: machine.id,
          },
        });

        if (form.features.length) {
          await tx.machineFeature.createMany({
            data: form.features.map((feature, index) => ({
              machineId: machine.id,

              title: feature,

              value: null,

              sortOrder: index,
            })),
          });
        }

        /* ========================================================
           IMAGES
        ======================================================== */
        await tx.machineImage.deleteMany({
          where: {
            machineId: machine.id,
          },
        });

        if (form.gallery.length) {
          await tx.machineImage.createMany({
            data: form.gallery.map((image, index) => ({
              machineId: machine.id,

              url: image,

              alt: form.title,

              sortOrder: index,

              isPrimary: index === 0,
            })),
          });
        }

        /* ========================================================
           VIDEOS
        ======================================================== */
        await tx.machineVideo.deleteMany({
          where: {
            machineId: machine.id,
          },
        });

        if (form.videos.length) {
          await tx.machineVideo.createMany({
            data: form.videos.map((video, index) => ({
              machineId: machine.id,

              url: video,

              sortOrder: index,
            })),
          });
        }

        /* ========================================================
           DOCUMENTS
        ======================================================== */
        await tx.machineDocument.deleteMany({
          where: {
            machineId: machine.id,
          },
        });

        if (form.documents.length) {
          await tx.machineDocument.createMany({
            data: form.documents.map((doc) => ({
              machineId: machine.id,

              title: "Document",

              fileUrl: doc,

              fileType: "file",
            })),
          });
        }

        return machine;
      },
      /* ✅ options transaction — بعد از callback، نه وسط آن */
      { timeout: 60000, maxWait: 30000 }
    );

    return NextResponse.json(result);
  } catch (error: any) {
    return NextResponse.json(
      {
        success: false,
        message: error.message,
      },
      {
        status: 400,
      }
    );
  }
}

/* ============================================================
   DELETE
============================================================ */

export async function DELETE(
  request: NextRequest,
  { params }: Context
) {
  const { id } = await params;

  await prisma.machine.delete({
    where: {
      id,
    },
  });

  return NextResponse.json({
    success: true,
  });
}