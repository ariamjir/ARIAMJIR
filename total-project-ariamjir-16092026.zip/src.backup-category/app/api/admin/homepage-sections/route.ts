import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
  try {
    const sections = await prisma.homePageSection.findMany({
      orderBy: { order: "asc" },
    });

    return NextResponse.json({ success: true, data: sections });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, message: error.message },
      { status: 500 }
    );
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();

    if (!Array.isArray(body)) {
      return NextResponse.json(
        { success: false, message: "Invalid payload" },
        { status: 400 }
      );
    }

    await prisma.$transaction(
      body.map((item: any) =>
        prisma.homePageSection.update({
          where: { id: item.id },
          data: {
            order: item.order,
            active: item.active,
            title: item.title,
            subtitle: item.subtitle,
            description: item.description,
            config: item.config ?? {},
          },
        })
      )
    );

    return NextResponse.json({ success: true });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, message: error.message },
      { status: 500 }
    );
  }
}