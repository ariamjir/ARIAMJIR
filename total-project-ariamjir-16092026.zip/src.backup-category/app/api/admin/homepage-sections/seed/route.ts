import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

const DEFAULT_SECTIONS = [
  {
    key: "hero",
    title: "بنر اصلی (Hero)",
    subtitle: "HERO",
    description: "بنر بزرگ بالای صفحه اول",
    order: 1,
    active: true,
    type: "client",
    config: {
      headline: "بزرگ‌ترین مارکت‌پلیس ماشین‌آلات سنگین",
      subheadline: "خرید، فروش و اجاره ماشین‌آلات راهسازی، معدنی و صنعتی با تضمین آریا",
      primaryCta: { text: "مشاهده آگهی‌ها", url: "/machines" },
      secondaryCta: { text: "فروش ویژه آریا", url: "/machines/new?program=PREMIUM" },
    },
  },
  {
    key: "exclusive-sale",
    title: "فروش ویژهٔ آریا",
    subtitle: "ARIA MJ EXCLUSIVE SALE",
    description: "هدف ما فروش دستگاه شما در کمتر از ۷ روز است — با کارشناسی رسمی، ارزش‌گذاری تخصصی و قرارداد تضمینی.",
    order: 2,
    active: true,
    type: "client",
    config: {
      ctaText: "ثبت دستگاه در فروش ویژه",
      ctaUrl: "/machines/new?program=PREMIUM",
      trustChips: ["کارشناسی فنی", "کارشناسی حقوقی", "ارزش‌گذاری رسمی", "مالک تأییدشده", "آماده انتقال"],
      steps: [
        { num: "۰۱", fa: "ثبت دستگاه و تأیید رزرو", en: "Register & Reserve", desc: "فرم کامل دستگاه را ثبت کنید؛ پس از بررسی اولیه، رزرو شما تأیید می‌شود." },
        { num: "۰۲", fa: "کارشناسی حقوقی، فنی و بدنه", en: "Inspection", desc: "کارشناسان آریا در سراسر کشور، دستگاه را بازدید و گزارش سه‌گانه ثبت می‌کنند." },
        { num: "۰۳", fa: "ارزش‌گذاری و اعلام قیمت", en: "Valuation", desc: "قیمت کارشناسی‌شده اعلام و پس از توافق، مبنای فروش قرار می‌گیرد." },
        { num: "۰۴", fa: "عقد قرارداد و تسویه", en: "Contract & Settlement", desc: "قرارداد رسمی، عکاسی حرفه‌ای، انتشار انحصاری و تسویهٔ شفاف." },
      ],
    },
  },
  {
    key: "verified-machines",
    title: "ماشین‌آلات تأییدشدهٔ آریا",
    subtitle: "ARIA VERIFIED MACHINES",
    description: "دستگاه‌های کارشناسی‌شده، ارزش‌گذاری‌شده و تضمینی از مسیر فروش ویژهٔ ARIA MJ.",
    order: 3,
    active: true,
    type: "server",
    config: { limit: 8 },
  },
  {
    key: "latest-ads",
    title: "آخرین آگهی‌ها",
    subtitle: "LATEST MACHINES",
    description: "جدیدترین ماشین‌آلات ثبت‌شده در آریا.",
    order: 4,
    active: true,
    type: "client",
    config: { limit: 8 },
  },
  {
    key: "categories",
    title: "دسته‌بندی ماشین‌آلات",
    subtitle: "CATEGORIES",
    description: "ماشین‌آلات موردنظر خود را بر اساس گروه‌های تخصصی انتخاب کنید.",
    order: 5,
    active: true,
    type: "client",
    config: { ringMax: 18 },
  },
  {
    key: "services",
    title: "خدمات صنعتی",
    subtitle: "INDUSTRIAL SERVICES",
    description: "تعمیرات، کارشناسی، آموزش و سایر خدمات تخصصی.",
    order: 6,
    active: true,
    type: "client",
    config: {},
  },
  {
    key: "brands",
    title: "برندهای معتبر",
    subtitle: "TOP BRANDS",
    description: "بزرگ‌ترین برندهای سازنده ماشین‌آلات سنگین.",
    order: 7,
    active: true,
    type: "client",
    config: { limit: 12 },
  },
  {
    key: "latest-news",
    title: "اخبار و مقالات",
    subtitle: "LATEST NEWS",
    description: "تازه‌ترین اخبار صنعت ماشین‌آلات و مقالات آموزشی.",
    order: 8,
    active: true,
    type: "client",
    config: { limit: 3 },
  },
  {
    key: "knowledge",
    title: "پایگاه دانش",
    subtitle: "KNOWLEDGE BASE",
    description: "راهنماها، استانداردها و مستندات فنی.",
    order: 9,
    active: true,
    type: "client",
    config: {},
  },
  {
    key: "why-us",
    title: "چرا آریا؟",
    subtitle: "WHY CHOOSE US",
    description: "مزایای استفاده از مارکت‌پلیس آریا.",
    order: 10,
    active: true,
    type: "client",
    config: {},
  },
];

export async function POST() {
  try {
    let created = 0;

    for (const section of DEFAULT_SECTIONS) {
      await prisma.homePageSection.upsert({
        where: { key: section.key },
        update: {},
        create: {
          key: section.key,
          title: section.title,
          subtitle: section.subtitle,
          description: section.description,
          order: section.order,
          active: section.active,
          type: section.type,
          config: section.config as any,
        },
      });
      created++;
    }

    return NextResponse.json({
      success: true,
      message: `✅ Seed complete: ${created} sections processed.`,
    });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, message: error.message },
      { status: 500 }
    );
  }
}