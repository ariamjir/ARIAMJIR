import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { ariaCategoryTree } from "@/modules/category/data/ariaStandard";
import { flattenCategoryTree } from "@/modules/category/data/categoryTree";

function errMsg(e: unknown): string {
  if (e instanceof Error) return e.message.split("\n")[0];
  return String(e);
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const wipe = searchParams.get("wipe") === "true";

    const result = { created: 0, skipped: 0, errors: [] as string[] };

    if (wipe) {
      await prisma.category.deleteMany({});
    }

    const flat = flattenCategoryTree(ariaCategoryTree);

    for (const cat of flat) {
      try {
        await prisma.category.upsert({
          where: { id: cat.id },
          update: {
            parentId: cat.parentId,
            name: cat.name,
            nameEn: cat.nameEn,
            code: cat.code,
            slug: cat.slug,
            description: cat.description,
            icon: cat.icon,
            sortOrder: cat.sortOrder,
            level: cat.level,
            active: cat.active,
            featured: cat.featured,
            showInMenu: cat.showInMenu,
            showOnHomepage: cat.showOnHomepage,
            domain: cat.domain,
          },
          create: {
            id: cat.id,
            parentId: cat.parentId,
            name: cat.name,
            nameEn: cat.nameEn,
            code: cat.code,
            slug: cat.slug,
            description: cat.description,
            icon: cat.icon,
            sortOrder: cat.sortOrder,
            level: cat.level,
            active: cat.active,
            featured: cat.featured,
            showInMenu: cat.showInMenu,
            showOnHomepage: cat.showOnHomepage,
            domain: cat.domain,
          },
        });
        result.created++;
      } catch (e) {
        const msg = errMsg(e);
        if (/unique|constraint/i.test(msg)) {
          result.skipped++;
        } else {
          result.errors.push(`${cat.id}: ${msg}`);
        }
      }
    }

    return NextResponse.json({
      success: result.errors.length === 0,
      wipe,
      total: flat.length,
      ...result,
    });
  } catch (e) {
    return NextResponse.json(
      { success: false, error: errMsg(e) },
      { status: 500 }
    );
  }
}