import { NextRequest, NextResponse } from "next/server";

export async function GET() {
  const { prisma } = await import("@/lib/prisma");
  const row = await prisma.homePageSection.findFirst({ where: { key: "ai-knowledge" } });
  return NextResponse.json({ success: true, data: (row?.config as any) ?? { enabled: true } });
}

export async function PUT(request: NextRequest) {
  const { prisma } = await import("@/lib/prisma");
  const body = await request.json();

  const row = await prisma.homePageSection.findFirst({ where: { key: "ai-knowledge" } });
  if (row) {
    await prisma.homePageSection.update({ where: { id: row.id }, data: { config: body } });
  } else {
    await prisma.homePageSection.create({
      data: { key: "ai-knowledge", title: "نویسندهٔ AI دانش", order: 91, active: true, config: body },
    });
  }

  return NextResponse.json({ success: true });
}

/* تولید دستی از پنل */
export async function POST() {
  const res = await fetch("http://localhost:3000/api/cron/generate-knowledge?force=1", { method: "POST" });
  const j = await res.json().catch(() => ({}));
  return NextResponse.json(j);
}