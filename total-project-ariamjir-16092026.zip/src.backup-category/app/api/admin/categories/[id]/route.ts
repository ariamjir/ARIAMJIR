import { NextRequest, NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";

interface Params {
  params: Promise<{
    id: string;
  }>;
}

/* ============================================================
   HELPERS  (استاندارد سایت‌های بزرگ)
============================================================ */

// تولید slug معتبر از نام
function generateSlug(name: string): string {
  return name
    .trim()
    .toLowerCase()
    .replace(/\s+/g, "-")
    .replace(/[^a-z0-9-]/g, "")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "");
}

// ✅ هماهنگ با Prisma (String?) — همیشه رشته یا null
function normalizeKeywords(
  value: unknown
): string | null {
  if (Array.isArray(value)) {
    const joined = value
      .map((item) => String(item).trim())
      .filter(Boolean)
      .join(", ");

    return joined || null;
  }

  if (typeof value === "string") {
    return value.trim() || null;
  }

  return null;
}

// serializer مشترک — شکل یکسان پاسخ
function mapCategory(category: any) {
  return {
    id: category.id,

    parentId: category.parentId,

    parent: category.parent
      ? {
          id: category.parent.id,
          name: category.parent.name,
          slug: category.parent.slug,
        }
      : null,

    name: category.name,

    slug: category.slug,

    icon: category.icon,

    image: category.image,

    description: category.description,

    sortOrder: category.sortOrder,

    active: category.active,

    featured: category.featured,

    showInMenu: category.showInMenu,

    showOnHomepage: category.showOnHomepage,

    metaTitle: category.metaTitle,

    metaDescription: category.metaDescription,

    keywords: category.keywords,

    createdAt: category.createdAt,

    updatedAt: category.updatedAt,

    machinesCount:
      category._count.machines,

    activeMachinesCount:
      category.machines?.length ?? 0,

    childrenCount:
      category.children.length,
  };
}

// جلوگیری از circular reference — آیا nodeId نوادهٔ ancestorId است؟
async function isDescendant(
  ancestorId: string,
  nodeId: string
): Promise<boolean> {
  let currentId: string | null = nodeId;

  while (currentId) {
    if (currentId === ancestorId) {
      return true;
    }

    // ✅ type annotation صریح — رفع خطای 7022
    const node: {
      parentId: string | null;
    } | null =
      await prisma.category.findUnique({
        where: {
          id: currentId,
        },
        select: {
          parentId: true,
        },
      });

    currentId = node?.parentId ?? null;
  }

  return false;
}

// ✅ شمارش محافظتی — اگر مدل/ریشن در schema نبود، crash نمی‌کند
async function safeCount(
  modelName: string,
  where: Record<string, unknown>
): Promise<number> {
  try {
    const model = (prisma as any)[modelName];

    if (
      model &&
      typeof model.count === "function"
    ) {
      return (await model.count({ where })) ?? 0;
    }
  } catch (err) {
    console.warn(
      `[safeCount] ${modelName} check skipped:`,
      err
    );
  }

  return 0;
}

/* ============================================================
   GET
============================================================ */

export async function GET(
  request: NextRequest,
  { params }: Params
) {
  try {
    const { id } = await params;

    const category =
      await prisma.category.findUnique({
        where: {
          id,
        },

        include: {
          parent: {
            select: {
              id: true,
              name: true,
              slug: true,
            },
          },

          children: {
            select: {
              id: true,
            },
          },

          machines: {
            where: {
              active: true,
            },
            select: {
              id: true,
            },
          },

          _count: {
            select: {
              machines: true,
            },
          },
        },
      });

    if (!category) {
      return NextResponse.json(
        {
          error:
            "Category not found",
        },
        {
          status: 404,
        }
      );
    }

    return NextResponse.json(
      mapCategory(category)
    );
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      {
        error: "Load failed",
        details:
          error instanceof Error
            ? error.message
            : String(error),
      },
      {
        status: 500,
      }
    );
  }
}

/* ============================================================
   PUT  (با اعتبارسنجی کامل — مشابه سایت‌های بزرگ)
============================================================ */

export async function PUT(
  request: NextRequest,
  { params }: Params
) {
  try {
    const { id } = await params;

    const body =
      await request.json();

    /* -----------------------------
       CHECK EXISTS (404)
    ----------------------------- */

    const existing =
      await prisma.category.findUnique({
        where: {
          id,
        },
        select: {
          id: true,
          slug: true,
        },
      });

    if (!existing) {
      return NextResponse.json(
        {
          error:
            "Category not found",
        },
        {
          status: 404,
        }
      );
    }

    /* -----------------------------
       SLUG VALIDATION + DUPLICATE (409)
    ----------------------------- */

    if (body.slug !== undefined) {
      const newSlug =
        body.slug.trim();

      if (
        newSlug &&
        !/^[a-z0-9-]+$/.test(newSlug)
      ) {
        return NextResponse.json(
          {
            error:
              "Slug نامعتبر است. فقط حروف انگلیسی کوچک، عدد و - مجاز است.",
          },
          {
            status: 400,
          }
        );
      }

      if (newSlug && newSlug !== existing.slug) {
        const duplicate =
          await prisma.category.findFirst({
            where: {
              slug: newSlug,
              NOT: {
                id,
              },
            },
            select: {
              id: true,
            },
          });

        if (duplicate) {
          return NextResponse.json(
            {
              error:
                "این Slug قبلاً استفاده شده است.",
            },
            {
              status: 409,
            }
          );
        }
      }
    }

    /* -----------------------------
       PARENT VALIDATION + CIRCULAR CHECK
    ----------------------------- */

    if (body.parentId !== undefined) {
      const newParentId =
        body.parentId || null;

      // دسته نمی‌تواند والد خودش باشد
      if (newParentId === id) {
        return NextResponse.json(
          {
            error:
              "دسته نمی‌تواند والد خودش باشد.",
          },
          {
            status: 400,
          }
        );
      }

      if (newParentId) {
        // والد باید وجود داشته باشد
        const parent =
          await prisma.category.findUnique({
            where: {
              id: newParentId,
            },
            select: {
              id: true,
            },
          });

        if (!parent) {
          return NextResponse.json(
            {
              error:
                "دستهٔ والد یافت نشد.",
            },
            {
              status: 400,
            }
          );
        }

        // جلوگیری از circular reference
        const circular =
          await isDescendant(id, newParentId);

        if (circular) {
          return NextResponse.json(
            {
              error:
                "والد انتخاب‌شده زیرمجموعهٔ این دسته است و باعث ایجاد چرخه می‌شود.",
            },
            {
              status: 400,
            }
          );
        }
      }
    }

    /* -----------------------------
       UPDATE
    ----------------------------- */

    const category =
      await prisma.category.update({
        where: {
          id,
        },

        data: {
          ...(body.parentId !==
            undefined && {
            parentId:
              body.parentId || null,
          }),

          ...(body.name !==
            undefined && {
            name: body.name.trim(),
          }),

          ...(body.slug !==
            undefined && {
            slug: body.slug.trim(),
          }),

          ...(body.icon !==
            undefined && {
            icon: body.icon,
          }),

          ...(body.image !==
            undefined && {
            image: body.image,
          }),

          ...(body.description !==
            undefined && {
            description:
              body.description,
          }),

          ...(body.sortOrder !==
            undefined && {
            sortOrder: Number(
              body.sortOrder
            ),
          }),

          ...(body.active !==
            undefined && {
            active:
              body.active,
          }),

          ...(body.featured !==
            undefined && {
            featured:
              body.featured,
          }),

          ...(body.showInMenu !==
            undefined && {
            showInMenu:
              body.showInMenu,
          }),

          ...(body.showOnHomepage !==
            undefined && {
            showOnHomepage:
              body.showOnHomepage,
          }),

          ...(body.metaTitle !==
            undefined && {
            metaTitle:
              body.metaTitle,
          }),

          ...(body.metaDescription !==
            undefined && {
            metaDescription:
              body.metaDescription,
          }),

          // ✅ هماهنگ با Prisma (String?) — رشته یا null
          ...(body.keywords !==
            undefined && {
            keywords:
              normalizeKeywords(
                body.keywords
              ),
          }),
        },

        include: {
          parent: {
            select: {
              id: true,
              name: true,
              slug: true,
            },
          },

          children: {
            select: {
              id: true,
            },
          },

          machines: {
            where: {
              active: true,
            },
            select: {
              id: true,
            },
          },

          _count: {
            select: {
              machines: true,
            },
          },
        },
      });

    return NextResponse.json(
      mapCategory(category)
    );
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      {
        error: "Update failed",
        details:
          error instanceof Error
            ? error.message
            : String(error),
      },
      {
        status: 500,
      }
    );
  }
}

/* ============================================================
   DELETE
============================================================ */

export async function DELETE(
  request: NextRequest,
  { params }: Params
) {
  try {
    const { id } = await params;

    /* -----------------------------
       CHECK EXISTS (404)
    ----------------------------- */

    const existing =
      await prisma.category.findUnique({
        where: {
          id,
        },
        select: {
          id: true,
        },
      });

    if (!existing) {
      return NextResponse.json(
        {
          error:
            "Category not found",
        },
        {
          status: 404,
        }
      );
    }

    /* -----------------------------
       CHECK CHILDREN
    ----------------------------- */

    const children =
      await prisma.category.count({
        where: {
          parentId: id,
        },
      });

    if (children > 0) {
      return NextResponse.json(
        {
          error:
            "این دسته دارای زیردسته است و قابل حذف نیست.",
        },
        {
          status: 400,
        }
      );
    }

    /* -----------------------------
       CHECK MACHINES
    ----------------------------- */

    const machines =
      await prisma.machine.count({
        where: {
          categoryId: id,
        },
      });

    if (machines > 0) {
      return NextResponse.json(
        {
          error:
            "این دسته به ماشین‌آلات اختصاص یافته و قابل حذف نیست.",
        },
        {
          status: 400,
        }
      );
    }

    /* -----------------------------
       ✅ CHECK PRODUCTS — محافظتی
       اگر مدل Product یا ریشن categoryId
       در schema نباشد، crash نمی‌کند.
    ----------------------------- */

    const products =
      await safeCount("product", {
        categoryId: id,
      });

    if (products > 0) {
      return NextResponse.json(
        {
          error:
            "این دسته به محصولات اختصاص یافته و قابل حذف نیست.",
        },
        {
          status: 400,
        }
      );
    }

    /* -----------------------------
       DELETE
    ----------------------------- */

    await prisma.category.delete({
      where: {
        id,
      },
    });

    return NextResponse.json({
      success: true,
    });
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      {
        error: "Delete failed",
        // ✅ پیام واقعی خطا — برای دیباگ
        details:
          error instanceof Error
            ? error.message
            : String(error),
      },
      {
        status: 500,
      }
    );
  }
}