import { NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";

/* ============================================================
   HELPERS  (استاندارد سایت‌های بزرگ — serializer و نرمال‌سازی)
============================================================ */

// تولید slug معتبر از نام (مشابه MachineryTrader / Mascus)
function generateSlug(name: string): string {
  return name
    .trim()
    .toLowerCase()
    .replace(/\s+/g, "-")
    .replace(/[^a-z0-9-]/g, "")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "");
}

// ✅ هماهنگ با Prisma (String?) — همیشه رشته یا null برمی‌گرداند
function normalizeKeywords(
  value: unknown
): string | null {
  if (Array.isArray(value)) {
    const joined = value
      .map((item) => String(item).trim())
      .filter(Boolean)
      .join(", ");

    return joined || null;
  }

  if (typeof value === "string") {
    return value.trim() || null;
  }

  return null;
}

// serializer مشترک — حذف تکرار و تضمین شکل یکسان پاسخ
function mapCategory(category: any) {
  return {
    id: category.id,

    parentId: category.parentId,

    name: category.name,

    slug: category.slug,

    icon: category.icon,

    image: category.image,

    description: category.description,

    sortOrder: category.sortOrder,

    active: category.active,

    featured: category.featured,

    showInMenu: category.showInMenu,

    showOnHomepage: category.showOnHomepage,

    metaTitle: category.metaTitle,

    metaDescription: category.metaDescription,

    keywords: category.keywords,

    createdAt: category.createdAt,

    updatedAt: category.updatedAt,

    machinesCount:
      category._count.machines,

    activeMachinesCount:
      category.machines?.length ?? 0,

    childrenCount:
      category.children.length,
  };
}

/* ============================================================
   GET  (با فیلتر، جستجو و مرتب‌سازی — مشابه سایت‌های بزرگ)
============================================================ */

export async function GET(
  request: Request
) {
  try {
    const { searchParams } =
      new URL(request.url);

    /* -----------------------------
       FILTERS
    ----------------------------- */

    const active =
      searchParams.get("active");

    const featured =
      searchParams.get("featured");

    const parentId =
      searchParams.get("parentId");

    const rootOnly =
      searchParams.get("rootOnly");

    const showInMenu =
      searchParams.get("showInMenu");

    const showOnHomepage =
      searchParams.get("showOnHomepage");

    const keyword =
      searchParams.get("keyword");

    /* -----------------------------
       SORTING
    ----------------------------- */

    const sortBy =
      searchParams.get("sortBy") ||
      "sortOrder";

    const order =
      searchParams.get("order") || "asc";

    const allowedSortFields = [
      "sortOrder",
      "name",
      "createdAt",
      "updatedAt",
    ];

    const sortField =
      allowedSortFields.includes(sortBy)
        ? sortBy
        : "sortOrder";

    const sortDirection =
      order === "desc" ? "desc" : "asc";

    /* -----------------------------
       BUILD WHERE
    ----------------------------- */

    const where: any = {};

    if (active === "true" || active === "false") {
      where.active = active === "true";
    }

    if (featured === "true" || featured === "false") {
      where.featured = featured === "true";
    }

    if (
      showInMenu === "true" ||
      showInMenu === "false"
    ) {
      where.showInMenu =
        showInMenu === "true";
    }

    if (
      showOnHomepage === "true" ||
      showOnHomepage === "false"
    ) {
      where.showOnHomepage =
        showOnHomepage === "true";
    }

    if (rootOnly === "true") {
      where.parentId = null;
    } else if (parentId) {
      where.parentId = parentId;
    }

    if (keyword) {
      where.OR = [
        {
          name: {
            contains: keyword,
            mode: "insensitive",
          },
        },
        {
          slug: {
            contains: keyword,
            mode: "insensitive",
          },
        },
        {
          description: {
            contains: keyword,
            mode: "insensitive",
          },
        },
      ];
    }

    /* -----------------------------
       QUERY
    ----------------------------- */

    const categories =
      await prisma.category.findMany({
        where,

        orderBy: [
          {
            [sortField]: sortDirection,
          },
          {
            name: "asc",
          },
        ],

        include: {
          children: {
            select: {
              id: true,
            },
          },

          // ماشین‌آلات فعال (برای شمارش آگهی‌های زنده)
          machines: {
            where: {
              active: true,
            },
            select: {
              id: true,
            },
          },

          // شمارش کل ماشین‌آلات
          _count: {
            select: {
              machines: true,
            },
          },
        },
      });

    return NextResponse.json(
      categories.map(mapCategory)
    );
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      {
        error:
          "Failed to load categories",
      },
      {
        status: 500,
      }
    );
  }
}

/* ============================================================
   POST  (با اعتبارسنجی کامل — مشابه سایت‌های بزرگ)
============================================================ */

export async function POST(
  request: Request
) {
  try {
    const body =
      await request.json();

    /* -----------------------------
       VALIDATION: NAME
    ----------------------------- */

    if (
      !body.name ||
      body.name.trim().length < 2
    ) {
      return NextResponse.json(
        {
          error:
            "نام دسته‌بندی الزامی است (حداقل ۲ کاراکتر).",
        },
        {
          status: 400,
        }
      );
    }

    /* -----------------------------
       SLUG (تولید خودکار یا اعتبارسنجی)
    ----------------------------- */

    const slug =
      body.slug?.trim() ||
      generateSlug(body.name);

    if (!/^[a-z0-9-]+$/.test(slug)) {
      return NextResponse.json(
        {
          error:
            "Slug نامعتبر است. فقط حروف انگلیسی کوچک، عدد و - مجاز است.",
        },
        {
          status: 400,
        }
      );
    }

    /* -----------------------------
       DUPLICATE CHECK (409 Conflict)
    ----------------------------- */

    const existing =
      await prisma.category.findFirst({
        where: {
          slug,
        },
        select: {
          id: true,
        },
      });

    if (existing) {
      return NextResponse.json(
        {
          error:
            "این Slug قبلاً استفاده شده است.",
        },
        {
          status: 409,
        }
      );
    }

    /* -----------------------------
       PARENT CHECK
    ----------------------------- */

    if (body.parentId) {
      const parent =
        await prisma.category.findFirst({
          where: {
            id: body.parentId,
          },
          select: {
            id: true,
          },
        });

      if (!parent) {
        return NextResponse.json(
          {
            error:
              "دستهٔ والد یافت نشد.",
          },
          {
            status: 400,
          }
        );
      }
    }

    /* -----------------------------
       CREATE
    ----------------------------- */

    const category =
      await prisma.category.create({
        data: {
          parentId:
            body.parentId ?? null,

          name: body.name.trim(),

          slug,

          icon:
            body.icon ?? null,

          image:
            body.image ?? null,

          description:
            body.description ?? null,

          sortOrder:
            Number(body.sortOrder) || 0,

          active:
            body.active ?? true,

          featured:
            body.featured ?? false,

          showInMenu:
            body.showInMenu ?? true,

          showOnHomepage:
            body.showOnHomepage ?? false,

          metaTitle:
            body.metaTitle ?? null,

          metaDescription:
            body.metaDescription ?? null,

          // ✅ هماهنگ با Prisma (String?) — رشته یا null
          keywords:
            normalizeKeywords(
              body.keywords
            ),
        },

        include: {
          children: {
            select: {
              id: true,
            },
          },

          machines: {
            where: {
              active: true,
            },
            select: {
              id: true,
            },
          },

          _count: {
            select: {
              machines: true,
            },
          },
        },
      });

    return NextResponse.json(
      mapCategory(category),
      {
        status: 201,
      }
    );
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      {
        error:
          "Failed to create category",
      },
      {
        status: 500,
      }
    );
  }
}