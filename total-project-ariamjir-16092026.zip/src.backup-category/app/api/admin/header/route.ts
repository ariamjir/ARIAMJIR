import { NextRequest, NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";

import { mergeHeaderConfig } from "@/lib/header-config";

export async function GET() {
  try {
    const row = await prisma.homePageSection.findFirst({
      where: { key: "header" },
    });

    return NextResponse.json({
      success: true,
      data: mergeHeaderConfig(row?.config),
    });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, message: error.message },
      { status: 500 }
    );
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();

    const existing = await prisma.homePageSection.findFirst({
      where: { key: "header" },
    });

    if (existing) {
      await prisma.homePageSection.update({
        where: { id: existing.id },
        data: { config: body },
      });
    } else {
      await prisma.homePageSection.create({
        data: {
          key: "header",
          title: "هدر سایت",
          order: 0,
          active: true,
          config: body,
        },
      });
    }

    return NextResponse.json({ success: true });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, message: error.message },
      { status: 500 }
    );
  }
}