import { NextRequest, NextResponse } from "next/server";
import { getProducts, createProduct } from "@/lib/product";

export async function GET() {
  const products = await getProducts();
  return NextResponse.json(products);
}

export async function POST(req: NextRequest) {
  const body = await req.json();

  const product = await createProduct({
    title: body.title,
    slug: body.slug,
    description: body.description,
    categoryId: body.categoryId ?? null,
    brandId: body.brandId ?? null,
    price: body.price ? Number(body.price) : undefined,
    stock: body.stock ? Number(body.stock) : 0,
    image: body.image,
    featured: body.featured,
    active: body.active,
  });

  return NextResponse.json(product);
}

