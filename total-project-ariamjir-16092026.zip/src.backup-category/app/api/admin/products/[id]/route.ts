import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

type Context = {
  params: Promise<{
    id: string;
  }>;
};

export async function GET(
  req: NextRequest,
  context: Context
) {
  const { id } = await context.params;

  const product = await prisma.product.findUnique({
    where: { id },
  });

  if (!product) {
    return NextResponse.json(
      { error: "Not found" },
      { status: 404 }
    );
  }

  return NextResponse.json(product);
}

export async function PUT(
  req: NextRequest,
  context: Context
) {
  const { id } = await context.params;

  const body = await req.json();

  const product = await prisma.product.update({
    where: { id },
    data: {
      title: body.title,
      slug: body.slug,
      description: body.description ?? "",
      image: body.image ?? null,
      price:
        body.price === "" || body.price == null
          ? null
          : Number(body.price),
      active: body.active ?? true,
    },
  });

  return NextResponse.json(product);
}

export async function DELETE(
  req: NextRequest,
  context: Context
) {
  const { id } = await context.params;

  await prisma.product.delete({
    where: { id },
  });

  return NextResponse.json({
    success: true,
  });
}