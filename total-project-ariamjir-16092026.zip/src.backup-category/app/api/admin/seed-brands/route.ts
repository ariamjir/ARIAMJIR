import { NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";

import { machineBrands } from "@/modules/machine/data/brands";

import { machineCategories } from "@/modules/machine/data/machineCategories";

export const dynamic = "force-dynamic";

/* ============================================================
   Seed برندها و دسته‌های استاتیک به دیتابیس
   ------------------------------------------------------------
   id را دقیقاً برابر id استاتیک می‌گذاریم تا connect در
   Step13 موفق شود. upsert روی id → تکرارش بی‌ضرر است.
   update: {} → رکوردِ موجود (دستی) دست نمی‌خورد.

   توجه: مدل Brand فیلد sortOrder ندارد (برخلاف Category)،
   پس در create برند آن را نمی‌آوریم.
============================================================ */

/* پیام خطا را کامل برمی‌گرداند (نه فقط خط اولِ خالی) */
function errMsg(e: unknown): string {
  const raw = e instanceof Error ? e.message : String(e);
  return raw.replace(/\s+/g, " ").trim().slice(0, 400) || "(no message)";
}

export async function GET() {
  const result = {
    brands: { ok: 0, skipped: 0, errors: [] as string[] },
    categories: { ok: 0, skipped: 0, errors: [] as string[] },
  };

  /* ---------- BRANDS  (بدون sortOrder) ---------- */
  for (let i = 0; i < machineBrands.length; i++) {
    const b = machineBrands[i] as any;
    const id = String(b.id ?? b.slug);
    const name = String(b.name ?? b.nameFa ?? id);
    const slug = String(b.slug ?? id);

    try {
      await prisma.brand.upsert({
        where: { id },
        update: {},
        create: {
          id,
          name,
          slug,
          active: true,
        },
      });
      result.brands.ok++;
    } catch (e) {
      const msg = errMsg(e);
      if (/unique|constraint|already/i.test(msg)) {
        result.brands.skipped++;
      } else {
        result.brands.errors.push(`${id}: ${msg}`);
      }
    }
  }

  /* ---------- CATEGORIES  (sortOrder دارد → موفق) ---------- */
  const cats = (machineCategories as any[]) ?? [];
  for (let i = 0; i < cats.length; i++) {
    const c = cats[i];
    const id = String(c.id ?? c.value ?? c.slug);
    const name = String(c.title ?? c.name ?? c.label ?? id);
    const slug = String(c.slug ?? id);

    try {
      await prisma.category.upsert({
        where: { id },
        update: {},
        create: {
          id,
          name,
          slug,
          active: true,
          sortOrder: i,
        },
      });
      result.categories.ok++;
    } catch (e) {
      const msg = errMsg(e);
      if (/unique|constraint|already/i.test(msg)) {
        result.categories.skipped++;
      } else {
        result.categories.errors.push(`${id}: ${msg}`);
      }
    }
  }

  return NextResponse.json({ success: true, ...result });
}