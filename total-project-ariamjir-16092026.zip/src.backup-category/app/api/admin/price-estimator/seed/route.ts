import { randomUUID } from "crypto";
import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function POST() {
  try {
    const existing = await prisma.priceEstimator.findFirst();

    if (existing) {
      return NextResponse.json({
        success: false,
        message: "داده‌های نمونه از قبل وجود دارند",
      });
    }

    const now = new Date();

    await prisma.priceEstimator.create({
      data: {
        id: randomUUID(),
        name: "بیل مکانیکی",
        description: "تخمین قیمت بیل مکانیکی بر اساس مشخصات فنی",
        basePrice: 5000000000,
        isActive: true,
        updatedAt: now,

        PriceEstimatorInput: {
          create: [
            {
              id: randomUUID(),
              name: "brand",
              label: "برند",
              type: "select",
              required: true,
              options: [
                "کوماتسو",
                "کاترپیلار",
                "ولوو",
                "هیوندای",
                "دوسان",
              ],
              sortOrder: 1,
            },
            {
              id: randomUUID(),
              name: "model",
              label: "مدل",
              type: "text",
              required: true,
              sortOrder: 2,
            },
            {
              id: randomUUID(),
              name: "year",
              label: "سال ساخت",
              type: "number",
              required: true,
              minValue: 1990,
              maxValue: 2026,
              sortOrder: 3,
            },
            {
              id: randomUUID(),
              name: "workingHours",
              label: "ساعت کارکرد",
              type: "number",
              required: true,
              minValue: 0,
              sortOrder: 4,
            },
            {
              id: randomUUID(),
              name: "condition",
              label: "وضعیت فنی",
              type: "select",
              required: true,
              options: [
                "نو",
                "در حد نو",
                "خوب",
                "متوسط",
                "نیاز به تعمیر",
              ],
              sortOrder: 5,
            },
          ],
        },
      },
    });

    await prisma.priceEstimator.create({
      data: {
        id: randomUUID(),
        name: "لودر",
        description: "تخمین قیمت لودر بر اساس مشخصات فنی",
        basePrice: 3000000000,
        isActive: true,
        updatedAt: now,

        PriceEstimatorInput: {
          create: [
            {
              id: randomUUID(),
              name: "brand",
              label: "برند",
              type: "select",
              required: true,
              options: [
                "کوماتسو",
                "کاترپیلار",
                "ولوو",
                "لیوبهر",
              ],
              sortOrder: 1,
            },
            {
              id: randomUUID(),
              name: "model",
              label: "مدل",
              type: "text",
              required: true,
              sortOrder: 2,
            },
            {
              id: randomUUID(),
              name: "year",
              label: "سال ساخت",
              type: "number",
              required: true,
              minValue: 1990,
              maxValue: 2026,
              sortOrder: 3,
            },
            {
              id: randomUUID(),
              name: "bucketCapacity",
              label: "ظرفیت باکت (متر مکعب)",
              type: "number",
              required: false,
              sortOrder: 4,
            },
          ],
        },
      },
    });

    return NextResponse.json({
      success: true,
      message: "داده‌های نمونه با موفقیت ساخته شدند",
      count: 2,
    });
  } catch (error: unknown) {
    const message =
      error instanceof Error
        ? error.message
        : "خطای ناشناخته";

    return NextResponse.json(
      {
        success: false,
        message,
      },
      {
        status: 500,
      },
    );
  }
}