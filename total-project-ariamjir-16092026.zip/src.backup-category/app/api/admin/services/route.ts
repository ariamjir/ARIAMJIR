import { NextRequest, NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";

import { servicesData } from "@/features/home/services/constants/services.data";

/* کلید آیکون برای fallback استاتیک */
const KEY_BY_INDEX = ["cart", "wrench", "cog", "package"];

/* نگاشت نام/اسلاگ دسته → کلید آیکون */
const ICON_RULES: { keys: string[]; icon: string }[] = [
  { keys: ["تعمیر", "repair", "بازسازی", "نگهداری"], icon: "wrench" },
  { keys: ["قطعه", "part", "یدکی", "تامین"], icon: "cog" },
  { keys: ["حمل", "نقل", "transport", "لجستیک", "جابه"], icon: "truck" },
  { keys: ["اجاره", "rent", "کرایه"], icon: "key" },
  { keys: ["اپراتور", "operator", "نیرو"], icon: "users" },
  { keys: ["کارشناسی", "ارزیابی", "inspection", "بازرسی"], icon: "clipboard" },
  { keys: ["آموزش", "training", "آموزشی"], icon: "graduation" },
  { keys: ["بیمه", "insurance", "ضمانت"], icon: "shield" },
  { keys: ["مالی", "بازرگانی", "finance", "واردات", "import", "صادرات"], icon: "banknote" },
  { keys: ["مشاوره", "consult"], icon: "headphones" },
];

function pickIconKey(slug: string, name: string): string {
  const hay = `${slug} ${name}`.toLowerCase();
  for (const r of ICON_RULES) {
    if (r.keys.some((k) => hay.includes(k))) return r.icon;
  }
  return "wrench";
}

/* ============================================================
   Seed خودکار از درخت دسته‌بندی خدمات (صنعت‌های واقعی)
   fallback: دادهٔ استاتیک servicesData
============================================================ */
async function seedFromCategories(): Promise<any[]> {
  const root = await prisma.category.findFirst({
    where: { slug: "services", parentId: null },
  });

  const industries = root
    ? await prisma.category.findMany({
        where: { parentId: root.id, active: true },
        orderBy: { sortOrder: "asc" },
      })
    : [];

  const data =
    industries.length > 0
      ? industries.map((c: any, i: number) => ({
          title: c.name,
          description:
            (c as any).description ??
            `خدمات ${c.name} با ضمانت و پشتیبانی آریا`,
          icon: pickIconKey(c.slug ?? "", c.name),
          order: i,
          active: true,
        }))
      : servicesData.map((s: any, i: number) => ({
          title: s.title,
          description: s.description,
          icon: KEY_BY_INDEX[i] ?? "wrench",
          order: i,
          active: true,
        }));

  await prisma.serviceItem.createMany({ data });

  return prisma.serviceItem.findMany({ orderBy: { order: "asc" } });
}

/* ============================================================
   GET — اگر خالی بود، خودکار از دسته‌های خدمات پر می‌شود
============================================================ */
export async function GET() {
  try {
    let items = await prisma.serviceItem.findMany({
      orderBy: { order: "asc" },
    });

    if (items.length === 0) {
      items = await seedFromCategories();
    }

    return NextResponse.json({ success: true, data: items });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, message: error.message },
      { status: 500 }
    );
  }
}

/* ذخیرهٔ کل لیست (جایگزینی کامل) */
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();

    if (!Array.isArray(body)) {
      return NextResponse.json(
        { success: false, message: "Invalid payload" },
        { status: 400 }
      );
    }

    await prisma.$transaction([
      prisma.serviceItem.deleteMany(),
      prisma.serviceItem.createMany({
        data: body.map((x: any, i: number) => ({
          title: x.title ?? "",
          description: x.description ?? null,
          icon: x.icon ?? "wrench",
          href: x.href ?? null,
          order: i,
          active: x.active ?? true,
        })),
      }),
    ]);

    return NextResponse.json({ success: true });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, message: error.message },
      { status: 500 }
    );
  }
}

/* POST — seed دستی */
export async function POST() {
  try {
    const count = await prisma.serviceItem.count();

    const items =
      count > 0
        ? await prisma.serviceItem.findMany({ orderBy: { order: "asc" } })
        : await seedFromCategories();

    return NextResponse.json({ success: true, data: items });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, message: error.message },
      { status: 500 }
    );
  }
}