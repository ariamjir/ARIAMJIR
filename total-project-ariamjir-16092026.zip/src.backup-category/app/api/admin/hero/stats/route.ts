import { NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";

export async function POST(request: Request) {
  try {
    const body = await request.json();

    const stat = await prisma.heroStat.create({
  data: {
    heroId: body.heroId,

    title: body.title,

    type: body.type,

    source: body.source,

    value:
      body.type === "MANUAL"
        ? body.value
        : null,

    icon: body.icon ?? null,

    sortOrder:
      Number(body.sortOrder) || 0,

    active:
      body.active ?? true,
  },
});

    return NextResponse.json(stat);
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      {
        error: "Create failed",
      },
      {
        status: 500,
      }
    );
  }
}