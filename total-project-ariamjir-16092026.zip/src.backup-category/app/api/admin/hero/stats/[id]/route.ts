import { NextRequest, NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";

interface Params {
  params: Promise<{
    id: string;
  }>;
}

export async function GET(
  request: NextRequest,
  { params }: Params
) {
  try {
    const { id } = await params;

    const stat = await prisma.heroStat.findUnique({
      where: {
        id,
      },
    });

    if (!stat) {
      return NextResponse.json(
        {
          error: "Stat not found",
        },
        {
          status: 404,
        }
      );
    }

    return NextResponse.json(stat);
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      {
        error: "Load failed",
      },
      {
        status: 500,
      }
    );
  }
}

export async function PUT(
  request: NextRequest,
  { params }: Params
) {
  try {
    const { id } = await params;

    const body = await request.json();

    const source =
      body.source ?? "manual";

    const stat =
  await prisma.heroStat.update({
    where: {
      id,
    },

    data: {
      title: body.title,

      type: body.type,

      source: body.source,

      value:
        body.type === "MANUAL"
          ? body.value
          : null,

      icon: body.icon ?? null,

      sortOrder:
        Number(body.sortOrder) || 0,

      active:
        body.active ?? true,
    },
  });

    return NextResponse.json(stat);
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      {
        error: "Update failed",
      },
      {
        status: 500,
      }
    );
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: Params
) {
  try {
    const { id } = await params;

    await prisma.heroStat.delete({
      where: {
        id,
      },
    });

    return NextResponse.json({
      success: true,
    });
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      {
        error: "Delete failed",
      },
      {
        status: 500,
      }
    );
  }
}