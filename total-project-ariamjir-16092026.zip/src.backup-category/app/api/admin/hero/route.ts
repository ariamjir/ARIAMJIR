import { NextRequest, NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";

import { getHomeHero } from "@/modules/home";

/* ✅ همان هیروی را برمی‌گرداند که سایت نمایش می‌دهد */
export async function GET() {
  try {
    const base = await getHomeHero();

    const hero = base
      ? await prisma.hero.findUnique({
          where: { id: base.id },
          include: {
            slides: { orderBy: { sortOrder: "asc" } },
            stats: { orderBy: { sortOrder: "asc" } },
          },
        })
      : null;

    return NextResponse.json({ success: true, data: hero });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, message: error.message },
      { status: 500 }
    );
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();

    const { id, slides, config, ...fields } = body;

    const data: any = {
      title: fields.title ?? "ARIA MJ",
      subtitle: fields.subtitle ?? null,
      badge: fields.badge ?? null,
      description: fields.description ?? null,
      buttonText: fields.buttonText ?? null,
      buttonLink: fields.buttonLink ?? null,
      secondButtonText: fields.secondButtonText ?? null,
      secondButtonLink: fields.secondButtonLink ?? null,
      config: config ?? undefined,
    };

    let heroId = id;

    if (heroId) {
      await prisma.hero.update({ where: { id: heroId }, data });
    } else {
      const created = await prisma.hero.create({ data });
      heroId = created.id;
    }

    if (Array.isArray(slides)) {
      await prisma.heroSlide.deleteMany({ where: { heroId } });

      await prisma.heroSlide.createMany({
        data: slides.map((s: any, i: number) => ({
          heroId,
          image: s.image,
          title: s.title ?? null,
          subtitle: s.subtitle ?? null,
          link: s.link ?? null,
          active: s.active !== false,
          sortOrder: i,
        })),
      });
    }

    return NextResponse.json({ success: true, id: heroId });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, message: error.message },
      { status: 500 }
    );
  }
}