import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

interface Params {
  params: Promise<{
    id: string;
  }>;
}

export async function GET(
  request: NextRequest,
  { params }: Params
) {
  try {
    const { id } = await params;

    const hero = await prisma.hero.findUnique({
      where: {
        id,
      },
      include: {
        slides: {
          orderBy: {
            sortOrder: "asc",
          },
        },
        stats: {
          orderBy: {
            sortOrder: "asc",
          },
        },
      },
    });

    if (!hero) {
      return NextResponse.json(
        { error: "Hero not found" },
        { status: 404 }
      );
    }

    return NextResponse.json(hero);
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      { error: "Load failed" },
      { status: 500 }
    );
  }
}

export async function PUT(
  request: NextRequest,
  { params }: Params
) {
  try {
    const { id } = await params;

    const body = await request.json();

    const hero = await prisma.hero.update({
      where: {
        id,
      },
      data: {
        badge: body.badge ?? null,
        title: body.title,
        subtitle: body.subtitle ?? null,
        description: body.description ?? null,
        buttonText: body.buttonText ?? null,
        buttonLink: body.buttonLink ?? null,
        secondButtonText:
          body.secondButtonText ?? null,
        secondButtonLink:
          body.secondButtonLink ?? null,
        active: body.active ?? true,
      },
    });

    return NextResponse.json(hero);
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      { error: "Update failed" },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: Params
) {
  try {
    const { id } = await params;

    await prisma.hero.delete({
      where: {
        id,
      },
    });

    return NextResponse.json({
      success: true,
    });
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      { error: "Delete failed" },
      { status: 500 }
    );
  }
}