import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

interface RouteContext {
  params: Promise<{
    id: string;
  }>;
}

// ======================
// GET
// ======================

export async function GET(
  request: NextRequest,
  { params }: RouteContext
) {
  try {
    const { id } = await params;

    const slide = await prisma.heroSlide.findUnique({
      where: {
        id,
      },
    });

    if (!slide) {
      return NextResponse.json(
        { error: "Slide not found" },
        { status: 404 }
      );
    }

    return NextResponse.json(slide);
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      { error: "Load failed" },
      { status: 500 }
    );
  }
}

// ======================
// PUT
// ======================

export async function PUT(
  request: NextRequest,
  { params }: RouteContext
) {
  try {
    const { id } = await params;

    const body = await request.json();

    const slide = await prisma.heroSlide.update({
      where: {
        id,
      },
      data: {
        image: body.image,
        title: body.title ?? null,
        subtitle: body.subtitle ?? null,
        link: body.link ?? null,
        sortOrder: body.sortOrder ?? 0,
        active: body.active ?? true,
      },
    });

    return NextResponse.json(slide);
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      { error: "Update failed" },
      { status: 500 }
    );
  }
}

// ======================
// DELETE
// ======================

export async function DELETE(
  request: NextRequest,
  { params }: RouteContext
) {
  try {
    const { id } = await params;

    await prisma.heroSlide.delete({
      where: {
        id,
      },
    });

    return NextResponse.json({
      success: true,
    });
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      { error: "Delete failed" },
      { status: 500 }
    );
  }
}