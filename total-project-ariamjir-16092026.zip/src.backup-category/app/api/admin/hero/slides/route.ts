import { NextRequest, NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    if (!body.heroId) {
      return NextResponse.json(
        {
          error: "heroId is required",
        },
        {
          status: 400,
        }
      );
    }

    if (!body.image) {
      return NextResponse.json(
        {
          error: "image is required",
        },
        {
          status: 400,
        }
      );
    }

    const hero = await prisma.hero.findUnique({
      where: {
        id: body.heroId,
      },
    });

    if (!hero) {
      return NextResponse.json(
        {
          error: "Hero not found",
        },
        {
          status: 404,
        }
      );
    }

    const slide = await prisma.heroSlide.create({
      data: {
        heroId: body.heroId,

        image: body.image,

        title: body.title ?? null,

        subtitle: body.subtitle ?? null,

        link: body.link ?? null,

        sortOrder: Number(body.sortOrder) || 0,

        active: body.active ?? true,
      },
    });

    return NextResponse.json(slide);
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      {
        error: "Create failed",
      },
      {
        status: 500,
      }
    );
  }
}