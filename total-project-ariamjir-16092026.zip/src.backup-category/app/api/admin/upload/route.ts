import { NextRequest, NextResponse } from "next/server";

import path from "path";

import fs from "fs/promises";

import { randomUUID } from "crypto";

const UPLOAD_DIR = path.join(

process.cwd(),

"public",

"uploads"

);

async function ensureDirectory(){

await fs.mkdir(

UPLOAD_DIR,

{

recursive:true,

}

);

}

export async function POST(

request:NextRequest

){

await ensureDirectory();

const data=

await request.formData();

const file=

data.get("file") as File;

if(!file){

return NextResponse.json(

{

success:false,

message:"No file uploaded"

},

{

status:400,

}

);

}

const extension=

file.name.split(".").pop();

const filename=

`${randomUUID()}.${extension}`;

const filepath=

path.join(

UPLOAD_DIR,

filename

);

const bytes=

await file.arrayBuffer();

await fs.writeFile(

filepath,

Buffer.from(bytes)

);

const url=

`/uploads/${filename}`;

return NextResponse.json({

success:true,

url,

fileName:filename,

size:file.size,

type:file.type,

});

}

