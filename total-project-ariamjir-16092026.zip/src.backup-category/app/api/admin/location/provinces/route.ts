import { NextResponse } from "next/server";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

export async function GET() {
  try {
    const provinces = await prisma.province.findMany({
      orderBy: {
        name: "asc",
      },
    });

    return NextResponse.json(
      provinces.map((p) => ({
        id: p.id,
        name: p.name,
      }))
    );
  } catch (error) {
    console.error(error);

    return NextResponse.json([], {
      status: 500,
    });
  }
}

