import { NextResponse } from "next/server";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);

  const province =
    searchParams.get("province");

  if (!province) {
    return NextResponse.json([]);
  }

  try {
    const provinceRecord =
      await prisma.province.findFirst({
        where: {
          name: province,
        },
      });

    if (!provinceRecord) {
      return NextResponse.json([]);
    }

    const cities =
      await prisma.city.findMany({
        where: {
          provinceId: provinceRecord.id,
        },
        orderBy: {
          name: "asc",
        },
      });

    return NextResponse.json(
      cities.map((c) => ({
        id: c.id,
        name: c.name,
      }))
    );
  } catch (error) {
    console.error(error);

    return NextResponse.json([], {
      status: 500,
    });
  }
}

