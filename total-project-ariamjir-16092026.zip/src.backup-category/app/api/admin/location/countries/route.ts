import { NextResponse } from "next/server";

export async function GET() {
  return NextResponse.json([
    { id: "iran", name: "Iran" },
    { id: "uae", name: "UAE" },
    { id: "turkey", name: "Turkey" },
    { id: "china", name: "China" },
  ]);
}

