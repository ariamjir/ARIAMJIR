import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

type Context = { params: Promise<{ id: string }> };

async function countryLink(value: unknown) {
  if (typeof value !== "string" || !value.trim()) return undefined;
  const id = value.trim();
  const exists = await prisma.country
    .findUnique({ where: { id } })
    .catch(() => null);
  return exists ? { connect: { id } } : undefined;
}

export async function GET(req: NextRequest, { params }: Context) {
  const { id } = await params;
  const brand = await prisma.brand.findUnique({ where: { id } });
  if (!brand) return NextResponse.json({ error: "Brand not found" }, { status: 404 });
  return NextResponse.json(brand);
}

export async function PUT(req: NextRequest, { params }: Context) {
  const { id } = await params;
  const body = await req.json();
  const country = await countryLink(body.country);

  const brand = await prisma.brand.update({
    where: { id },
    data: {
      ...(body.name !== undefined && { name: body.name }),
      ...(body.slug !== undefined && { slug: body.slug }),
      ...(body.description !== undefined && { description: body.description }),
      ...(body.logo !== undefined && { logo: body.logo }),
      ...(body.image !== undefined && { image: body.image }),
      ...(body.icon !== undefined && { icon: body.icon }),
      ...(body.link !== undefined && { link: body.link }),
      ...(body.website !== undefined && { website: body.website }),
      ...(body.active !== undefined && { active: Boolean(body.active) }),
      ...(body.featured !== undefined && { featured: Boolean(body.featured) }),
      ...(body.sortOrder !== undefined && { sortOrder: body.sortOrder }),
      ...(country ? { country } : {}),
    },
  });

  return NextResponse.json(brand);
}

export async function DELETE(req: NextRequest, { params }: Context) {
  const { id } = await params;
  await prisma.brand.delete({ where: { id } });
  return NextResponse.json({ success: true });
}