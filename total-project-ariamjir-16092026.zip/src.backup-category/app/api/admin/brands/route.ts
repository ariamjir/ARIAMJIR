import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

/* اگر country یک id معتبر از جدول Country باشد، connect می‌کند؛
   وگرنه null برمی‌گرداند تا رابطه نادیده گرفته شود. */
async function countryLink(value: unknown) {
  if (typeof value !== "string" || !value.trim()) return undefined;
  const id = value.trim();
  const exists = await prisma.country
    .findUnique({ where: { id } })
    .catch(() => null);
  return exists ? { connect: { id } } : undefined;
}

export async function GET() {
  try {
    const brands = await prisma.brand.findMany({
      orderBy: [{ sortOrder: "asc" }, { name: "asc" }],
    });
    return NextResponse.json(brands);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed to load brands" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const country = await countryLink(body.country);

    const brand = await prisma.brand.create({
      data: {
        name: body.name,
        slug: body.slug,
        description: body.description ?? "",
        logo: body.logo ?? "",
        image: body.image ?? null,
        icon: body.icon ?? null,
        link: body.link ?? null,
        website: body.website ?? "",
        active: body.active ?? true,
        featured: body.featured ?? false,
        sortOrder: body.sortOrder ?? 0,
        ...(country ? { country } : {}),
      },
    });

    return NextResponse.json(brand);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed to create brand" }, { status: 500 });
  }
}