import { NextRequest, NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";

import { resolveRealLogo } from "@/lib/brand-logo";

const KEY = "home-brands";

/* لیست همهٔ برندها + انتخاب‌شده‌ها برای صفحه اول */
export async function GET() {
  try {
    const [brands, row] = await Promise.all([
      prisma.brand.findMany({
        orderBy: { name: "asc" },
        include: { _count: { select: { machines: true } } },
      }),
      prisma.homePageSection.findFirst({ where: { key: KEY } }),
    ]);

    const selected: string[] = (row?.config as any)?.ids ?? [];

    return NextResponse.json({
      success: true,
      data: {
        brands: brands.map((b: any) => ({
          id: b.id,
          name: b.name,
          slug: b.slug,
          logo: b.logo ?? null,
          machines: b._count?.machines ?? 0,
        })),
        selected,
      },
    });
  } catch (error: any) {
    return NextResponse.json({ success: false, message: error.message }, { status: 500 });
  }
}

/* ذخیرهٔ برندهای انتخابی برای نمایش در صفحه اول */
export async function PATCH(request: NextRequest) {
  try {
    const { ids } = await request.json();

    const existing = await prisma.homePageSection.findFirst({ where: { key: KEY } });

    if (existing) {
      await prisma.homePageSection.update({
        where: { id: existing.id },
        data: { config: { ids: ids ?? [] } },
      });
    } else {
      await prisma.homePageSection.create({
        data: { key: KEY, title: "برندهای صفحه اول", order: 80, active: true, config: { ids: ids ?? [] } },
      });
    }

    return NextResponse.json({ success: true });
  } catch (error: any) {
    return NextResponse.json({ success: false, message: error.message }, { status: 500 });
  }
}

/* ✅ دریافت لوگوی واقعی برند — تکی یا گروهی (هر بار حداکثر ۶) */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json().catch(() => ({}));
    const limit = Math.min(Number(body.limit ?? 6), 6);

    let targets: any[] = [];

    if (Array.isArray(body.ids) && body.ids.length) {
      targets = await prisma.brand.findMany({ where: { id: { in: body.ids } } });
    } else {
      targets = await prisma.brand.findMany({
        where: { OR: [{ logo: null }, { logo: "" }] },
        orderBy: { name: "asc" },
      });
    }

    targets = targets.slice(0, limit);

    let updated = 0;

    for (const b of targets) {
      const url = await resolveRealLogo(b.name, b.slug);
      if (!url) continue;

      await prisma.brand.update({ where: { id: b.id }, data: { logo: url } });
      updated++;
    }

    return NextResponse.json({ success: true, updated, total: targets.length });
  } catch (error: any) {
    return NextResponse.json({ success: false, message: error.message }, { status: 500 });
  }
}