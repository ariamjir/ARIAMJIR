import { NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";

import { countries } from "@/data/countries";

export const dynamic = "force-dynamic";

function errMsg(e: unknown): string {
  const raw = e instanceof Error ? e.message : String(e);
  return raw.replace(/\s+/g, " ").trim().slice(0, 300) || "(no message)";
}

/* ============================================================
   Seed جدول Country
   ------------------------------------------------------------
   id هر کشور = همان کدی که در @/data/countries استفاده می‌شود
   (مثل IR, CN, JP). این‌طوری select برند همان id را می‌فرستد
   و connect موفق می‌شود.
============================================================ */

export async function GET() {
  const result = {
    total: 0,
    created: 0,
    skipped: 0,
    errors: [] as string[],
  };

  for (const c of countries as { value: string; label: string }[]) {
    result.total++;
    try {
      const exists = await prisma.country.findUnique({
        where: { id: c.value },
      });

      if (exists) {
        result.skipped++;
        continue;
      }

      await prisma.country.create({
        data: {
          id: c.value,
          name: c.label,
        },
      });

      result.created++;
    } catch (e) {
      result.errors.push(`${c.value}: ${errMsg(e)}`);
    }
  }

  return NextResponse.json({
    success: result.errors.length === 0,
    ...result,
  });
}