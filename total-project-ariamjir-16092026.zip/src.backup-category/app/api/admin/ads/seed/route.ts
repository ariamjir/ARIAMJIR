import { NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";

/* ============================================================
   Seed — دقیقاً همان ۳ آگهیِ استاتیک، با عکس متفاوت و متناسب
   Idempotent: اگر slug وجود داشت، دوباره نمی‌سازد
============================================================ */

const SEED = [
  {
    slug: "caterpillar-320d-2019-mashhad",
    title: "بیل مکانیکی Caterpillar 320D",
    shortDescription: "دستگاه سالم، بدون نشتی، آماده کار، سرویس کامل انجام شده.",
    description:
      "بیل مکانیکی Caterpillar 320D مدل 2019 با موتور اصلی، پمپ اصلی، بدون نشتی و آماده کار در پروژه‌های عمرانی، راه‌سازی و معدنی.",
    brandName: "Caterpillar",
    brandSlug: "caterpillar",
    image: "/images/hero/hero-1.jpg",
    featured: true,
    urgent: false,
    price: 16800000000,
    model: "320D",
    year: 2019,
    engine: "CAT C6.4",
    workingHours: 5200,
    location: "شهرک صنعتی توس",
    serial: "CAT320D2019-001",
    publishedAt: new Date("2026-07-03"),
  },
  {
    slug: "komatsu-pc220-2021-tehran",
    title: "بیل مکانیکی Komatsu PC220",
    shortDescription: "کم‌کارکرد، کاملاً سالم، آماده تحویل.",
    description:
      "بیل مکانیکی Komatsu PC220 مدل 2021 با موتور اصلی، کارکرد پایین، بدون رنگ و آماده تحویل فوری.",
    brandName: "Komatsu",
    brandSlug: "komatsu",
    image: "/images/hero/hero-2.jpg",
    featured: false,
    urgent: true,
    price: 24500000000,
    model: "PC220",
    year: 2021,
    engine: "Komatsu SAA6D107E",
    workingHours: 1800,
    location: "تهران",
    serial: "PC220-2021-002",
    publishedAt: new Date("2026-07-02"),
  },
  {
    slug: "volvo-ec210-2018-isfahan",
    title: "بیل مکانیکی Volvo EC210",
    shortDescription: "موتور و پمپ اصلی، بدون رنگ، آماده کار در معدن.",
    description:
      "بیل مکانیکی Volvo EC210 مدل 2018 با موتور اصلی، سیستم هیدرولیک سالم، مناسب پروژه‌های راه‌سازی، عمرانی و معدنی.",
    brandName: "Volvo",
    brandSlug: "volvo",
    image: "/images/hero/hero-3.jpg",
    featured: true,
    urgent: false,
    price: 15100000000,
    model: "EC210",
    year: 2018,
    engine: "Volvo D6",
    workingHours: 6400,
    location: "اصفهان",
    serial: "VOL-EC210-003",
    publishedAt: new Date("2026-07-01"),
  },
];

export async function POST() {
  try {
    const created: string[] = [];

    for (const s of SEED) {
      const exists = await prisma.machine.findUnique({
        where: { slug: s.slug },
      });

      if (exists) continue;

      const brand = await prisma.brand.upsert({
        where: { slug: s.brandSlug },
        update: {},
        create: { name: s.brandName, slug: s.brandSlug },
      });

      await prisma.machine.create({
        data: {
          title: s.title,
          slug: s.slug,
          shortDescription: s.shortDescription,
          description: s.description,
          status: "PUBLISHED",
          featured: s.featured,
          active: true,
          publishedAt: s.publishedAt,
          brandId: brand.id,

          specification: {
            create: {
              model: s.model,
              manufactureYear: s.year,
              condition: "USED",
              engine: s.engine,
              workingHours: s.workingHours,
              location: s.location,
              serialNumber: s.serial,
            },
          },

          price: {
            create: {
              price: s.price,
              currency: "IRR",
              priceType: "FIXED",
            },
          },

          images: {
            create: [
              { url: s.image, isPrimary: true, sortOrder: 0 },
            ],
          },
        },
      });

      created.push(s.slug);
    }

    return NextResponse.json({
      success: true,
      created,
      message:
        created.length > 0
          ? `${created.length} آگهی ثبت شد.`
          : "آگهی‌ها از قبل وجود داشتند.",
    });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, message: error.message },
      { status: 500 }
    );
  }
}