import { NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";

/* خروجی CSV از همهٔ آگهی‌ها برای حسابداری / گزارش */
export async function GET() {
  try {
    const machines = await prisma.machine.findMany({
      orderBy: { createdAt: "desc" },
      include: {
        brand: true,
        category: true,
        specification: true,
        price: true,
        _count: { select: { views: true, favorites: true } },
      },
    });

    const headers = [
      "عنوان",
      "اسلاگ",
      "برند",
      "دسته",
      "مدل",
      "سال ساخت",
      "موقعیت",
      "کارکرد",
      "قیمت",
      "وضعیت",
      "ویژه",
      "بازدید",
      "علاقه‌مندی",
      "تاریخ ثبت",
      "انقضا",
    ];

    const toFa = (v: any) => (v == null ? "" : String(v).replace(/,/g, "،"));

    const rows = machines.map((m: any) => [
      toFa(m.title),
      m.slug,
      toFa(m.brand?.name ?? "-"),
      toFa(m.category?.name ?? "-"),
      toFa(m.specification?.model ?? "-"),
      toFa(m.specification?.manufactureYear),
      toFa(m.specification?.location ?? "-"),
      toFa(m.specification?.workingHours),
      toFa(
        m.price?.price
          ? Number(m.price.price).toLocaleString("fa-IR") + " تومان"
          : "تماس بگیرید"
      ),
      m.status,
      m.featured ? "ویژه" : "-",
      toFa(m._count?.views ?? 0),
      toFa(m._count?.favorites ?? 0),
      new Date(m.createdAt).toLocaleDateString("fa-IR"),
      m.expiresAt
        ? new Date(m.expiresAt).toLocaleDateString("fa-IR")
        : "-",
    ]);

    const csv =
      "\uFEFF" + /* BOM برای Excel */
      [headers, ...rows].map((r) => r.map(csvEscape).join(",")).join("\n");

    const now = new Date().toISOString().slice(0, 10);

    return new NextResponse(csv, {
      status: 200,
      headers: {
        "Content-Type": "text/csv; charset=utf-8",
        "Content-Disposition": `attachment; filename="ariamj-ads-${now}.csv"`,
      },
    });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, message: error.message },
      { status: 500 }
    );
  }
}

function csvEscape(v: string) {
  const s = String(v ?? "");
  if (/[",\n]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
  return s;
}