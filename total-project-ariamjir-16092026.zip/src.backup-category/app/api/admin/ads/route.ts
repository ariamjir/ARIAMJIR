import { NextRequest, NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";

/* خودکار: آگهی‌های منقضی‌شده را غیرفعال کن */
async function expireOutdated() {
  const now = new Date();

  const expired = await prisma.machine.findMany({
    where: { active: true, expiresAt: { lt: now } },
    select: { id: true, slug: true, title: true, sellerId: true },
  });

  if (expired.length === 0) return;

  await prisma.machine.updateMany({
    where: { id: { in: expired.map((x) => x.id) } },
    data: { active: false },
  });

  /* پیام به فروشنده */
  for (const m of expired) {
    if (!m.sellerId) continue;
    await prisma.notification.create({
      data: {
        type: "EXPIRED",
        title: "آگهی شما منقضی شد",
        message: `«${m.title}» منقضی و غیرفعال شد. برای تمدید ۳۰ روزه اقدام کنید.`,
        link: `/machines/${m.slug}`,
        refId: m.id,
        userId: m.sellerId,
      },
    });
  }
}

export async function GET() {
  try {
    await expireOutdated();

    const machines = await prisma.machine.findMany({
      orderBy: { createdAt: "desc" },
      include: {
        brand: true,
        specification: true,
        price: true,
        images: { orderBy: { sortOrder: "asc" } },
        _count: {
          select: { views: true, favorites: true, images: true },
        },
      },
    });

    const data = machines.map((m: any) => ({
      id: m.id,
      slug: m.slug,
      title: m.title,
      status: m.status,
      active: m.active,
      featured: m.featured,
      brand: m.brand?.name ?? "-",
      image:
        m.images?.[0]?.url ??
        "/images/machines/ariamjexcavator-1.png",
      galleryCount: m._count?.images ?? 0,
      views: m._count?.views ?? 0,
      favorites: m._count?.favorites ?? 0,
      price: m.price?.price
        ? `${Number(m.price.price).toLocaleString("fa-IR")} تومان`
        : "تماس بگیرید",
      priceValue: Number(m.price?.price ?? 0),
      year: m.specification?.manufactureYear ?? null,
      location: m.specification?.location ?? null,
      createdAt: m.createdAt,
      expiresAt: m.expiresAt,
      rejectionReason: m.rejectionReason ?? null,
      rejectedAt: m.rejectedAt,
    }));

    return NextResponse.json({ success: true, data });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, message: error.message },
      { status: 500 }
    );
  }
}

/* کپی آگهی */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    if (!body?.id) {
      return NextResponse.json(
        { success: false, message: "id لازم است" },
        { status: 400 }
      );
    }

    const src = await prisma.machine.findUnique({
      where: { id: body.id },
      include: { specification: true, price: true, images: true },
    });

    if (!src) {
      return NextResponse.json(
        { success: false, message: "آگهی پیدا نشد" },
        { status: 404 }
      );
    }

    const copy = await prisma.machine.create({
      data: {
        title: `${src.title} (کپی)`,
        slug: `${src.slug}-copy-${Date.now().toString(36)}`,
        shortDescription: src.shortDescription,
        description: src.description,
        status: "DRAFT",
        active: true,
        featured: false,
        brandId: src.brandId,
        categoryId: src.categoryId,
        expiresAt: new Date(Date.now() + 30 * 86400000),

        specification: src.specification
          ? {
              create: {
                model: src.specification.model,
                manufactureYear: src.specification.manufactureYear,
                condition: src.specification.condition,
                engine: src.specification.engine,
                workingHours: src.specification.workingHours,
                location: src.specification.location,
              },
            }
          : undefined,

        price: src.price
          ? {
              create: {
                price: src.price.price,
                currency: src.price.currency,
                priceType: src.price.priceType,
              },
            }
          : undefined,

        images: {
          create: src.images.map((img: any, i: number) => ({
            url: img.url,
            alt: img.alt,
            sortOrder: i,
            isPrimary: i === 0,
          })),
        },
      },
    });

    return NextResponse.json({ success: true, id: copy.id });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, message: error.message },
      { status: 500 }
    );
  }
}

/* PATCH: وضعیت / فعال / ویژه / رد / تمدید */
export async function PATCH(request: NextRequest) {
  try {
    const { id, patch } = await request.json();

    const allowed: any = {};

    if (typeof patch?.active === "boolean") allowed.active = patch.active;
    if (typeof patch?.featured === "boolean") allowed.featured = patch.featured;
    if (patch?.status) allowed.status = patch.status;

    /* انتشار → ست کردن expiresAt = الان + ۳۰ روز */
    if (patch?.status === "PUBLISHED") {
      allowed.expiresAt = new Date(Date.now() + 30 * 86400000);
      allowed.rejectionReason = null;
      allowed.rejectedAt = null;
    }

    /* رد با دلیل */
    if (patch?.reject === true) {
      allowed.status = "REJECTED";
      allowed.rejectionReason = patch.reason ?? "بدون توضیح";
      allowed.rejectedAt = new Date();
      allowed.active = false;
    }

    /* تمدید: +۳۰ روز از تاریخ انقضای فعلی یا الان */
    if (patch?.extend === true) {
      const current = await prisma.machine.findUnique({ where: { id } });
      const base =
        current?.expiresAt && current.expiresAt > new Date()
          ? current.expiresAt
          : new Date();
      allowed.expiresAt = new Date(base.getTime() + 30 * 86400000);
      allowed.active = true;
    }

    await prisma.machine.update({ where: { id }, data: allowed });

          const machine = await prisma.machine.findUnique({ where: { id } });
      if (machine?.sellerId) {
        await prisma.notification.create({
          data: {
            type: "REJECTED",
            title: "آگهی شما رد شد",
            message: `«${machine.title}» — دلیل: ${patch.reason ?? "-"}`,
            link: `/machines/${machine.slug}`,
            refId: id,
            userId: machine.sellerId,
          },
        });
      }

    return NextResponse.json({ success: true });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, message: error.message },
      { status: 500 }
    );
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { id } = await request.json();
    await prisma.machine.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, message: error.message },
      { status: 500 }
    );
  }
}