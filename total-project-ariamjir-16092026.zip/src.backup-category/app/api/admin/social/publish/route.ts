import { NextRequest, NextResponse } from "next/server";

import { publishMachine } from "@/lib/social/publisher";

import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { machineId, network = "telegram", markOnly = false } = body;

    if (!machineId) {
      return NextResponse.json(
        { success: false, message: "machineId لازم است" },
        { status: 400 }
      );
    }

    /* فقط ثبت بدون ارسال (اشتراک دستی) */
    if (markOnly) {
      const m = await prisma.machine.findUnique({ where: { id: machineId } });
      const post = await prisma.socialPost.create({
        data: {
          machineId,
          network,
          caption: m?.title ?? "",
          status: "PUBLISHED",
          publishedAt: new Date(),
        },
      });
      return NextResponse.json({ success: true, post });
    }

    const post = await publishMachine(machineId, network);
    return NextResponse.json({ success: true, post });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, message: error.message },
      { status: 500 }
    );
  }
}