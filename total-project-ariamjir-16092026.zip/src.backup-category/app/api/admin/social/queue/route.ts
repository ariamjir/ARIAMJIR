import { NextResponse } from "next/server";

import { getQueue, prisma } from "./deps";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const queue = await getQueue();

    const history = await prisma.socialPost.findMany({
      orderBy: { createdAt: "desc" },
      take: 20,
    });

    return NextResponse.json({ success: true, data: { queue, history } });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, message: error.message },
      { status: 500 }
    );
  }
}