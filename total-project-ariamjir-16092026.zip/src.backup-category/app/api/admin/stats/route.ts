import { NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";

/* شمارش امن — اگر مدلی وجود نداشت، 0 برمی‌گرداند */
async function countAny(names: string[], where?: any): Promise<number> {
  for (const n of names) {
    const d = (prisma as any)[n];
    if (d && typeof d.count === "function") {
      try {
        return await d.count(where ? { where } : undefined);
      } catch {
        /* مدل نیست — رد شو */
      }
    }
  }
  return 0;
}

export async function GET() {
  try {
    const [
      machines,
      brands,
      categories,
      users,
      services,
      news,
      knowledge,
      adsPublished,
      adsDraft,
      adsPending,
      adsRejected,
      adsFeatured,
      views,
      recent,
    ] = await Promise.all([
      countAny(["machine"]),
      countAny(["brand"]),
      countAny(["category"]),
      countAny(["user"]),
      countAny(["serviceItem", "service"]),
      countAny(["news", "newsPost", "article", "blogPost"]),
      countAny(["knowledgeBase", "knowledge", "knowledgeArticle"]),
      countAny(["machine"], { status: "PUBLISHED" }),
      countAny(["machine"], { status: "DRAFT" }),
      countAny(["machine"], { status: "PENDING" }),
      countAny(["machine"], { status: "REJECTED" }),
      countAny(["machine"], { featured: true }),
      countAny(["machineView"]),
      prisma.machine.findMany({
        orderBy: { createdAt: "desc" },
        take: 6,
        include: { brand: true, price: true },
      }),
    ]);

    return NextResponse.json({
      success: true,
      data: {
        machines,
        brands,
        categories,
        users,
        services,
        news,
        knowledge,
        adsPublished,
        adsDraft,
        adsPending,
        adsRejected,
        adsFeatured,
        views,
        recent: recent.map((m: any) => ({
          id: m.id,
          title: m.title,
          slug: m.slug,
          status: m.status,
          brand: m.brand?.name ?? "-",
          price: m.price?.price
            ? `${Number(m.price.price).toLocaleString("fa-IR")} تومان`
            : "تماس بگیرید",
          createdAt: m.createdAt,
        })),
      },
    });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, message: error.message },
      { status: 500 }
    );
  }
}