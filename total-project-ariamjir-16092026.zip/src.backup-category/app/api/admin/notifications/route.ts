import { NextRequest, NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";

/* ساخت خودکار اعلان برای آگهی‌های جدیدِ در انتظار و رو به انقضا */
async function ensureNotifications() {
  /* آگهی‌های جدید در انتظار بررسی */
  const pending = await prisma.machine.findMany({
    where: { status: "PENDING" },
    select: { id: true, title: true, slug: true, createdAt: true },
  });

  for (const m of pending) {
    const exists = await prisma.notification.findFirst({
      where: { type: "NEW_AD", refId: m.id, userId: null },
    });
    if (!exists) {
      await prisma.notification.create({
        data: {
          type: "NEW_AD",
          title: "آگهی جدید در انتظار بررسی",
          message: `«${m.title}» منتظر تأیید شماست.`,
          link: "/admin/ads",
          refId: m.id,
        },
      });
    }
  }

  /* آگهی‌های رو به انقضا (۷ روز) */
  const soon = new Date(Date.now() + 7 * 86400000);
  const expiring = await prisma.machine.findMany({
    where: {
      status: "PUBLISHED",
      active: true,
      expiresAt: { lte: soon, gt: new Date() },
    },
    select: { id: true, title: true, slug: true },
  });

  for (const m of expiring) {
    const exists = await prisma.notification.findFirst({
      where: { type: "EXPIRING", refId: m.id, userId: null },
    });
    if (!exists) {
      await prisma.notification.create({
        data: {
          type: "EXPIRING",
          title: "آگهی رو به انقضا",
          message: `«${m.title}» تا ۷ روز دیگر منقضی می‌شود.`,
          link: "/admin/ads",
          refId: m.id,
        },
      });
    }
  }
}

export async function GET() {
  try {
    await ensureNotifications();

    const [data, unread] = await Promise.all([
      prisma.notification.findMany({
        where: { userId: null },
        orderBy: { createdAt: "desc" },
        take: 30,
      }),
      prisma.notification.count({
        where: { userId: null, read: false },
      }),
    ]);

    return NextResponse.json({ success: true, data, unread });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, message: error.message },
      { status: 500 }
    );
  }
}

/* خوانده‌شدن (تکی یا همه) */
export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json();

    if (body?.all) {
      await prisma.notification.updateMany({
        where: { userId: null, read: false },
        data: { read: true },
      });
    } else if (body?.id) {
      await prisma.notification.update({
        where: { id: body.id },
        data: { read: true },
      });
    }

    return NextResponse.json({ success: true });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, message: error.message },
      { status: 500 }
    );
  }
}