import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

const ITEMS = [
  {
    title: "۲۵ سال تجربه در بازار ماشین‌آلات سنگین",
    subtitle: "از ۱۴۰۰ تا امروز",
    description: "ما در آریا ماشین جم، با ربع قرن حضور مستمر در بازار، اعتماد هزاران صنعتگر را به دست آورده‌ایم. تجربه یعنی شناخت دقیق نیاز بازار و تحویل راه‌حل درست.",
    icon: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 8v4l3 3"/><circle cx="12" cy="12" r="10"/></svg>`,
    stat: "۲۵+",
    statLabel: "سال تجربه",
  },
  {
    title: "ضمانت اصالت ۱۰۰٪ دستگاه‌ها",
    subtitle: "بدون واسطه، بدون کلاه",
    description: "هر دستگاهی که در پلتفرم ما معامله می‌شود، از ۱۲ نقطهٔ بازرسی کارشناسی عبور می‌کند. ساعت کارکرد، تاریخچه سرویس و اصالت بدنه همه بررسی می‌شوند.",
    icon: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>`,
    stat: "۱۰۰٪",
    statLabel: "ضمانت اصالت",
  },
  {
    title: "پشتیبانی فنی ۲۴ ساعته",
    subtitle: "مهندسان متخصص در کنار شما",
    description: "تیم پشتیبانی فنی ما شامل ۲۰ مهندس مجرب ماشین‌آلات سنگین است که در هر ساعت از شبانه‌روز، راهنمای شما در نصب، سرویس و رفع عیب دستگاه هستند.",
    icon: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>`,
    stat: "۲۴/۷",
    statLabel: "پشتیبانی",
  },
  {
    title: "قیمت‌گذاری شفاف و منصفانه",
    subtitle: "بدون پنهان‌کاری",
    description: "قیمت‌های ما بر اساس بازار روز، ساعت کارکرد و وضعیت فنی دستگاه محاسبه می‌شوند. گزارش شفاف قیمت‌گذاری را قبل از خرید دریافت می‌کنید.",
    icon: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>`,
    stat: "۰٪",
    statLabel: "هزینه پنهان",
  },
  {
    title: "خدمات لجستیک و حمل سراسری",
    subtitle: "از معدن تا کارگاه",
    description: "ناوگان اختصاصی حمل با تجهیزات سنگین‌بر، دستگاه شما را در هر نقطهٔ ایران و منطقه تحویل می‌دهد. بیمه کامل بار تا درب کارگاه.",
    icon: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="3" width="15" height="13"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>`,
    stat: "۳۱",
    statLabel: "استان تحت پوشش",
  },
  {
    title: "خدمات مالی و اقساط ویژه",
    subtitle: "خرید راحت، بدون فشار",
    description: "همکاری با ۱۲ بانک و مؤسسهٔ مالی برای ارائهٔ طرح‌های اقساطی ۳۶ ماهه. تأمین مالی خرید دستگاه سنگین را برایتان آسان می‌کنیم.",
    icon: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>`,
    stat: "۳۶",
    statLabel: "ماه اقساط",
  },
];

export async function POST() {
  try {
    await prisma.whyUsItem.deleteMany();

    let i = 0;
    for (const item of ITEMS) {
      await prisma.whyUsItem.create({ data: { ...item, sortOrder: i++ } });
    }

    return NextResponse.json({ success: true, count: ITEMS.length });
  } catch (error: any) {
    return NextResponse.json({ success: false, message: error.message }, { status: 500 });
  }
}