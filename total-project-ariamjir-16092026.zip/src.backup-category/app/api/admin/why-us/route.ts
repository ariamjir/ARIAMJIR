import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
  try {
    const items = await prisma.whyUsItem.findMany({ orderBy: { sortOrder: "asc" } });
    return NextResponse.json({ success: true, data: items });
  } catch (error: any) {
    return NextResponse.json({ success: false, message: error.message }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const max = await prisma.whyUsItem.aggregate({ _max: { sortOrder: true } });
    const item = await prisma.whyUsItem.create({
      data: {
        title: body.title ?? "",
        subtitle: body.subtitle ?? null,
        description: body.description ?? "",
        icon: body.icon ?? null,
        stat: body.stat ?? null,
        statLabel: body.statLabel ?? null,
        sortOrder: body.sortOrder ?? (max._max.sortOrder ?? 0) + 1,
        active: body.active ?? true,
      },
    });
    return NextResponse.json({ success: true, id: item.id });
  } catch (error: any) {
    return NextResponse.json({ success: false, message: error.message }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, ...data } = body;
    await prisma.whyUsItem.update({ where: { id }, data });
    return NextResponse.json({ success: true });
  } catch (error: any) {
    return NextResponse.json({ success: false, message: error.message }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const body = await request.json().catch(() => ({}));

    if (body.seed && body.seed === true) {
      /* حذف همه برای seed مجدد */
      await prisma.whyUsItem.deleteMany();
      return NextResponse.json({ success: true });
    }

    if (body.id) {
      await prisma.whyUsItem.delete({ where: { id: body.id } });
      return NextResponse.json({ success: true });
    }

    return NextResponse.json({ success: false, message: "id لازم است" }, { status: 400 });
  } catch (error: any) {
    return NextResponse.json({ success: false, message: error.message }, { status: 500 });
  }
}