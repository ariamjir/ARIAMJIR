import { NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";

const CATS = [
  { name: "فیلترها", slug: "filters" },
  { name: "قطعات هیدرولیک", slug: "hydraulic-parts" },
  { name: "قطعات موتور", slug: "engine-parts" },
  { name: "سیستم برقی", slug: "electrical-parts" },
  { name: "زیربندی و شاسی", slug: "undercarriage" },
];

const BRANDS = [
  { name: "Komatsu", slug: "komatsu" },
  { name: "Caterpillar", slug: "caterpillar" },
  { name: "Volvo", slug: "volvo" },
  { name: "Hitachi", slug: "hitachi" },
];

const PARTS = [
  { title: "فیلتر هیدرولیک کوماتسو PC200-8", slug: "komatsu-pc200-hydraulic-filter", cat: "filters", brand: "komatsu", oem: "207-60-71180" },
  { title: "پمپ هیدرولیک اصلی کاترپیلار 320D", slug: "cat-320d-hydraulic-pump", cat: "hydraulic-parts", brand: "caterpillar", oem: "272-6955" },
  { title: "استارت ولوو EC210B — ۲۴ ولت", slug: "volvo-ec210-starter-24v", cat: "electrical-parts", brand: "volvo", oem: "VOE11717320" },
  { title: "دندهٔ نهایی هیتاچی ZX330", slug: "hitachi-zx330-final-drive", cat: "undercarriage", brand: "hitachi", oem: "9189572" },
  { title: "رادیاتور بیل مکانیکی کوماتسو PC220-7", slug: "komatsu-pc220-radiator", cat: "engine-parts", brand: "komatsu", oem: "206-03-21111" },
  { title: "فیلتر هوا کاترپیلار 950H", slug: "cat-950h-air-filter", cat: "filters", brand: "caterpillar", oem: "291-4930" },
];

/* ✅ enum guessing ایمن — همهٔ ترکیب‌ها را تست می‌کند */
async function createPriceSafely(partId: string) {
  const currencies = ["TOMAN", "IRR", "RIAL", "USD", "EUR"] as const;
  const types = ["FIXED", "BASE", "SALE", "NEGOTIABLE", "ASK", "CONTACT", "AGREEMENT"] as const;

  for (const currency of currencies) {
    for (const priceType of types) {
      try {
        await prisma.partPrice.create({
          data: {
            partId,
            price: 5000000,
            currency: currency as any,
            priceType: priceType as any,
            stock: 10,
          },
        });
        return { ok: true, currency, priceType };
      } catch {
        /* ترکیب نامعتبر — ادامه بده */
      }
    }
  }
  return { ok: false };
}

export async function POST() {
  try {
    const seller = await prisma.user.findFirst({ orderBy: { createdAt: "asc" } });

    const catMap: Record<string, string> = {};
    for (const c of CATS) {
      const found = await prisma.partCategory.upsert({
        where: { slug: c.slug },
        update: {},
        create: { name: c.name, slug: c.slug },
      });
      catMap[c.slug] = found.id;
    }

    const brandMap: Record<string, string> = {};
    for (const b of BRANDS) {
      const found = await prisma.partBrand.upsert({
        where: { slug: b.slug },
        update: {},
        create: { name: b.name, slug: b.slug },
      });
      brandMap[b.slug] = found.id;
    }

    let created = 0;
    let priceOk = false;

    for (const p of PARTS) {
      const exists = await prisma.sparePart.findUnique({ where: { slug: p.slug } });
      if (exists) continue;

      /* ✅ ساخت data به‌صورت any — sellerId فقط در صورت موجود بودن کاربر */
      const data: any = {
        categoryId: catMap[p.cat],
        brandId: brandMap[p.brand],
        title: p.title,
        slug: p.slug,
        oemNumber: p.oem,
        description: `${p.title} — قطعهٔ اصلی با ضمانت اصالت آریا ماشین جم. شمارهٔ فنی: ${p.oem}. مناسب برای ماشین‌آلات سنگین معدنی و راه‌سازی.`,
        status: "PUBLISHED",
        active: true,
      };
      if (seller?.id) data.sellerId = seller.id;

      const part = await prisma.sparePart.create({ data });

      await prisma.partImage.create({
        data: { partId: part.id, url: "/images/machines/default.svg", isPrimary: true },
      });

      const priceResult = await createPriceSafely(part.id);
      if (priceResult.ok) priceOk = true;
      created++;
    }

    return NextResponse.json({
      success: true,
      created,
      priceCreated: priceOk,
      note: priceOk
        ? "قیمت‌ها ساخته شدند"
        : "قطعات بدون قیمت ساخته شدند — از پنل می‌توانید قیمت اضافه کنید",
    });
  } catch (error: any) {
    return NextResponse.json({ success: false, message: error.message }, { status: 500 });
  }
}