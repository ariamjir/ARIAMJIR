import { NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

const SELLERS = [
  {
    name: "گروه صنعتی راهنما",
    slug: "rahnema-group",
    legalName: "شرکت گروه صنعتی راهنما (سهامی خاص)",
    registrationNumber: "۴۵۲۳۱۸",
    nationalId: "۱۰۱۰۱۲۳۴۵۶۷",
    description:
      "بزرگترین تأمین‌کنندهٔ ماشین‌آلات راه‌سازی و معدنی ایران با بیش از ۲۵ سال تجربه و ۸ شعبه در سراسر کشور.",
    phone: "02188106385",
    mobile: "09121234567",
    email: "info@rahnema-group.ir",
    website: "https://rahnema-group.ir",
    establishedYear: 1378,
    employeeCount: 85,
    verified: true,
    featured: true,
    branches: [
      { title: "دفتر مرکزی تهران", address: "تهران، خیابان آزادی، پلاک ۱۲۰", manager: "مهندس احمدی", mobile: "02188106385" },
      { title: "شعبهٔ اصفهان", address: "اصفهان، شهرک صنعتی جی", manager: "آقای رضایی", mobile: "03133456789" },
      { title: "شعبهٔ مشهد", address: "مشهد، بلوار صنعت", manager: "خانم محمدی", mobile: "05138765432" },
    ],
    socials: {
      instagram: "https://instagram.com/rahnema.group",
      telegram: "https://t.me/rahnema_group",
      linkedin: "https://linkedin.com/company/rahnema-group",
    },
    gallery: 4,
    documents: [{ title: "روزنامه رسمی", fileUrl: "/images/machines/default.svg" }],
  },
  {
    name: "پارس ماشین تجهیز",
    slug: "pars-machine",
    legalName: "شرکت پارس ماشین تجهیز",
    registrationNumber: "۵۱۲۴۹۰",
    description: "متخصص فروش بیل مکانیکی و لودر معدنی با گارانتی اصالت.",
    phone: "02144876543",
    mobile: "09129876543",
    email: "sales@pars-machine.ir",
    establishedYear: 1385,
    employeeCount: 42,
    verified: true,
    featured: true,
    branches: [{ title: "دفتر مرکزی", address: "تهران، سعادت‌آباد", manager: "مهندس کریمی", mobile: "02144876543" }],
    socials: { instagram: "https://instagram.com/pars.machine" },
    gallery: 3,
    documents: [],
  },
  {
    name: "آریان تجهیز صنعت",
    slug: "arian-tajhiz",
    legalName: "شرکت آریان تجهیز صنعت",
    registrationNumber: "۳۹۸۲۱۵",
    description: "عرضه‌کنندهٔ قطعات یدکی و ماشین‌آلات دست دوم کارکرده با ضمانت سلامت فنی.",
    phone: "03132345678",
    mobile: "09131112233",
    establishedYear: 1392,
    employeeCount: 28,
    verified: true,
    featured: false,
    branches: [
      { title: "دفتر اصفهان", address: "اصفهان، خیابان چهارباغ", manager: "آقای موسوی", mobile: "03132345678" },
      { title: "انبار شیراز", address: "شیراز، شهرک صنعتی", manager: "آقای حسینی", mobile: "07136543210" },
    ],
    socials: { whatsapp: "09131112233" },
    gallery: 2,
    documents: [],
  },
  {
    name: "تبریز هیدرو تراک",
    slug: "tabriz-hydro",
    legalName: "شرکت تبریز هیدرو تراک",
    registrationNumber: "۲۸۷۱۳۴",
    description: "متخصص تعمیر و فروش پمپ‌های هیدرولیک و قطعات اصلی کوماتسو و کاترپیلار.",
    phone: "04133456789",
    mobile: "09143334455",
    establishedYear: 1395,
    employeeCount: 18,
    verified: false,
    featured: false,
    branches: [{ title: "دفتر تبریز", address: "تبریز، شهرک صنعتی غرب", manager: "مهندس قربانی", mobile: "04133456789" }],
    socials: { instagram: "https://instagram.com/tabriz.hydro" },
    gallery: 3,
    documents: [],
  },
  {
    name: "جنوب ماشین اهواز",
    slug: "south-machine",
    legalName: "شرکت جنوب ماشین خوزستان",
    registrationNumber: "۴۴۵۸۹۲",
    description: "ارائه‌دهندهٔ خدمات اجاره و فروش ماشین‌آلات سنگین در مناطق نفتی جنوب کشور.",
    phone: "06132234567",
    mobile: "09165556677",
    establishedYear: 1390,
    employeeCount: 35,
    verified: true,
    featured: false,
    branches: [
      { title: "دفتر اهواز", address: "اهواز، منطقهٔ صنعتی کیانشهر", manager: "آقای نوری", mobile: "06132234567" },
      { title: "شعبهٔ عسلویه", address: "عسلویه، فاز ۳", manager: "آقای رحیمی", mobile: "07735432100" },
    ],
    socials: { telegram: "https://t.me/south_machine" },
    gallery: 4,
    documents: [{ title: "پروانه کسب", fileUrl: "/images/machines/default.svg" }],
  },
];

export async function POST() {
  try {
    const owner = await prisma.user.findFirst({ orderBy: { createdAt: "asc" } });
    let created = 0;
    let branchesCreated = 0;
    let galleryCreated = 0;
    let documentsCreated = 0;

    for (const s of SELLERS) {
      const exists = await prisma.company.findUnique({ where: { slug: s.slug } });
      if (exists) continue;

      /* ✅ ساخت Company با ownerId اختیاری */
      const data: any = {
        name: s.name,
        slug: s.slug,
        legalName: s.legalName,
        registrationNumber: s.registrationNumber,
        nationalId: s.nationalId,
        description: s.description,
        phone: s.phone,
        mobile: s.mobile,
        email: s.email,
        website: s.website,
        establishedYear: s.establishedYear,
        employeeCount: s.employeeCount,
        verified: s.verified,
        featured: s.featured,
        status: "PUBLISHED",
      };
      if (owner?.id) data.ownerId = owner.id;

      const company = await prisma.company.create({ data });

      /* شعب */
      for (const b of s.branches) {
        await prisma.branch.create({
          data: {
            companyId: company.id,
            title: b.title,
            address: b.address,
            manager: b.manager,
            mobile: b.mobile,
            active: true,
          },
        });
        branchesCreated++;
      }

      /* سوشال */
      await prisma.companySocial.create({
        data: {
          companyId: company.id,
          instagram: s.socials?.instagram ?? null,
          telegram: s.socials?.telegram ?? null,
          whatsapp: s.socials?.whatsapp ?? null,
          linkedin: s.socials?.linkedin ?? null,
        },
      });

      /* گالری */
      for (let i = 0; i < s.gallery; i++) {
        await prisma.companyGallery.create({
          data: { companyId: company.id, image: "/images/machines/default.svg", sortOrder: i },
        });
        galleryCreated++;
      }

      /* اسناد */
      for (const d of s.documents) {
        await prisma.companyDocument.create({
          data: { companyId: company.id, title: d.title, fileUrl: d.fileUrl, verified: true },
        });
        documentsCreated++;
      }

      created++;
    }

    return NextResponse.json({
      success: true,
      created,
      branchesCreated,
      galleryCreated,
      documentsCreated,
      hasOwner: !!owner,
    });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, message: error.message, stack: error.stack?.split("\n").slice(0, 3).join("\n") },
      { status: 500 }
    );
  }
}