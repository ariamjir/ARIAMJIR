import { NextRequest, NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";

import {
  DEFAULT_ITEMS,
  realCounts,
} from "@/lib/home-stats";

const KEY = "stats";

/* سازگاری با دادهٔ قدیمی (متن دستی) */
function normalize(items: any[]) {
  return items.map((x: any) =>
    x?.source
      ? x
      : {
          title: x.title ?? "",
          source: "manual",
          manualText: String(x.value ?? ""),
          suffix: "",
          active: x.active !== false,
        }
  );
}

export async function GET() {
  try {
    const row = await prisma.homePageSection.findFirst({
      where: { key: KEY },
    });

    const items = normalize(
      (row?.config as any)?.items ?? DEFAULT_ITEMS
    );

    const real = await realCounts();

    return NextResponse.json({ success: true, data: { items, real } });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, message: error.message },
      { status: 500 }
    );
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const items = Array.isArray(body?.items) ? body.items : [];

    const existing = await prisma.homePageSection.findFirst({
      where: { key: KEY },
    });

    if (existing) {
      await prisma.homePageSection.update({
        where: { id: existing.id },
        data: { config: { ...(existing.config as any), items } },
      });
    } else {
      await prisma.homePageSection.create({
        data: {
          key: KEY,
          title: "آمار",
          order: 70,
          active: true,
          config: { items },
        },
      });
    }

    return NextResponse.json({ success: true });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, message: error.message },
      { status: 500 }
    );
  }
}