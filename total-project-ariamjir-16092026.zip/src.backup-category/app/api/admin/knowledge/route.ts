import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { slugify, readMinutes } from "@/lib/news";

export async function GET(request: NextRequest) {
  try {
    const id = request.nextUrl.searchParams.get("id");

    if (id) {
      const post = await prisma.knowledgePost.findUnique({ where: { id }, include: { category: true } });
      return NextResponse.json({ success: true, data: post });
    }

    const list = await prisma.knowledgePost.findMany({
      orderBy: { createdAt: "desc" },
      include: { category: true },
    });

    return NextResponse.json({ success: true, data: list });
  } catch (error: any) {
    return NextResponse.json({ success: false, message: error.message }, { status: 500 });
  }
}

function fullPick(body: any) {
  return {
    title: body.title ?? "",
    slug: body.slug ? slugify(body.slug) : slugify(body.title ?? "knowledge"),
    excerpt: body.excerpt ?? null,
    content: body.content ?? null,
    coverImage: body.coverImage ?? null,
    categoryId: body.categoryId || null,
    authorName: body.authorName ?? null,
    tags: Array.isArray(body.tags) ? body.tags : [],
    status: body.status ?? "DRAFT",
    featured: !!body.featured,
    publishedAt: body.publishedAt ? new Date(body.publishedAt) : body.status === "PUBLISHED" ? new Date() : null,
    readMinutes: readMinutes(body.content),
    metaTitle: body.metaTitle ?? null,
    metaDescription: body.metaDescription ?? null,
  };
}

function partialPick(body: any) {
  const data: any = {};

  if (body.title !== undefined) data.title = body.title;
  if (body.slug !== undefined) data.slug = slugify(body.slug);
  if (body.excerpt !== undefined) data.excerpt = body.excerpt;
  if (body.content !== undefined) {
    data.content = body.content;
    data.readMinutes = readMinutes(body.content);
  }
  if (body.coverImage !== undefined) data.coverImage = body.coverImage;
  if (body.categoryId !== undefined) data.categoryId = body.categoryId || null;
  if (body.authorName !== undefined) data.authorName = body.authorName;
  if (body.tags !== undefined) data.tags = body.tags;
  if (body.featured !== undefined) data.featured = !!body.featured;
  if (body.publishedAt !== undefined) {
    data.publishedAt = body.publishedAt ? new Date(body.publishedAt) : null;
  }
  if (body.metaTitle !== undefined) data.metaTitle = body.metaTitle;
  if (body.metaDescription !== undefined) data.metaDescription = body.metaDescription;

  if (body.status !== undefined) {
    data.status = body.status;
    if (body.status === "PUBLISHED" && body.publishedAt === undefined) {
      data.publishedAt = new Date();
    }
  }

  return data;
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    /* ✅ حذف تکی از طریق POST (محیط‌هایی که DELETE را بلاک می‌کنند) */
    if (body.deleteId) {
      await prisma.knowledgePost.delete({ where: { id: body.deleteId } });
      return NextResponse.json({ success: true });
    }

    /* ✅ پاکسازی مقالات خالی از طریق POST */
    if (body.cleanupEmpty) {
      const res = await prisma.knowledgePost.deleteMany({
        where: { OR: [{ content: null }, { content: "" }] },
      });
      return NextResponse.json({ success: true, deleted: res.count });
    }

    const data = fullPick(body);

    const exists = await prisma.knowledgePost.findUnique({ where: { slug: data.slug } });
    if (exists) data.slug = `${data.slug}-${Date.now().toString(36)}`;

    const post = await prisma.knowledgePost.create({ data });
    return NextResponse.json({ success: true, id: post.id });
  } catch (error: any) {
    return NextResponse.json({ success: false, message: error.message }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, ...rest } = body;
    const data = partialPick(rest);

    if (data.slug) {
      const dup = await prisma.knowledgePost.findFirst({ where: { slug: data.slug, id: { not: id } } });
      if (dup) data.slug = `${data.slug}-${Date.now().toString(36)}`;
    }

    await prisma.knowledgePost.update({ where: { id }, data });
    return NextResponse.json({ success: true });
  } catch (error: any) {
    return NextResponse.json({ success: false, message: error.message }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const body = await request.json().catch(() => ({}));

    if (body.empty || body.cleanupEmpty) {
      const res = await prisma.knowledgePost.deleteMany({
        where: { OR: [{ content: null }, { content: "" }] },
      });
      return NextResponse.json({ success: true, deleted: res.count });
    }

    const id = body.id ?? body.deleteId;
    if (id) {
      await prisma.knowledgePost.delete({ where: { id } });
      return NextResponse.json({ success: true });
    }

    return NextResponse.json({ success: false, message: "id لازم است" }, { status: 400 });
  } catch (error: any) {
    return NextResponse.json({ success: false, message: error.message }, { status: 500 });
  }
}