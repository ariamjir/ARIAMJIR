import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { readMinutes } from "@/lib/news";

const POSTS = [
  {
    title: "راهنمای کامل خرید بیل مکانیکی دست‌دوم",
    slug: "buy-used-excavator-guide",
    excerpt: "چک‌لیست ۱۲ موردی بازرسی فنی قبل از خرید بیل مکانیکی کارکرده.",
    cover: "/images/news/brand-5.jpg",
    cat: "training",
    content:
      "## ساعت کارکرد واقعی\nکنتور ساعت را با تاریخچهٔ سرویس‌ها تطبیق دهید؛ میانگین سالم ۲۵۰۰ ساعت در سال است.\n![بازرسی موتور](/images/news/brand-5.jpg)\n## هیدرولیک\nپمپ اصلی، شلنگ‌ها و جک‌ها را زیر بار تست کنید؛ نشتی و صدای غیرعادی یعنی هزینهٔ سنگین.\n## زیربندی\nزنجیر، غلطک و چرخ زنجیر؛ فرسایش بیش از ۵۰٪ یعنی تعویض قریب‌الوقوع.",
  },
  {
    title: "انتخاب لودر مناسب برای بارگیری فله",
    slug: "choose-loader-for-bulk",
    excerpt: "ظرفیت باکت، نیروی شکست و ارتفاع تخلیه؛ سه معیار طلایی انتخاب لودر.",
    cover: "/images/news/brand-3.jpg",
    cat: "training",
    content:
      "## ظرفیت باکت\nبرای بارگیری کامیون ۱۰ چرخ، باکت ۳ متر مکعب به بالا لازم است.\n![لودر در معدن](/images/news/brand-3.jpg)\n## نیروی شکست\nسنگ‌های بزرگ به نیروی شکست بالای ۱۲ تن نیاز دارند.\n## ارتفاع تخلیه\nبا ارتفاع لبهٔ باکت باید از ارتفاع بدنهٔ کامیون بیشتر باشد.",
  },
  {
    title: "چک‌لیست نگهداری هیدرولیک در تابستان",
    slug: "hydraulic-summer-checklist",
    excerpt: "دما، ویسکوزیته و فیلتراسیون؛ سه ضلع مثلث سلامت هیدرولیک.",
    cover: "/images/news/brand-1.jpg",
    cat: "training",
    content:
      "## دمای روغن\nبالای ۸۰ درجه یعنی خنک‌کننده مشکل دارد؛ هر هفته دما را ثبت کنید.\n## فیلترها\nفیلتر مکش و فشار را هر ۵۰۰ ساعت تعویض کنید.\n## نشتی‌یابی\nاتصالات و اورینگ‌ها را زیر بار بازرسی چشمی کنید.",
  },
  {
    title: "جرثقیل بازویی یا دروازه‌ای؟ راهنمای انتخاب",
    slug: "crane-selection-guide",
    excerpt: "مقایسهٔ کاربردی جرثقیل‌های بازویی و دروازه‌ای برای پروژه‌های عمرانی.",
    cover: "/images/news/brand-4.jpg",
    cat: "training",
    content:
      "## جرثقیل بازویی\nانعطاف بالا برای نصب در ارتفاع و فضای باز.\n## جرثقیل دروازه‌ای\nباربری سنگین در مسیر ثابت کارگاهی.\n## جمع‌بندی\nبرای پروژه‌های شهری بازویی و برای پیش‌ساخته دروازه‌ای.",
  },
];

export async function POST() {
  try {
    let created = 0;

    for (const p of POSTS) {
      const exists = await prisma.knowledgePost.findUnique({ where: { slug: p.slug } });
      if (exists) continue;

      const cat = await prisma.newsCategory.findFirst({ where: { slug: p.cat } });

      await prisma.knowledgePost.create({
        data: {
          title: p.title,
          slug: p.slug,
          excerpt: p.excerpt,
          content: p.content,
          coverImage: p.cover,
          categoryId: cat?.id ?? null,
          authorName: "تحریریه آریا MJ",
          status: "PUBLISHED",
          publishedAt: new Date(),
          readMinutes: readMinutes(p.content),
          tags: ["آموزش", "ماشین‌آلات"],
        },
      });
      created++;
    }

    return NextResponse.json({ success: true, created });
  } catch (error: any) {
    return NextResponse.json({ success: false, message: error.message }, { status: 500 });
  }
}