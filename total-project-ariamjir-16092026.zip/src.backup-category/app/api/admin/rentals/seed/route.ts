import { NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";

export async function POST() {
  try {
    const owner = await prisma.user.findFirst({ orderBy: { createdAt: "asc" } });

    const machines = await prisma.machine.findMany({
      where: { status: "PUBLISHED", active: true },
      take: 6,
      orderBy: { createdAt: "desc" },
    });

    if (machines.length === 0) {
      return NextResponse.json(
        { success: false, message: "هیچ ماشین منتشرشده‌ای وجود ندارد" },
        { status: 400 }
      );
    }

    let created = 0;

    for (const m of machines) {
      const exists = await prisma.rentalListing.findFirst({ where: { machineId: m.id } });
      if (exists) continue;

      /* ✅ ownerId فقط در صورت وجود کاربر (فیلد اختیاری در schema) */
      const data: any = {
        machineId: m.id,
        dailyPrice: 25000000,
        weeklyPrice: 150000000,
        monthlyPrice: 550000000,
        deposit: 100000000,
        operatorIncluded: created % 2 === 0,
        fuelIncluded: false,
        transportationIncluded: true,
        minimumRentalDays: 1,
        availableFrom: new Date(),
        availableTo: new Date(Date.now() + 90 * 24 * 3600 * 1000),
      };
      if (owner?.id) data.ownerId = owner.id;

      await prisma.rentalListing.create({ data });
      created++;
    }

    return NextResponse.json({ success: true, created });
  } catch (error: any) {
    return NextResponse.json({ success: false, message: error.message }, { status: 500 });
  }
}