import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { slugify } from "@/lib/news";

export async function GET() {
  try {
    const list = await prisma.newsCategory.findMany({ orderBy: { sortOrder: "asc" } });
    return NextResponse.json({ success: true, data: list });
  } catch (error: any) {
    return NextResponse.json({ success: false, message: error.message }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const { name, color } = await request.json();
    const cat = await prisma.newsCategory.create({
      data: { name, slug: slugify(name) || `cat-${Date.now().toString(36)}`, color: color ?? "#F58220" },
    });
    return NextResponse.json({ success: true, id: cat.id });
  } catch (error: any) {
    return NextResponse.json({ success: false, message: error.message }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { id } = await request.json();
    await prisma.newsCategory.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error: any) {
    return NextResponse.json({ success: false, message: error.message }, { status: 500 });
  }
}