import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { readMinutes } from "@/lib/news";

const CATS = [
  { name: "اخبار بازار", slug: "market-news", color: "#F58220" },
  { name: "تحلیل بازار", slug: "market-analysis", color: "#3b82f6" },
  { name: "رویدادها", slug: "events", color: "#8b5cf6" },
  { name: "آموزش", slug: "training", color: "#10b981" },
];

const POSTS = [
  {
    title: "رشد بازار ماشین‌آلات راهسازی در ایران",
    slug: "iran-road-machinery-market-growth",
    excerpt: "گزارش تازهٔ انجمن ماشین‌آلات از رشد ۲۲ درصدی واردات و فروش داخلی در نیمهٔ اول سال.",
    cover: "/images/blog/news-1.jpg",
    cat: "market-news",
    featured: true,
    content:
      "## رشد بی‌سابقهٔ تقاضا\nبر اساس گزارش تازه، تقاضا برای بیل مکانیکی و لودر در پروژه‌های عمرانی به بالاترین سطح پنج سال اخیر رسیده است.\n![نمودار بازار](/images/blog/news-1.jpg)\n## چشم‌انداز نیمهٔ دوم\nکارشناسان پیش‌بینی می‌کنند با آزادسازی بودجه‌های عمرانی، روند صعودی ادامه یابد.",
  },
  {
    title: "کوماتسو از نسل جدید بیل‌های هیبریدی رونمایی کرد",
    slug: "komatsu-hybrid-excavators-launch",
    excerpt: "نسل جدید بیل‌های هیبریدی کوماتسو با ۳۰٪ مصرف سوخت کمتر معرفی شدند.",
    cover: "/images/blog/news-2.jpg",
    cat: "market-news",
    featured: false,
    content:
      "## فناوری هیبریدی\nکوماتسو اعلام کرد نسل جدید ماشین‌های هیبریدی خود را وارد بازار آسیا می‌کند.\n## مصرف سوخت\nمدل PC220 هیبریدی تا ۳۰٪ مصرف سوخت کمتری نسبت به نسل قبل دارد.",
  },
  {
    title: "نمایشگاه بین‌المللی ماشین‌آلات سنگین تهران",
    slug: "tehran-heavy-machinery-expo",
    excerpt: "بزرگ‌ترین رویداد سال صنعت ماشین‌آلات با حضور ۱۲۰ برند داخلی و خارجی برگزار می‌شود.",
    cover: "/images/blog/news-3.jpg",
    cat: "events",
    featured: false,
    content:
      "## جزئیات رویداد\nنمایشگاه امسال در محل دائمی نمایشگاه‌های تهران برگزار خواهد شد.\n## غرفهٔ آریا MJ\nتیم آریا ماشین جم در سالن ۲، غرفهٔ ۴۵ میزبان شماست.",
  },
  {
    title: "راهنمای کامل نگهداری بیل مکانیکی در تابستان",
    slug: "excavator-summer-maintenance-guide",
    excerpt: "چک‌لیست ۱۲ موردی نگهداری سیستم هیدرولیک و خنک‌کننده در گرمای تابستان.",
    cover: "/images/hero/hero-4.jpg",
    cat: "training",
    featured: false,
    content:
      "## سیستم خنک‌کننده\nرادیاتور را هر هفته از گرد و غبار پاک‌سازی کنید.\n## هیدرولیک\nسطح روغن هیدرولیک و شلنگ‌ها را روزانه بررسی کنید.",
  },
];

export async function POST() {
  try {
    const catMap: Record<string, string> = {};
    for (const c of CATS) {
      const found = await prisma.newsCategory.upsert({
        where: { slug: c.slug },
        update: {},
        create: { name: c.name, slug: c.slug, color: c.color },
      });
      catMap[c.slug] = found.id;
    }

    let created = 0;
    for (const p of POSTS) {
      const exists = await prisma.newsPost.findUnique({ where: { slug: p.slug } });
      if (exists) continue;

      await prisma.newsPost.create({
        data: {
          title: p.title,
          slug: p.slug,
          excerpt: p.excerpt,
          content: p.content,
          coverImage: p.cover,
          categoryId: catMap[p.cat],
          authorName: "تحریریه آریا MJ",
          status: "PUBLISHED",
          featured: p.featured,
          publishedAt: new Date(),
          readMinutes: readMinutes(p.content),
          tags: ["ماشین‌آلات"],
        },
      });
      created++;
    }

    return NextResponse.json({ success: true, created });
  } catch (error: any) {
    return NextResponse.json({ success: false, message: error.message }, { status: 500 });
  }
}