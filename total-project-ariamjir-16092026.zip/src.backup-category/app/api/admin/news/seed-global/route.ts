import { NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";

import { readMinutes } from "@/lib/news";

const POSTS = [
  {
    title: "موج برقی‌شدن ماشین‌آلات سنگین؛ بیل‌های برقی نسل جدید وارد معادن شدند",
    slug: "electric-excavators-enter-mines-2026",
    excerpt: "غول‌های سازنده با عرضهٔ بیل‌های مکانیکی برقی شارژسریع، هزینهٔ انرژی را تا ۵۰٪ کاهش می‌دهند.",
    cover: "/images/news/brand-1.jpg",
    cat: "market-news",
    tags: ["برقی", "بیل مکانیکی", "انرژی پاک"],
    content:
      "## رقابت برقی‌ها در فست‌شارژ\nنسل جدید بیل‌های برقی با شارژرهای ۳۰۰ کیلوواتی تنها در ۲۰ دقیقه شارژ می‌شوند و یک شیفت کامل کار می‌کنند.\n![بیل برقی](/images/news/brand-1.jpg)\n## کاهش چشمگیر هزینه\nبر اساس گزارش اپراتورهای اروپایی، هزینهٔ انرژی هر ساعت کارکرد نسبت به دیزل تا ۵۰٪ کاهش یافته است.\n## چشم‌انداز بازار\nتحلیلگران پیش‌بینی می‌کنند تا ۲۰۲۸ یک‌سوم فروش بیل‌های شهری در اروپا برقی باشد.",
  },
  {
    title: "معدن بدون راننده؛ رکوردشکنی ناوگان خودران در استرالیا",
    slug: "autonomous-haul-fleet-record-australia",
    excerpt: "ناوگان کامیون‌های خودران یک اپراتور بزرگ آهن، از مرز ۱۰ میلیارد تن‌کیلومتر عبور کرد.",
    cover: "/images/news/brand-2.jpg",
    cat: "market-analysis",
    tags: ["خودران", "معدن آهن", "اتوماسیون"],
    content:
      "## ایمنی و بهره‌وری هم‌زمان\nکامیون‌های خودران با لیدار و دوربین‌های سقفی، بدون خستگی و با مسیرهای بهینه کار می‌کنند.\n![کامیون خودران](/images/news/brand-2.jpg)\n## کاهش ۱۸٪ هزینهٔ حمل\nگزارش فصلی اپراتور نشان می‌دهد هزینهٔ هر تن‌کیلومتر نسبت به ناوگان انسانی ۱۸٪ کمتر است.\n## درس برای ایران\nمتخصصان معتقدند معادن بزرگ مس و آهن ایران کاندیدای جدی اتوماسیون مرحله‌ای هستند.",
  },
  {
    title: "لودرهای برقی در معادن سنگ اروپا؛ کاهش ۴۰٪ هزینه انرژی",
    slug: "electric-loaders-europe-quarries",
    excerpt: "معادن سنگ‌آهک آلپ با جایگزینی لودرهای دیزلی، آلایندگی و صدا را نیز نزدیک به صفر رسانده‌اند.",
    cover: "/images/news/brand-3.jpg",
    cat: "events",
    tags: ["لودر برقی", "اروپا", "معدن سنگ"],
    content:
      "## تحول در معادن آلپ\nلودرهای برقی در محیط‌های بسته و تونلی که تهویه محدود است، برگ برندهٔ مطلق هستند.\n![لودر برقی](/images/news/brand-3.jpg)\n## بازگشت سرمایهٔ ۳ ساله\nاختلاف قیمت خرید نسبت به دیزل، با صرفه‌جویی انرژی و حذف سرویس موتور در ۳ سال جبران می‌شود.\n## استاندارد جدید شهرداری‌ها\nچند شهرداری بزرگ اروپا پیمانکاران را به استفاده از ماشین‌آلات برقی در پروژه‌های شهری ملزم کرده‌اند.",
  },
  {
    title: "رکورد استخراج مس با غول‌های حفاری؛ تقاضای جهانی برای بیل‌های عظیم",
    slug: "copper-mining-record-mining-shovels",
    excerpt: "جهش قیمت مس، سفارش بیل‌های ۱۰۰ تنی را به بالاترین سطح دو دههٔ اخیر رسانده است.",
    cover: "/images/news/brand-4.jpg",
    cat: "market-news",
    tags: ["مس", "بیل معدنی", "بازار جهانی"],
    content:
      "## تشنگی جهان برای مس\nگذار انرژی و شبکه‌های برق، تقاضای مس را بی‌سابقه کرده و معادن جدید صف کشیده‌اند.\n![بیل عظیم مس](/images/news/brand-4.jpg)\n## صف سفارش ۲۴ ماهه\nتولیدکنندگان بیل‌های عظیم اعلام کرده‌اند ظرفیت سفارش تا دو سال آینده تکمیل است.\n## فرصت بازار ثانویه\nکمبود دستگاه نو، بازار ماشین‌آلات دست‌دوم و بازسازی‌شده را داغ‌تر از همیشه کرده است.",
  },
  {
    title: "نگهداری پیش‌بینانه با هوش مصنوعی؛ کاهش ۳۰٪ خواب دستگاه‌ها",
    slug: "ai-predictive-maintenance-30-percent",
    excerpt: "سنسور ارتعاش + مدل هوش مصنوعی، خرابی پمپ و موتور را هفته‌ها قبل پیش‌بینی می‌کند.",
    cover: "/images/news/brand-5.jpg",
    cat: "training",
    tags: ["هوش مصنوعی", "نگهداری", "هیدرولیک"],
    content:
      "## از تعمیر اضطراری تا پیش‌بینی\nالگوریتم‌ها با تحلیل ارتعاش، دما و فشار هیدرولیک، الگوی خرابی را هفته‌ها زودتر شناسایی می‌کنند.\n![تشخیص هوشمند](/images/news/brand-5.jpg)\n## چک‌لیست شروع\nنصب سنسور روی پمپ اصلی، ثبت روزانهٔ دمای روغن و اتصال به داشبورد، سه گام اول هر ناوگان است.\n## نتیجهٔ میدانی\nناوگان‌های پیشرو کاهش ۳۰٪ توقف غیربرنامه‌ای و ۲۵٪ کاهش هزینهٔ قطعه را گزارش کرده‌اند.",
  },
];

export async function POST() {
  try {
    let created = 0;

    for (const p of POSTS) {
      const exists = await prisma.newsPost.findUnique({ where: { slug: p.slug } });
      if (exists) continue;

      const cat = await prisma.newsCategory.findFirst({ where: { slug: p.cat } });

      await prisma.newsPost.create({
        data: {
          title: p.title,
          slug: p.slug,
          excerpt: p.excerpt,
          content: p.content,
          coverImage: p.cover,
          categoryId: cat?.id ?? null,
          authorName: "تحریریه آریا MJ",
          status: "PUBLISHED",
          publishedAt: new Date(),
          readMinutes: readMinutes(p.content),
          tags: p.tags,
        },
      });

      created++;
    }

    return NextResponse.json({ success: true, created });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, message: error.message },
      { status: 500 }
    );
  }
}