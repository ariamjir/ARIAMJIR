import { NextRequest, NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";

export async function GET() {
  const row = await prisma.homePageSection.findFirst({ where: { key: "ai-news" } });
  const cfg = (row?.config as any) ?? { enabled: true };
  return NextResponse.json({ success: true, data: cfg });
}

export async function PUT(request: NextRequest) {
  const body = await request.json();
  const row = await prisma.homePageSection.findFirst({ where: { key: "ai-news" } });

  if (row) {
    await prisma.homePageSection.update({ where: { id: row.id }, data: { config: body } });
  } else {
    await prisma.homePageSection.create({
      data: { key: "ai-news", title: "خبرنگار AI", order: 90, active: true, config: body },
    });
  }

  return NextResponse.json({ success: true });
}