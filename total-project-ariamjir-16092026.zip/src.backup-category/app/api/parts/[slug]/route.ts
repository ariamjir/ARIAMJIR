import { NextRequest, NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ slug: string }> }
) {
  try {
    const { slug } = await params;

    const part = await prisma.sparePart.findUnique({
      where: { slug },
      include: {
        brand: true,
        category: true,
        price: true,
        images: { orderBy: { sortOrder: "asc" } },
        documents: true,
      },
    });

    if (!part || part.status !== "PUBLISHED" || !part.active) {
      return NextResponse.json({ success: false, message: "یافت نشد" }, { status: 404 });
    }

    const related = await prisma.sparePart.findMany({
      where: { status: "PUBLISHED", active: true, id: { not: part.id }, categoryId: part.categoryId },
      take: 4,
      include: { brand: true, price: true, images: { take: 1, orderBy: { sortOrder: "asc" } } },
    });

    return NextResponse.json({ success: true, data: { part, related } });
  } catch (error: any) {
    return NextResponse.json({ success: false, message: error.message }, { status: 500 });
  }
}