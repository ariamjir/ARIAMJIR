import { NextRequest, NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";

export const revalidate = 60;

export async function GET(request: NextRequest) {
  try {
    const sp = request.nextUrl.searchParams;
    const page = Math.max(1, Number(sp.get("page") ?? 1));
    const category = sp.get("category") ?? "";
    const brand = sp.get("brand") ?? "";
    const q = sp.get("q") ?? "";
    const limit = 12;

    const where: any = { status: "PUBLISHED", active: true };
    if (category) where.category = { slug: category };
    if (brand) where.brand = { slug: brand };
    if (q.trim()) {
      where.OR = [
        { title: { contains: q.trim() } },
        { oemNumber: { contains: q.trim() } },
        { sku: { contains: q.trim() } },
      ];
    }

    const [items, total, categories, brands] = await Promise.all([
      prisma.sparePart.findMany({
        where,
        orderBy: { createdAt: "desc" },
        skip: (page - 1) * limit,
        take: limit,
        include: {
          brand: true,
          category: true,
          price: true,
          images: { orderBy: { sortOrder: "asc" }, take: 1 },
        },
      }),
      prisma.sparePart.count({ where }),
      prisma.partCategory.findMany({ where: { active: true } }),
      prisma.partBrand.findMany({ where: { active: true } }),
    ]);

    return NextResponse.json({
      success: true,
      data: {
        items,
        total,
        page,
        pages: Math.max(1, Math.ceil(total / limit)),
        categories,
        brands,
      },
    });
  } catch (error: any) {
    return NextResponse.json({ success: false, message: error.message }, { status: 500 });
  }
}