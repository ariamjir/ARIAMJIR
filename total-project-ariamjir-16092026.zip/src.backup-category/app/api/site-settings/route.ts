import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getSiteSettings } from "@/lib/site-settings";

export async function GET() {
  try {
    const settings = await getSiteSettings();
    return NextResponse.json({ success: true, data: settings });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, message: error.message },
      { status: 500 }
    );
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();

    const data: any = {
      logoUrl: body.logoUrl,
      brandName: body.brandName,
      tagline: body.tagline,
      about: body.about,
      phones: body.phones ?? [],
      mobiles: body.mobiles ?? [],
      emails: body.emails ?? [],
      address: body.address,
      workingHours: body.workingHours,
      socials: body.socials ?? [],
      customColumns: body.customColumns ?? [],
      trustBadges: body.trustBadges ?? [],
      footerLinks: body.footerLinks ?? [],
      copyright: body.copyright,
      newsletterEnabled: body.newsletterEnabled ?? true,
      newsletterTitle: body.newsletterTitle ?? "",
      newsletterDesc: body.newsletterDesc ?? "",
    };

    await prisma.siteSettings.upsert({
      where: { id: "main" },
      update: data,
      create: {
        id: "main",
        brandName: data.brandName ?? "ARIA MJ",
        tagline: data.tagline ?? "",
        ...data,
      },
    });

    return NextResponse.json({ success: true });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, message: error.message },
      { status: 500 }
    );
  }
}