import { NextRequest, NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";

export const revalidate = 300;

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ slug: string }> },
) {
  try {
    const { slug } = await params;

    const normalizedSlug = slug.trim();

    if (!normalizedSlug) {
      return NextResponse.json(
        {
          success: false,
          message: "شناسه فروشنده معتبر نیست",
        },
        {
          status: 400,
        },
      );
    }

    /*
     * ------------------------------------------------------------
     * Company
     * ------------------------------------------------------------
     */
    const company = await prisma.company.findUnique({
      where: {
        slug: normalizedSlug,
      },
    });

    if (!company || company.status !== "PUBLISHED") {
      return NextResponse.json(
        {
          success: false,
          message: "فروشنده یافت نشد",
        },
        {
          status: 404,
        },
      );
    }

    /*
     * ------------------------------------------------------------
     * Main relations
     * ------------------------------------------------------------
     */
    const [
      branches,
      documents,
      gallery,
      socials,
      reviews,
      machines,
      avgAgg,
      reviewCount,
      machineCount,
      related,
    ] = await Promise.all([
      /*
       * Branches
       */
      prisma.branch.findMany({
        where: {
          companyId: company.id,
          active: true,
        },
        orderBy: {
          title: "asc",
        },
      }),

      /*
       * Verified company documents
       */
      prisma.companyDocument.findMany({
        where: {
          companyId: company.id,
          verified: true,
        },
        orderBy: {
          createdAt: "desc",
        },
      }),

      /*
       * Company gallery
       */
      prisma.companyGallery.findMany({
        where: {
          companyId: company.id,
        },
        orderBy: {
          sortOrder: "asc",
        },
      }),

      /*
       * Social profiles
       */
      prisma.companySocial.findMany({
        where: {
          companyId: company.id,
        },
        take: 1,
      }),

      /*
       * Latest reviews
       */
      prisma.companyReview.findMany({
        where: {
          companyId: company.id,
        },
        orderBy: {
          createdAt: "desc",
        },
        take: 20,
        select: {
          id: true,
          rating: true,
          comment: true,
          createdAt: true,
        },
      }),

      /*
       * Published machines
       *
       * sellerId به User اشاره می‌کند،
       * بنابراین company.ownerId صحیح است.
       */
      prisma.machine.findMany({
        where: {
          sellerId: company.ownerId,
          status: "PUBLISHED",
          active: true,
        },
        orderBy: {
          createdAt: "desc",
        },
        take: 12,
        include: {
          brand: true,
          category: true,
          specification: true,
          price: true,
          images: {
            take: 1,
            orderBy: {
              sortOrder: "asc",
            },
          },
        },
      }),

      /*
       * Average rating
       */
      prisma.companyReview.aggregate({
        where: {
          companyId: company.id,
        },
        _avg: {
          rating: true,
        },
      }),

      /*
       * Review count
       */
      prisma.companyReview.count({
        where: {
          companyId: company.id,
        },
      }),

      /*
       * Published machine count
       */
      prisma.machine.count({
        where: {
          sellerId: company.ownerId,
          status: "PUBLISHED",
          active: true,
        },
      }),

      /*
       * Related sellers
       *
       * فعلاً همان منطق قبلی حفظ شده:
       * فروشندگان منتشرشده به‌جز فروشنده جاری.
       */
      prisma.company.findMany({
        where: {
          status: "PUBLISHED",
          id: {
            not: company.id,
          },
        },
        orderBy: [
          {
            featured: "desc",
          },
          {
            createdAt: "desc",
          },
        ],
        take: 6,
        select: {
          id: true,
          name: true,
          slug: true,
          logo: true,
          description: true,
          verified: true,
          featured: true,
        },
      }),
    ]);

    /*
     * ------------------------------------------------------------
     * Resolve branch locations
     * ------------------------------------------------------------
     *
     * Branch در Prisma فقط provinceId/cityId دارد،
     * بنابراین نام‌ها را با دو query می‌گیریم.
     */
    const provinceIds = Array.from(
      new Set(
        branches
          .map((branch) => branch.provinceId)
          .filter((id): id is string => Boolean(id)),
      ),
    );

    const cityIds = Array.from(
      new Set(
        branches
          .map((branch) => branch.cityId)
          .filter((id): id is string => Boolean(id)),
      ),
    );

    const [provinces, cities] = await Promise.all([
      provinceIds.length > 0
        ? prisma.province.findMany({
            where: {
              id: {
                in: provinceIds,
              },
            },
            select: {
              id: true,
              name: true,
            },
          })
        : Promise.resolve([]),

      cityIds.length > 0
        ? prisma.city.findMany({
            where: {
              id: {
                in: cityIds,
              },
            },
            select: {
              id: true,
              name: true,
            },
          })
        : Promise.resolve([]),
    ]);

    const provinceMap = new Map(
      provinces.map((province) => [
        province.id,
        province.name,
      ]),
    );

    const cityMap = new Map(
      cities.map((city) => [
        city.id,
        city.name,
      ]),
    );

    const branchesFormatted = branches.map((branch) => ({
      ...branch,

      city: branch.cityId
        ? {
            id: branch.cityId,
            name: cityMap.get(branch.cityId) ?? null,
          }
        : null,

      province: branch.provinceId
        ? {
            id: branch.provinceId,
            name: provinceMap.get(branch.provinceId) ?? null,
          }
        : null,
    }));

    /*
     * ------------------------------------------------------------
     * Review statistics
     * ------------------------------------------------------------
     */
    const avgRating = avgAgg._avg.rating ?? 0;

    /*
     * ------------------------------------------------------------
     * Response
     * ------------------------------------------------------------
     *
     * ساختار اصلی پاسخ حفظ شده است.
     */
    return NextResponse.json(
      {
        success: true,

        data: {
          company,

          branches: branchesFormatted,

          documents,

          gallery,

          socials,

          reviews,

          machines,

          avgRating,

          reviewCount,

          machineCount,

          related,
        },
      },
      {
        headers: {
          "Cache-Control":
            "public, s-maxage=300, stale-while-revalidate=60",
        },
      },
    );
  } catch (error) {
    console.error(
      "GET /api/sellers/[slug] error:",
      error,
    );

    return NextResponse.json(
      {
        success: false,
        message: "خطا در دریافت اطلاعات فروشنده",
      },
      {
        status: 500,
      },
    );
  }
}