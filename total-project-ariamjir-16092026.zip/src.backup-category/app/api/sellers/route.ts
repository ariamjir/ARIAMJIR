import { NextRequest, NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";
export const revalidate = 300;

const PAGE_SIZE = 12;
const MAX_PAGE = 1000;

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;

    const rawPage = Number(searchParams.get("page") ?? "1");

    const page = Number.isFinite(rawPage)
      ? Math.min(Math.max(Math.floor(rawPage), 1), MAX_PAGE)
      : 1;

    const query = searchParams.get("q")?.trim() ?? "";
    const featuredOnly = searchParams.get("featured") === "1";

    const where = {
      status: "PUBLISHED" as const,

      ...(featuredOnly
        ? {
            featured: true,
          }
        : {}),

      ...(query
        ? {
            OR: [
              {
                name: {
                  contains: query,
                  mode: "insensitive" as const,
                },
              },
              {
                legalName: {
                  contains: query,
                  mode: "insensitive" as const,
                },
              },
              {
                description: {
                  contains: query,
                  mode: "insensitive" as const,
                },
              },
            ],
          }
        : {}),
    };

    const [companies, total] = await Promise.all([
      prisma.company.findMany({
        where,

        orderBy: [
          { featured: "desc" },
          { verified: "desc" },
          { createdAt: "desc" },
        ],

        skip: (page - 1) * PAGE_SIZE,
        take: PAGE_SIZE,

        include: {
          branches: {
            where: {
              active: true,
            },
            orderBy: {
              title: "asc",
            },
            take: 3,
          },

          _count: {
            select: {
              reviews: true,
              gallery: true,
            },
          },
        },
      }),

      prisma.company.count({
        where,
      }),
    ]);

    /*
     * اگر فروشنده‌ای وجود نداشته باشد،
     * نیازی به Queryهای بعدی نداریم.
     */
    if (companies.length === 0) {
      return NextResponse.json(
        {
          success: true,
          data: {
            items: [],
            total,
            page,
            pages: Math.max(1, Math.ceil(total / PAGE_SIZE)),
            pageSize: PAGE_SIZE,
          },
        },
        {
          headers: {
            "Cache-Control":
              "public, s-maxage=300, stale-while-revalidate=600",
          },
        }
      );
    }

    const companyIds = companies.map((company) => company.id);

    /*
     * برای Rating از N+1 Query جلوگیری می‌کنیم.
     */
    const ratings = await prisma.companyReview.groupBy({
      by: ["companyId"],

      where: {
        companyId: {
          in: companyIds,
        },
      },

      _avg: {
        rating: true,
      },

      _count: {
        _all: true,
      },
    });

    const ratingMap = new Map(
      ratings.map((item) => [
        item.companyId,
        {
          avgRating: item._avg.rating ?? 0,
          reviewCount: item._count._all,
        },
      ])
    );

    /*
     * Company به User متصل است و Machine نیز از طریق sellerId
     * به همان User متصل می‌شود.
     *
     * بنابراین تعداد ماشین‌های فعال را بر اساس ownerId شرکت
     * به صورت یکجا محاسبه می‌کنیم.
     */
    const ownerIds = companies
      .map((company) => company.ownerId)
      .filter((id): id is string => Boolean(id));

    const machineCounts =
      ownerIds.length > 0
        ? await prisma.machine.groupBy({
            by: ["sellerId"],

            where: {
              sellerId: {
                in: ownerIds,
              },
              status: "PUBLISHED",
              active: true,
            },

            _count: {
              _all: true,
            },
          })
        : [];

    const machineCountMap = new Map(
      machineCounts.map((item) => [
        item.sellerId,
        item._count._all,
      ])
    );

    /*
     * Branch در Schema فعلی relation مستقیم با City / Province ندارد.
     * بنابراین شهر و استان را با IDهای موجود در Branch resolve می‌کنیم.
     */
    const cityIds = [
      ...new Set(
        companies.flatMap((company) =>
          company.branches
            .map((branch) => branch.cityId)
            .filter((id): id is string => Boolean(id))
        )
      ),
    ];

    const provinceIds = [
      ...new Set(
        companies.flatMap((company) =>
          company.branches
            .map((branch) => branch.provinceId)
            .filter((id): id is string => Boolean(id))
        )
      ),
    ];

    const [cities, provinces] = await Promise.all([
      cityIds.length > 0
        ? prisma.city.findMany({
            where: {
              id: {
                in: cityIds,
              },
              active: true,
            },
            select: {
              id: true,
              name: true,
            },
          })
        : [],

      provinceIds.length > 0
        ? prisma.province.findMany({
            where: {
              id: {
                in: provinceIds,
              },
              active: true,
            },
            select: {
              id: true,
              name: true,
            },
          })
        : [],
    ]);

    const cityMap = new Map(
      cities.map((city) => [city.id, city.name])
    );

    const provinceMap = new Map(
      provinces.map((province) => [
        province.id,
        province.name,
      ])
    );

    const items = companies.map((company) => {
      const rating = ratingMap.get(company.id);

      const topBranch = company.branches[0];

      const topCity = topBranch?.cityId
        ? cityMap.get(topBranch.cityId) ?? null
        : null;

      const topProvince = topBranch?.provinceId
        ? provinceMap.get(topBranch.provinceId) ?? null
        : null;

      const avgRating = rating?.avgRating ?? 0;

      const machineCount = company.ownerId
        ? machineCountMap.get(company.ownerId) ?? 0
        : 0;

      return {
        ...company,

        avgRating,

        reviewCount:
          rating?.reviewCount ?? company._count.reviews,

        activeBranchCount: company.branches.length,

        activeMachineCount: machineCount,

        galleryCount: company._count.gallery,

        topCity,

        topProvince,
      };
    });

    const pages = Math.max(
      1,
      Math.ceil(total / PAGE_SIZE)
    );

    return NextResponse.json(
      {
        success: true,

        data: {
          items,
          total,
          page,
          pages,
          pageSize: PAGE_SIZE,
        },
      },

      {
        headers: {
          "Cache-Control":
            "public, s-maxage=300, stale-while-revalidate=600",
        },
      }
    );
  } catch (error) {
    console.error("[GET /api/sellers]", error);

    return NextResponse.json(
      {
        success: false,
        message: "خطا در دریافت فهرست فروشندگان",
      },
      {
        status: 500,
      }
    );
  }
}

