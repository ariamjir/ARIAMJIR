import { NextRequest, NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ slug: string }> }
) {
  try {
    const { slug } = await params;

    const listing = await prisma.rentalListing.findFirst({
      where: { machine: { slug }, status: { in: ["APPROVED", "PUBLISHED"] } },
      include: {
        machine: {
          include: {
            brand: true,
            category: true,
            images: { orderBy: { sortOrder: "asc" } },
            specification: true,
          },
        },
      },
    });

    if (!listing) {
      return NextResponse.json({ success: false, message: "یافت نشد" }, { status: 404 });
    }

    const related = await prisma.rentalListing.findMany({
      where: {
        status: { in: ["APPROVED", "PUBLISHED"] },
        id: { not: listing.id },
        machine: { categoryId: listing.machine.categoryId },
      },
      take: 4,
      include: { machine: { include: { brand: true, images: { take: 1 } } } },
    });

    return NextResponse.json({ success: true, data: { listing, related } });
  } catch (error: any) {
    return NextResponse.json({ success: false, message: error.message }, { status: 500 });
  }
}