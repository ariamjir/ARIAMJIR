import { NextRequest, NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";

export const revalidate = 60;

export async function GET(request: NextRequest) {
  try {
    const sp = request.nextUrl.searchParams;
    const page = Math.max(1, Number(sp.get("page") ?? 1));
    const category = sp.get("category") ?? "";
    const q = sp.get("q") ?? "";
    const limit = 12;

    const where: any = {
      status: { in: ["APPROVED", "PUBLISHED"] },
      machine: { status: "PUBLISHED", active: true },
    };
    if (category) where.machine = { ...where.machine, category: { slug: category } };
    if (q.trim()) where.machine = { ...where.machine, title: { contains: q.trim() } };

    const [items, total, categories] = await Promise.all([
      prisma.rentalListing.findMany({
        where,
        orderBy: { createdAt: "desc" },
        skip: (page - 1) * limit,
        take: limit,
        include: {
          machine: {
            include: {
              brand: true,
              category: true,
              specification: true,
              images: { take: 1 },
            },
          },
        },
      }),
      prisma.rentalListing.count({ where }),
      prisma.category.findMany({ take: 30 }),
    ]);

    return NextResponse.json({
      success: true,
      data: { items, total, page, pages: Math.max(1, Math.ceil(total / limit)), categories },
    });
  } catch (error: any) {
    return NextResponse.json({ success: false, message: error.message }, { status: 500 });
  }
}