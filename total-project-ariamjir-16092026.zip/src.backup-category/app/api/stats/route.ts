import { NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";

import {
  DEFAULT_ITEMS,
  resolveStats,
} from "@/lib/home-stats";

/* آمار زندهٔ سایت — برای پنل کوچک هیرو */
export const revalidate = 60;

export async function GET() {
  try {
    const row = await prisma.homePageSection.findFirst({
      where: { key: "stats" },
    });

    const items = (row?.config as any)?.items ?? DEFAULT_ITEMS;

    const stats = await resolveStats(items);

    return NextResponse.json({ success: true, data: stats });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, message: error.message },
      { status: 500 }
    );
  }
}