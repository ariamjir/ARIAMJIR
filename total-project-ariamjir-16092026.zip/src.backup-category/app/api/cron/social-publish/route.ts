import { NextResponse } from "next/server";

import { getQueue, publishMachine } from "@/lib/social/publisher";

export const maxDuration = 60;

export async function GET() {
  try {
    const hasTelegram =
      !!process.env.TELEGRAM_BOT_TOKEN && !!process.env.TELEGRAM_CHAT_ID;

    if (!hasTelegram) {
      return NextResponse.json({
        success: true,
        published: 0,
        note: "تلگرام تنظیم نشده — TELEGRAM_BOT_TOKEN و TELEGRAM_CHAT_ID را در .env قرار دهید",
      });
    }

    console.log("🔍 [Social Publish] شروع بررسی صف انتشار...");
    const queue = await getQueue();
    console.log(`✅ [Social Publish] تعداد آگهی‌های آمادهٔ انتشار: ${queue.length}`);

    let published = 0;
    const errors: string[] = [];

    for (const m of queue.slice(0, 5)) {
      try {
        console.log(`📤 [Social Publish] در حال انتشار: ${m.slug}`);
        await publishMachine(m.id, "telegram");
        published++;
        console.log(`✅ [Social Publish] با موفقیت منتشر شد: ${m.slug}`);
      } catch (e: any) {
        console.error(`❌ [Social Publish] خطا در انتشار ${m.slug}:`, e.message);
        errors.push(`${m.slug}: ${e.message}`);
      }
    }

    return NextResponse.json({ success: true, published, errors });
  } catch (error: any) {
    console.error("💥 [Social Publish] خطای بحرانی:", error);
    return NextResponse.json(
      { 
        success: false, 
        message: error.message, 
        stack: error.stack 
      },
      { status: 500 }
    );
  }
}