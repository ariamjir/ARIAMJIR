import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function POST(request: NextRequest) {
  try {
    const topic = request.nextUrl.searchParams.get("topic") ?? "خدمات پس از فروش ماشین‌آلات سنگین";

    const max = await prisma.whyUsItem.aggregate({ _max: { sortOrder: true } });
    const nextOrder = (max._max.sortOrder ?? 0) + 1;

    /* تولید خودکار یک مزیت جدید با ساختار استاندارد */
    const templates = [
      { title: `${topic} حرفه‌ای`, subtitle: "تخصص ما، آسودگی شما", description: `در ${topic}، ما استانداردهای جهانی را به‌کار می‌بریم. تیم متخصص ما با سال‌ها تجربه، کیفیت تحویل بی‌نقص را تضمین می‌کند.`, icon: "award", stat: "A+", statLabel: "کیفیت" },
      { title: `${topic} سریع و مطمئن`, subtitle: "زمان طلاست", description: `فرآیند ${topic} در آریا ماشین جم بهینه‌سازی شده تا در کمترین زمان ممکن، بهترین نتیجه را دریافت کنید.`, icon: "zap", stat: "۲۴h", statLabel: "تحویل" },
    ];

    const t = templates[Math.floor(Math.random() * templates.length)];

    const item = await prisma.whyUsItem.create({
      data: {
        title: t.title,
        subtitle: t.subtitle,
        description: t.description,
        icon: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>`,
        stat: t.stat,
        statLabel: t.statLabel,
        sortOrder: nextOrder,
      },
    });

    return NextResponse.json({ success: true, id: item.id });
  } catch (error: any) {
    return NextResponse.json({ success: false, message: error.message }, { status: 500 });
  }
}