import { NextRequest, NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";

import { readMinutes, slugify } from "@/lib/news";

import { autoAuthor } from "@/server/ai/auto-author";

export async function GET(request: NextRequest) {
  return run(request);
}

export async function POST(request: NextRequest) {
  return run(request);
}

async function run(request: NextRequest) {
  try {
    const settings = await prisma.homePageSection.findFirst({ where: { key: "ai-knowledge" } });
    const cfg = (settings?.config as any) ?? { enabled: true };

    const manual = request.nextUrl.searchParams.get("force") === "1";
    if (!cfg.enabled && !manual) return NextResponse.json({ success: true, skipped: true });

    /* ✅ عناوین موجود برای جلوگیری از تکرار */
    const existing = (
      await prisma.knowledgePost.findMany({ select: { title: true } })
    ).map((x) => x.title);

    const { ai, cover } = await autoAuthor("knowledge", existing);

    if (!ai) {
      return NextResponse.json({
        success: true,
        skipped: true,
        message: "همهٔ موضوعات فعلی استفاده شده‌اند؛ موضوع تازه‌ای در صف نیست.",
      });
    }

    let slug = slugify(ai.title ?? "ai-knowledge") || `ai-k-${Date.now().toString(36)}`;
    const dup = await prisma.knowledgePost.findUnique({ where: { slug } });
    if (dup) slug = `${slug}-${Date.now().toString(36)}`;

    const cat = await prisma.newsCategory.findFirst({ where: { slug: ai.categorySlug ?? "training" } });

    const post = await prisma.knowledgePost.create({
      data: {
        title: (ai.title ?? "مقالهٔ هوش مصنوعی").slice(0, 160),
        slug,
        excerpt: ai.excerpt ?? "",
        content: ai.content ?? "",
        coverImage: cover,
        categoryId: cat?.id ?? null,
        authorName: "هوش مصنوعی آریا MJ",
        tags: Array.isArray(ai.tags) ? ai.tags.slice(0, 5) : [],
        status: "PENDING",
        readMinutes: readMinutes(ai.content),
      },
    });

    await prisma.notification.create({
      data: {
        type: "AI_KNOWLEDGE",
        title: "مقالهٔ جدید مرکز دانش (AI)",
        message: `«${post.title}» با تصویر اختصاصی، آمادهٔ تأیید است.`,
        link: `/admin/knowledge/edit/${post.id}`,
        refId: post.id,
      },
    });

    return NextResponse.json({ success: true, id: post.id });
  } catch (error: any) {
    return NextResponse.json({ success: false, message: error.message }, { status: 500 });
  }
}