import { NextRequest, NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";

import { resolveRealLogo } from "@/lib/brand-logo";

/* ============================================================
   cron روزانه: برندهای بدون لوگو → لوگوی واقعی خودکار
============================================================ */

export async function GET(request: NextRequest) {
  return run(request);
}

export async function POST(request: NextRequest) {
  return run(request);
}

async function run(request: NextRequest) {
  try {
    const limit = Math.min(Number(request.nextUrl.searchParams.get("limit") ?? 10), 20);

    const targets = await prisma.brand.findMany({
      where: { OR: [{ logo: null }, { logo: "" }] },
      orderBy: { name: "asc" },
      take: limit,
    });

    let updated = 0;

    for (const b of targets) {
      const url = await resolveRealLogo(b.name, b.slug);
      if (!url) continue;

      await prisma.brand.update({ where: { id: b.id }, data: { logo: url } });
      updated++;
    }

    return NextResponse.json({ success: true, updated, total: targets.length });
  } catch (error: any) {
    return NextResponse.json({ success: false, message: error.message }, { status: 500 });
  }
}