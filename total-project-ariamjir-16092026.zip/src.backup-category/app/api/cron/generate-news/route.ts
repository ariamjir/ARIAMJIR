import { NextRequest, NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";

import { readMinutes, slugify } from "@/lib/news";

import { autoAuthor } from "@/server/ai/auto-author";

export async function GET(request: NextRequest) {
  return run(request);
}

export async function POST(request: NextRequest) {
  return run(request);
}

async function run(request: NextRequest) {
  try {
    const kind =
      request.nextUrl.searchParams.get("kind") === "knowledge" ? "knowledge" : "news";

    const settings = await prisma.homePageSection.findFirst({ where: { key: "ai-news" } });
    const cfg = (settings?.config as any) ?? { enabled: true };

    const manual = request.nextUrl.searchParams.get("force") === "1";
    if (!cfg.enabled && !manual) return NextResponse.json({ success: true, skipped: true });

    const existing = (
      await prisma.newsPost.findMany({ select: { title: true } })
    ).map((x) => x.title);

    const { ai, cover } = await autoAuthor(kind, existing);

    if (!ai) {
      return NextResponse.json({
        success: true,
        skipped: true,
        message: "همهٔ موضوعات فعلی استفاده شده‌اند.",
      });
    }

    let slug = slugify(ai.title ?? "ai-news") || `ai-${Date.now().toString(36)}`;
    const dup = await prisma.newsPost.findUnique({ where: { slug } });
    if (dup) slug = `${slug}-${Date.now().toString(36)}`;

    const cat = await prisma.newsCategory.findFirst({ where: { slug: ai.categorySlug ?? "market-news" } });

    const post = await prisma.newsPost.create({
      data: {
        title: (ai.title ?? "خبر هوش مصنوعی").slice(0, 160),
        slug,
        excerpt: ai.excerpt ?? "",
        content: ai.content ?? "",
        coverImage: cover,
        categoryId: cat?.id ?? null,
        authorName: "هوش مصنوعی آریا MJ",
        tags: Array.isArray(ai.tags) ? ai.tags.slice(0, 5) : [],
        status: "PENDING",
        readMinutes: readMinutes(ai.content),
      },
    });

    await prisma.notification.create({
      data: {
        type: "AI_NEWS",
        title: kind === "knowledge" ? "مقالهٔ جدید دانشنامه (AI)" : "خبر جدید (AI)",
        message: `«${post.title}» با تصویر اختصاصی، آمادهٔ تأیید است.`,
        link: `/admin/news/edit/${post.id}`,
        refId: post.id,
      },
    });

    return NextResponse.json({ success: true, id: post.id });
  } catch (error: any) {
    return NextResponse.json({ success: false, message: error.message }, { status: 500 });
  }
}