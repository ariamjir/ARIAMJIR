import { NextRequest } from "next/server";

import { buildContext, streamPollinations, SYSTEM_PROMPT } from "@/lib/ai/chatbot";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

export async function POST(request: NextRequest) {
  const body = await request.json();
  const userMessage: string = (body.message ?? "").toString().trim();
  const history: Array<{ role: string; content: string }> = Array.isArray(body.history)
    ? body.history.slice(-6)
    : [];

  const encoder = new TextEncoder();

  const stream = new ReadableStream({
    async start(controller) {
      const send = (data: any) => {
        controller.enqueue(encoder.encode(`data: ${JSON.stringify(data)}\n\n`));
      };

      if (!userMessage || userMessage.length < 2) {
        send({ type: "error", message: "پیام خالی است" });
        controller.close();
        return;
      }

      send({ type: "status", message: "در حال جستجو در سایت..." });
      const context = await buildContext(userMessage);

      const userWithCtx = context
        ? `اطلاعات مرجع:\n${context}\n\nسوال کاربر: ${userMessage}\n\nبر اساس اطلاعات بالا پاسخ بده. اگر اطلاعات کافی نیست، از کاربر بخواه با شماره‌های موجود در context تماس بگیرد.`
        : userMessage;

      const messages = [
        { role: "system", content: SYSTEM_PROMPT },
        ...history,
        { role: "user", content: userWithCtx },
      ];

      const abortController = new AbortController();
      /* timeout کوتاه‌تر: ۳۰ ثانیه */
      const timeoutId = setTimeout(() => {
        try { abortController.abort(); } catch {}
      }, 30000);

      send({ type: "status", message: "آریا در حال پاسخ دادن..." });
      send({ type: "start" });

      let hasContent = false;

      try {
        await streamPollinations(
          messages,
          (chunk) => {
            hasContent = true;
            send({ type: "chunk", content: chunk });
          },
          abortController.signal
        );
      } catch (error: any) {
        if (!hasContent) {
          /* استخراج شماره تماس از context */
          const phoneMatch = context.match(/تلفن:\s*([^\n]+)/);
          const mobileMatch = context.match(/موبایل:\s*([^\n]+)/);
          const phone = phoneMatch?.[1] ?? "";
          const mobile = mobileMatch?.[1] ?? "";

          let contactInfo = "";
          if (phone) contactInfo += `\n📞 تلفن: ${phone}`;
          if (mobile) contactInfo += `\n📱 موبایل: ${mobile}`;

          send({
            type: "chunk",
            content: `متأسفم الان نمی‌تونم پاسخ بدم.${contactInfo ? `\n\nلطفاً با ما تماس بگیرید:${contactInfo}` : ""}\n\nیا از صفحهٔ [/تماس با ما](/contact) استفاده کنید.`,
          });
        }
      } finally {
        clearTimeout(timeoutId);
      }

      send({ type: "end" });
      controller.close();
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
    },
  });
}