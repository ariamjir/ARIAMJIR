import { NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";

/* ============================================================
   TYPES
============================================================ */

type CategoryNode = {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  image: string | null;
  parentId: string | null;
  sortOrder: number;
  active: boolean;
  showInMenu: boolean;
};

/* ============================================================
   GET
   Category tree مخصوص Mega Menu
============================================================ */

export async function GET() {
  try {
    const categories = await prisma.category.findMany({
      where: {
        active: true,
        showInMenu: true,
      },

      orderBy: [
        {
          sortOrder: "asc",
        },
        {
          name: "asc",
        },
      ],

      select: {
        id: true,
        name: true,
        slug: true,
        description: true,
        image: true,
        parentId: true,
        sortOrder: true,
        active: true,
        showInMenu: true,
      },
    });

    const items: CategoryNode[] = categories.map(
      (category) => ({
        id: category.id,
        name: category.name,
        slug: category.slug,
        description: category.description,
        image: category.image,
        parentId: category.parentId,
        sortOrder: category.sortOrder,
        active: category.active,
        showInMenu: category.showInMenu,
      }),
    );

    return NextResponse.json(
      {
        items,
      },
      {
        status: 200,
        headers: {
          "Cache-Control":
            "no-store, max-age=0",
        },
      },
    );
  } catch (error) {
    console.error(
      "[API /api/menu/categories] GET failed:",
      error,
    );

    return NextResponse.json(
      {
        items: [],
        error:
          "خطا در دریافت دسته‌بندی‌های منوی ماشین‌آلات",
      },
      {
        status: 500,
      },
    );
  }
}