import { NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    /*
     * بسیار مهم:
     *
     * این Query باید تمام آیتم‌های منو را برگرداند،
     * نه فقط parentId = null را.
     *
     * ساختار درختی در سمت NavMenu با parentId ساخته می‌شود.
     */
    const items = await prisma.menuItem.findMany({
      where: {
        active: true,
      },

      orderBy: [
        {
          sortOrder: "asc",
        },
        {
          createdAt: "asc",
        },
      ],

      select: {
        id: true,
        title: true,
        href: true,
        parentId: true,
        type: true,
        icon: true,
        categoryId: true,
        sortOrder: true,
        active: true,
        showDesktop: true,
        showMobile: true,
        openInNewTab: true,
        megaMenu: true,

        category: {
          select: {
            id: true,
            name: true,
            slug: true,
            link: true,
          },
        },
      },
    });

    return NextResponse.json(
      {
        success: true,
        items,
      },
      {
        status: 200,
        headers: {
          "Cache-Control":
            "no-store, no-cache, must-revalidate",
        },
      },
    );
  } catch (error) {
    console.error(
      "[GET /api/menu] Failed to load menu:",
      error,
    );

    return NextResponse.json(
      {
        success: false,
        items: [],
        error: "Failed to load menu",
      },
      {
        status: 500,
      },
    );
  }
}