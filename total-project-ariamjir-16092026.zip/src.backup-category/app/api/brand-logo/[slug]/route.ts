import { NextRequest } from "next/server";

import { prisma } from "@/lib/prisma";

/* ============================================================
   لوگوی مونوگرام داخلی — همیشه در دسترس، بدون اینترنت خارجی
   fallback تضمینی برای وقتی لوگوی واقعی در دسترس نیست
============================================================ */

export const revalidate = 3600;

const COLORS = [
  "#F58220",
  "#2563eb",
  "#16a34a",
  "#dc2626",
  "#7c3aed",
  "#0891b2",
  "#db2777",
  "#65a30d",
];

function escapeXml(s: string) {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ slug: string }> }
) {
  try {
    const { slug } = await params;

    const brand = await prisma.brand.findUnique({ where: { slug } });
    const name = brand?.name ?? slug;

    const initial = (name[0] ?? "A").toUpperCase();
    const code = (name.charCodeAt(0) ?? 0) + name.length;
    const color = COLORS[code % COLORS.length];

    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="224" height="128" viewBox="0 0 224 128">
  <rect width="224" height="128" rx="16" fill="#ffffff"/>
  <circle cx="112" cy="46" r="26" fill="${color}"/>
  <text x="112" y="56" font-family="Arial, sans-serif" font-size="28" font-weight="900" fill="#ffffff" text-anchor="middle">${escapeXml(initial)}</text>
  <text x="112" y="100" font-family="Arial, sans-serif" font-size="15" font-weight="700" fill="#374151" text-anchor="middle">${escapeXml(name)}</text>
</svg>`;

    return new Response(svg, {
      headers: {
        "Content-Type": "image/svg+xml",
        "Cache-Control": "public, max-age=86400",
      },
    });
  } catch (error: any) {
    return new Response(error.message, { status: 500 });
  }
}