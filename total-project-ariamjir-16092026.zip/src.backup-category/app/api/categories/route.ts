import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export const revalidate = 300;

export async function GET(request: NextRequest) {
  try {
    const sp = request.nextUrl.searchParams;
    const domain = sp.get("domain");
    const active = sp.get("active") === "true";
    const featured = sp.get("featured") === "true";
    const showInMenu = sp.get("showInMenu") === "true";
    const parentId = sp.get("parentId");

    const where: any = {};
    if (domain) where.domain = domain;
    if (active) where.active = true;
    if (featured) where.featured = true;
    if (showInMenu) where.showInMenu = true;
    if (parentId) where.parentId = parentId;

    const categories = await prisma.category.findMany({
      where,
      orderBy: { sortOrder: "asc" },
      select: {
        id: true,
        name: true,
        slug: true,
        icon: true,
        image: true,
        banner: true,
        description: true,
        domain: true,
        parentId: true,
        level: true,
        active: true,
        featured: true,
        showInMenu: true,
        showOnHomepage: true,
        sortOrder: true,
        viewCount: true,
      },
    });

    return NextResponse.json({ success: true, data: categories });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, message: error.message },
      { status: 500 }
    );
  }
}