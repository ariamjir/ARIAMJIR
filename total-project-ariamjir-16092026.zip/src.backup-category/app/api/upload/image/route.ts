import { NextRequest, NextResponse } from "next/server";

import { mkdir, writeFile } from "fs/promises";

import path from "path";

import { randomUUID } from "node:crypto";

/* ============================================================
   RUNTIME
   ------------------------------------------------------------
   fs استفاده می‌کنیم، پس حتماً Node runtime (نه edge).
============================================================ */

export const runtime = "nodejs";

/* ============================================================
   CONFIG
============================================================ */

const MAX_BYTES = 25 * 1024 * 1024; // 25MB (کلاینت عکس را 1MB می‌کند؛ ویدیو تا 15MB)

const ALLOWED = [
  "image/jpeg",
  "image/png",
  "image/webp",
  "image/avif",
  "image/gif",
  "video/mp4",
  "video/webm",
  "video/quicktime",
  "application/pdf",
];

/* folder را به حروف/عدد/خط تیره محدود می‌کنیم تا path traversal غیرممکن شود */
function safeFolder(raw: unknown): string {
  const s = String(raw ?? "")
    .replace(/[^a-zA-Z0-9_-]/g, "")
    .slice(0, 40);
  return s || "uploads";
}

/* زیرپوشه بر اساس نوع — سازگار با URLهای قبلی */
function subDir(mime: string): string {
  if (mime.startsWith("image/")) return "images";
  if (mime.startsWith("video/")) return "videos";
  return "files";
}

/* پسوند امن از نام یا mime */
function extOf(name: string, mime: string): string {
  const fromName = path.extname(name).toLowerCase();
  if (fromName && fromName.length <= 6) return fromName;

  const map: Record<string, string> = {
    "image/jpeg": ".jpg",
    "image/png": ".png",
    "image/webp": ".webp",
    "image/avif": ".avif",
    "image/gif": ".gif",
    "video/mp4": ".mp4",
    "video/webm": ".webm",
    "video/quicktime": ".mov",
    "application/pdf": ".pdf",
  };
  return map[mime] ?? "";
}

/* ============================================================
   POST — دریافت و ذخیرهٔ فایل (بدون sharp)
============================================================ */

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();

    const file = formData.get("file");
    const folder = safeFolder(formData.get("folder"));

    if (!(file instanceof Blob) || file.size === 0) {
      return NextResponse.json(
        { success: false, message: "فایلی دریافت نشد." },
        { status: 400 }
      );
    }

    const mime = (file as File).type || "application/octet-stream";

    if (!ALLOWED.includes(mime)) {
      return NextResponse.json(
        { success: false, message: `نوع فایل مجاز نیست: ${mime}` },
        { status: 400 }
      );
    }

    if (file.size > MAX_BYTES) {
      return NextResponse.json(
        { success: false, message: "حجم فایل بیش از حد مجاز است." },
        { status: 400 }
      );
    }

    /* TODO: احراز هویت — در صورت نیاز، اینجا توکن/نقش را چک کن */

    const id = randomUUID();
    const ext = extOf((file as File).name || "", mime);
    const fileName = `${id}${ext}`;
    const sub = subDir(mime);

    const relDir = path.join("uploads", folder, sub);
    const absDir = path.join(process.cwd(), "public", relDir);

    await mkdir(absDir, { recursive: true });

    const buffer = Buffer.from(await file.arrayBuffer());
    await writeFile(path.join(absDir, fileName), buffer);

    const url = `/${relDir}/${fileName}`.replace(/\\/g, "/");

    /* پاسخ سازگار با extractServerUrl / extractServerId در repository */
    return NextResponse.json(
      {
        success: true,
        id,
        url,
        path: url,
        src: url,
        name: fileName,
        originalName: (file as File).name || fileName,
        size: file.size,
        mimeType: mime,
        folder,
      },
      { status: 200 }
    );
  } catch (error: any) {
    return NextResponse.json(
      { success: false, message: error?.message ?? "خطا در آپلود." },
      { status: 500 }
    );
  }
}