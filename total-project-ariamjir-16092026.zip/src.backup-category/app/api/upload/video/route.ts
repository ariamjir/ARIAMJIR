import { NextRequest, NextResponse } from "next/server";
import { mkdir, writeFile } from "fs/promises";
import { existsSync } from "fs";
import path from "path";
import { v4 as uuid } from "uuid";

const MAX_VIDEO_SIZE = 20 * 1024 * 1024;

const ALLOWED_TYPES = [
  "video/mp4",
  "video/webm",
  "video/quicktime",
];

export async function POST(req: NextRequest) {
  try {
    const formData = await req.formData();

    const file = formData.get("file") as File | null;

    if (!file) {
      return NextResponse.json(
        {
          error: "فایلی ارسال نشده است.",
        },
        {
          status: 400,
        }
      );
    }

    if (!ALLOWED_TYPES.includes(file.type)) {
      return NextResponse.json(
        {
          error: "فرمت ویدئو مجاز نیست.",
        },
        {
          status: 400,
        }
      );
    }

    if (file.size > MAX_VIDEO_SIZE) {
      return NextResponse.json(
        {
          error:
            "حداکثر حجم ویدئو 20MB است.",
        },
        {
          status: 400,
        }
      );
    }

    const uploadDir = path.join(
      process.cwd(),
      "public",
      "uploads",
      "machines",
      "videos"
    );

    if (!existsSync(uploadDir)) {
      await mkdir(uploadDir, {
        recursive: true,
      });
    }

    const extension =
      file.name.split(".").pop() ?? "mp4";

    const filename =
      `${uuid()}.${extension}`;

    const filepath = path.join(
      uploadDir,
      filename
    );

    const bytes = Buffer.from(
      await file.arrayBuffer()
    );

    await writeFile(
      filepath,
      bytes
    );

    return NextResponse.json({
      success: true,
      url:
        "/uploads/machines/videos/" +
        filename,
      size: file.size,
    });

  } catch (error) {

    console.error(error);

    return NextResponse.json(
      {
        error: "خطا در آپلود ویدئو",
      },
      {
        status: 500,
      }
    );
  }
}

