import { NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";

import { mergeHeaderConfig } from "@/lib/header-config";

export const revalidate = 60;

export async function GET() {
  try {
    const row = await prisma.homePageSection.findFirst({
      where: { key: "header" },
    });

    return NextResponse.json({
      success: true,
      data: mergeHeaderConfig(row?.config),
    });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, message: error.message },
      { status: 500 }
    );
  }
}