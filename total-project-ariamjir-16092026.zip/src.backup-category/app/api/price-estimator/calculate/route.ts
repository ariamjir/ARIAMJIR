import { NextRequest, NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";

/* ============================================================
   TYPES
============================================================ */

type Condition = "excellent" | "good" | "fair" | "poor";
type DocumentsStatus = "complete" | "partial" | "none";
type CustomsStatus = "cleared" | "in_process" | "uncleared";

type ComponentCondition = {
  id: string;
  label: string;
  percentage: number;
  condition: string;
  hasIssue: boolean;
  issueDescription: string;
};

type RequestBody = {
  categoryId: string;
  activityId: string;
  machineTypeId: string;
  brandId: string;
  model: string;
  manufactureYear: number;
  workingHours: number;
  machineCondition: Condition;
  componentConditions: ComponentCondition[];
  hasDocuments: DocumentsStatus;
  customsStatus: CustomsStatus;
  hasInspectionReport: boolean;
};

type MarketPrice = {
  id: string;
  price: number;
  currency: string;
  year: number | null;
  hours: number | null;
};

/* ============================================================
   CONSTANTS
============================================================ */

const CONDITION_FACTORS: Record<Condition, number> = {
  excellent: 1.08,
  good: 1,
  fair: 0.9,
  poor: 0.78,
};

const VALID_CONDITIONS: Condition[] = ["excellent", "good", "fair", "poor"];
const VALID_DOCUMENTS: DocumentsStatus[] = ["complete", "partial", "none"];
const VALID_CUSTOMS: CustomsStatus[] = ["cleared", "in_process", "uncleared"];

/* ============================================================
   HELPERS
============================================================ */

function normalize(value: string) {
  return value.trim().replace(/\s+/g, " ");
}

function key(value: string) {
  return normalize(value).toLocaleLowerCase("fa-IR");
}

function isFiniteNumber(value: unknown): value is number {
  return typeof value === "number" && Number.isFinite(value);
}

function roundPrice(value: number) {
  return Number.isFinite(value) ? Math.round(value) : 0;
}

function median(values: number[]) {
  if (!values.length) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const middle = Math.floor(sorted.length / 2);
  return sorted.length % 2 === 0
    ? (sorted[middle - 1] + sorted[middle]) / 2
    : sorted[middle];
}

function selectMarketCurrency(prices: MarketPrice[]) {
  if (!prices.length) return null;

  const counts = new Map<string, number>();

  for (const item of prices) {
    const currency = item.currency.trim().toUpperCase();
    counts.set(currency, (counts.get(currency) ?? 0) + 1);
  }

  if (counts.has("IRR")) return "IRR";

  let selected: string | null = null;
  let count = 0;

  for (const [currency, currencyCount] of counts) {
    if (currencyCount > count) {
      selected = currency;
      count = currencyCount;
    }
  }

  return selected;
}

function filterOutliers(values: number[]) {
  if (values.length < 5) return values;

  const sorted = [...values].sort((a, b) => a - b);
  const q1 = sorted[Math.floor((sorted.length - 1) * 0.25)];
  const q3 = sorted[Math.floor((sorted.length - 1) * 0.75)];
  const iqr = q3 - q1;

  if (!Number.isFinite(iqr) || iqr <= 0) return values;

  const lower = q1 - iqr * 1.5;
  const upper = q3 + iqr * 1.5;
  const filtered = sorted.filter((value) => value >= lower && value <= upper);

  return filtered.length >= 3 ? filtered : values;
}

function isCondition(value: unknown): value is Condition {
  return typeof value === "string" && VALID_CONDITIONS.includes(value as Condition);
}

function isDocumentsStatus(value: unknown): value is DocumentsStatus {
  return typeof value === "string" && VALID_DOCUMENTS.includes(value as DocumentsStatus);
}

function isCustomsStatus(value: unknown): value is CustomsStatus {
  return typeof value === "string" && VALID_CUSTOMS.includes(value as CustomsStatus);
}

function validateComponentConditions(items: unknown): items is ComponentCondition[] {
  if (!Array.isArray(items)) return false;

  return items.every((item) => {
    if (!item || typeof item !== "object") return false;

    const component = item as Partial<ComponentCondition>;

    return (
      typeof component.id === "string" &&
      typeof component.label === "string" &&
      isFiniteNumber(component.percentage) &&
      component.percentage >= 0 &&
      component.percentage <= 100 &&
      typeof component.condition === "string" &&
      typeof component.hasIssue === "boolean" &&
      typeof component.issueDescription === "string"
    );
  });
}

function validateRequest(body: Partial<RequestBody>): string | null {
  const requiredIds: Array<[keyof RequestBody, string]> = [
    ["categoryId", "دسته‌بندی دستگاه انتخاب نشده است."],
    ["activityId", "نوع فعالیت / کاربرد انتخاب نشده است."],
    ["machineTypeId", "نوع دستگاه انتخاب نشده است."],
    ["brandId", "برند دستگاه انتخاب نشده است."],
  ];

  for (const [field, message] of requiredIds) {
    if (typeof body[field] !== "string" || !(body[field] as string).trim()) {
      return message;
    }
  }

  if (typeof body.model !== "string" || !body.model.trim()) {
    return "مدل دستگاه انتخاب نشده است.";
  }

  if (!isFiniteNumber(body.manufactureYear)) {
    return "سال ساخت دستگاه نامعتبر است.";
  }

  if (body.manufactureYear < 1900 || body.manufactureYear > new Date().getFullYear() + 1) {
    return "سال ساخت دستگاه خارج از محدوده معتبر است.";
  }

  if (!isFiniteNumber(body.workingHours) || body.workingHours < 0) {
    return "ساعت کارکرد دستگاه نامعتبر است.";
  }

  if (!isCondition(body.machineCondition)) {
    return "وضعیت کلی دستگاه نامعتبر است.";
  }

  if (!isDocumentsStatus(body.hasDocuments)) {
    return "وضعیت مدارک دستگاه نامعتبر است.";
  }

  if (!isCustomsStatus(body.customsStatus)) {
    return "وضعیت گمرکی دستگاه نامعتبر است.";
  }

  if (typeof body.hasInspectionReport !== "boolean") {
    return "وضعیت گزارش کارشناسی نامعتبر است.";
  }

  if (!validateComponentConditions(body.componentConditions)) {
    return "اطلاعات وضعیت اجزای دستگاه نامعتبر است.";
  }

  return null;
}

/* ============================================================
   VALIDATE EXACT CATEGORY → ACTIVITY → TYPE → BRAND
============================================================ */

async function validateHierarchy(body: RequestBody) {
  const [category, activity, machineType, brand] = await Promise.all([
    prisma.category.findUnique({
      where: { id: body.categoryId },
      select: { id: true, parentId: true, active: true, domain: true, name: true },
    }),
    prisma.category.findUnique({
      where: { id: body.activityId },
      select: { id: true, parentId: true, active: true, domain: true, name: true },
    }),
    prisma.category.findUnique({
      where: { id: body.machineTypeId },
      select: { id: true, parentId: true, active: true, domain: true, name: true },
    }),
    prisma.brand.findUnique({
      where: { id: body.brandId },
      select: { id: true, active: true, name: true },
    }),
  ]);

  if (!category || !category.active || category.domain !== "MACHINE" || category.parentId !== null) {
    return { valid: false, message: "دسته ماشین‌آلات انتخاب‌شده معتبر نیست." };
  }

  if (!activity || !activity.active || activity.domain !== "MACHINE" || activity.parentId !== category.id) {
    return { valid: false, message: "نوع فعالیت با دسته ماشین‌آلات هماهنگ نیست." };
  }

  if (
    !machineType ||
    !machineType.active ||
    machineType.domain !== "MACHINE" ||
    machineType.parentId !== activity.id
  ) {
    return { valid: false, message: "نوع دستگاه با نوع فعالیت هماهنگ نیست." };
  }

  if (key(activity.name) === key(machineType.name)) {
    return {
      valid: false,
      message: "نوع فعالیت و نوع دستگاه نباید عنوان تکراری داشته باشند.",
    };
  }

  if (!brand || !brand.active) {
    return { valid: false, message: "برند انتخاب‌شده معتبر نیست." };
  }

  const matchingMachine = await prisma.machine.findFirst({
    where: {
      active: true,
      status: "PUBLISHED",
      domain: "MACHINE",
      categoryId: machineType.id,
      brandId: brand.id,
    },
    select: { id: true },
  });

  if (!matchingMachine) {
    return {
      valid: false,
      message: "این برند برای نوع دستگاه انتخاب‌شده داده واقعی قابل استفاده ندارد.",
    };
  }

  return {
    valid: true,
    categoryName: category.name,
    activityName: activity.name,
    machineTypeName: machineType.name,
    brandName: brand.name,
  };
}

/* ============================================================
   MARKET DATA
============================================================ */

async function getMarketPrices(body: RequestBody): Promise<MarketPrice[]> {
  const model = normalize(body.model);

  const machines = await prisma.machine.findMany({
    where: {
      active: true,
      status: "PUBLISHED",
      domain: "MACHINE",
      categoryId: body.machineTypeId,
      brandId: body.brandId,
      listingType: { in: ["SALE", "OFFER", "AUCTION"] },
      specification: {
        is: {
          model: {
            equals: model,
            mode: "insensitive",
          },
        },
      },
      price: {
        is: {
          price: { not: null },
        },
      },
    },
    select: {
      id: true,
      specification: {
        select: {
          manufactureYear: true,
          workingHours: true,
        },
      },
      price: {
        select: {
          price: true,
          currency: true,
        },
      },
    },
    orderBy: { createdAt: "desc" },
    take: 80,
  });

  const result = machines
    .map((machine) => {
      const rawPrice = machine.price?.price;
      if (rawPrice === null || rawPrice === undefined) return null;

      const price = Number(rawPrice);
      if (!Number.isFinite(price) || price <= 0) return null;

      return {
        id: machine.id,
        price,
        currency: machine.price?.currency?.trim().toUpperCase() ?? "IRR",
        year: machine.specification?.manufactureYear ?? null,
        hours: machine.specification?.workingHours ?? null,
      } satisfies MarketPrice;
    })
    .filter((item): item is MarketPrice => item !== null);

  const currency = selectMarketCurrency(result);
  if (!currency) return [];

  return result.filter((item) => item.currency === currency);
}

/* ============================================================
   MAIN POST
============================================================ */

export async function POST(request: NextRequest) {
  try {
    let rawBody: unknown;

    try {
      rawBody = await request.json();
    } catch {
      return NextResponse.json(
        { success: false, message: "بدنه درخواست نامعتبر است." },
        { status: 400 },
      );
    }

    if (!rawBody || typeof rawBody !== "object") {
      return NextResponse.json(
        { success: false, message: "اطلاعات درخواست نامعتبر است." },
        { status: 400 },
      );
    }

    const body = rawBody as Partial<RequestBody>;
    const validationError = validateRequest(body);

    if (validationError) {
      return NextResponse.json(
        { success: false, message: validationError },
        { status: 400 },
      );
    }

    const validatedBody = body as RequestBody;
    const hierarchy = await validateHierarchy(validatedBody);

    if (!hierarchy.valid) {
      return NextResponse.json(
        { success: false, message: hierarchy.message },
        { status: 400 },
      );
    }

    const marketPrices = await getMarketPrices(validatedBody);

    if (!marketPrices.length) {
      return NextResponse.json({
        success: true,
        data: {
          available: false,
          message: "برای این مدل هنوز قیمت کافی در بازار ARIA MJ ثبت نشده است.",
          confidence: "low",
          sampleSize: 0,
          currency: "IRR",
        },
      });
    }

    const currency = marketPrices[0]?.currency ?? "IRR";
    const rawMarketPrices = marketPrices.map((item) => item.price);
    const usablePrices = filterOutliers(rawMarketPrices);
    const basePrice = median(usablePrices);

    if (!Number.isFinite(basePrice) || basePrice <= 0) {
      return NextResponse.json({
        success: true,
        data: {
          available: false,
          message: "قیمت معتبر قابل استفاده برای این مدل پیدا نشد.",
          confidence: "low",
          sampleSize: marketPrices.length,
          currency,
        },
      });
    }

    const currentYear = new Date().getFullYear();
    const age = Math.max(0, currentYear - validatedBody.manufactureYear);
    const yearRate = Math.min(age * 0.03, 0.3);
    const yearAdjustment = -basePrice * yearRate;

    const averageHoursValues = marketPrices
      .map((item) => item.hours)
      .filter((value): value is number =>
        typeof value === "number" && Number.isFinite(value) && value >= 0,
      );

    const marketAverageHours = averageHoursValues.length
      ? averageHoursValues.reduce((sum, value) => sum + value, 0) / averageHoursValues.length
      : 5000;

    const hoursDifference = validatedBody.workingHours - marketAverageHours;
    const hoursRate = Math.max(
      -0.2,
      Math.min(
        0.1,
        -(hoursDifference / Math.max(marketAverageHours, 1)) * 0.15,
      ),
    );
    const hoursAdjustment = basePrice * hoursRate;

    const componentAverage = validatedBody.componentConditions.length
      ? validatedBody.componentConditions.reduce((sum, item) => sum + item.percentage, 0) /
        validatedBody.componentConditions.length
      : 80;

    const conditionRate = (componentAverage - 80) / 400;
    const conditionAdjustment = basePrice * conditionRate;

    let marketRate = 0;

    if (validatedBody.hasDocuments === "complete") marketRate += 0.02;
    if (validatedBody.hasDocuments === "none") marketRate -= 0.08;
    if (validatedBody.customsStatus === "cleared") marketRate += 0.01;
    if (validatedBody.customsStatus === "uncleared") marketRate -= 0.05;
    if (validatedBody.hasInspectionReport) marketRate += 0.015;

    const marketAdjustment = basePrice * marketRate;
    const overallFactor = CONDITION_FACTORS[validatedBody.machineCondition];

    const adjustedBase =
      basePrice + yearAdjustment + hoursAdjustment + conditionAdjustment + marketAdjustment;
    const rawAverage = Math.max(0, adjustedBase * overallFactor);

    const sampleSize = marketPrices.length;
    const confidence = sampleSize >= 10 ? "high" : sampleSize >= 4 ? "medium" : "low";
    const rangeRate = confidence === "high" ? 0.07 : confidence === "medium" ? 0.12 : 0.18;

    const minPrice = Math.max(0, rawAverage * (1 - rangeRate));
    const maxPrice = Math.max(minPrice, rawAverage * (1 + rangeRate));

    const criticalIssues = validatedBody.componentConditions
      .filter((item) => item.hasIssue || item.percentage < 30)
      .map(
        (item) =>
          `${item.label}: ${item.issueDescription.trim() || "نیازمند بررسی فنی"}`,
      );

    const recommendations: string[] = [];

    if (validatedBody.workingHours > marketAverageHours * 1.25) {
      recommendations.push("کارکرد دستگاه نسبت به نمونه‌های مشابه بازار بالاتر است.");
    }

    if (validatedBody.workingHours < marketAverageHours * 0.75) {
      recommendations.push(
        "کارکرد دستگاه نسبت به نمونه‌های مشابه بازار پایین‌تر است و می‌تواند یک مزیت معاملاتی باشد.",
      );
    }

    if (componentAverage < 60) {
      recommendations.push("پیشنهاد می‌شود قبل از معامله کارشناسی فنی حضوری انجام شود.");
    }

    if (validatedBody.hasDocuments !== "complete") {
      recommendations.push("تکمیل مدارک می‌تواند روی قابلیت معامله و ارزش دستگاه اثرگذار باشد.");
    }

    if (validatedBody.customsStatus === "uncleared") {
      recommendations.push("وضعیت گمرکی دستگاه می‌تواند ریسک معامله را افزایش دهد.");
    }

    if (!validatedBody.hasInspectionReport) {
      recommendations.push(
        "ارائه گزارش کارشناسی معتبر می‌تواند اعتماد خریدار و دقت ارزیابی را افزایش دهد.",
      );
    }

    return NextResponse.json({
      success: true,
      data: {
        available: true,
        minPrice: roundPrice(minPrice),
        maxPrice: roundPrice(maxPrice),
        averagePrice: roundPrice(rawAverage),
        currency,
        confidence,
        sampleSize,
        breakdown: {
          basePrice: roundPrice(basePrice),
          yearAdjustment: roundPrice(yearAdjustment),
          hoursAdjustment: roundPrice(hoursAdjustment),
          conditionAdjustment: roundPrice(conditionAdjustment),
          marketAdjustment: roundPrice(marketAdjustment),
        },
        criticalIssues,
        recommendations,
        methodology: {
          marketSamples: sampleSize,
          marketAverageHours: Math.round(marketAverageHours),
          componentAverage: Math.round(componentAverage),
        },
        hierarchy: {
          categoryId: validatedBody.categoryId,
          categoryName: hierarchy.categoryName,
          activityId: validatedBody.activityId,
          activityName: hierarchy.activityName,
          machineTypeId: validatedBody.machineTypeId,
          machineTypeName: hierarchy.machineTypeName,
          brandId: validatedBody.brandId,
          brandName: hierarchy.brandName,
          model: normalize(validatedBody.model),
        },
      },
    });
  } catch (error) {
    console.error("[PRICE_ESTIMATOR_CALCULATE]", error);
    return NextResponse.json(
      { success: false, message: "خطا در محاسبه قیمت." },
      { status: 500 },
    );
  }
}
