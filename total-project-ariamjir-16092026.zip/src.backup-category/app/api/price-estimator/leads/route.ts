import { NextRequest, NextResponse } from "next/server";
import { Prisma } from "@prisma/client";

import { prisma } from "@/lib/prisma";

/* ============================================================
   TYPES
============================================================ */

type LeadBody = {
  mobile?: unknown;
  consent?: unknown;

  categoryId?: unknown;
  activityId?: unknown;
  machineTypeId?: unknown;
  brandId?: unknown;

  model?: unknown;
  manufactureYear?: unknown;
  workingHours?: unknown;

  machineCondition?: unknown;
  hasDocuments?: unknown;
  customsStatus?: unknown;
  hasInspectionReport?: unknown;
  componentConditions?: unknown;

  estimation?: unknown;
  source?: unknown;
};

/* ============================================================
   HELPERS
============================================================ */

function normalizeMobile(value: string): string | null {
  const digits = value.replace(/\D/g, "");

  if (/^09\d{9}$/.test(digits)) {
    return digits;
  }

  if (/^989\d{9}$/.test(digits)) {
    return `0${digits.slice(2)}`;
  }

  if (/^9\d{9}$/.test(digits)) {
    return `0${digits}`;
  }

  return null;
}

function isPlainObject(
  value: unknown,
): value is Record<string, unknown> {
  return (
    Boolean(value) &&
    typeof value === "object" &&
    !Array.isArray(value)
  );
}

function getClientIp(
  request: NextRequest,
): string | null {
  const forwarded =
    request.headers.get("x-forwarded-for");

  if (forwarded) {
    return (
      forwarded.split(",")[0]?.trim() || null
    );
  }

  return (
    request.headers.get("x-real-ip") || null
  );
}

function jsonError(
  message: string,
  status = 400,
) {
  return NextResponse.json(
    {
      success: false,
      message,
    },
    { status },
  );
}

/* ============================================================
   POST
============================================================ */

export async function POST(
  request: NextRequest,
) {
  try {
    /* ========================================================
       READ BODY
    ======================================================== */

    let rawBody: unknown;

    try {
      rawBody = await request.json();
    } catch {
      return jsonError(
        "اطلاعات درخواست نامعتبر است.",
      );
    }

    if (!isPlainObject(rawBody)) {
      return jsonError(
        "اطلاعات درخواست نامعتبر است.",
      );
    }

    const body = rawBody as LeadBody;

    /* ========================================================
       CONSENT
    ======================================================== */

    if (
      typeof body.consent !== "boolean" ||
      body.consent !== true
    ) {
      return jsonError(
        "تأیید استفاده از اطلاعات برای ثبت درخواست الزامی است.",
      );
    }

    /* ========================================================
       MOBILE
    ======================================================== */

    if (typeof body.mobile !== "string") {
      return jsonError(
        "شماره موبایل وارد نشده است.",
      );
    }

    const mobile = normalizeMobile(
      body.mobile,
    );

    if (!mobile) {
      return jsonError(
        "شماره موبایل معتبر نیست.",
      );
    }

    /* ========================================================
       REQUIRED IDS
    ======================================================== */

    if (
      typeof body.categoryId !== "string" ||
      !body.categoryId.trim()
    ) {
      return jsonError(
        "دسته دستگاه مشخص نشده است.",
      );
    }

    if (
      typeof body.activityId !== "string" ||
      !body.activityId.trim()
    ) {
      return jsonError(
        "نوع فعالیت مشخص نشده است.",
      );
    }

    if (
      typeof body.machineTypeId !== "string" ||
      !body.machineTypeId.trim()
    ) {
      return jsonError(
        "نوع دستگاه مشخص نشده است.",
      );
    }

    if (
      typeof body.brandId !== "string" ||
      !body.brandId.trim()
    ) {
      return jsonError(
        "برند دستگاه مشخص نشده است.",
      );
    }

    /* ========================================================
       MODEL
    ======================================================== */

    if (
      typeof body.model !== "string" ||
      !body.model.trim()
    ) {
      return jsonError(
        "مدل دستگاه مشخص نشده است.",
      );
    }

    /* ========================================================
       MANUFACTURE YEAR
    ======================================================== */

    if (
      typeof body.manufactureYear !== "number" ||
      !Number.isInteger(
        body.manufactureYear,
      ) ||
      body.manufactureYear < 1900 ||
      body.manufactureYear >
        new Date().getFullYear() + 1
    ) {
      return jsonError(
        "سال ساخت دستگاه معتبر نیست.",
      );
    }

    /* ========================================================
       WORKING HOURS
    ======================================================== */

    if (
      typeof body.workingHours !== "number" ||
      !Number.isFinite(
        body.workingHours,
      ) ||
      body.workingHours < 0
    ) {
      return jsonError(
        "ساعت کارکرد دستگاه معتبر نیست.",
      );
    }

    /* ========================================================
       SNAPSHOT
    ======================================================== */

    const snapshot = {
      categoryId: body.categoryId,
      activityId: body.activityId,
      machineTypeId: body.machineTypeId,
      brandId: body.brandId,

      model: body.model.trim(),

      manufactureYear:
        body.manufactureYear,

      workingHours:
        body.workingHours,

      machineCondition:
        body.machineCondition ?? null,

      hasDocuments:
        body.hasDocuments ?? null,

      customsStatus:
        body.customsStatus ?? null,

      hasInspectionReport:
        body.hasInspectionReport ?? false,

      componentConditions:
        body.componentConditions ?? [],

      estimation:
        body.estimation ?? null,
    };

    /* ========================================================
       SOURCE
    ======================================================== */

    const source =
      typeof body.source === "string" &&
      body.source.trim()
        ? body.source.trim()
        : "PRICE_ESTIMATOR";

    /* ========================================================
       IP / USER AGENT
    ======================================================== */

    const ipAddress =
      getClientIp(request);

    const userAgent =
      request.headers.get(
        "user-agent",
      );

    /* ========================================================
       CREATE LEAD
       
       Prisma Client فعلی مدل PriceEstimatorLead
       را ندارد؛ بنابراین مستقیماً رکورد را در جدول
       PostgreSQL ثبت می‌کنیم.
    ======================================================== */

    const leads =
      await prisma.$queryRaw<
        Array<{
          id: string;
          status: string;
          createdAt: Date;
        }>
      >(
        Prisma.sql`
          INSERT INTO "PriceEstimatorLead" (
            "id",
            "mobile",
            "status",
            "intent",
            "source",
            "categoryId",
            "activityId",
            "machineTypeId",
            "brandId",
            "model",
            "manufactureYear",
            "workingHours",
            "estimationSnapshot",
            "consentAt",
            "ipAddress",
            "userAgent"
          )
          VALUES (
            gen_random_uuid()::text,
            ${mobile},
            ${"NEW"},
            ${"SELL_READY"},
            ${source},
            ${body.categoryId},
            ${body.activityId},
            ${body.machineTypeId},
            ${body.brandId},
            ${body.model.trim()},
            ${body.manufactureYear},
            ${body.workingHours},
            ${JSON.stringify(snapshot)}::jsonb,
            ${new Date()},
            ${ipAddress},
            ${userAgent}
          )
          RETURNING
            "id",
            "status",
            "createdAt"
        `,
      );

    const lead = leads[0];

    if (!lead) {
      throw new Error(
        "رکورد درخواست فروش ایجاد نشد.",
      );
    }

    /* ========================================================
       RESPONSE
    ======================================================== */

    return NextResponse.json({
      success: true,
      message:
        "درخواست فروش با موفقیت ثبت شد.",
      data: {
        id: lead.id,
        status: lead.status,
        createdAt: lead.createdAt,
      },
    });
  } catch (error) {
    console.error(
      "[PRICE_ESTIMATOR_LEAD]",
      error,
    );

    return NextResponse.json(
      {
        success: false,
        message:
          "ثبت درخواست فروش انجام نشد.",
      },
      {
        status: 500,
      },
    );
  }
}