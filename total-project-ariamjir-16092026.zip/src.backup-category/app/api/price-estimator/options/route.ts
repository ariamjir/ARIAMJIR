import { NextRequest, NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";

/* ============================================================
   TYPES
============================================================ */

type CategoryOption = {
  id: string;
  name: string;
  slug: string | null;
  icon: string | null;
  image: string | null;
  description: string | null;
  parentId: string | null;
  sortOrder: number;
};

type BrandOption = {
  id: string;
  name: string;
  slug: string;
  logo: string | null;
  website: string | null;
  countryId: string | null;
};

type ModelItem = {
  model: string;
  machineCount: number;
  latestMachineId: string;
  latestTitle: string;
  latestSlug: string;
  image: string | null;
};

/* ============================================================
   HELPERS
============================================================ */

function jsonError(message: string, status = 500) {
  return NextResponse.json(
    { success: false, message },
    { status },
  );
}

function normalize(value: string) {
  return value.trim().replace(/\s+/g, " ");
}

function key(value: string) {
  return normalize(value).toLocaleLowerCase("fa-IR");
}

function uniqueById<T extends { id: string }>(items: T[]) {
  const map = new Map<string, T>();
  for (const item of items) map.set(item.id, item);
  return Array.from(map.values());
}

function sortFa<T extends { name: string }>(items: T[]) {
  return [...items].sort((a, b) =>
    a.name.localeCompare(b.name, "fa", { sensitivity: "base" }),
  );
}

async function getCategory(id: string) {
  return prisma.category.findUnique({
    where: { id },
    select: {
      id: true,
      name: true,
      slug: true,
      icon: true,
      image: true,
      description: true,
      parentId: true,
      sortOrder: true,
      active: true,
      domain: true,
      level: true,
    },
  });
}

async function getDirectChildren(parentId: string): Promise<CategoryOption[]> {
  return prisma.category.findMany({
    where: {
      parentId,
      active: true,
      domain: "MACHINE",
    },
    orderBy: [{ sortOrder: "asc" }, { name: "asc" }],
    select: {
      id: true,
      name: true,
      slug: true,
      icon: true,
      image: true,
      description: true,
      parentId: true,
      sortOrder: true,
    },
  });
}

/* ============================================================
   GET

   EXACT MACHINE FLOW:

   دسته ماشین‌آلات
       ↓
   نوع فعالیت / کاربرد
       ↓
   نوع دستگاه
       ↓
   برند
       ↓
   مدل

   مهم:
   - activityId و machineTypeId عمداً مستقل هستند.
   - هیچ مرحله‌ای از categoryId به عنوان type تکرار نمی‌شود.
   - برند فقط از دستگاه‌های متعلق به machineTypeId استخراج می‌شود.
============================================================ */

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const mode = searchParams.get("mode")?.trim() || "machine";

    if (mode !== "machine" && mode !== "part") {
      return jsonError("حالت درخواست نامعتبر است.", 400);
    }

    if (mode === "part") {
      const categories = await prisma.category.findMany({
        where: {
          active: true,
          parentId: null,
          domain: "PART",
        },
        orderBy: [{ sortOrder: "asc" }, { name: "asc" }],
        select: {
          id: true,
          name: true,
          slug: true,
          icon: true,
          image: true,
          description: true,
          parentId: true,
          sortOrder: true,
        },
      });

      return NextResponse.json({
        success: true,
        step: "categories",
        items: categories,
      });
    }

    const categoryId = searchParams.get("categoryId")?.trim() || null;
    const activityId = searchParams.get("activityId")?.trim() || null;
    const machineTypeId = searchParams.get("machineTypeId")?.trim() || null;
    const brandId = searchParams.get("brandId")?.trim() || null;

    /* ========================================================
       STEP 1 — ROOT CATEGORY
    ======================================================== */

    if (!categoryId) {
      const categories = await prisma.category.findMany({
        where: {
          active: true,
          parentId: null,
          domain: "MACHINE",
        },
        orderBy: [{ sortOrder: "asc" }, { name: "asc" }],
        select: {
          id: true,
          name: true,
          slug: true,
          icon: true,
          image: true,
          description: true,
          parentId: true,
          sortOrder: true,
        },
      });

      return NextResponse.json({
        success: true,
        step: "categories",
        items: categories,
      });
    }

    const category = await getCategory(categoryId);

    if (!category || !category.active || category.domain !== "MACHINE") {
      return jsonError("دسته ماشین‌آلات انتخاب‌شده پیدا نشد.", 404);
    }

    if (category.parentId !== null) {
      return jsonError("دسته انتخاب‌شده، دسته اصلی ماشین‌آلات نیست.", 400);
    }

    /* ========================================================
       STEP 2 — ACTIVITY
    ======================================================== */

    if (!activityId) {
      const activities = await getDirectChildren(categoryId);

      return NextResponse.json({
        success: true,
        step: "activities",
        items: sortFa(activities),
        parent: {
          id: category.id,
          name: category.name,
        },
      });
    }

    const activity = await getCategory(activityId);

    if (!activity || !activity.active || activity.domain !== "MACHINE") {
      return jsonError("نوع فعالیت انتخاب‌شده پیدا نشد.", 404);
    }

    if (activity.parentId !== categoryId) {
      return jsonError("نوع فعالیت با دسته ماشین‌آلات انتخاب‌شده هماهنگ نیست.", 400);
    }

    /* ========================================================
       STEP 3 — MACHINE TYPE
    ======================================================== */

    if (!machineTypeId) {
      const machineTypes = await getDirectChildren(activityId);

      /*
       * جلوگیری از نمایش تکراری همان عنوان فعالیت در سطح نوع دستگاه.
       * اگر دیتای قدیمی دارای child هم‌نام باشد، آن child نمایش داده نمی‌شود.
       * این guard فقط UI را تمیز می‌کند و ساختار دیتابیس را تغییر نمی‌دهد.
       */
      const activityKey = key(activity.name);
      const cleanedMachineTypes = machineTypes.filter(
        (item) => key(item.name) !== activityKey,
      );

      return NextResponse.json({
        success: true,
        step: "machineTypes",
        items: sortFa(cleanedMachineTypes),
        parent: {
          id: activity.id,
          name: activity.name,
        },
      });
    }

    const machineType = await getCategory(machineTypeId);

    if (!machineType || !machineType.active || machineType.domain !== "MACHINE") {
      return jsonError("نوع دستگاه انتخاب‌شده پیدا نشد.", 404);
    }

    if (machineType.parentId !== activityId) {
      return jsonError("نوع دستگاه با نوع فعالیت انتخاب‌شده هماهنگ نیست.", 400);
    }

    if (key(machineType.name) === key(activity.name)) {
      return jsonError(
        "ساختار دسته‌بندی این نوع دستگاه تکراری است. نوع دستگاه باید فرزند واقعی فعالیت باشد و عنوان آن با فعالیت یکسان نباشد.",
        400,
      );
    }

    /* ========================================================
       STEP 4 — BRANDS
    ======================================================== */

    if (!brandId) {
      const machines = await prisma.machine.findMany({
        where: {
          active: true,
          status: "PUBLISHED",
          domain: "MACHINE",
          categoryId: machineTypeId,
          brandId: { not: null },
        },
        select: {
          brand: {
            select: {
              id: true,
              name: true,
              slug: true,
              logo: true,
              website: true,
              countryId: true,
              active: true,
            },
          },
        },
      });

      const brands = uniqueById(
        machines
          .map((machine) => machine.brand)
          .filter((brand): brand is NonNullable<typeof brand> => Boolean(brand?.active)),
      ) as BrandOption[];

      return NextResponse.json({
        success: true,
        step: "brands",
        items: sortFa(brands),
        parent: {
          id: machineType.id,
          name: machineType.name,
        },
      });
    }

    /* ========================================================
       VALIDATE BRAND RELATION
    ======================================================== */

    const brand = await prisma.brand.findUnique({
      where: { id: brandId },
      select: {
        id: true,
        name: true,
        slug: true,
        logo: true,
        website: true,
        countryId: true,
        active: true,
      },
    });

    if (!brand || !brand.active) {
      return jsonError("برند انتخاب‌شده پیدا نشد یا فعال نیست.", 404);
    }

    const matchingMachineExists = await prisma.machine.findFirst({
      where: {
        active: true,
        status: "PUBLISHED",
        domain: "MACHINE",
        categoryId: machineTypeId,
        brandId,
        specification: { isNot: null },
      },
      select: { id: true },
    });

    if (!matchingMachineExists) {
      return jsonError("این برند برای نوع دستگاه انتخاب‌شده داده معتبر ندارد.", 400);
    }

    /* ========================================================
       STEP 5 — MODELS
    ======================================================== */

    const machines = await prisma.machine.findMany({
      where: {
        active: true,
        status: "PUBLISHED",
        domain: "MACHINE",
        categoryId: machineTypeId,
        brandId,
        specification: {
          isNot: null,
        },
      },
      orderBy: { createdAt: "desc" },
      select: {
        id: true,
        title: true,
        slug: true,
        createdAt: true,
        specification: {
          select: {
            model: true,
          },
        },
        images: {
          where: { isPrimary: true },
          take: 1,
          select: { url: true },
        },
      },
    });

    const modelMap = new Map<string, ModelItem>();

    for (const machine of machines) {
      const rawModel = machine.specification?.model;
      if (typeof rawModel !== "string") continue;

      const normalizedModel = normalize(rawModel);
      if (!normalizedModel) continue;

      const modelKey = key(normalizedModel);
      const existing = modelMap.get(modelKey);

      if (!existing) {
        modelMap.set(modelKey, {
          model: normalizedModel,
          machineCount: 1,
          latestMachineId: machine.id,
          latestTitle: machine.title,
          latestSlug: machine.slug,
          image: machine.images[0]?.url ?? null,
        });
      } else {
        existing.machineCount += 1;
      }
    }

    const models = Array.from(modelMap.values()).sort((a, b) =>
      a.model.localeCompare(b.model, "en", {
        numeric: true,
        sensitivity: "base",
      }),
    );

    return NextResponse.json({
      success: true,
      step: "models",
      items: models,
      parent: {
        id: brand.id,
        name: brand.name,
      },
    });
  } catch (error) {
    console.error("[PRICE_ESTIMATOR_OPTIONS]", error);
    return jsonError("خطا در دریافت اطلاعات قیمت‌گذاری.", 500);
  }
}
