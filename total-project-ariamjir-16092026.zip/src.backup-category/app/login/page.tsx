import { loginAction } from "./actions";

export default function LoginPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-zinc-950">

      <form
        action={loginAction}
        className="w-full max-w-md bg-white rounded-2xl shadow-2xl p-8 space-y-6"
      >

        <div className="text-center">

          <h1 className="text-3xl font-bold text-orange-500">
            ARIA MJ
          </h1>

          <p className="text-zinc-500 mt-2">
            ورود به پنل مدیریت
          </p>

        </div>

        <div>

          <label className="block mb-2 text-sm font-medium text-zinc-700">
            نام کاربری
          </label>

          <input
            name="username"
            type="text"
            autoComplete="username"
            placeholder="نام کاربری"
            className="w-full rounded-xl border border-zinc-300 bg-white px-4 py-3 text-zinc-900 placeholder:text-zinc-400 outline-none focus:border-orange-500 focus:ring-2 focus:ring-orange-200"
          />

        </div>

        <div>

          <label className="block mb-2 text-sm font-medium text-zinc-700">
            رمز عبور
          </label>

          <input
            name="password"
            type="password"
            autoComplete="current-password"
            placeholder="رمز عبور"
            className="w-full rounded-xl border border-zinc-300 bg-white px-4 py-3 text-zinc-900 placeholder:text-zinc-400 outline-none focus:border-orange-500 focus:ring-2 focus:ring-orange-200"
          />

        </div>

        <button
          type="submit"
          className="w-full rounded-xl bg-orange-500 py-3 font-bold text-white transition hover:bg-orange-600"
        >
          ورود
        </button>

      </form>

    </div>
  );
}

