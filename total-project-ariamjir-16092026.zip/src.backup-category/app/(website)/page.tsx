export { default } from "../page";

