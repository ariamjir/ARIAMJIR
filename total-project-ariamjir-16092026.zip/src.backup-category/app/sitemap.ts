import type { MetadataRoute } from "next";

import { prisma } from "@/lib/prisma";

import { SITE_URL } from "@/lib/seo";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const now = new Date();

  const [machines, news, knowledge, parts, sellers, cats] = await Promise.all([
    prisma.machine.findMany({
      where: { status: "PUBLISHED", active: true },
      select: { slug: true, updatedAt: true },
    }),
    prisma.newsPost.findMany({
      where: { status: "PUBLISHED" },
      select: { slug: true, updatedAt: true },
    }),
    prisma.knowledgePost.findMany({
      where: { status: "PUBLISHED" },
      select: { slug: true, updatedAt: true },
    }),
    prisma.sparePart.findMany({
      where: { status: "PUBLISHED", active: true },
      select: { slug: true, updatedAt: true },
    }),
    prisma.company.findMany({
      where: { status: "PUBLISHED" },
      select: { slug: true, updatedAt: true },
    }),
    prisma.category.findMany({ select: { slug: true } }),
  ]);

  const statics: MetadataRoute.Sitemap = [
    "",
    "/machines",
    "/news",
    "/brands",
    "/services",
    "/knowledge",
    "/parts",
    "/compare",
    "/rental",
    "/sellers",
  ].map((p) => ({
    url: `${SITE_URL}${p}`,
    lastModified: now,
    changeFrequency: p === "" ? "daily" : "weekly",
    priority: p === "" ? 1 : 0.8,
  }));

  return [
    ...statics,
    ...machines.map((m) => ({
      url: `${SITE_URL}/machines/${m.slug}`,
      lastModified: m.updatedAt,
      changeFrequency: "weekly" as const,
      priority: 0.9,
    })),
    ...news.map((n) => ({
      url: `${SITE_URL}/news/${n.slug}`,
      lastModified: n.updatedAt,
      changeFrequency: "monthly" as const,
      priority: 0.7,
    })),
    ...knowledge.map((k) => ({
      url: `${SITE_URL}/knowledge/${k.slug}`,
      lastModified: k.updatedAt,
      changeFrequency: "monthly" as const,
      priority: 0.7,
    })),
    ...parts.map((p) => ({
      url: `${SITE_URL}/parts/${p.slug}`,
      lastModified: p.updatedAt,
      changeFrequency: "weekly" as const,
      priority: 0.8,
    })),
    ...sellers.map((s) => ({
      url: `${SITE_URL}/sellers/${s.slug}`,
      lastModified: s.updatedAt,
      changeFrequency: "weekly" as const,
      priority: 0.8,
    })),
    ...cats.map((c) => ({
      url: `${SITE_URL}/machines/category/${c.slug}`,
      lastModified: now,
      changeFrequency: "weekly" as const,
      priority: 0.7,
    })),
  ];
}