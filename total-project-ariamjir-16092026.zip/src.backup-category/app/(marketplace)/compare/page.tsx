import { Metadata } from "next";

import CompareClientPage from "@/modules/compare/components/CompareClientPage";

export const metadata: Metadata = {

title: "مقایسه ماشین‌آلات | ARIA MJ",

description: "مقایسه تخصصی ماشین‌آلات راهسازی، معدنی و عمرانی",

};

export default function ComparePage() {

return (

<div className="container mx-auto py-8">

<div className="mb-8">

<h1 className="text-3xl font-bold">

مقایسه ماشین‌آلات

</h1>

<p className="mt-2 text-gray-500">

مشخصات فنی، امکانات و ویژگی‌های ماشین‌ها را کنار هم مقایسه کنید.

</p>

</div>

<CompareClientPage/>

</div>

);

}

