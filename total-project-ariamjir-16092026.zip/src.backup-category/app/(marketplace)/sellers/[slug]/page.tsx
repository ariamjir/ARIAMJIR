import type { Metadata } from "next";

import Link from "next/link";
import { notFound } from "next/navigation";

import {
  ArrowRight,
  AtSign,
  BadgeCheck,
  Building2,
  Briefcase,
  Calendar,
  CheckCircle2,
  FileCheck2,
  FileText,
  Globe,
  Mail,
  MapPin,
  MessageCircle,
  Package,
  Phone,
  Send,
  ShieldCheck,
  Star,
  Users,
  Video,
} from "lucide-react";

import { prisma } from "@/lib/prisma";

import { SITE_URL, SITE_NAME } from "@/lib/seo";

import SellerCard from "@/components/seller/SellerCard";

import MachineCard from "@/components/machine/card/MachineCard";

import JsonLd from "@/components/seo/JsonLd";

export const revalidate = 300;

const DEFAULT_LOGO = "/images/machines/default.svg";
const DEFAULT_BANNER = "/images/hero/hero-2.jpg";

function absoluteUrl(value?: string | null) {
  if (!value) return undefined;

  if (
    value.startsWith("http://") ||
    value.startsWith("https://")
  ) {
    return value;
  }

  return `${SITE_URL}${value.startsWith("/") ? value : `/${value}`}`;
}

function formatPersianNumber(value: number) {
  return value.toLocaleString("fa-IR");
}

function formatPersianDate(value: Date) {
  return new Date(value).toLocaleDateString("fa-IR");
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;

  const company = await prisma.company.findUnique({
    where: { slug },
    select: {
      name: true,
      description: true,
      logo: true,
      banner: true,
      status: true,
      verified: true,
    },
  });

  if (!company || company.status !== "PUBLISHED") {
    return {
      title: "فروشنده پیدا نشد | آریا ماشین جم",
      robots: {
        index: false,
        follow: false,
      },
    };
  }

  const title = `${company.name} | فروشنده ماشین‌آلات سنگین | آریا ماشین جم`;

  const description =
    company.description?.trim().slice(0, 160) ||
    `پروفایل ${company.name} در آریا ماشین جم؛ مشاهده اطلاعات شرکت، ماشین‌آلات، شعب، راه‌های ارتباطی و وضعیت تأیید فروشنده.`;

  const url = `${SITE_URL}/sellers/${slug}`;

  const logo = absoluteUrl(company.logo);
  const banner = absoluteUrl(company.banner);

  return {
    title,
    description,
    alternates: {
      canonical: url,
    },
    robots: {
      index: true,
      follow: true,
    },
    openGraph: {
      title,
      description,
      url,
      type: "profile",
      locale: "fa_IR",
      siteName: SITE_NAME,
      ...(logo || banner
        ? {
            images: [
              {
                url: logo ?? banner!,
                alt: company.name,
              },
            ],
          }
        : {}),
    },
    twitter: {
      card: "summary",
      title,
      description,
      ...(logo
        ? {
            images: [logo],
          }
        : {}),
    },
  };
}

export default async function SellerDetailPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;

  const company = await prisma.company.findUnique({
    where: { slug },
  });

  if (!company || company.status !== "PUBLISHED") {
    notFound();
  }

  const [
    branches,
    documents,
    gallery,
    socials,
    reviews,
    machines,
    avgAgg,
    reviewCount,
    machineCount,
    related,
  ] = await Promise.all([
    prisma.branch.findMany({
      where: {
        companyId: company.id,
        active: true,
      },
      orderBy: {
        title: "asc",
      },
    }),

    prisma.companyDocument.findMany({
      where: {
        companyId: company.id,
        verified: true,
      },
      orderBy: {
        createdAt: "desc",
      },
    }),

    prisma.companyGallery.findMany({
      where: {
        companyId: company.id,
      },
      orderBy: {
        sortOrder: "asc",
      },
    }),

    prisma.companySocial.findMany({
      where: {
        companyId: company.id,
      },
      take: 1,
    }),

    prisma.companyReview.findMany({
      where: {
        companyId: company.id,
      },
      orderBy: {
        createdAt: "desc",
      },
      take: 20,
    }),

    prisma.machine.findMany({
      where: {
        sellerId: company.ownerId,
        status: "PUBLISHED",
        active: true,
      },
      orderBy: {
        createdAt: "desc",
      },
      take: 12,
      include: {
        brand: true,
        category: true,
        specification: true,
        price: true,
        images: {
          take: 1,
          orderBy: {
            sortOrder: "asc",
          },
        },
      },
    }),

    prisma.companyReview.aggregate({
      where: {
        companyId: company.id,
      },
      _avg: {
        rating: true,
      },
    }),

    prisma.companyReview.count({
      where: {
        companyId: company.id,
      },
    }),

    prisma.machine.count({
      where: {
        sellerId: company.ownerId,
        status: "PUBLISHED",
        active: true,
      },
    }),

    prisma.company.findMany({
      where: {
        status: "PUBLISHED",
        id: {
          not: company.id,
        },
      },
      take: 6,
      orderBy: [
        {
          featured: "desc",
        },
        {
          verified: "desc",
        },
        {
          createdAt: "desc",
        },
      ],
    }),
  ]);

  const avgRating = avgAgg._avg.rating ?? 0;

  const social = socials[0];

  const logo = company.logo ?? DEFAULT_LOGO;
  const banner = company.banner ?? DEFAULT_BANNER;

  const logoUrl = absoluteUrl(logo);
  const bannerUrl = absoluteUrl(banner);
  const companyUrl = `${SITE_URL}/sellers/${company.slug}`;

  const reviewsFormatted = reviews.map((review) => ({
    id: review.id,
    rating: Math.min(5, Math.max(0, review.rating)),
    comment: review.comment,
    date: formatPersianDate(review.createdAt),
  }));

  const socialSameAs = [
    social?.instagram,
    social?.telegram,
    social?.linkedin,
    social?.youtube,
    social?.aparat,
    social?.x,
  ].filter(Boolean);

  const organizationJsonLd = {
    "@context": "https://schema.org",
    "@type": "Organization",
    "@id": `${companyUrl}#organization`,
    name: company.name,
    url: companyUrl,
    ...(logoUrl ? { logo: logoUrl } : {}),
    ...(bannerUrl ? { image: bannerUrl } : {}),
    ...(company.description
      ? {
          description: company.description,
        }
      : {}),
    ...(company.phone
      ? {
          telephone: company.phone,
        }
      : {}),
    ...(company.email
      ? {
          email: company.email,
        }
      : {}),
    ...(company.website
      ? {
          sameAs: [company.website, ...socialSameAs],
        }
      : socialSameAs.length
        ? {
            sameAs: socialSameAs,
          }
        : {}),
    ...(company.establishedYear
      ? {
          foundingDate: String(company.establishedYear),
        }
      : {}),
    ...(company.employeeCount
      ? {
          numberOfEmployees: {
            "@type": "QuantitativeValue",
            value: company.employeeCount,
          },
        }
      : {}),
    ...(branches[0]?.address
      ? {
          address: {
            "@type": "PostalAddress",
            streetAddress: branches[0].address,
            addressCountry: "IR",
          },
        }
      : {}),
    ...(reviewCount > 0
      ? {
          aggregateRating: {
            "@type": "AggregateRating",
            ratingValue: Number(avgRating).toFixed(1),
            bestRating: "5",
            worstRating: "1",
            reviewCount: String(reviewCount),
          },
        }
      : {}),
  };

  return (
    <main className="min-h-screen bg-[#0d0d0d]">
      <JsonLd
        data={organizationJsonLd}
      />

      <JsonLd
        data={{
          "@context": "https://schema.org",
          "@type": "BreadcrumbList",
          itemListElement: [
            {
              "@type": "ListItem",
              position: 1,
              name: "خانه",
              item: SITE_URL,
            },
            {
              "@type": "ListItem",
              position: 2,
              name: "فروشندگان",
              item: `${SITE_URL}/sellers`,
            },
            {
              "@type": "ListItem",
              position: 3,
              name: company.name,
              item: companyUrl,
            },
          ],
        }}
      />

      <div className="mx-auto max-w-[1280px] px-5 pb-20 pt-28 lg:px-8">
        {/* Breadcrumb */}
        <nav
          aria-label="مسیر صفحه"
          className="mb-6 flex flex-wrap items-center gap-2 text-[11px]"
        >
          <Link
            href="/"
            className="text-white/35 transition hover:text-[#F58220]"
          >
            خانه
          </Link>

          <span className="text-white/20">‹</span>

          <Link
            href="/sellers"
            className="text-white/35 transition hover:text-[#F58220]"
          >
            فروشندگان
          </Link>

          <span className="text-white/20">‹</span>

          <span className="font-bold text-white/65">
            {company.name}
          </span>
        </nav>

        {/* Seller Hero */}
        <section className="relative overflow-hidden rounded-[28px] border border-white/10 bg-[#141414] shadow-2xl">
          <div className="relative h-52 overflow-hidden md:h-72">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={banner}
              alt=""
              aria-hidden="true"
              className="h-full w-full object-cover opacity-45"
            />

            <div className="absolute inset-0 bg-gradient-to-t from-[#141414] via-[#141414]/65 to-[#141414]/10" />

            <div className="absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-[#141414] to-transparent" />
          </div>

          <div className="relative -mt-28 px-5 pb-7 md:px-9">
            <div className="flex flex-col gap-6 lg:flex-row lg:items-end">
              {/* Logo */}
              <div className="flex h-32 w-32 shrink-0 items-center justify-center rounded-[22px] border-4 border-[#141414] bg-white p-5 shadow-2xl md:h-36 md:w-36">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={logo}
                  alt={`لوگوی ${company.name}`}
                  className="h-full w-full object-contain"
                />
              </div>

              {/* Main identity */}
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2.5">
                  <h1 className="text-2xl font-black tracking-tight text-white md:text-3xl">
                    {company.name}
                  </h1>

                  {company.verified && (
                    <span className="inline-flex items-center gap-1.5 rounded-full border border-blue-400/20 bg-blue-500/10 px-3 py-1.5 text-[10px] font-black text-blue-300">
                      <BadgeCheck className="h-3.5 w-3.5" />
                      فروشنده تأییدشده
                    </span>
                  )}

                  {company.featured && (
                    <span className="inline-flex items-center gap-1 rounded-full bg-[#F58220] px-3 py-1.5 text-[10px] font-black text-white shadow-lg shadow-[#F58220]/10">
                      <Star className="h-3 w-3 fill-current" />
                      فروشنده برتر
                    </span>
                  )}
                </div>

                {company.description && (
                  <p className="mt-3 max-w-3xl text-sm leading-7 text-white/55">
                    {company.description}
                  </p>
                )}

                <div className="mt-4 flex flex-wrap gap-x-5 gap-y-2.5 text-[11px] text-white/45">
                  {company.establishedYear && (
                    <span className="inline-flex items-center gap-1.5">
                      <Calendar className="h-3.5 w-3.5 text-[#F58220]" />
                      سابقه از {company.establishedYear.toLocaleString("fa-IR")}
                    </span>
                  )}

                  {company.employeeCount && (
                    <span className="inline-flex items-center gap-1.5">
                      <Users className="h-3.5 w-3.5 text-[#F58220]" />
                      {formatPersianNumber(company.employeeCount)} کارمند
                    </span>
                  )}

                  <span className="inline-flex items-center gap-1.5">
                    <Building2 className="h-3.5 w-3.5 text-[#F58220]" />
                    {formatPersianNumber(branches.length)} شعبه فعال
                  </span>

                  {reviewCount > 0 && (
                    <span className="inline-flex items-center gap-1.5 text-amber-400">
                      <Star className="h-3.5 w-3.5 fill-current" />
                      {Number(avgRating).toFixed(1)} از ۵
                      <span className="text-white/35">
                        ({formatPersianNumber(reviewCount)} نظر)
                      </span>
                    </span>
                  )}
                </div>
              </div>

              {/* Contact actions */}
              <div className="flex shrink-0 flex-col gap-2 sm:flex-row lg:flex-col">
                {company.phone && (
                  <a
                    href={`tel:${company.phone}`}
                    className="inline-flex h-11 items-center justify-center gap-2 rounded-xl bg-[#F58220] px-6 text-sm font-black text-white shadow-lg shadow-[#F58220]/10 transition hover:bg-[#df7016]"
                  >
                    <Phone className="h-4 w-4" />
                    تماس با فروشنده
                  </a>
                )}

                {company.mobile && (
                  <a
                    href={`https://wa.me/${company.mobile.replace(/^0/, "98")}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex h-11 items-center justify-center gap-2 rounded-xl border border-white/10 bg-white/5 px-6 text-sm font-bold text-white transition hover:border-green-400/30 hover:bg-green-400/10"
                  >
                    <MessageCircle className="h-4 w-4" />
                    واتساپ
                  </a>
                )}
              </div>
            </div>
          </div>
        </section>

        {/* Trust strip */}
        <section className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <TrustCard
            icon={<ShieldCheck className="h-5 w-5" />}
            title={company.verified ? "هویت تأییدشده" : "پروفایل ثبت‌شده"}
            description={
              company.verified
                ? "اطلاعات فروشنده توسط آریا ماشین جم بررسی شده است."
                : "اطلاعات فروشنده در سامانه ثبت شده است."
            }
            active={company.verified}
          />

          <TrustCard
            icon={<Package className="h-5 w-5" />}
            title="موجودی فعال"
            description={`${formatPersianNumber(machineCount)} دستگاه منتشرشده`}
            active={machineCount > 0}
          />

          <TrustCard
            icon={<FileCheck2 className="h-5 w-5" />}
            title="اسناد"
            description={`${formatPersianNumber(documents.length)} سند تأییدشده`}
            active={documents.length > 0}
          />

          <TrustCard
            icon={<Star className="h-5 w-5" />}
            title="اعتبار مشتریان"
            description={
              reviewCount > 0
                ? `${Number(avgRating).toFixed(1)} از ۵`
                : "هنوز امتیازی ثبت نشده"
            }
            active={reviewCount > 0}
          />
        </section>

        {/* KPIs */}
        <section className="mt-4 grid grid-cols-2 gap-3 lg:grid-cols-4">
          <KPI
            label="دستگاه فعال"
            value={machineCount}
            icon={<Package className="h-5 w-5" />}
          />

          <KPI
            label="شعبه فعال"
            value={branches.length}
            icon={<MapPin className="h-5 w-5" />}
          />

          <KPI
            label="امتیاز مشتریان"
            value={
              avgRating > 0
                ? Number(avgRating).toFixed(1)
                : "—"
            }
            icon={<Star className="h-5 w-5 fill-current" />}
          />

          <KPI
            label="تعداد نظرات"
            value={reviewCount}
            icon={<MessageCircle className="h-5 w-5" />}
          />
        </section>

        {/* Machines */}
        {machines.length > 0 && (
          <section className="mt-16">
            <SectionHeader
              eyebrow="INVENTORY"
              title={`ماشین‌آلات ${company.name}`}
              description="آخرین ماشین‌آلات فعال این فروشنده را مشاهده کنید."
            />

            <div className="mt-7 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {machines.map((machine: any) => (
                <MachineCard
                  key={machine.id}
                  machine={machine}
                />
              ))}
            </div>

            {machineCount > machines.length && (
              <div className="mt-6 text-center">
                <span className="text-xs text-white/35">
                  {formatPersianNumber(machineCount - machines.length)} دستگاه دیگر در موجودی این فروشنده فعال است.
                </span>
              </div>
            )}
          </section>
        )}

        {/* Company + branches */}
        <section className="mt-16 grid gap-6 lg:grid-cols-2">
          <div className="rounded-3xl border border-white/10 bg-[#141414] p-7 md:p-8">
            <SectionTitle
              icon={<Building2 className="h-5 w-5" />}
              title="درباره شرکت"
            />

            <dl className="mt-7 space-y-4">
              <Row
                label="نام رسمی"
                value={company.legalName ?? company.name}
              />

              {company.registrationNumber && (
                <Row
                  label="شماره ثبت"
                  value={company.registrationNumber}
                />
              )}

              {company.nationalId && (
                <Row
                  label="شناسه ملی"
                  value={company.nationalId}
                />
              )}

              {company.economicCode && (
                <Row
                  label="کد اقتصادی"
                  value={company.economicCode}
                />
              )}

              {company.establishedYear && (
                <Row
                  label="سال تأسیس"
                  value={company.establishedYear.toLocaleString("fa-IR")}
                />
              )}

              {company.employeeCount && (
                <Row
                  label="تعداد کارکنان"
                  value={`${company.employeeCount.toLocaleString("fa-IR")} نفر`}
                />
              )}

              {company.email && (
                <Row
                  label="ایمیل"
                  value={company.email}
                  icon={<Mail className="h-4 w-4" />}
                  ltr
                />
              )}

              {company.website && (
                <Row
                  label="وب‌سایت"
                  value={company.website}
                  icon={<Globe className="h-4 w-4" />}
                  ltr
                  href={company.website}
                />
              )}
            </dl>
          </div>

          <div className="rounded-3xl border border-white/10 bg-[#141414] p-7 md:p-8">
            <SectionTitle
              icon={<MapPin className="h-5 w-5" />}
              title={`شعب و مراکز فعالیت (${formatPersianNumber(branches.length)})`}
            />

            <div className="mt-7 space-y-3">
              {branches.map((branch: any) => (
                <div
                  key={branch.id}
                  className="rounded-2xl border border-white/10 bg-white/[0.025] p-4 transition hover:border-[#F58220]/20 hover:bg-white/[0.04]"
                >
                  <div className="flex items-start gap-3">
                    <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-[#F58220]/10 text-[#F58220]">
                      <MapPin className="h-4 w-4" />
                    </span>

                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <h3 className="text-sm font-black text-white">
                          {branch.title}
                        </h3>

                        {branch.id === branches[0]?.id && (
                          <span className="rounded-full bg-[#F58220]/10 px-2 py-0.5 text-[9px] font-bold text-[#F58220]">
                            مرکز اصلی
                          </span>
                        )}
                      </div>

                      {branch.address && (
                        <p className="mt-2 text-[11px] leading-6 text-white/45">
                          {branch.address}
                        </p>
                      )}

                      <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-[10px] text-white/35">
                        {branch.manager && (
                          <span>
                            مدیر: {branch.manager}
                          </span>
                        )}

                        {branch.mobile && (
                          <a
                            href={`tel:${branch.mobile}`}
                            className="transition hover:text-[#F58220]"
                          >
                            {branch.mobile}
                          </a>
                        )}

                        {branch.phone && (
                          <a
                            href={`tel:${branch.phone}`}
                            className="transition hover:text-[#F58220]"
                          >
                            {branch.phone}
                          </a>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}

              {branches.length === 0 && (
                <EmptyState text="اطلاعات شعب این فروشنده هنوز ثبت نشده است." />
              )}
            </div>
          </div>
        </section>

        {/* Social / documents / gallery */}
        <section className="mt-6 grid gap-6 lg:grid-cols-3">
          {/* Social */}
          <div className="rounded-3xl border border-white/10 bg-[#141414] p-7">
            <h2 className="text-sm font-black text-white">
              شبکه‌های اجتماعی
            </h2>

            <div className="mt-5 flex flex-wrap gap-2.5">
              <SocialButton
                href={social?.instagram}
                label="اینستاگرام"
                icon={<AtSign className="h-4 w-4" />}
              />

              <SocialButton
                href={social?.telegram}
                label="تلگرام"
                icon={<Send className="h-4 w-4" />}
              />

              <SocialButton
                href={social?.linkedin}
                label="لینکدین"
                icon={<Briefcase className="h-4 w-4" />}
              />

              <SocialButton
                href={social?.youtube}
                label="یوتیوب"
                icon={<Video className="h-4 w-4" />}
              />

              <SocialButton
                href={social?.aparat}
                label="آپارات"
                icon={<Video className="h-4 w-4" />}
              />

              <SocialButton
                href={social?.x}
                label="X"
                icon={<span className="text-sm font-black">𝕏</span>}
              />

              {social?.whatsapp && (
                <SocialButton
                  href={
                    social.whatsapp.startsWith("http")
                      ? social.whatsapp
                      : `https://wa.me/${social.whatsapp.replace(/^0/, "98")}`
                  }
                  label="واتساپ"
                  icon={<MessageCircle className="h-4 w-4" />}
                />
              )}

              {!social?.instagram &&
                !social?.telegram &&
                !social?.linkedin &&
                !social?.youtube &&
                !social?.aparat &&
                !social?.x &&
                !social?.whatsapp && (
                  <EmptyState text="شبکه اجتماعی ثبت نشده است." />
                )}
            </div>
          </div>

          {/* Documents */}
          <div className="rounded-3xl border border-white/10 bg-[#141414] p-7">
            <h2 className="flex items-center gap-2 text-sm font-black text-white">
              <FileCheck2 className="h-4 w-4 text-[#F58220]" />
              اسناد تأییدشده
            </h2>

            {documents.length === 0 ? (
              <div className="mt-5">
                <EmptyState text="سند تأییدشده‌ای برای نمایش وجود ندارد." />
              </div>
            ) : (
              <ul className="mt-5 space-y-2">
                {documents.map((document: any) => (
                  <li key={document.id}>
                    <a
                      href={document.fileUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-3 rounded-xl border border-white/10 bg-white/[0.025] p-3 text-xs text-white/65 transition hover:border-[#F58220]/30 hover:text-[#F58220]"
                    >
                      <FileText className="h-4 w-4 shrink-0" />

                      <span className="min-w-0 flex-1 truncate">
                        {document.title}
                      </span>

                      <CheckCircle2 className="h-3.5 w-3.5 shrink-0 text-emerald-400" />
                    </a>
                  </li>
                ))}
              </ul>
            )}
          </div>

          {/* Gallery */}
          <div className="rounded-3xl border border-white/10 bg-[#141414] p-7">
            <h2 className="text-sm font-black text-white">
              گالری شرکت
              <span className="mr-1 text-white/30">
                ({formatPersianNumber(gallery.length)})
              </span>
            </h2>

            {gallery.length === 0 ? (
              <div className="mt-5">
                <EmptyState text="تصویری برای گالری ثبت نشده است." />
              </div>
            ) : (
              <div className="mt-5 grid grid-cols-3 gap-2">
                {gallery.slice(0, 6).map((item: any) => (
                  <div
                    key={item.id}
                    className="group aspect-square overflow-hidden rounded-xl bg-white/[0.03]"
                  >
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={item.image}
                      alt={`${company.name} - تصویر شرکت`}
                      loading="lazy"
                      className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
                    />
                  </div>
                ))}
              </div>
            )}
          </div>
        </section>

        {/* Reviews */}
        <section className="mt-16">
          <SectionHeader
            eyebrow="CUSTOMER REVIEWS"
            title={`نظر مشتریان درباره ${company.name}`}
            description={
              reviewCount > 0
                ? `${formatPersianNumber(reviewCount)} نظر ثبت شده با میانگین امتیاز ${Number(avgRating).toFixed(1)} از ۵`
                : "هنوز نظری برای این فروشنده ثبت نشده است."
            }
          />

          {reviewsFormatted.length === 0 ? (
            <div className="mt-7">
              <EmptyState
                large
                text="هنوز نظری برای این فروشنده ثبت نشده است."
              />
            </div>
          ) : (
            <div className="mt-7 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {reviewsFormatted.map((review) => (
                <article
                  key={review.id}
                  className="rounded-2xl border border-white/10 bg-[#141414] p-5 transition hover:border-white/15"
                >
                  <div className="flex items-center justify-between gap-4">
                    <div className="flex items-center gap-1 text-amber-400">
                      {Array.from({ length: 5 }).map((_, index) => (
                        <Star
                          key={index}
                          className={`h-3.5 w-3.5 ${
                            index < review.rating
                              ? "fill-current"
                              : "text-white/15"
                          }`}
                        />
                      ))}
                    </div>

                    <span className="text-[10px] text-white/30">
                      {review.date}
                    </span>
                  </div>

                  {review.comment ? (
                    <p className="mt-4 text-xs leading-7 text-white/65">
                      {review.comment}
                    </p>
                  ) : (
                    <p className="mt-4 text-xs text-white/30">
                      کاربر امتیاز ثبت کرده است.
                    </p>
                  )}

                  <div className="mt-5 flex items-center gap-2 border-t border-white/5 pt-4 text-[10px] text-white/35">
                    <span className="flex h-7 w-7 items-center justify-center rounded-full bg-white/5">
                      <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />
                    </span>
                    کاربر تأییدشده
                  </div>
                </article>
              ))}
            </div>
          )}
        </section>

        {/* Related sellers */}
        {related.length > 0 && (
          <section className="mt-16">
            <SectionHeader
              eyebrow="DISCOVER MORE"
              title="فروشندگان مشابه"
              description="سایر فروشندگان فعال و تأییدشده در شبکه آریا ماشین جم."
            />

            <div className="mt-7 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {related.map((seller: any) => (
                <SellerCard
                  key={seller.id}
                  s={{
                    ...seller,
                    branches: [],
                    avgRating: 0,
                    reviewCount: 0,
                  }}
                />
              ))}
            </div>
          </section>
        )}

        {/* Back */}
        <div className="mt-14 border-t border-white/5 pt-8">
          <Link
            href="/sellers"
            className="inline-flex items-center gap-2 rounded-xl border border-white/10 bg-white/[0.04] px-5 py-3 text-sm font-bold text-white transition hover:border-[#F58220]/30 hover:bg-[#F58220]/5"
          >
            <ArrowRight className="h-4 w-4" />
            بازگشت به همه فروشندگان
          </Link>
        </div>
      </div>
    </main>
  );
}

function TrustCard({
  icon,
  title,
  description,
  active,
}: {
  icon: React.ReactNode;
  title: string;
  description: string;
  active: boolean;
}) {
  return (
    <div className="rounded-2xl border border-white/10 bg-[#141414] p-4">
      <div className="flex items-start gap-3">
        <div
          className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ${
            active
              ? "bg-[#F58220]/10 text-[#F58220]"
              : "bg-white/5 text-white/35"
          }`}
        >
          {icon}
        </div>

        <div className="min-w-0">
          <div className="text-xs font-black text-white">
            {title}
          </div>

          <div className="mt-1 text-[10px] leading-5 text-white/35">
            {description}
          </div>
        </div>
      </div>
    </div>
  );
}

function KPI({
  label,
  value,
  icon,
}: {
  label: string;
  value: number | string;
  icon: React.ReactNode;
}) {
  return (
    <div className="rounded-2xl border border-white/10 bg-[#141414] p-5 text-center">
      <div className="mx-auto mb-2 flex h-10 w-10 items-center justify-center rounded-xl bg-[#F58220]/10 text-[#F58220]">
        {icon}
      </div>

      <div className="text-2xl font-black text-white">
        {typeof value === "number"
          ? formatPersianNumber(value)
          : value}
      </div>

      <div className="mt-1 text-[10px] text-white/40">
        {label}
      </div>
    </div>
  );
}

function SectionHeader({
  eyebrow,
  title,
  description,
}: {
  eyebrow: string;
  title: string;
  description?: string;
}) {
  return (
    <div>
      <div className="mb-2 text-[9px] font-black tracking-[0.22em] text-[#F58220]">
        {eyebrow}
      </div>

      <h2 className="text-xl font-black tracking-tight text-white md:text-2xl">
        {title}
      </h2>

      {description && (
        <p className="mt-2 max-w-2xl text-xs leading-6 text-white/35">
          {description}
        </p>
      )}
    </div>
  );
}

function SectionTitle({
  icon,
  title,
}: {
  icon: React.ReactNode;
  title: string;
}) {
  return (
    <h2 className="flex items-center gap-2 text-lg font-black text-white">
      <span className="text-[#F58220]">{icon}</span>
      {title}
    </h2>
  );
}

function Row({
  label,
  value,
  icon,
  ltr,
  href,
}: {
  label: string;
  value: string;
  icon?: React.ReactNode;
  ltr?: boolean;
  href?: string;
}) {
  const content = (
    <span
      className={`flex items-center gap-1.5 text-sm font-bold ${
        href
          ? "text-white transition hover:text-[#F58220]"
          : "text-white"
      }`}
      dir={ltr ? "ltr" : undefined}
    >
      {icon}
      {value}
    </span>
  );

  return (
    <div className="flex items-start justify-between gap-5 border-b border-white/5 pb-3 last:border-0 last:pb-0">
      <span className="shrink-0 text-xs text-white/35">
        {label}
      </span>

      {href ? (
        <a
          href={href}
          target="_blank"
          rel="noopener noreferrer"
          className="max-w-[70%] truncate"
        >
          {content}
        </a>
      ) : (
        <div className="max-w-[70%] text-left">
          {content}
        </div>
      )}
    </div>
  );
}

function SocialButton({
  href,
  label,
  icon,
}: {
  href?: string | null;
  label: string;
  icon: React.ReactNode;
}) {
  if (!href) return null;

  const target =
    href.startsWith("http://") ||
    href.startsWith("https://")
      ? href
      : `https://${href}`;

  return (
    <a
      href={target}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={label}
      title={label}
      className="inline-flex h-10 w-10 items-center justify-center rounded-xl border border-white/10 bg-white/[0.03] text-white/55 transition hover:border-[#F58220]/35 hover:bg-[#F58220]/5 hover:text-[#F58220]"
    >
      {icon}
    </a>
  );
}

function EmptyState({
  text,
  large = false,
}: {
  text: string;
  large?: boolean;
}) {
  return (
    <div
      className={`rounded-2xl border border-dashed border-white/10 bg-white/[0.015] text-center text-white/30 ${
        large ? "p-12" : "p-5"
      }`}
    >
      <p className="text-xs">{text}</p>
    </div>
  );
}