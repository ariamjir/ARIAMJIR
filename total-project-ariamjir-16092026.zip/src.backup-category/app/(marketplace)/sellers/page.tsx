import type { Metadata } from "next";

import SellerListClient from "@/components/seller/SellerListClient";

import JsonLd from "@/components/seo/JsonLd";

import { SITE_URL, SITE_NAME } from "@/lib/seo";

const PAGE_URL = `${SITE_URL}/sellers`;

export const metadata: Metadata = {
  title: "فروشندگان ماشین‌آلات سنگین | آریا ماشین جم",
  description:
    "فهرست فروشندگان و شرکت‌های فعال ماشین‌آلات سنگین، راه‌سازی، معدنی، کشاورزی و صنعتی در آریا ماشین جم؛ مشاهده موجودی، اطلاعات شرکت، شعب، امتیاز و وضعیت تأیید فروشندگان.",
  keywords: [
    "فروشندگان ماشین آلات سنگین",
    "فروشنده ماشین آلات راهسازی",
    "فروشنده ماشین آلات معدنی",
    "شرکت ماشین آلات سنگین",
    "نمایندگی ماشین آلات",
    "فروشندگان آریا ماشین جم",
    "ماشین آلات راهسازی",
    "ماشین آلات معدنی",
  ],
  alternates: {
    canonical: PAGE_URL,
  },
  robots: {
    index: true,
    follow: true,
  },
  openGraph: {
    title: "فروشندگان ماشین‌آلات سنگین | آریا ماشین جم",
    description:
      "شبکه فروشندگان و شرکت‌های فعال ماشین‌آلات سنگین در سراسر ایران؛ اطلاعات شرکت، موجودی، شعب، امتیاز و وضعیت تأیید.",
    url: PAGE_URL,
    type: "website",
    locale: "fa_IR",
    siteName: SITE_NAME,
  },
  twitter: {
    card: "summary",
    title: "فروشندگان ماشین‌آلات سنگین | آریا ماشین جم",
    description:
      "شبکه فروشندگان و شرکت‌های فعال ماشین‌آلات سنگین در آریا ماشین جم.",
  },
};

export const revalidate = 300;

export default function SellersPage() {
  return (
    <>
      <JsonLd
        data={{
          "@context": "https://schema.org",
          "@type": "CollectionPage",
          "@id": `${PAGE_URL}#collection`,
          name: "فروشندگان ماشین‌آلات سنگین",
          description:
            "فهرست فروشندگان و شرکت‌های فعال ماشین‌آلات سنگین در آریا ماشین جم.",
          url: PAGE_URL,
          inLanguage: "fa-IR",
          isPartOf: {
            "@type": "WebSite",
            name: SITE_NAME,
            url: SITE_URL,
          },
          about: {
            "@type": "Thing",
            name: "فروشندگان ماشین‌آلات سنگین",
          },
          breadcrumb: {
            "@type": "BreadcrumbList",
            itemListElement: [
              {
                "@type": "ListItem",
                position: 1,
                name: "خانه",
                item: SITE_URL,
              },
              {
                "@type": "ListItem",
                position: 2,
                name: "فروشندگان",
                item: PAGE_URL,
              },
            ],
          },
        }}
      />

      <SellerListClient />
    </>
  );
}