import type { Metadata } from "next";

import Link from "next/link";

import { notFound } from "next/navigation";

import { Eye, Clock3, Calendar, ArrowRight, Share2, Download } from "lucide-react";

import { prisma } from "@/lib/prisma";

import { faDate } from "@/lib/news";

import { SITE_URL, SITE_NAME } from "@/lib/seo";

import NewsContent from "@/components/news/NewsContent";
import NewsCard from "@/components/news/NewsCard";
import JsonLd from "@/components/seo/JsonLd";

export const revalidate = 60;

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const post = await prisma.newsPost.findUnique({ where: { slug } });

  const title = post?.metaTitle ?? `${post?.title ?? "خبر"} | آریا ماشین جم`;
  const desc = post?.metaDescription ?? post?.excerpt ?? "";
  const url = `${SITE_URL}/news/${slug}`;

  return {
    title,
    description: desc,
    alternates: { canonical: url },
    openGraph: {
      title,
      description: desc,
      url,
      type: "article",
      locale: "fa_IR",
      siteName: SITE_NAME,
      images: post?.coverImage ? [post.coverImage] : [],
    },
    twitter: { card: "summary_large_image", title, description: desc },
  };
}

export default async function NewsDetailPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;

  const post = await prisma.newsPost.findUnique({
    where: { slug },
    include: { category: true },
  });

  if (!post || post.status !== "PUBLISHED") notFound();

  await prisma.newsPost.update({
    where: { id: post.id },
    data: { viewCount: { increment: 1 } },
  });

  const related = await prisma.newsPost.findMany({
    where: { status: "PUBLISHED", id: { not: post.id } },
    orderBy: { publishedAt: "desc" },
    take: 3,
    include: { category: true },
  });

  const absUrl = `${SITE_URL}/news/${post.slug}`;

  return (
    <div className="mx-auto max-w-[900px] px-5 py-16 lg:px-8">
      {/* ✅ سئوی ساختاریافته */}
      <JsonLd
        data={{
          "@context": "https://schema.org",
          "@type": "NewsArticle",
          headline: post.title,
          description: post.excerpt,
          image: post.coverImage ? [`${SITE_URL}${post.coverImage}`] : [],
          datePublished: post.publishedAt,
          dateModified: post.updatedAt,
          inLanguage: "fa",
          articleSection: post.category?.name,
          keywords: post.tags.join("، "),
          mainEntityOfPage: absUrl,
          author: { "@type": "Organization", name: post.authorName ?? "تحریریه آریا MJ" },
          publisher: {
            "@type": "Organization",
            name: SITE_NAME,
            url: SITE_URL,
            logo: { "@type": "ImageObject", url: `${SITE_URL}/images/logo/ariamj-logo.png` },
          },
        }}
      />
      <JsonLd
        data={{
          "@context": "https://schema.org",
          "@type": "BreadcrumbList",
          itemListElement: [
            { "@type": "ListItem", position: 1, name: "خانه", item: SITE_URL },
            { "@type": "ListItem", position: 2, name: "اخبار", item: `${SITE_URL}/news` },
            { "@type": "ListItem", position: 3, name: post.title, item: absUrl },
          ],
        }}
      />

      {/* مسیر */}
      <div className="mb-6 flex items-center gap-2 text-[11px] text-white/40">
        <Link href="/" className="hover:text-[#F58220]">خانه</Link>
        <Chevron />
        <Link href="/news" className="hover:text-[#F58220]">اخبار</Link>
        <Chevron />
        <span className="font-bold text-white/70">{post.title}</span>
      </div>

      {/* سربرگ خبر */}
      <div className="text-center">
        {post.category && (
          <span
            className="rounded-full px-4 py-1.5 text-[11px] font-black text-white"
            style={{ backgroundColor: post.category.color ?? "#F58220" }}
          >
            {post.category.name}
          </span>
        )}
        <h1 className="mt-4 text-2xl font-black leading-[1.6] text-white lg:text-4xl">{post.title}</h1>
        <div className="mt-5 flex flex-wrap items-center justify-center gap-5 text-[11px] text-white/40">
          {post.authorName && <span>✍ {post.authorName}</span>}
          <span className="inline-flex items-center gap-1">
            <Calendar className="h-3.5 w-3.5" />
            {faDate(post.publishedAt)}
          </span>
          <span className="inline-flex items-center gap-1">
            <Clock3 className="h-3.5 w-3.5" />
            {post.readMinutes} دقیقه مطالعه
          </span>
          <span className="inline-flex items-center gap-1">
            <Eye className="h-3.5 w-3.5" />
            {(post.viewCount + 1).toLocaleString("fa-IR")}
          </span>
        </div>
      </div>

      {/* تصویر شاخص + دانلود واترمارک‌دار */}
      {post.coverImage && (
        <div className="mt-8">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={post.coverImage} alt={post.title} className="w-full rounded-3xl border border-white/10" />
          <div className="mt-3 flex justify-end">
            <a
              href={`/api/download/image?url=${encodeURIComponent(post.coverImage)}`}
              className="inline-flex items-center gap-2 rounded-xl border border-white/10 bg-white/[0.05] px-5 py-2.5 text-xs font-bold text-white transition hover:border-[#F58220]/40 hover:bg-[#F58220]/10 hover:text-[#F58220]"
            >
              <Download className="h-4 w-4" />
              دانلود تصویر با واترمارک
            </a>
          </div>
        </div>
      )}

      {/* اشتراک */}
      <div className="mt-6 flex items-center justify-center gap-3">
        <span className="inline-flex items-center gap-1 text-[11px] text-white/40">
          <Share2 className="h-3.5 w-3.5" />
          اشتراک:
        </span>
        <ShareBtn href={`https://t.me/share/url?url=${encodeURIComponent(absUrl)}`} label="تلگرام" />
        <ShareBtn href={`https://wa.me/?text=${encodeURIComponent(post.title + " " + absUrl)}`} label="واتساپ" />
        <ShareBtn href={`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(absUrl)}`} label="لینکدین" />
      </div>

      {/* محتوا */}
      <div className="mt-10 rounded-3xl border border-white/10 bg-[#141414] p-6 lg:p-10">
        <NewsContent content={post.content ?? ""} />
      </div>

      {/* برچسب‌ها */}
      {post.tags.length > 0 && (
        <div className="mt-6 flex flex-wrap gap-2">
          {post.tags.map((t: string) => (
            <span key={t} className="rounded-full border border-white/10 bg-white/[0.04] px-3 py-1 text-[10px] font-bold text-white/50">
              #{t}
            </span>
          ))}
        </div>
      )}

      {/* اخبار مرتبط */}
      {related.length > 0 && (
        <div className="mt-16">
          <h2 className="mb-6 text-xl font-black text-white">اخبار مرتبط</h2>
          <div className="grid gap-6 md:grid-cols-3">
            {related.map((r: any) => (
              <NewsCard key={r.id} post={r} />
            ))}
          </div>
        </div>
      )}

      <Link
        href="/news"
        className="mt-12 inline-flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-6 py-3 text-sm font-bold text-white transition hover:border-[#F58220]/40"
      >
        <ArrowRight className="h-4 w-4" />
        همهٔ اخبار
      </Link>
    </div>
  );
}

function Chevron() {
  return <span className="text-white/30">‹</span>;
}

function ShareBtn({ href, label }: { href: string; label: string }) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className="rounded-full border border-white/10 bg-white/[0.04] px-4 py-1.5 text-[10px] font-bold text-white/60 transition hover:border-[#F58220]/50 hover:text-[#F58220]"
    >
      {label}
    </a>
  );
}