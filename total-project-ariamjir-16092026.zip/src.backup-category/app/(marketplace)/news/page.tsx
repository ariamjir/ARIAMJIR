import type { Metadata } from "next";

import NewsListClient from "@/components/news/NewsListClient";

import JsonLd from "@/components/seo/JsonLd";

import { SITE_URL, SITE_NAME } from "@/lib/seo";

export const metadata: Metadata = {
  title: "اخبار ماشین‌آلات سنگین و معدن | آریا ماشین جم",
  description:
    "تازه‌ترین اخبار بازار ماشین‌آلات سنگین، معدن و راه‌سازی، تحلیل قیمت، رویدادها و فناوری‌های صنعتی ایران و جهان در خبرنامهٔ تخصصی آریا ماشین جم.",
  keywords: "اخبار ماشین‌آلات سنگین, اخبار معدن, بیل مکانیکی, لودر, بازار ماشین‌آلات",
  alternates: { canonical: `${SITE_URL}/news` },
  openGraph: {
    title: "اخبار ماشین‌آلات سنگین و معدن | آریا ماشین جم",
    description: "خبرنامهٔ تخصصی صنعت ماشین‌آلات سنگین ایران و جهان",
    url: `${SITE_URL}/news`,
    type: "website",
    locale: "fa_IR",
    siteName: SITE_NAME,
  },
  twitter: { card: "summary_large_image" },
};

export const revalidate = 300;

export default function NewsPage() {
  return (
    <>
      <JsonLd
        data={{
          "@context": "https://schema.org",
          "@type": "CollectionPage",
          name: "اخبار ماشین‌آلات سنگین و معدن",
          url: `${SITE_URL}/news`,
          isPartOf: { "@type": "WebSite", name: SITE_NAME, url: SITE_URL },
          inLanguage: "fa",
        }}
      />
      <NewsListClient />
    </>
  );
}