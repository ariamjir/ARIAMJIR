import type { Metadata } from "next";

import KnowledgeListClient from "@/components/knowledge/KnowledgeListClient";

import JsonLd from "@/components/seo/JsonLd";

import { SITE_URL, SITE_NAME } from "@/lib/seo";

export const metadata: Metadata = {
  title: "مرکز دانش ماشین‌آلات سنگین | آموزش و راهنما | آریا ماشین جم",
  description:
    "مقالات آموزشی و راهنمای تخصصی خرید، نگهداری و بهره‌برداری ماشین‌آلات سنگین، معدنی و راه‌سازی — مرکز دانش آریا ماشین جم.",
  alternates: { canonical: `${SITE_URL}/knowledge` },
  openGraph: {
    title: "مرکز دانش ماشین‌آلات سنگین | آریا ماشین جم",
    description: "آکادمی تخصصی صنعت ماشین‌آلات سنگین",
    url: `${SITE_URL}/knowledge`,
    type: "website",
    locale: "fa_IR",
    siteName: SITE_NAME,
  },
};

export const revalidate = 300;

export default function KnowledgePage() {
  return (
    <>
      <JsonLd
        data={{
          "@context": "https://schema.org",
          "@type": "CollectionPage",
          name: "مرکز دانش ماشین‌آلات سنگین",
          url: `${SITE_URL}/knowledge`,
          inLanguage: "fa",
        }}
      />
      <KnowledgeListClient />
    </>
  );
}