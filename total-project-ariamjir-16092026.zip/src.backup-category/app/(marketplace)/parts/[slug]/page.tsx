import type { Metadata } from "next";

import Link from "next/link";

import { notFound } from "next/navigation";

import { ArrowRight, Package, FileText, ShieldCheck, Truck, BadgeCheck } from "lucide-react";

import { prisma } from "@/lib/prisma";

import { SITE_URL, SITE_NAME } from "@/lib/seo";

import PartCard, { priceLabel } from "@/components/parts/PartCard";

import JsonLd from "@/components/seo/JsonLd";

export const revalidate = 60;

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const part = await prisma.sparePart.findUnique({ where: { slug } });

  const title = `${part?.title ?? "قطعه یدکی"} | خرید با ضمانت | آریا ماشین جم`;
  const desc = part?.description?.slice(0, 160) ?? "خرید قطعه یدکی اصلی با ضمانت اصالت";
  const url = `${SITE_URL}/parts/${slug}`;

  return {
    title,
    description: desc,
    alternates: { canonical: url },
    openGraph: {
      title,
      description: desc,
      url,
      type: "website",
      locale: "fa_IR",
      siteName: SITE_NAME,
    },
  };
}

export default async function PartDetailPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;

  const part = await prisma.sparePart.findUnique({
    where: { slug },
    include: {
      brand: true,
      category: true,
      price: true,
      images: { orderBy: { sortOrder: "asc" } },
      documents: true,
    },
  });

  if (!part || part.status !== "PUBLISHED" || !part.active) notFound();

  const related = await prisma.sparePart.findMany({
    where: { status: "PUBLISHED", active: true, id: { not: part.id }, categoryId: part.categoryId },
    take: 4,
    include: { brand: true, price: true, images: { take: 1, orderBy: { sortOrder: "asc" } } },
  });

  const mainImage = part.images?.[0]?.url ?? "/images/machines/default.svg";

  /* ✅ قیمت ایمن */
  const priceValue = part.price?.price != null ? Number(part.price.price) : null;
  const stock = part.price?.stock ?? 0;
  const hasInstallment = !!part.price?.installment;
  const hasStock = stock > 0;

  return (
        <div className="mx-auto max-w-[1200px] px-5 pt-32 pb-16 lg:px-8">
      {/* ✅ سئوی Product */}
      <JsonLd
        data={{
          "@context": "https://schema.org",
          "@type": "Product",
          name: part.title,
          description: part.description,
          sku: part.sku,
          image: [`${SITE_URL}${mainImage}`],
          brand: { "@type": "Brand", name: part.brand?.name ?? "ARIA MJ" },
          category: part.category?.name,
          offers: priceValue != null
            ? {
                "@type": "Offer",
                price: priceValue,
                priceCurrency: "IRR",
                availability: hasStock ? "https://schema.org/InStock" : "https://schema.org/OutOfStock",
                url: `${SITE_URL}/parts/${part.slug}`,
              }
            : undefined,
        }}
      />

      {/* مسیر */}
      <div className="mb-8 flex items-center gap-2 text-[11px] text-white/40">
        <Link href="/" className="hover:text-[#F58220]">خانه</Link>
        <span>‹</span>
        <Link href="/parts" className="hover:text-[#F58220]">قطعات یدکی</Link>
        <span>‹</span>
        <span className="font-bold text-white/70">{part.title}</span>
      </div>

      <div className="grid gap-10 lg:grid-cols-2">
        {/* گالری */}
        <div>
          <div className="flex aspect-square items-center justify-center rounded-3xl border border-white/10 bg-white/[0.03] p-10">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={mainImage} alt={part.title} className="max-h-full max-w-full object-contain" />
          </div>
          {part.images.length > 1 && (
            <div className="mt-4 flex gap-3 overflow-x-auto">
              {part.images.map((img: any) => (
                /* eslint-disable-next-line @next/next/no-img-element */
                <img key={img.id} src={img.url} alt="" className="h-20 w-20 shrink-0 rounded-xl border border-white/10 bg-white/[0.03] object-contain p-2" />
              ))}
            </div>
          )}
        </div>

        {/* اطلاعات */}
        <div className="space-y-6">
          <div>
            {part.category && (
              <span className="rounded-full bg-[#F58220] px-3 py-1 text-[10px] font-black text-white">
                {part.category.name}
              </span>
            )}
            <h1 className="mt-3 text-2xl font-black leading-[1.6] text-white lg:text-3xl">{part.title}</h1>
          </div>

          {/* مشخصات */}
          <div className="grid grid-cols-2 gap-3">
            <SpecBox label="برند" value={part.brand?.name ?? "—"} />
            <SpecBox label="دسته‌بندی" value={part.category?.name ?? "—"} />
            <SpecBox label="شمارهٔ OEM" value={part.oemNumber ?? "—"} ltr />
            <SpecBox label="SKU" value={part.sku ?? "—"} ltr />
          </div>

          {/* قیمت */}
          <div className="rounded-2xl border border-[#F58220]/30 bg-[#F58220]/5 p-6">
            <div className="flex items-end justify-between">
              <div>
                <div className="text-[11px] text-white/50">قیمت</div>
                <div className="mt-1 text-2xl font-black text-[#F58220]">{priceLabel(part.price)}</div>
              </div>
              {hasInstallment && (
                <span className="rounded-full bg-white/10 px-3 py-1 text-[10px] font-bold text-white/70">
                  امکان خرید اقساطی
                </span>
              )}
            </div>
            <div className="mt-4 flex items-center gap-2 text-[11px] text-white/60">
              {hasStock ? (
                <><BadgeCheck className="h-4 w-4 text-green-400" /> موجود در انبار — {stock.toLocaleString("fa-IR")} عدد</>
              ) : (
                <><Package className="h-4 w-4 text-white/40" /> فعلاً ناموجود — درخواست اطلاع‌گذاری ثبت کنید</>
              )}
            </div>
          </div>

          {/* اعتماد */}
          <div className="grid grid-cols-3 gap-3 text-center">
            <TrustBox icon={<ShieldCheck className="h-5 w-5" />} label="ضمانت اصالت" />
            <TrustBox icon={<Truck className="h-5 w-5" />} label="ارسال سراسری" />
            <TrustBox icon={<BadgeCheck className="h-5 w-5" />} label="۷ روز مهلت بازگشت" />
          </div>

          <div className="flex gap-3">
            <a
              href="tel:02188106385"
              className="flex-1 rounded-xl bg-[#F58220] py-3.5 text-center text-sm font-black text-white transition hover:bg-[#d96f15]"
            >
              استعلام و خرید تلفنی
            </a>
            <Link
              href="/contact-us"
              className="flex-1 rounded-xl border border-white/10 bg-white/5 py-3.5 text-center text-sm font-bold text-white transition hover:border-[#F58220]/40"
            >
              ارسال درخواست
            </Link>
          </div>
        </div>
      </div>

      {/* توضیحات */}
      {part.description && (
        <div className="mt-14 rounded-3xl border border-white/10 bg-[#141414] p-8">
          <h2 className="text-lg font-black text-white">توضیحات قطعه</h2>
          <p className="mt-4 whitespace-pre-line text-sm leading-8 text-white/60">{part.description}</p>
        </div>
      )}

      {/* اسناد */}
      {part.documents.length > 0 && (
        <div className="mt-8 rounded-3xl border border-white/10 bg-[#141414] p-8">
          <h2 className="flex items-center gap-2 text-lg font-black text-white">
            <FileText className="h-5 w-5 text-[#F58220]" />
            اسناد و کاتالوگ
          </h2>
          <div className="mt-4 flex flex-wrap gap-3">
            {part.documents.map((d: any) => (
              <a
                key={d.id}
                href={d.fileUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="rounded-xl border border-white/10 bg-white/5 px-4 py-2 text-xs font-bold text-white/70 transition hover:border-[#F58220]/40 hover:text-[#F58220]"
              >
                {d.title}
              </a>
            ))}
          </div>
        </div>
      )}

      {/* مرتبط */}
      {related.length > 0 && (
        <div className="mt-16">
          <h2 className="mb-6 text-xl font-black text-white">قطعات مشابه</h2>
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {related.map((r: any) => (
              <PartCard key={r.id} part={r} />
            ))}
          </div>
        </div>
      )}

      <Link
        href="/parts"
        className="mt-12 inline-flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-6 py-3 text-sm font-bold text-white transition hover:border-[#F58220]/40"
      >
        <ArrowRight className="h-4 w-4" />
        همهٔ قطعات
      </Link>
    </div>
  );
}

function SpecBox({ label, value, ltr }: { label: string; value: string; ltr?: boolean }) {
  return (
    <div className="rounded-xl border border-white/10 bg-white/[0.03] p-4">
      <div className="text-[10px] text-white/40">{label}</div>
      <div className="mt-1 text-sm font-bold text-white" dir={ltr ? "ltr" : undefined}>
        {value}
      </div>
    </div>
  );
}

function TrustBox({ icon, label }: { icon: React.ReactNode; label: string }) {
  return (
    <div className="flex flex-col items-center gap-2 rounded-xl border border-white/10 bg-white/[0.03] p-4 text-[#F58220]">
      {icon}
      <span className="text-[10px] font-bold text-white/60">{label}</span>
    </div>
  );
}