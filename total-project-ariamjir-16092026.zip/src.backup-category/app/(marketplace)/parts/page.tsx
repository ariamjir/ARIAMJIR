import type { Metadata } from "next";

import PartsListClient from "@/components/parts/PartsListClient";

import JsonLd from "@/components/seo/JsonLd";

import { SITE_URL, SITE_NAME } from "@/lib/seo";

export const metadata: Metadata = {
  title: "قطعات یدکی ماشین‌آلات سنگین | خرید با ضمانت | آریا ماشین جم",
  description:
    "خرید آنلاین قطعات یدکی اصلی و اورجینال بیل مکانیکی، لودر و بولدوزر — فیلتر، پمپ هیدرولیک، قطعات موتور و زیربندی با ضمانت اصالت و ارسال سراسری.",
  keywords: "قطعات یدکی, قطعات بیل مکانیکی, پمپ هیدرولیک, فیلتر, زیربندی, کوماتسو, کاترپیلار",
  alternates: { canonical: `${SITE_URL}/parts` },
  openGraph: {
    title: "بازار قطعات یدکی ماشین‌آلات سنگین | آریا ماشین جم",
    description: "قطعات اصلی با ضمانت اصالت و ارسال سراسری",
    url: `${SITE_URL}/parts`,
    type: "website",
    locale: "fa_IR",
    siteName: SITE_NAME,
  },
};

export const revalidate = 300;

export default function PartsPage() {
  return (
    <>
      <JsonLd
        data={{
          "@context": "https://schema.org",
          "@type": "CollectionPage",
          name: "بازار قطعات یدکی ماشین‌آلات سنگین",
          url: `${SITE_URL}/parts`,
          inLanguage: "fa",
        }}
      />
      <PartsListClient />
    </>
  );
}