import type { Metadata } from "next";

import Link from "next/link";

import { prisma } from "@/lib/prisma";

import JsonLd from "@/components/seo/JsonLd";

import { SITE_URL, SITE_NAME } from "@/lib/seo";

export const revalidate = 600;

export const metadata: Metadata = {
  title: "برندهای ماشین‌آلات سنگین | کوماتسو، کاترپیلار، ولوو | آریا ماشین جم",
  description:
    "فهرست کامل برندهای ماشین‌آلات سنگین، معدنی و راه‌سازی در آریا ماشین جم — کوماتسو، کاترپیلار، ولوو، هیتاچی و ده‌ها برند معتبر جهانی با قیمت و مشخصات فنی.",
  alternates: { canonical: `${SITE_URL}/brands` },
  openGraph: {
    title: "برندهای ماشین‌آلات سنگین | آریا ماشین جم",
    description: "مرجع برندهای معتبر ماشین‌آلات سنگین جهان",
    url: `${SITE_URL}/brands`,
    type: "website",
    locale: "fa_IR",
    siteName: SITE_NAME,
  },
};

export default async function BrandsIndexPage() {
  const brands = await prisma.brand.findMany({
    orderBy: { name: "asc" },
    include: { _count: { select: { machines: true } } },
  });

  return (
    <div className="mx-auto max-w-[1440px] px-5 py-16 lg:px-10">
      <JsonLd
        data={{
          "@context": "https://schema.org",
          "@type": "CollectionPage",
          name: "برندهای ماشین‌آلات سنگین",
          url: `${SITE_URL}/brands`,
          inLanguage: "fa",
        }}
      />

      <div className="mb-10 text-center">
        <div className="text-xs font-black tracking-[0.3em] text-[#F58220]">TOP BRANDS</div>
        <h1 className="mt-3 text-3xl font-black text-white lg:text-4xl">برندهای ماشین‌آلات سنگین</h1>
        <p className="mt-3 text-sm text-white/50">
          {brands.length.toLocaleString("fa-IR")} برند معتبر جهانی — عرضهٔ مستقیم با ضمانت اصالت
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6">
        {brands.map((b: any) => (
          <Link
            key={b.id}
            href={`/brands/${b.slug}`}
            className="group flex flex-col items-center gap-3 rounded-2xl border border-white/10 bg-[#141414] p-5 transition hover:border-[#F58220]/40 hover:bg-[#F58220]/5"
          >
            {b.logo ? (
              /* eslint-disable-next-line @next/next/no-img-element */
              <img src={b.logo} alt={`لوگو ${b.name}`} className="h-14 w-full object-contain opacity-80 transition group-hover:opacity-100" />
            ) : (
              <span className="flex h-14 w-14 items-center justify-center rounded-xl bg-white/5 text-2xl font-black text-white/40">
                {b.name?.[0]}
              </span>
            )}
            <span className="text-sm font-black text-white transition group-hover:text-[#F58220]">{b.name}</span>
            <span className="text-[10px] text-white/40">
              {(b._count?.machines ?? 0).toLocaleString("fa-IR")} دستگاه فعال
            </span>
          </Link>
        ))}
      </div>
    </div>
  );
}