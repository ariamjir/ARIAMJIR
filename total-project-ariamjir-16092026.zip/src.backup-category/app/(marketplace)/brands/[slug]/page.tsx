import type { Metadata } from "next";

import Link from "next/link";

import { notFound } from "next/navigation";

import { ArrowRight } from "lucide-react";

import { prisma } from "@/lib/prisma";

import { getMachines } from "@/lib/actions/machine";

import MachineList from "@/components/machine/list/MachineList";

import JsonLd from "@/components/seo/JsonLd";

import { SITE_URL, SITE_NAME } from "@/lib/seo";

export const revalidate = 300;

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const brand = await prisma.brand.findUnique({ where: { slug } });

  const title = `ماشین‌آلات ${brand?.name ?? ""} | خرید، قیمت و مشخصات | آریا ماشین جم`;
  const desc = `فهرست کامل ماشین‌آلات ${brand?.name ?? ""} در آریا ماشین جم — بیل مکانیکی، لودر، بولدوزر و سایر دستگاه‌های ${brand?.name ?? ""} با قیمت روز و ضمانت اصالت.`;
  const url = `${SITE_URL}/brands/${slug}`;

  return {
    title,
    description: desc,
    alternates: { canonical: url },
    openGraph: {
      title,
      description: desc,
      url,
      type: "website",
      locale: "fa_IR",
      siteName: SITE_NAME,
      images: brand?.logo ? [brand.logo] : [],
    },
  };
}

export default async function BrandLandingPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;

  const brand = await prisma.brand.findUnique({ where: { slug } });
  if (!brand) notFound();

  const machines = await getMachines({ page: 1, brand: slug });

  return (
    <div className="mx-auto max-w-[1440px] space-y-8 px-5 py-16 lg:px-10">
      <JsonLd
        data={{
          "@context": "https://schema.org",
          "@type": "Brand",
          name: brand.name,
          url: `${SITE_URL}/brands/${brand.slug}`,
          logo: brand.logo ? `${SITE_URL}${brand.logo.startsWith("http") ? "" : brand.logo}` : undefined,
        }}
      />

      {/* سربرگ برند */}
      <div className="flex flex-wrap items-center justify-between gap-6 rounded-3xl border border-white/10 bg-[#141414] p-8">
        <div className="flex items-center gap-5">
          {brand.logo ? (
            /* eslint-disable-next-line @next/next/no-img-element */
            <img src={brand.logo} alt={`لوگو ${brand.name}`} className="h-20 w-20 rounded-2xl border border-white/10 bg-white object-contain p-2" />
          ) : (
            <span className="flex h-20 w-20 items-center justify-center rounded-2xl bg-white/5 text-3xl font-black text-white/40">
              {brand.name?.[0]}
            </span>
          )}
          <div>
            <div className="text-xs font-black tracking-[0.25em] text-[#F58220]">BRAND</div>
            <h1 className="mt-1 text-2xl font-black text-white lg:text-3xl">{brand.name}</h1>
            <p className="mt-2 text-xs text-white/45">
              {(machines.pagination?.total ?? machines.items?.length ?? 0).toLocaleString("fa-IR")} دستگاه فعال در آریا ماشین جم
            </p>
          </div>
        </div>

        <Link
          href="/brands"
          className="inline-flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-5 py-2.5 text-xs font-bold text-white transition hover:border-[#F58220]/40 hover:text-[#F58220]"
        >
          <ArrowRight className="h-4 w-4" />
          همهٔ برندها
        </Link>
      </div>

      {/* ماشین‌آلات برند */}
      <MachineList machines={machines.items} pagination={machines.pagination} />
    </div>
  );
}