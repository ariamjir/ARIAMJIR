import type { Metadata } from "next";

import MachineList from "@/components/machine/list/MachineList";
import MachineFilters from "@/components/machine/filter/MachineFilters";
import SearchBar from "@/components/machine/filter/SearchBar";

import { getMachines } from "@/lib/actions/machine";

/* ============================================================
   METADATA
============================================================ */

export const metadata: Metadata = {
  title: "ماشین آلات | آریا ماشین جم",
  description:
    "بازار تخصصی ماشین آلات راهسازی، معدنی و عمرانی",
};

/* ============================================================
   TYPES
============================================================ */

interface SearchParams {
  page?: string;
  search?: string;
  brand?: string;
  category?: string;
}

interface Props {
  searchParams: Promise<SearchParams>;
}

/* ============================================================
   PAGE
============================================================ */

export default async function MachinesPage({
  searchParams,
}: Props) {
  const params = await searchParams;

  const parsedPage = Number(params.page ?? "1");

  const page =
    Number.isFinite(parsedPage) && parsedPage > 0
      ? Math.floor(parsedPage)
      : 1;

  const machines = await getMachines({
    page,
    search: params.search,
    brand: params.brand,
    category: params.category,
  });

  return (
    <div className="container mx-auto space-y-8 py-8">
      <SearchBar />

      <div className="grid grid-cols-12 gap-8">
        <aside className="col-span-12 lg:col-span-3">
          <MachineFilters />
        </aside>

        <section className="col-span-12 lg:col-span-9">
          <MachineList
            machines={machines.items}
            pagination={machines.pagination}
          />
        </section>
      </div>
    </div>
  );
}