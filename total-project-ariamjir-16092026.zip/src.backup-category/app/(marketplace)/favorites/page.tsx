import { Metadata } from "next";

import FavoritesClientPage from "@/modules/favorites/components/FavoritesClientPage";

export const metadata: Metadata = {

title: "علاقه‌مندی‌ها | ARIA MJ",

description: "لیست ماشین‌آلات ذخیره شده",

};

export default function FavoritesPage(){

return(

<div className="container mx-auto py-8">

<div className="mb-8">

<h1 className="text-3xl font-bold">

علاقه‌مندی‌ها

</h1>

<p className="mt-2 text-gray-500">

ماشین‌هایی که ذخیره کرده‌اید.

</p>

</div>

<FavoritesClientPage/>

</div>

);

}

