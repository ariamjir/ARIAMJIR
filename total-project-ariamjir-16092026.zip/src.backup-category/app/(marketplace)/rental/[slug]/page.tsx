import type { Metadata } from "next";

import Link from "next/link";

import { notFound } from "next/navigation";

import { ArrowRight, Truck, User, Fuel, CalendarDays } from "lucide-react";

import { prisma } from "@/lib/prisma";

import { SITE_URL, SITE_NAME } from "@/lib/seo";

import RentalCard, { toman } from "@/components/rental/RentalCard";

import JsonLd from "@/components/seo/JsonLd";

export const revalidate = 60;

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const listing = await prisma.rentalListing.findFirst({
    where: { machine: { slug } },
    include: { machine: true },
  });

  const title = `اجارهٔ ${listing?.machine?.title ?? "ماشین‌آلات سنگین"} | آریا ماشین جم`;
  const desc = `اجارهٔ روزانه ${listing?.machine?.title ?? ""} با قیمت ${
    listing?.dailyPrice ? Number(listing.dailyPrice).toLocaleString("fa-IR") + " تومان" : "توافقی"
  } — ضمانت سلامت فنی و اعزام سراسری.`;
  const url = `${SITE_URL}/rental/${slug}`;

  return {
    title,
    description: desc,
    alternates: { canonical: url },
    openGraph: { title, description: desc, url, type: "website", locale: "fa_IR", siteName: SITE_NAME },
  };
}

export default async function RentalDetailPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;

  const listing = await prisma.rentalListing.findFirst({
    where: { machine: { slug }, status: { in: ["APPROVED", "PUBLISHED"] } },
    include: {
      machine: {
        include: {
          brand: true,
          category: true,
          specification: true,
          images: { orderBy: { sortOrder: "asc" } },
        },
      },
    },
  });

  if (!listing) notFound();

  const m = listing.machine;
  const year = m.specification?.manufactureYear ?? null;
  const mainImage = m.images?.[0]?.url ?? "/images/machines/default.svg";

  const related = await prisma.rentalListing.findMany({
    where: {
      status: { in: ["APPROVED", "PUBLISHED"] },
      id: { not: listing.id },
      machine: { categoryId: m.categoryId },
    },
    take: 4,
    include: { machine: { include: { brand: true, specification: true, images: { take: 1 } } } },
  });

  return (
    <div className="mx-auto max-w-[1200px] px-5 pt-32 pb-16 lg:px-8">
      <JsonLd
        data={{
          "@context": "https://schema.org",
          "@type": "Service",
          name: `اجارهٔ ${m.title}`,
          serviceType: "اجاره ماشین‌آلات سنگین",
          areaServed: "IR",
          provider: { "@type": "Organization", name: SITE_NAME, url: SITE_URL },
          offers: listing.dailyPrice
            ? { "@type": "Offer", price: Number(listing.dailyPrice), priceCurrency: "IRR", description: "روزانه" }
            : undefined,
        }}
      />

      <div className="mb-8 flex items-center gap-2 text-[11px] text-white/40">
        <Link href="/" className="hover:text-[#F58220]">خانه</Link>
        <span>‹</span>
        <Link href="/rental" className="hover:text-[#F58220]">اجاره ماشین‌آلات</Link>
        <span>‹</span>
        <span className="font-bold text-white/70">{m.title}</span>
      </div>

      <div className="grid gap-10 lg:grid-cols-2">
        <div className="flex aspect-[4/3] items-center justify-center overflow-hidden rounded-3xl border border-white/10 bg-white/[0.03]">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={mainImage} alt={m.title} className="h-full w-full object-cover" />
        </div>

        <div className="space-y-6">
          <div>
            {m.category && (
              <span className="rounded-full bg-[#F58220] px-3 py-1 text-[10px] font-black text-white">
                {m.category.name}
              </span>
            )}
            <h1 className="mt-3 text-2xl font-black leading-[1.6] text-white lg:text-3xl">اجارهٔ {m.title}</h1>
            <div className="mt-2 text-xs text-white/40">
              {m.brand?.name ?? ""} {year ? `· مدل ${year}` : ""}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <PriceBox label="روزانه" value={toman(listing.dailyPrice)} highlight />
            <PriceBox label="هفتگی" value={toman(listing.weeklyPrice)} />
            <PriceBox label="ماهانه" value={toman(listing.monthlyPrice)} />
            <PriceBox label="ودیعه" value={toman(listing.deposit)} />
          </div>

          <div className="grid grid-cols-3 gap-3 text-center">
            <IncBox on={listing.operatorIncluded} icon={<User className="h-5 w-5" />} label="اپراتور" />
            <IncBox on={listing.fuelIncluded} icon={<Fuel className="h-5 w-5" />} label="سوخت" />
            <IncBox on={listing.transportationIncluded} icon={<Truck className="h-5 w-5" />} label="حمل‌ونقل" />
          </div>

          <div className="flex items-center gap-2 rounded-xl border border-white/10 bg-white/[0.03] p-4 text-[11px] text-white/60">
            <CalendarDays className="h-4 w-4 text-[#F58220]" />
            حداقل مدت اجاره: {listing.minimumRentalDays} روز
            {listing.availableFrom && (
              <span className="mr-auto">
                در دسترس از {new Date(listing.availableFrom).toLocaleDateString("fa-IR")}
              </span>
            )}
          </div>

          <div className="flex gap-3">
            <a
              href="tel:02188106385"
              className="flex-1 rounded-xl bg-[#F58220] py-3.5 text-center text-sm font-black text-white transition hover:bg-[#d96f15]"
            >
              رزرو تلفنی
            </a>
            <Link
              href={`/machines/${m.slug}`}
              className="flex-1 rounded-xl border border-white/10 bg-white/5 py-3.5 text-center text-sm font-bold text-white transition hover:border-[#F58220]/40"
            >
              مشخصات کامل دستگاه
            </Link>
          </div>
        </div>
      </div>

      {related.length > 0 && (
        <div className="mt-16">
          <h2 className="mb-6 text-xl font-black text-white">دستگاه‌های مشابه برای اجاره</h2>
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {related.map((r: any) => (
              <RentalCard key={r.id} r={r} />
            ))}
          </div>
        </div>
      )}

      <Link
        href="/rental"
        className="mt-12 inline-flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-6 py-3 text-sm font-bold text-white transition hover:border-[#F58220]/40"
      >
        <ArrowRight className="h-4 w-4" />
        همهٔ دستگاه‌های اجاره‌ای
      </Link>
    </div>
  );
}

function PriceBox({ label, value, highlight }: { label: string; value: string; highlight?: boolean }) {
  return (
    <div
      className={`rounded-xl border p-4 ${
        highlight ? "border-[#F58220]/40 bg-[#F58220]/10" : "border-white/10 bg-white/[0.03]"
      }`}
    >
      <div className="text-[10px] text-white/40">{label}</div>
      <div className={`mt-1 text-sm font-black ${highlight ? "text-[#F58220]" : "text-white"}`}>{value}</div>
    </div>
  );
}

function IncBox({ on, icon, label }: { on: boolean; icon: React.ReactNode; label: string }) {
  return (
    <div
      className={`flex flex-col items-center gap-2 rounded-xl border p-4 ${
        on ? "border-green-400/30 bg-green-400/5 text-green-400" : "border-white/10 bg-white/[0.03] text-white/30"
      }`}
    >
      {icon}
      <span className="text-[10px] font-bold">{on ? `${label} دارد` : `بدون ${label}`}</span>
    </div>
  );
}