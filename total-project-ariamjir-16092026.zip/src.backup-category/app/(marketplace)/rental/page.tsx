import type { Metadata } from "next";

import RentalListClient from "@/components/rental/RentalListClient";

import JsonLd from "@/components/seo/JsonLd";

import { SITE_URL, SITE_NAME } from "@/lib/seo";

export const metadata: Metadata = {
  title: "اجاره ماشین‌آلات سنگین | لودر، بیل، جرثقیل | آریا ماشین جم",
  description:
    "اجارهٔ روزانه و ماهانهٔ ماشین‌آلات سنگین راه‌سازی و معدنی با یا بدون اپراتور — لودر، بیل مکانیکی، جرثقیل و بولدوزر با ضمانت و اعزام سراسری.",
  alternates: { canonical: `${SITE_URL}/rental` },
  openGraph: {
    title: "اجارهٔ ماشین‌آلات سنگین | آریا ماشین جم",
    description: "ناوگان اجاره‌ای آمادهٔ اعزام به سراسر کشور",
    url: `${SITE_URL}/rental`,
    type: "website",
    locale: "fa_IR",
    siteName: SITE_NAME,
  },
};

export const revalidate = 300;

export default function RentalPage() {
  return (
    <>
      <JsonLd
        data={{
          "@context": "https://schema.org",
          "@type": "CollectionPage",
          name: "اجاره ماشین‌آلات سنگین",
          url: `${SITE_URL}/rental`,
          inLanguage: "fa",
        }}
      />
      <RentalListClient />
    </>
  );
}