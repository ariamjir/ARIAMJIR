"use client";

import { useEffect, useState } from "react";
import type { SiteSettings } from "@/lib/site-settings";

let cachedSettings: SiteSettings | null = null;
let cacheTime = 0;
const CACHE_TTL = 60_000; // 60 seconds

export function useSiteSettings() {
  const [settings, setSettings] = useState<SiteSettings | null>(
    cachedSettings
  );
  const [loading, setLoading] = useState(!cachedSettings);

  useEffect(() => {
    if (cachedSettings && Date.now() - cacheTime < CACHE_TTL) {
      setSettings(cachedSettings);
      setLoading(false);
      return;
    }

    let cancelled = false;
    setLoading(true);

    fetch("/api/site-settings")
      .then((r) => r.json())
      .then((json) => {
        if (cancelled) return;
        if (json.success && json.data) {
          cachedSettings = json.data;
          cacheTime = Date.now();
          setSettings(json.data);
        }
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, []);

  return { settings, loading };
}