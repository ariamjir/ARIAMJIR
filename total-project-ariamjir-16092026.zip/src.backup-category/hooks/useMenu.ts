"use client";

import { useCallback, useEffect, useState } from "react";

export interface MenuItem {
  id: string;
  title: string;
  href: string | null;

  parentId: string | null;

  type: string;

  icon: string | null;

  categoryId: string | null;

  sortOrder: number;

  active: boolean;

  showDesktop: boolean;
  showMobile: boolean;

  openInNewTab: boolean;

  megaMenu: boolean;

  category?: {
    id: string;
    name: string;
    slug: string;
    icon: string | null;
    image: string | null;
    domain: string;
    active: boolean;
    showInMenu: boolean;
  } | null;
}

export function useMenu() {
  const [items, setItems] = useState<MenuItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      setLoading(true);

      const response = await fetch("/api/menu", {
        cache: "no-store",
      });

      if (!response.ok) {
        throw new Error("Failed to load menu");
      }

      const data = await response.json();

      setItems(Array.isArray(data) ? data : []);
      setError(null);
    } catch (error) {
      console.error("[useMenu]", error);

      setItems([]);
      setError(
        error instanceof Error
          ? error.message
          : "Failed to load menu",
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  return {
    items,
    loading,
    error,
    reload: load,
  };
}