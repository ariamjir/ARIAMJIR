export const menu = [
  {
    title: "خانه",
    href: "/",
  },
  {
    title: "ماشین آلات",
    href: "/machines",
  },
  {
    title: "قطعات",
    href: "/parts",
  },
  {
    title: "خدمات فنی",
    href: "/services",
  },
  {
    title: "ثبت آگهی",
    href: "/ads",
  },
  {
    title: "فروشگاه",
    href: "/shop",
  },
  {
    title: "اخبار",
    href: "/news",
  },
  {
    title: "آکادمی",
    href: "/academy",
  },
];