export type AttributeType =
  | "text"
  | "textarea"
  | "number"
  | "select"
  | "checkbox"
  | "radio"
  | "date"
  | "boolean";

export interface ListingAttribute {

  key: string;

  label: string;

  type: AttributeType;

  required?: boolean;

  unit?: string;

  placeholder?: string;

  options?: {
    label: string;
    value: string;
  }[];

}

export interface MachineAttributeGroup {

  machineId: string;

  title: string;

  attributes: ListingAttribute[];

}

export const MACHINE_ATTRIBUTES: MachineAttributeGroup[] = [

  //==================================================
  // Loader
  //==================================================

  {

    machineId: "loader",

    title: "مشخصات لودر",

    attributes: [

      {
        key: "manufactureYear",
        label: "سال ساخت",
        type: "number",
        required: true,
      },

      {
        key: "condition",
        label: "وضعیت",
        type: "select",
        required: true,
        options: [
          {
            value: "new",
            label: "نو",
          },
          {
            value: "used",
            label: "کارکرده",
          },
        ],
      },

      {
        key: "brand",
        label: "برند",
        type: "text",
        required: true,
      },

      {
        key: "model",
        label: "مدل",
        type: "text",
        required: true,
      },

      {
        key: "engine",
        label: "موتور",
        type: "text",
      },

      {
        key: "enginePower",
        label: "قدرت موتور",
        type: "number",
        unit: "HP",
      },

      {
        key: "bucketCapacity",
        label: "ظرفیت باکت",
        type: "number",
        unit: "m³",
      },

      {
        key: "operatingWeight",
        label: "وزن عملیاتی",
        type: "number",
        unit: "Kg",
      },

      {
        key: "workingHours",
        label: "ساعات کارکرد",
        type: "number",
        unit: "Hour",
      },

      {
        key: "fuelType",
        label: "نوع سوخت",
        type: "select",
        options: [
          {
            value: "diesel",
            label: "دیزل",
          },
          {
            value: "electric",
            label: "برقی",
          },
          {
            value: "hybrid",
            label: "هیبرید",
          },
        ],
      },

      {
        key: "transmission",
        label: "گیربکس",
        type: "select",
        options: [
          {
            value: "manual",
            label: "دستی",
          },
          {
            value: "automatic",
            label: "اتومات",
          },
        ],
      },

      {
        key: "driveType",
        label: "سیستم حرکت",
        type: "select",
        options: [
          {
            value: "wheel",
            label: "چرخ لاستیکی",
          },
          {
            value: "crawler",
            label: "زنجیری",
          },
        ],
      },

      {
        key: "color",
        label: "رنگ",
        type: "text",
      },
            {
        key: "serialNumber",
        label: "شماره سریال",
        type: "text",
      },

      {
        key: "chassisNumber",
        label: "شماره شاسی",
        type: "text",
      },

      {
        key: "engineSerial",
        label: "شماره موتور",
        type: "text",
      },

      {
        key: "tireCondition",
        label: "وضعیت لاستیک",
        type: "select",
        options: [
          {
            value: "100",
            label: "۱۰۰٪"
          },
          {
            value: "80",
            label: "۸۰٪"
          },
          {
            value: "60",
            label: "۶۰٪"
          },
          {
            value: "40",
            label: "۴۰٪"
          },
          {
            value: "needsReplace",
            label: "نیاز به تعویض"
          },
        ],
      },

      {
        key: "hydraulicSystem",
        label: "وضعیت سیستم هیدرولیک",
        type: "select",
        options: [
          {
            value: "excellent",
            label: "عالی"
          },
          {
            value: "good",
            label: "خوب"
          },
          {
            value: "average",
            label: "متوسط"
          },
          {
            value: "needsRepair",
            label: "نیازمند تعمیر"
          },
        ],
      },

      {
        key: "gearboxCondition",
        label: "وضعیت گیربکس",
        type: "select",
        options: [
          {
            value: "excellent",
            label: "عالی"
          },
          {
            value: "good",
            label: "خوب"
          },
          {
            value: "average",
            label: "متوسط"
          },
          {
            value: "needsRepair",
            label: "نیازمند تعمیر"
          },
        ],
      },

      {
        key: "paintCondition",
        label: "وضعیت رنگ",
        type: "select",
        options: [
          {
            value: "factory",
            label: "فابریک"
          },
          {
            value: "repaint",
            label: "رنگ شده"
          },
          {
            value: "partial",
            label: "قسمتی رنگ شده"
          },
        ],
      },

      {
        key: "descriptionTechnical",
        label: "توضیحات فنی",
        type: "textarea",
        placeholder:
          "هرگونه توضیح در خصوص وضعیت موتور، تعمیرات، سرویس‌ها، قطعات تعویض شده و ...",
      },

    ],

  },

  //==================================================
  // Excavator
  //==================================================

  {

    machineId: "excavator",

    title: "مشخصات بیل مکانیکی",

    attributes: [

      {
        key: "manufactureYear",
        label: "سال ساخت",
        type: "number",
        required: true,
      },

      {
        key: "condition",
        label: "وضعیت",
        type: "select",
        required: true,
        options: [
          {
            value: "new",
            label: "نو",
          },
          {
            value: "used",
            label: "کارکرده",
          },
        ],
      },

      {
        key: "engine",
        label: "موتور",
        type: "text",
      },

      {
        key: "enginePower",
        label: "قدرت موتور",
        type: "number",
        unit: "HP",
      },

      {
        key: "bucketCapacity",
        label: "ظرفیت باکت",
        type: "number",
        unit: "m³",
      },

      {
        key: "boomLength",
        label: "طول بوم",
        type: "number",
        unit: "mm",
      },

      {
        key: "armLength",
        label: "طول بازو",
        type: "number",
        unit: "mm",
      },

      {
        key: "digDepth",
        label: "عمق حفاری",
        type: "number",
        unit: "mm",
      },

      {
        key: "operatingWeight",
        label: "وزن عملیاتی",
        type: "number",
        unit: "Kg",
      },

      {
        key: "workingHours",
        label: "ساعات کارکرد",
        type: "number",
      },

      {
        key: "crawlerCondition",
        label: "وضعیت زنجیر",
        type: "select",
        options: [
          {
            value: "excellent",
            label: "عالی",
          },
          {
            value: "good",
            label: "خوب",
          },
          {
            value: "average",
            label: "متوسط",
          },
          {
            value: "needsReplace",
            label: "نیازمند تعویض",
          },
        ],
      },
            {
        key: "hammerLine",
        label: "خط پیکور",
        type: "boolean",
      },

      {
        key: "quickCoupler",
        label: "کوئیک کوپلر",
        type: "boolean",
      },

      {
        key: "hydraulicSystem",
        label: "وضعیت سیستم هیدرولیک",
        type: "select",
        options: [
          { value: "excellent", label: "عالی" },
          { value: "good", label: "خوب" },
          { value: "average", label: "متوسط" },
          { value: "needsRepair", label: "نیازمند تعمیر" },
        ],
      },

      {
        key: "technicalDescription",
        label: "توضیحات فنی",
        type: "textarea",
      },

    ],

  },

  //==================================================
  // Forklift
  //==================================================

  {

    machineId: "forklift",

    title: "مشخصات لیفتراک",

    attributes: [

      {
        key: "manufactureYear",
        label: "سال ساخت",
        type: "number",
      },

      {
        key: "capacity",
        label: "ظرفیت بار",
        type: "number",
        unit: "Kg",
      },

      {
        key: "liftingHeight",
        label: "ارتفاع بالابری",
        type: "number",
        unit: "mm",
      },

      {
        key: "mastType",
        label: "نوع دکل",
        type: "text",
      },

      {
        key: "fuelType",
        label: "نوع سوخت",
        type: "select",
        options: [
          { value: "diesel", label: "دیزل" },
          { value: "gasoline", label: "بنزین" },
          { value: "gas", label: "گاز" },
          { value: "electric", label: "برقی" },
        ],
      },

      {
        key: "workingHours",
        label: "ساعات کار",
        type: "number",
      },

      {
        key: "technicalDescription",
        label: "توضیحات",
        type: "textarea",
      },

    ],

  },

  //==================================================
  // Crane
  //==================================================

  {

    machineId: "crane",

    title: "مشخصات جرثقیل",

    attributes: [

      {
        key: "manufactureYear",
        label: "سال ساخت",
        type: "number",
      },

      {
        key: "liftingCapacity",
        label: "ظرفیت",
        type: "number",
        unit: "Ton",
      },

      {
        key: "boomLength",
        label: "طول بوم",
        type: "number",
        unit: "m",
      },

      {
        key: "workingRadius",
        label: "شعاع کاری",
        type: "number",
        unit: "m",
      },

      {
        key: "workingHours",
        label: "کارکرد",
        type: "number",
      },

      {
        key: "technicalDescription",
        label: "توضیحات",
        type: "textarea",
      },

    ],

  },

  //==================================================
  // Shared Machines
  //==================================================

  {

    machineId: "generic",

    title: "مشخصات عمومی",

    attributes: [

      {
        key: "manufactureYear",
        label: "سال ساخت",
        type: "number",
      },

      {
        key: "condition",
        label: "وضعیت",
        type: "select",
        options: [
          {
            value: "new",
            label: "نو",
          },
          {
            value: "used",
            label: "کارکرده",
          },
        ],
      },

      {
        key: "workingHours",
        label: "ساعات کارکرد",
        type: "number",
      },

      {
        key: "engine",
        label: "موتور",
        type: "text",
      },

      {
        key: "enginePower",
        label: "قدرت موتور",
        type: "number",
        unit: "HP",
      },

      {
        key: "serialNumber",
        label: "شماره سریال",
        type: "text",
      },

      {
        key: "technicalDescription",
        label: "توضیحات",
        type: "textarea",
      },

    ],

  },

];