export interface ListingCategory {
  id: string;
  title: string;
  icon?: string;
  children?: ListingCategory[];
}

export const LISTING_CATEGORIES: ListingCategory[] = [
  {
    id: "road",
    title: "ماشین آلات راهسازی",
    children: [
      { id: "loader", title: "لودر" },
      { id: "wheel-loader", title: "لودر چرخ لاستیکی" },
      { id: "skid-loader", title: "بابکت" },
      { id: "backhoe-loader", title: "بکهو لودر" },
      { id: "excavator", title: "بیل مکانیکی" },
      { id: "mini-excavator", title: "مینی بیل" },
      { id: "long-reach", title: "بیل بازوی بلند" },
      { id: "bulldozer", title: "بولدوزر" },
      { id: "grader", title: "گریدر" },
      { id: "roller", title: "غلتک" },
      { id: "asphalt-paver", title: "فینیشر آسفالت" },
      { id: "cold-milling", title: "کولد میلینگ" },
      { id: "soil-stabilizer", title: "استابلایزر" },
      { id: "road-sweeper", title: "جاروب خیابانی" },
      { id: "road-cutter", title: "کاتر آسفالت" }
    ]
  },

  {
    id: "mining",
    title: "ماشین آلات معدنی",
    children: [
      { id: "mining-loader", title: "لودر معدنی" },
      { id: "mining-excavator", title: "بیل معدنی" },
      { id: "dump-truck", title: "دامپتراک" },
      { id: "articulated-truck", title: "دامپتراک مفصلی" },
      { id: "drilling-rig", title: "دکل حفاری" },
      { id: "blast-drill", title: "دریل واگن" },
      { id: "crusher", title: "سنگ شکن" },
      { id: "jaw-crusher", title: "سنگ شکن فکی" },
      { id: "cone-crusher", title: "سنگ شکن مخروطی" },
      { id: "impact-crusher", title: "سنگ شکن ضربه ای" },
      { id: "screen", title: "سرند" },
      { id: "feeder", title: "فیدر" }
    ]
  },

  {
    id: "crane",
    title: "جرثقیل",
    children: [
      { id: "mobile-crane", title: "جرثقیل موبایل" },
      { id: "crawler-crane", title: "جرثقیل زنجیری" },
      { id: "tower-crane", title: "تاور کرین" },
      { id: "truck-crane", title: "جرثقیل کامیونی" },
      { id: "rough-terrain", title: "جرثقیل RT" },
      { id: "all-terrain", title: "جرثقیل AT" }
    ]
  },

  {
    id: "forklift",
    title: "لیفتراک",
    children: [
      { id: "diesel-forklift", title: "لیفتراک دیزل" },
      { id: "electric-forklift", title: "لیفتراک برقی" },
      { id: "gas-forklift", title: "لیفتراک گازی" },
      { id: "reach-truck", title: "ریچتراک" },
      { id: "stacker", title: "استاکر" },
      { id: "pallet-truck", title: "پالت تراک" }
    ]
  },

  {
    id: "generator",
    title: "ژنراتور",
    children: [
      { id: "diesel-generator", title: "دیزل ژنراتور" },
      { id: "gas-generator", title: "ژنراتور گازی" },
      { id: "silent-generator", title: "ژنراتور سایلنت" },
      { id: "mobile-generator", title: "ژنراتور پرتابل" }
    ]
  },

  {
    id: "compressor",
    title: "کمپرسور",
    children: [
      { id: "air-compressor", title: "کمپرسور هوا" },
      { id: "portable-compressor", title: "کمپرسور پرتابل" },
      { id: "screw-compressor", title: "اسکرو" },
      { id: "piston-compressor", title: "پیستونی" }
    ]
  },

  {
    id: "concrete",
    title: "ماشین آلات بتن",
    children: [
      { id: "batching", title: "بچینگ" },
      { id: "concrete-mixer", title: "میکسر بتن" },
      { id: "transit-mixer", title: "تراک میکسر" },
      { id: "concrete-pump", title: "پمپ بتن" },
      { id: "placing-boom", title: "دکل بتن ریز" }
    ]
  },

  {
    id: "agriculture",
    title: "ماشین آلات کشاورزی",
    children: [
      { id: "tractor", title: "تراکتور" },
      { id: "combine", title: "کمباین" },
      { id: "sprayer", title: "سمپاش" },
      { id: "seeder", title: "بذرکار" },
      { id: "baler", title: "بیلر" },
      { id: "harvester", title: "برداشت کننده" }
    ]
  },

  {
    id: "transport",
    title: "حمل و نقل",
    children: [
      { id: "truck", title: "کامیون" },
      { id: "tractor-head", title: "کشنده" },
      { id: "trailer", title: "تریلی" },
      { id: "lowbed", title: "کفی" },
      { id: "fuel-tanker", title: "تانکر سوخت" },
      { id: "dump", title: "کمپرسی" }
    ]
  },

  {
    id: "attachments",
    title: "تجهیزات جانبی",
    children: [
      { id: "bucket", title: "باکت" },
      { id: "hammer", title: "پیکور" },
      { id: "quick-coupler", title: "کوئیک کوپلر" },
      { id: "grapple", title: "چنگک" },
      { id: "ripper", title: "ریپر" },
      { id: "auger", title: "اوگر" }
    ]
  },

  {
    id: "parts",
    title: "قطعات",
    children: [
      { id: "engine-parts", title: "قطعات موتور" },
      { id: "hydraulic-parts", title: "قطعات هیدرولیک" },
      { id: "undercarriage", title: "زیربندی" },
      { id: "filters", title: "فیلتر" },
      { id: "tires", title: "لاستیک" },
      { id: "tracks", title: "زنجیر" }
    ]
  },

  {
    id: "services",
    title: "خدمات",
    children: [
      { id: "repair", title: "تعمیرات" },
      { id: "maintenance", title: "سرویس و نگهداری" },
      { id: "inspection", title: "کارشناسی" },
      { id: "transport-service", title: "حمل ماشین آلات" },
      { id: "rental", title: "اجاره ماشین آلات" },
      { id: "operator", title: "اپراتور" }
    ]
  }
];