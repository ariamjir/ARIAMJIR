import {
  Currency,
  MachineCondition,
  PriceType,
  RecordStatus,
} from "@prisma/client";

import type { Ad } from "@/features/home/latest-ads/types/ad";

export const ads: Ad[] = [
  {
    id: "ad-001",

    slug: "caterpillar-320d-2019-mashhad",

    title: "بیل مکانیکی Caterpillar 320D",

    shortDescription:
      "دستگاه سالم، بدون نشتی، آماده کار، سرویس کامل انجام شده.",

    description:
      "بیل مکانیکی Caterpillar 320D مدل 2019 با موتور اصلی، پمپ اصلی، بدون نشتی و آماده کار در پروژه‌های عمرانی، راه‌سازی و معدنی.",

    status: RecordStatus.PUBLISHED,

    featured: true,

    urgent: false,

    verified: true,

    active: true,

    createdAt: new Date("2026-07-03"),

    updatedAt: new Date("2026-07-03"),

    publishedAt: new Date("2026-07-03"),

    brand: {
      id: "cat",

      name: "Caterpillar",

      slug: "caterpillar",
    },

    category: {
      id: "excavator",

      name: "Excavator",

      slug: "excavator",
    },

    specification: {
      model: "320D",

      manufactureYear: 2019,

      condition: MachineCondition.USED,

      engine: "CAT C6.4",

      workingHours: 5200,

      location: "شهرک صنعتی توس",

      province: "خراسان رضوی",

      city: "مشهد",

      power: 138,

      weight: 22000,

      serialNumber: "CAT320D2019-001",
    },

    seller: {
      name: "شرکت آریا ماشین شرق",

      type: "company",

      phone: "09151234567",

      whatsapp: "09151234567",
    },

    price: {
      price: 16800000000,

      currency: Currency.IRR,

      priceType: PriceType.FIXED,

      installment: false,

      exchangePossible: false,
    },

    image: "/images/machines/ariamjexcavator-1.png",

    gallery: [
      "/images/machines/ariamjexcavator-1.png",
    ],

    viewCount: 248,

    favoriteCount: 34,
  },

    {
    id: "ad-002",

    slug: "komatsu-pc220-2021-tehran",

    title: "بیل مکانیکی Komatsu PC220",

    shortDescription:
      "کم‌کارکرد، کاملاً سالم، آماده تحویل.",

    description:
      "بیل مکانیکی Komatsu PC220 مدل 2021 با موتور اصلی، کارکرد پایین، بدون رنگ و آماده تحویل فوری.",

    status: RecordStatus.PUBLISHED,

    featured: false,

    urgent: true,

    verified: true,

    active: true,

    createdAt: new Date("2026-07-02"),

    updatedAt: new Date("2026-07-02"),

    publishedAt: new Date("2026-07-02"),

    brand: {
      id: "komatsu",

      name: "Komatsu",

      slug: "komatsu",
    },

    category: {
      id: "excavator",

      name: "Excavator",

      slug: "excavator",
    },

    specification: {
      model: "PC220",

      manufactureYear: 2021,

      condition: MachineCondition.USED,

      engine: "Komatsu SAA6D107E",

      workingHours: 1800,

      location: "جاده مخصوص",

      province: "تهران",

      city: "تهران",

      power: 165,

      weight: 23600,

      serialNumber: "PC220-2021-002",
    },

    seller: {
      name: "شرکت پارس ماشین",

      type: "company",

      phone: "09121234567",

      whatsapp: "09121234567",
    },

    price: {
      price: 24500000000,

      currency: Currency.IRR,

      priceType: PriceType.FIXED,

      installment: false,

      exchangePossible: false,
    },

    image: "/images/machines/ariamjexcavator-1.png",

    gallery: [
      "/images/machines/ariamjexcavator-1.png",
    ],

    viewCount: 196,

    favoriteCount: 27,
  },

    {
    id: "ad-003",

    slug: "volvo-ec210-2018-isfahan",

    title: "بیل مکانیکی Volvo EC210",

    shortDescription:
      "موتور و پمپ اصلی، بدون رنگ، آماده کار در معدن.",

    description:
      "بیل مکانیکی Volvo EC210 مدل 2018 با موتور اصلی، سیستم هیدرولیک سالم، مناسب پروژه‌های راه‌سازی، عمرانی و معدنی.",

    status: RecordStatus.PUBLISHED,

    featured: true,

    urgent: false,

    verified: true,

    active: true,

    createdAt: new Date("2026-07-01"),

    updatedAt: new Date("2026-07-01"),

    publishedAt: new Date("2026-07-01"),

    brand: {
      id: "volvo",

      name: "Volvo",

      slug: "volvo",
    },

    category: {
      id: "excavator",

      name: "Excavator",

      slug: "excavator",
    },

    specification: {
      model: "EC210",

      manufactureYear: 2018,

      condition: MachineCondition.USED,

      engine: "Volvo D6",

      workingHours: 6400,

      location: "منطقه صنعتی دولت‌آباد",

      province: "اصفهان",

      city: "اصفهان",

      power: 160,

      weight: 21500,

      serialNumber: "VOL-EC210-003",
    },

    seller: {
      id: "seller-003",

      name: "ماشین آلات نقش جهان",

      type: "company",

      phone: "09133123456",

      whatsapp: "09133123456",
    },

    price: {
      price: 15100000000,

      currency: Currency.IRR,

      priceType: PriceType.FIXED,

      installment: false,

      exchangePossible: false,
    },

    image: "/images/machines/ariamjexcavator-1.png",

    gallery: [
      "/images/machines/ariamjexcavator-1.png",
    ],

    viewCount: 305,

    favoriteCount: 49,
  },
];