export interface ServiceItem {
  id: number;
  title: string;
  slug: string;
}

const services: ServiceItem[] = [];

export default services;