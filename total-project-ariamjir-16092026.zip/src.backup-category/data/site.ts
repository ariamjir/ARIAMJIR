export const site = {
  name: "ARIAMJ",

  slogan: "هر ارتباط، آغاز یک فرصت",

  description:
    "مرجع خرید، فروش، تعمیرات، خدمات فنی و مهندسی، قطعات و ماشین آلات سنگین",

  url: "https://ariamj.ir",

  email: "info@ariamj.ir",

  phone: "",

  address: "",
};