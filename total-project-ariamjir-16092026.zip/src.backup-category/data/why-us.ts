import type { WhyItem } from "@/features/home/why-us/types/why";

export const whyUs: WhyItem[] = [
  {
    id: "1",
    title: "واردکننده مستقیم",
    description: "تأمین مستقیم ماشین‌آلات و قطعات از برندهای معتبر جهانی.",
    icon: "🏗",
    featured: true,
  },
  {
    id: "2",
    title: "قطعات اصلی",
    description: "عرضه قطعات اورجینال با تضمین اصالت کالا.",
    icon: "⚙️",
    featured: true,
  },
  {
    id: "3",
    title: "پشتیبانی فنی",
    description: "تیم متخصص برای مشاوره، سرویس و تعمیرات.",
    icon: "🛠",
    featured: true,
  },
  {
    id: "4",
    title: "ارسال سریع",
    description: "ارسال قطعات و تجهیزات به سراسر کشور.",
    icon: "🚚",
    featured: false,
  },
  {
    id: "5",
    title: "مشاوره تخصصی",
    description: "کمک در انتخاب بهترین ماشین‌آلات متناسب با پروژه.",
    icon: "📞",
    featured: false,
  },
  {
    id: "6",
    title: "تجربه و اعتماد",
    description: "سال‌ها تجربه در تأمین ماشین‌آلات راهسازی و معدنی.",
    icon: "⭐️",
    featured: true,
  },
];