import type { NewsItem } from "@/features/home/latest-news/types/news";

export const news: NewsItem[] = [
  {
    id: "news-001",
    slug: "komatsu-hybrid-launch",

    title: "رونمایی از نسل جدید بیل‌های هیبریدی Komatsu",

    summary:
      "کماتسو نسل جدید ماشین‌آلات هیبریدی خود را با کاهش مصرف سوخت و آلایندگی معرفی کرد.",

    content:
      "نسل جدید بیل‌های مکانیکی هیبریدی Komatsu با بهره‌گیری از فناوری‌های جدید، مصرف سوخت کمتر و بازدهی بالاتری را برای پروژه‌های عمرانی فراهم می‌کنند.",

    category: "فناوری",

    image: "/images/blog/news-1.jpg",

    featured: true,

    author: "تحریریه ARIA MJ",

    publishedAt: "2026-07-03",

    readTime: 4,

    tags: ["Komatsu", "Hybrid", "Excavator"],
  },

  {
    id: "news-002",
    slug: "iran-construction-market",

    title: "رشد بازار ماشین‌آلات راهسازی در ایران",

    summary:
      "بازار ماشین‌آلات راهسازی در نیمه نخست سال رشد قابل توجهی را تجربه کرده است.",

    content:
      "افزایش پروژه‌های عمرانی و معدنی موجب افزایش تقاضا برای ماشین‌آلات سنگین در بازار ایران شده است.",

    category: "بازار",

    image: "/images/blog/news-2.jpg",

    featured: false,

    author: "تحریریه ARIA MJ",

    publishedAt: "2026-07-02",

    readTime: 3,

    tags: ["Market", "Iran"],
  },

  {
    id: "news-003",
    slug: "volvo-electric-machines",

    title: "ولوو تولید ماشین‌آلات تمام برقی را افزایش می‌دهد",

    summary:
      "ولوو اعلام کرد سرمایه‌گذاری جدیدی برای توسعه ماشین‌آلات تمام برقی انجام خواهد داد.",

    content:
      "این شرکت قصد دارد سهم ماشین‌آلات الکتریکی را در پروژه‌های ساختمانی و معدنی افزایش دهد.",

    category: "برندها",

    image: "/images/blog/news-3.jpg",

    featured: false,

    author: "تحریریه ARIA MJ",

    publishedAt: "2026-07-01",

    readTime: 5,

    tags: ["Volvo", "Electric"],
  },
];