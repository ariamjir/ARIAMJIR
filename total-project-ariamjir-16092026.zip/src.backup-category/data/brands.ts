export interface Brand {
  id: string;
  name: string;
  slug: string;
  logo: string;
  country: string;
  website?: string;
  featured?: boolean;
}

export const brands: Brand[] = [
  {
    id: "cat",
    name: "Caterpillar",
    slug: "caterpillar",
    logo: "/brands/caterpillar.svg",
    country: "USA",
    featured: true,
  },

  {
    id: "komatsu",
    name: "Komatsu",
    slug: "komatsu",
    logo: "/brands/komatsu.svg",
    country: "Japan",
    featured: true,
  },

  {
    id: "hitachi",
    name: "Hitachi",
    slug: "hitachi",
    logo: "/brands/hitachi.svg",
    country: "Japan",
    featured: true,
  },

  {
    id: "volvo",
    name: "Volvo CE",
    slug: "volvo",
    logo: "/brands/volvo.svg",
    country: "Sweden",
    featured: true,
  },

  {
    id: "jcb",
    name: "JCB",
    slug: "jcb",
    logo: "/brands/jcb.svg",
    country: "United Kingdom",
    featured: true,
  },

  {
    id: "hyundai",
    name: "Hyundai",
    slug: "hyundai",
    logo: "/brands/hyundai.svg",
    country: "South Korea",
    featured: true,
  },

  {
    id: "doosan",
    name: "Doosan",
    slug: "doosan",
    logo: "/brands/doosan.svg",
    country: "South Korea",
    featured: true,
  },

  {
    id: "sany",
    name: "SANY",
    slug: "sany",
    logo: "/brands/sany.svg",
    country: "China",
    featured: true,
  },

  {
    id: "xcmg",
    name: "XCMG",
    slug: "xcmg",
    logo: "/brands/xcmg.svg",
    country: "China",
    featured: true,
  },

  {
    id: "zoomlion",
    name: "Zoomlion",
    slug: "zoomlion",
    logo: "/brands/zoomlion.svg",
    country: "China",
    featured: true,
  },

  {
    id: "shantui",
    name: "Shantui",
    slug: "shantui",
    logo: "/brands/shantui.svg",
    country: "China",
    featured: true,
  },

  {
    id: "lovol",
    name: "Lovol",
    slug: "lovol",
    logo: "/brands/lovol.svg",
    country: "China",
    featured: true,
  },

  {
    id: "changlin",
    name: "Changlin",
    slug: "changlin",
    logo: "/brands/changlin.svg",
    country: "China",
    featured: true,
  },

  {
    id: "liebherr",
    name: "Liebherr",
    slug: "liebherr",
    logo: "/brands/liebherr.svg",
    country: "Germany",
    featured: true,
  },

  {
    id: "cummins",
    name: "Cummins",
    slug: "cummins",
    logo: "/brands/cummins.svg",
    country: "USA",
    featured: true,
  },
];