export interface SocialItem {
  id: number;
  name: string;
  url: string;
  icon?: string;
}

const social: SocialItem[] = [];

export default social;