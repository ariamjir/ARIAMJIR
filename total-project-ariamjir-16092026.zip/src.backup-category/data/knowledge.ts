import type { KnowledgeItem } from "@/features/home/knowledge/types/knowledge";

export const knowledge: KnowledgeItem[] = [
  {
    id: "knowledge-001",
    slug: "excavator-maintenance",
    title: "راهنمای کامل نگهداری بیل مکانیکی",
    summary: "اصول نگهداری روزانه و دوره‌ای بیل مکانیکی برای افزایش عمر مفید دستگاه.",
    category: "نگهداری",
    image: "/images/blog/news-1.jpg",
    author: "ARIA MJ",
    readTime: 6,
    featured: true,
    publishedAt: "2026-07-04",
    tags: ["Excavator", "Maintenance"],
  },

  {
    id: "knowledge-002",
    slug: "hydraulic-oil",
    title: "انتخاب روغن هیدرولیک مناسب",
    summary: "راهنمای انتخاب روغن مناسب برای ماشین‌آلات سنگین.",
    category: "آموزشی",
    image: "/images/blog/news-2.jpg",
    author: "ARIA MJ",
    readTime: 5,
    featured: false,
    publishedAt: "2026-07-03",
    tags: ["Hydraulic", "Oil"],
  },

  {
    id: "knowledge-003",
    slug: "used-machinery",
    title: "راهنمای خرید ماشین‌آلات کارکرده",
    summary: "نکات مهم هنگام خرید ماشین‌آلات دست دوم.",
    category: "راهنما",
    image: "/images/blog/news-3.jpg",
    author: "ARIA MJ",
    readTime: 7,
    featured: true,
    publishedAt: "2026-07-02",
    tags: ["Buying"],
  },
];