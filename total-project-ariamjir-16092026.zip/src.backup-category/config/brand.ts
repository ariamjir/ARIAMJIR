export const BRAND = {
  name: "ARIA MJ",
  fullName: "گروه صنعتی آریا ماشین جم",
  slogan: "Industrial Marketplace",
  primary: "#F47C20",
  dark: "#111111",
  gray: "#3A3A3A",
  font: "Yekan Bakh",
};