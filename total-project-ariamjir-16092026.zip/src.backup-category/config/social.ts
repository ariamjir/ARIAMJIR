export const socials = [
  {
    name: "WhatsApp",
    url: "https://wa.me/qr/NZUDSXMYK5PBB1",
  },
  {
    name: "Instagram",
    url: "https://www.instagram.com/ariamachinejam",
  },
  {
    name: "X (Twitter)",
    url: "https://www.x.com/ariamachinejam",
  },
  {
    name: "Telegram",
    url: "https://t.me/ariamjcom",
  },
  {
    name: "YouTube",
    url: "https://www.youtube.com/ariamachinejam",
  },
  {
    name: "LinkedIn",
    url: "https://www.linkedin.com/ariamachinejam",
  },
];