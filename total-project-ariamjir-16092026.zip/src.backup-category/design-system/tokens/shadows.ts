export const shadows = {
  sm: "0 2px 8px rgba(0,0,0,.15)",

  md: "0 6px 20px rgba(0,0,0,.25)",

  lg: "0 12px 35px rgba(0,0,0,.35)",

  orange: "0 0 20px rgba(245,130,32,.35)",
} as const;