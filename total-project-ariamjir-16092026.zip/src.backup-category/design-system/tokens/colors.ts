export const colors = {
  primary: "#F58220",
  primaryHover: "#ff9a3c",

  secondary: "#1A1A1A",

  background: "#000000",

  surface: "#111111",

  surfaceLight: "#1D1D1D",

  border: "#2A2A2A",

  white: "#FFFFFF",

  text: "#FFFFFF",

  textSecondary: "#B3B3B3",

  success: "#00C853",

  warning: "#FFC107",

  danger: "#F44336",

  info: "#2196F3",
} as const;