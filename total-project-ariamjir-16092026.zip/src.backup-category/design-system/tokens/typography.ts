export const typography = {
  fontFamily: "Yekan Bakh",

  h1: "56px",

  h2: "44px",

  h3: "36px",

  h4: "28px",

  h5: "22px",

  body: "16px",

  small: "14px",

  caption: "12px",
} as const;