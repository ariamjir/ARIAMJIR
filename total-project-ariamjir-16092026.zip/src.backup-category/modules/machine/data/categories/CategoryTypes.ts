/* ==========================================================
   MACHINE CATEGORY DATA TYPES
   ARIA MJ
========================================================== */

export interface MachineCategoryItem {
  id: string;

  slug: string;

  parent?: string;

  titleFa: string;
  titleEn: string;

  icon?: string;

  listingType: string;

  children?: string[];

  active: boolean;

  featured?: boolean;
}