import type { MachineCategoryItem } from "../CategoryTypes";

export const lubricants: MachineCategoryItem[] = [



];
