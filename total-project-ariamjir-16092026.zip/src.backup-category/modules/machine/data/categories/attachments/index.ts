import type { MachineCategoryItem } from "../CategoryTypes";

export const attachments: MachineCategoryItem[] = [

{
    id: "buckets",
    parent: "attachments",
    slug: "buckets",
    titleFa: "باکت ها",
    titleEn: "Buckets",
    listingType: "attachment",
    children: [
      "general-purpose-bucket",
      "heavy-duty-bucket",
      "rock-bucket",
      "coal-bucket",
      "high-tip-bucket",
      "ditch-cleaning-bucket",
      "trenching-bucket",
      "skeleton-bucket",
      "tilting-bucket",
      "v-bucket",
      "clamshell-bucket",
      "mud-bucket",
      "grading-bucket"
    ],
    active: true,
  },

{
    id: "general-purpose-bucket",
    parent: "buckets",
    slug: "general-purpose-bucket",
    titleFa: "باکت معمولی",
    titleEn: "General Purpose Bucket",
    listingType: "attachment",
    active: true,
  },

{
    id: "heavy-duty-bucket",
    parent: "buckets",
    slug: "heavy-duty-bucket",
    titleFa: "باکت سنگین",
    titleEn: "Heavy Duty Bucket",
    listingType: "attachment",
    active: true,
  },

{
    id: "rock-bucket",
    parent: "buckets",
    slug: "rock-bucket",
    titleFa: "باکت سنگ",
    titleEn: "Rock Bucket",
    listingType: "attachment",
    active: true,
  },

{
    id: "coal-bucket",
    parent: "buckets",
    slug: "coal-bucket",
    titleFa: "باکت زغال",
    titleEn: "Coal Bucket",
    listingType: "attachment",
    active: true,
  },

{
    id: "high-tip-bucket",
    parent: "buckets",
    slug: "high-tip-bucket",
    titleFa: "باکت تخلیه بلند",
    titleEn: "High Tip Bucket",
    listingType: "attachment",
    active: true,
  },

{
    id: "ditch-cleaning-bucket",
    parent: "buckets",
    slug: "ditch-cleaning-bucket",
    titleFa: "باکت پاکسازی کانال",
    titleEn: "Ditch Cleaning Bucket",
    listingType: "attachment",
    active: true,
  },

{
    id: "trenching-bucket",
    parent: "buckets",
    slug: "trenching-bucket",
    titleFa: "باکت ترنچر",
    titleEn: "Trenching Bucket",
    listingType: "attachment",
    active: true,
  },

{
    id: "skeleton-bucket",
    parent: "buckets",
    slug: "skeleton-bucket",
    titleFa: "باکت مشبک",
    titleEn: "Skeleton Bucket",
    listingType: "attachment",
    active: true,
  },

{
    id: "tilting-bucket",
    parent: "buckets",
    slug: "tilting-bucket",
    titleFa: "باکت شیب دار",
    titleEn: "Tilting Bucket",
    listingType: "attachment",
    active: true,
  },

{
    id: "v-bucket",
    parent: "buckets",
    slug: "v-bucket",
    titleFa: "باکت V",
    titleEn: "V Bucket",
    listingType: "attachment",
    active: true,
  },

{
    id: "clamshell-bucket",
    parent: "buckets",
    slug: "clamshell-bucket",
    titleFa: "باکت دو فکی",
    titleEn: "Clamshell Bucket",
    listingType: "attachment",
    active: true,
  },

{
    id: "mud-bucket",
    parent: "buckets",
    slug: "mud-bucket",
    titleFa: "باکت گل",
    titleEn: "Mud Bucket",
    listingType: "attachment",
    active: true,
  },

{
    id: "grading-bucket",
    parent: "buckets",
    slug: "grading-bucket",
    titleFa: "باکت تسطیح",
    titleEn: "Grading Bucket",
    listingType: "attachment",
    active: true,
  },

{
    id: "breakers",
    parent: "attachments",
    slug: "breakers",
    titleFa: "چکش های هیدرولیکی",
    titleEn: "Hydraulic Breakers",
    listingType: "attachment",
    children: [
      "mini-breaker",
      "light-breaker",
      "medium-breaker",
      "heavy-breaker",
      "extra-heavy-breaker",
      "silent-breaker",
      "open-breaker",
      "box-breaker",
      "top-breaker",
      "side-breaker"
    ],
    active: true,
  },

{
    id: "mini-breaker",
    parent: "breakers",
    slug: "mini-breaker",
    titleFa: "چکش مینی",
    titleEn: "Mini Breaker",
    listingType: "attachment",
    active: true,
  },

{
    id: "light-breaker",
    parent: "breakers",
    slug: "light-breaker",
    titleFa: "چکش سبک",
    titleEn: "Light Breaker",
    listingType: "attachment",
    active: true,
  },

{
    id: "medium-breaker",
    parent: "breakers",
    slug: "medium-breaker",
    titleFa: "چکش متوسط",
    titleEn: "Medium Breaker",
    listingType: "attachment",
    active: true,
  },

{
    id: "heavy-breaker",
    parent: "breakers",
    slug: "heavy-breaker",
    titleFa: "چکش سنگین",
    titleEn: "Heavy Breaker",
    listingType: "attachment",
    active: true,
  },

{
    id: "extra-heavy-breaker",
    parent: "breakers",
    slug: "extra-heavy-breaker",
    titleFa: "چکش فوق سنگین",
    titleEn: "Extra Heavy Breaker",
    listingType: "attachment",
    active: true,
  },

{
    id: "silent-breaker",
    parent: "breakers",
    slug: "silent-breaker",
    titleFa: "چکش سایلنت",
    titleEn: "Silent Breaker",
    listingType: "attachment",
    active: true,
  },

{
    id: "open-breaker",
    parent: "breakers",
    slug: "open-breaker",
    titleFa: "چکش اپن تایپ",
    titleEn: "Open Type Breaker",
    listingType: "attachment",
    active: true,
  },

{
    id: "box-breaker",
    parent: "breakers",
    slug: "box-breaker",
    titleFa: "چکش باکس",
    titleEn: "Box Type Breaker",
    listingType: "attachment",
    active: true,
  },

{
    id: "top-breaker",
    parent: "breakers",
    slug: "top-breaker",
    titleFa: "چکش تاپ تایپ",
    titleEn: "Top Type Breaker",
    listingType: "attachment",
    active: true,
  },

{
    id: "side-breaker",
    parent: "breakers",
    slug: "side-breaker",
    titleFa: "چکش ساید تایپ",
    titleEn: "Side Type Breaker",
    listingType: "attachment",
    active: true,
  },

{
    id: "rippers",
    parent: "attachments",
    slug: "rippers",
    titleFa: "ریپر",
    titleEn: "Rippers",
    listingType: "attachment",
    children: [
      "single-shank-ripper",
      "multi-shank-ripper",
      "vibro-ripper",
      "frost-ripper",
      "rock-ripper"
    ],
    active: true,
  },

{
    id: "single-shank-ripper",
    parent: "rippers",
    slug: "single-shank-ripper",
    titleFa: "ریپر تک شاخ",
    titleEn: "Single Shank Ripper",
    listingType: "attachment",
    active: true,
  },

{
    id: "multi-shank-ripper",
    parent: "rippers",
    slug: "multi-shank-ripper",
    titleFa: "ریپر چند شاخ",
    titleEn: "Multi Shank Ripper",
    listingType: "attachment",
    active: true,
  },

{
    id: "vibro-ripper",
    parent: "rippers",
    slug: "vibro-ripper",
    titleFa: "ویبرو ریپر",
    titleEn: "Vibro Ripper",
    listingType: "attachment",
    active: true,
  },

{
    id: "frost-ripper",
    parent: "rippers",
    slug: "frost-ripper",
    titleFa: "ریپر یخ",
    titleEn: "Frost Ripper",
    listingType: "attachment",
    active: true,
  },

{
    id: "rock-ripper",
    parent: "rippers",
    slug: "rock-ripper",
    titleFa: "ریپر سنگ",
    titleEn: "Rock Ripper",
    listingType: "attachment",
    active: true,
  },

{
    id: "compactors",
    parent: "attachments",
    slug: "compactors",
    titleFa: "کمپکتور",
    titleEn: "Compactors",
    listingType: "attachment",
    children: [
      "plate-compactor",
      "wheel-compactor",
      "vibratory-compactor",
      "tamping-rammer"
    ],
    active: true,
  },

{
    id: "plate-compactor",
    parent: "compactors",
    slug: "plate-compactor",
    titleFa: "کمپکتور صفحه ای",
    titleEn: "Plate Compactor",
    listingType: "attachment",
    active: true,
  },

{
    id: "wheel-compactor",
    parent: "compactors",
    slug: "wheel-compactor",
    titleFa: "غلتک چرخی",
    titleEn: "Wheel Compactor",
    listingType: "attachment",
    active: true,
  },

{
    id: "vibratory-compactor",
    parent: "compactors",
    slug: "vibratory-compactor",
    titleFa: "کمپکتور ویبره",
    titleEn: "Vibratory Compactor",
    listingType: "attachment",
    active: true,
  },

{
    id: "tamping-rammer",
    parent: "compactors",
    slug: "tamping-rammer",
    titleFa: "تمپر",
    titleEn: "Tamping Rammer",
    listingType: "attachment",
    active: true,
  },

{
    id: "forks",
    parent: "attachments",
    slug: "forks",
    titleFa: "شاخک و فورک",
    titleEn: "Forks",
    listingType: "attachment",
    children: [
      "pallet-fork",
      "block-fork",
      "log-fork",
      "pipe-fork",
      "hay-fork",
      "manure-fork",
      "stone-fork"
    ],
    active: true,
  },

{
    id: "pallet-fork",
    parent: "forks",
    slug: "pallet-fork",
    titleFa: "شاخک پالت",
    titleEn: "Pallet Fork",
    listingType: "attachment",
    active: true,
  },

{
    id: "block-fork",
    parent: "forks",
    slug: "block-fork",
    titleFa: "شاخک بلوک",
    titleEn: "Block Fork",
    listingType: "attachment",
    active: true,
  },

{
    id: "log-fork",
    parent: "forks",
    slug: "log-fork",
    titleFa: "شاخک چوب",
    titleEn: "Log Fork",
    listingType: "attachment",
    active: true,
  },

{
    id: "pipe-fork",
    parent: "forks",
    slug: "pipe-fork",
    titleFa: "شاخک لوله",
    titleEn: "Pipe Fork",
    listingType: "attachment",
    active: true,
  },

{
    id: "hay-fork",
    parent: "forks",
    slug: "hay-fork",
    titleFa: "شاخک علوفه",
    titleEn: "Hay Fork",
    listingType: "attachment",
    active: true,
  },

{
    id: "manure-fork",
    parent: "forks",
    slug: "manure-fork",
    titleFa: "شاخک کود",
    titleEn: "Manure Fork",
    listingType: "attachment",
    active: true,
  },

{
    id: "stone-fork",
    parent: "forks",
    slug: "stone-fork",
    titleFa: "شاخک سنگ",
    titleEn: "Stone Fork",
    listingType: "attachment",
    active: true,
  },

{
    id: "grapples",
    parent: "attachments",
    slug: "grapples",
    titleFa: "گراپل",
    titleEn: "Grapples",
    listingType: "attachment",
    children: [
      "log-grapple",
      "scrap-grapple",
      "orange-peel-grapple",
      "demolition-grapple",
      "sorting-grapple",
      "multi-purpose-grapple",
      "forest-grapple"
    ],
    active: true,
  },

{
    id: "log-grapple",
    parent: "grapples",
    slug: "log-grapple",
    titleFa: "گراپل چوب",
    titleEn: "Log Grapple",
    listingType: "attachment",
    active: true,
  },

{
    id: "scrap-grapple",
    parent: "grapples",
    slug: "scrap-grapple",
    titleFa: "گراپل ضایعات",
    titleEn: "Scrap Grapple",
    listingType: "attachment",
    active: true,
  },

{
    id: "orange-peel-grapple",
    parent: "grapples",
    slug: "orange-peel-grapple",
    titleFa: "گراپل پرتقالی",
    titleEn: "Orange Peel Grapple",
    listingType: "attachment",
    active: true,
  },

{
    id: "demolition-grapple",
    parent: "grapples",
    slug: "demolition-grapple",
    titleFa: "گراپل تخریب",
    titleEn: "Demolition Grapple",
    listingType: "attachment",
    active: true,
  },

{
    id: "sorting-grapple",
    parent: "grapples",
    slug: "sorting-grapple",
    titleFa: "گراپل تفکیکی",
    titleEn: "Sorting Grapple",
    listingType: "attachment",
    active: true,
  },

{
    id: "multi-purpose-grapple",
    parent: "grapples",
    slug: "multi-purpose-grapple",
    titleFa: "گراپل چندمنظوره",
    titleEn: "Multi Purpose Grapple",
    listingType: "attachment",
    active: true,
  },

{
    id: "forest-grapple",
    parent: "grapples",
    slug: "forest-grapple",
    titleFa: "گراپل جنگلداری",
    titleEn: "Forestry Grapple",
    listingType: "attachment",
    active: true,
  },

{
    id: "quick-couplers",
    parent: "attachments",
    slug: "quick-couplers",
    titleFa: "کوپلر",
    titleEn: "Quick Couplers",
    listingType: "attachment",
    children: [
      "hydraulic-coupler",
      "manual-coupler",
      "tilt-coupler",
      "rotating-coupler"
    ],
    active: true,
  },

{
    id: "hydraulic-coupler",
    parent: "quick-couplers",
    slug: "hydraulic-coupler",
    titleFa: "کوپلر هیدرولیکی",
    titleEn: "Hydraulic Quick Coupler",
    listingType: "attachment",
    active: true,
  },

{
    id: "manual-coupler",
    parent: "quick-couplers",
    slug: "manual-coupler",
    titleFa: "کوپلر دستی",
    titleEn: "Manual Quick Coupler",
    listingType: "attachment",
    active: true,
  },

{
    id: "tilt-coupler",
    parent: "quick-couplers",
    slug: "tilt-coupler",
    titleFa: "تیلت کوپلر",
    titleEn: "Tilt Coupler",
    listingType: "attachment",
    active: true,
  },

{
    id: "rotating-coupler",
    parent: "quick-couplers",
    slug: "rotating-coupler",
    titleFa: "روتاتور کوپلر",
    titleEn: "Rotating Coupler",
    listingType: "attachment",
    active: true,
  },

{
    id: "pulverizers",
    parent: "attachments",
    slug: "pulverizers",
    titleFa: "پالورایزر",
    titleEn: "Pulverizers",
    listingType: "attachment",
    children: [
      "concrete-pulverizer",
      "rotating-pulverizer",
      "fixed-pulverizer",
      "secondary-pulverizer"
    ],
    active: true,
  },

{
    id: "concrete-pulverizer",
    parent: "pulverizers",
    slug: "concrete-pulverizer",
    titleFa: "پالورایزر بتن",
    titleEn: "Concrete Pulverizer",
    listingType: "attachment",
    active: true,
  },

{
    id: "rotating-pulverizer",
    parent: "pulverizers",
    slug: "rotating-pulverizer",
    titleFa: "پالورایزر چرخشی",
    titleEn: "Rotating Pulverizer",
    listingType: "attachment",
    active: true,
  },

{
    id: "fixed-pulverizer",
    parent: "pulverizers",
    slug: "fixed-pulverizer",
    titleFa: "پالورایزر ثابت",
    titleEn: "Fixed Pulverizer",
    listingType: "attachment",
    active: true,
  },

{
    id: "secondary-pulverizer",
    parent: "pulverizers",
    slug: "secondary-pulverizer",
    titleFa: "پالورایزر ثانویه",
    titleEn: "Secondary Pulverizer",
    listingType: "attachment",
    active: true,
  },

{
    id: "demolition-shears",
    parent: "attachments",
    slug: "demolition-shears",
    titleFa: "قیچی تخریب",
    titleEn: "Demolition Shears",
    listingType: "attachment",
    children: [
      "steel-shear",
      "scrap-shear",
      "mobile-shear",
      "rotating-shear"
    ],
    active: true,
  },

{
    id: "steel-shear",
    parent: "demolition-shears",
    slug: "steel-shear",
    titleFa: "قیچی فولاد",
    titleEn: "Steel Shear",
    listingType: "attachment",
    active: true,
  },

{
    id: "scrap-shear",
    parent: "demolition-shears",
    slug: "scrap-shear",
    titleFa: "قیچی ضایعات",
    titleEn: "Scrap Shear",
    listingType: "attachment",
    active: true,
  },

{
    id: "mobile-shear",
    parent: "demolition-shears",
    slug: "mobile-shear",
    titleFa: "قیچی متحرک",
    titleEn: "Mobile Shear",
    listingType: "attachment",
    active: true,
  },

{
    id: "rotating-shear",
    parent: "demolition-shears",
    slug: "rotating-shear",
    titleFa: "قیچی چرخشی",
    titleEn: "Rotating Shear",
    listingType: "attachment",
    active: true,
  },

{
    id: "augers",
    parent: "attachments",
    slug: "augers",
    titleFa: "مته حفاری",
    titleEn: "Augers",
    listingType: "attachment",
    children: [
      "earth-auger",
      "rock-auger",
      "tree-auger",
      "foundation-auger"
    ],
    active: true,
  },

{
    id: "earth-auger",
    parent: "augers",
    slug: "earth-auger",
    titleFa: "مته خاک",
    titleEn: "Earth Auger",
    listingType: "attachment",
    active: true,
  },

{
    id: "rock-auger",
    parent: "augers",
    slug: "rock-auger",
    titleFa: "مته سنگ",
    titleEn: "Rock Auger",
    listingType: "attachment",
    active: true,
  },

{
    id: "tree-auger",
    parent: "augers",
    slug: "tree-auger",
    titleFa: "مته درختکاری",
    titleEn: "Tree Planting Auger",
    listingType: "attachment",
    active: true,
  },

{
    id: "foundation-auger",
    parent: "augers",
    slug: "foundation-auger",
    titleFa: "مته فونداسیون",
    titleEn: "Foundation Auger",
    listingType: "attachment",
    active: true,
  },

{
    id: "sweepers",
    parent: "attachments",
    slug: "sweepers",
    titleFa: "جاروب",
    titleEn: "Sweepers",
    listingType: "attachment",
    children: [
      "road-sweeper",
      "bucket-sweeper",
      "angle-broom",
      "pickup-broom"
    ],
    active: true,
  },

{
    id: "road-sweeper",
    parent: "sweepers",
    slug: "road-sweeper",
    titleFa: "جاروب خیابانی",
    titleEn: "Road Sweeper",
    listingType: "attachment",
    active: true,
  },

{
    id: "bucket-sweeper",
    parent: "sweepers",
    slug: "bucket-sweeper",
    titleFa: "جاروب باکتی",
    titleEn: "Bucket Sweeper",
    listingType: "attachment",
    active: true,
  },

{
    id: "angle-broom",
    parent: "sweepers",
    slug: "angle-broom",
    titleFa: "جاروب زاویه دار",
    titleEn: "Angle Broom",
    listingType: "attachment",
    active: true,
  },

{
    id: "pickup-broom",
    parent: "sweepers",
    slug: "pickup-broom",
    titleFa: "جاروب جمع کننده",
    titleEn: "Pickup Broom",
    listingType: "attachment",
    active: true,
  },

{
    id: "snow-equipment",
    parent: "attachments",
    slug: "snow-equipment",
    titleFa: "تجهیزات برف روبی",
    titleEn: "Snow Equipment",
    listingType: "attachment",
    children: [
      "snow-blade",
      "snow-blower",
      "snow-plow",
      "snow-pusher",
      "salt-spreader"
    ],
    active: true,
  },

{
    id: "snow-blade",
    parent: "snow-equipment",
    slug: "snow-blade",
    titleFa: "تیغه برف",
    titleEn: "Snow Blade",
    listingType: "attachment",
    active: true,
  },

{
    id: "snow-blower",
    parent: "snow-equipment",
    slug: "snow-blower",
    titleFa: "برف روب دوار",
    titleEn: "Snow Blower",
    listingType: "attachment",
    active: true,
  },

{
    id: "snow-plow",
    parent: "snow-equipment",
    slug: "snow-plow",
    titleFa: "گاوآهن برف",
    titleEn: "Snow Plow",
    listingType: "attachment",
    active: true,
  },

{
    id: "snow-pusher",
    parent: "snow-equipment",
    slug: "snow-pusher",
    titleFa: "برف جمع کن",
    titleEn: "Snow Pusher",
    listingType: "attachment",
    active: true,
  },

{
    id: "salt-spreader",
    parent: "snow-equipment",
    slug: "salt-spreader",
    titleFa: "نمک پاش",
    titleEn: "Salt Spreader",
    listingType: "attachment",
    active: true,
  },

{
    id: "forestry",
    parent: "attachments",
    slug: "forestry",
    titleFa: "تجهیزات جنگلداری",
    titleEn: "Forestry Equipment",
    listingType: "attachment",
    children: [
      "tree-shear",
      "mulcher",
      "stump-grinder",
      "forestry-head",
      "tree-puller"
    ],
    active: true,
  },

{
    id: "tree-shear",
    parent: "forestry",
    slug: "tree-shear",
    titleFa: "قیچی درخت",
    titleEn: "Tree Shear",
    listingType: "attachment",
    active: true,
  },

{
    id: "mulcher",
    parent: "forestry",
    slug: "mulcher",
    titleFa: "مالچر",
    titleEn: "Forestry Mulcher",
    listingType: "attachment",
    active: true,
  },

{
    id: "stump-grinder",
    parent: "forestry",
    slug: "stump-grinder",
    titleFa: "ریشه خردکن",
    titleEn: "Stump Grinder",
    listingType: "attachment",
    active: true,
  },

{
    id: "forestry-head",
    parent: "forestry",
    slug: "forestry-head",
    titleFa: "هد هاروستر",
    titleEn: "Harvester Head",
    listingType: "attachment",
    active: true,
  },

{
    id: "tree-puller",
    parent: "forestry",
    slug: "tree-puller",
    titleFa: "درخت کش",
    titleEn: "Tree Puller",
    listingType: "attachment",
    active: true,
  },

{
    id: "recycling",
    parent: "attachments",
    slug: "recycling",
    titleFa: "بازیافت",
    titleEn: "Recycling Equipment",
    listingType: "attachment",
    children: [
      "crusher-bucket",
      "screening-bucket",
      "mixing-bucket",
      "electromagnet",
      "sorting-grapple"
    ],
    active: true,
  },

{
    id: "crusher-bucket",
    parent: "recycling",
    slug: "crusher-bucket",
    titleFa: "باکت سنگ شکن",
    titleEn: "Crusher Bucket",
    listingType: "attachment",
    active: true,
  },

{
    id: "screening-bucket",
    parent: "recycling",
    slug: "screening-bucket",
    titleFa: "باکت سرند",
    titleEn: "Screening Bucket",
    listingType: "attachment",
    active: true,
  },

{
    id: "mixing-bucket",
    parent: "recycling",
    slug: "mixing-bucket",
    titleFa: "باکت میکسر",
    titleEn: "Mixing Bucket",
    listingType: "attachment",
    active: true,
  },

{
    id: "electromagnet",
    parent: "recycling",
    slug: "electromagnet",
    titleFa: "مگنت صنعتی",
    titleEn: "Electromagnet",
    listingType: "attachment",
    active: true,
  },

{
    id: "road-construction",
    parent: "attachments",
    slug: "road-construction",
    titleFa: "راهسازی",
    titleEn: "Road Construction",
    listingType: "attachment",
    children: [
      "cold-planer",
      "asphalt-cutter",
      "road-profiler",
      "compaction-wheel",
      "soil-stabilizer",
      "road-widener"
    ],
    active: true,
  },

{
    id: "cold-planer",
    parent: "road-construction",
    slug: "cold-planer",
    titleFa: "کولد پلنر",
    titleEn: "Cold Planer",
    listingType: "attachment",
    active: true,
  },

{
    id: "asphalt-cutter",
    parent: "road-construction",
    slug: "asphalt-cutter",
    titleFa: "برش آسفالت",
    titleEn: "Asphalt Cutter",
    listingType: "attachment",
    active: true,
  },

{
    id: "road-profiler",
    parent: "road-construction",
    slug: "road-profiler",
    titleFa: "پروفایلر جاده",
    titleEn: "Road Profiler",
    listingType: "attachment",
    active: true,
  },

{
    id: "compaction-wheel",
    parent: "road-construction",
    slug: "compaction-wheel",
    titleFa: "چرخ تراکم",
    titleEn: "Compaction Wheel",
    listingType: "attachment",
    active: true,
  },

{
    id: "soil-stabilizer",
    parent: "road-construction",
    slug: "soil-stabilizer",
    titleFa: "تثبیت کننده خاک",
    titleEn: "Soil Stabilizer",
    listingType: "attachment",
    active: true,
  },

{
    id: "road-widener",
    parent: "road-construction",
    slug: "road-widener",
    titleFa: "عریض کننده جاده",
    titleEn: "Road Widener",
    listingType: "attachment",
    active: true,
  },

{
    id: "concrete-equipment",
    parent: "attachments",
    slug: "concrete-equipment",
    titleFa: "تجهیزات بتن",
    titleEn: "Concrete Equipment",
    listingType: "attachment",
    children: [
      "concrete-mixer",
      "concrete-pump",
      "concrete-bucket",
      "concrete-vibrator",
      "concrete-breaker"
    ],
    active: true,
  },

{
    id: "concrete-mixer",
    parent: "concrete-equipment",
    slug: "concrete-mixer",
    titleFa: "میکسر بتن",
    titleEn: "Concrete Mixer",
    listingType: "attachment",
    active: true,
  },

{
    id: "concrete-pump",
    parent: "concrete-equipment",
    slug: "concrete-pump",
    titleFa: "پمپ بتن",
    titleEn: "Concrete Pump",
    listingType: "attachment",
    active: true,
  },

{
    id: "concrete-bucket",
    parent: "concrete-equipment",
    slug: "concrete-bucket",
    titleFa: "باکت بتن",
    titleEn: "Concrete Bucket",
    listingType: "attachment",
    active: true,
  },

{
    id: "concrete-vibrator",
    parent: "concrete-equipment",
    slug: "concrete-vibrator",
    titleFa: "ویبراتور بتن",
    titleEn: "Concrete Vibrator",
    listingType: "attachment",
    active: true,
  },

{
    id: "concrete-breaker",
    parent: "concrete-equipment",
    slug: "concrete-breaker",
    titleFa: "تخریب بتن",
    titleEn: "Concrete Breaker",
    listingType: "attachment",
    active: true,
  },

{
    id: "agriculture",
    parent: "attachments",
    slug: "agriculture",
    titleFa: "کشاورزی",
    titleEn: "Agriculture",
    listingType: "attachment",
    children: [
      "bale-grabber",
      "silage-fork",
      "grain-bucket",
      "fertilizer-spreader",
      "feed-pusher",
      "manure-spreader"
    ],
    active: true,
  },

{
    id: "bale-grabber",
    parent: "agriculture",
    slug: "bale-grabber",
    titleFa: "بسته گیر علوفه",
    titleEn: "Bale Grabber",
    listingType: "attachment",
    active: true,
  },

{
    id: "silage-fork",
    parent: "agriculture",
    slug: "silage-fork",
    titleFa: "چنگک سیلاژ",
    titleEn: "Silage Fork",
    listingType: "attachment",
    active: true,
  },

{
    id: "grain-bucket",
    parent: "agriculture",
    slug: "grain-bucket",
    titleFa: "باکت غلات",
    titleEn: "Grain Bucket",
    listingType: "attachment",
    active: true,
  },

{
    id: "fertilizer-spreader",
    parent: "agriculture",
    slug: "fertilizer-spreader",
    titleFa: "کودپاش",
    titleEn: "Fertilizer Spreader",
    listingType: "attachment",
    active: true,
  },

{
    id: "feed-pusher",
    parent: "agriculture",
    slug: "feed-pusher",
    titleFa: "خوراک ران",
    titleEn: "Feed Pusher",
    listingType: "attachment",
    active: true,
  },

{
    id: "manure-spreader",
    parent: "agriculture",
    slug: "manure-spreader",
    titleFa: "کودپاش دامی",
    titleEn: "Manure Spreader",
    listingType: "attachment",
    active: true,
  },

{
    id: "railway-equipment",
    parent: "attachments",
    slug: "railway-equipment",
    titleFa: "تجهیزات راه‌آهن",
    titleEn: "Railway Equipment",
    listingType: "attachment",
    children: [
      "rail-grapple",
      "rail-clamp",
      "sleeper-grabber",
      "ballast-cleaner",
      "rail-lifter"
    ],
    active: true,
  },

{
    id: "rail-grapple",
    parent: "railway-equipment",
    slug: "rail-grapple",
    titleFa: "گراپل ریل",
    titleEn: "Rail Grapple",
    listingType: "attachment",
    active: true,
  },

{
    id: "rail-clamp",
    parent: "railway-equipment",
    slug: "rail-clamp",
    titleFa: "گیره ریل",
    titleEn: "Rail Clamp",
    listingType: "attachment",
    active: true,
  },

{
    id: "sleeper-grabber",
    parent: "railway-equipment",
    slug: "sleeper-grabber",
    titleFa: "گیرنده تراورس",
    titleEn: "Sleeper Grabber",
    listingType: "attachment",
    active: true,
  },

{
    id: "ballast-cleaner",
    parent: "railway-equipment",
    slug: "ballast-cleaner",
    titleFa: "پاک کننده بالاست",
    titleEn: "Ballast Cleaner",
    listingType: "attachment",
    active: true,
  },

{
    id: "rail-lifter",
    parent: "railway-equipment",
    slug: "rail-lifter",
    titleFa: "ریل بردار",
    titleEn: "Rail Lifter",
    listingType: "attachment",
    active: true,
  },

{
    id: "marine-equipment",
    parent: "attachments",
    slug: "marine-equipment",
    titleFa: "تجهیزات دریایی",
    titleEn: "Marine Equipment",
    listingType: "attachment",
    children: [
      "dredging-bucket",
      "marine-grapple",
      "underwater-hammer",
      "pile-driver",
      "vibro-hammer"
    ],
    active: true,
  },

{
    id: "dredging-bucket",
    parent: "marine-equipment",
    slug: "dredging-bucket",
    titleFa: "باکت لایروبی",
    titleEn: "Dredging Bucket",
    listingType: "attachment",
    active: true,
  },

{
    id: "marine-grapple",
    parent: "marine-equipment",
    slug: "marine-grapple",
    titleFa: "گراپل دریایی",
    titleEn: "Marine Grapple",
    listingType: "attachment",
    active: true,
  },

{
    id: "underwater-hammer",
    parent: "marine-equipment",
    slug: "underwater-hammer",
    titleFa: "چکش زیرآبی",
    titleEn: "Underwater Hammer",
    listingType: "attachment",
    active: true,
  },

{
    id: "pile-driver",
    parent: "marine-equipment",
    slug: "pile-driver",
    titleFa: "شمع کوب",
    titleEn: "Pile Driver",
    listingType: "attachment",
    active: true,
  },

{
    id: "vibro-hammer",
    parent: "marine-equipment",
    slug: "vibro-hammer",
    titleFa: "ویبرو هامر",
    titleEn: "Vibro Hammer",
    listingType: "attachment",
    active: true,
  },

{
    id: "mining-equipment",
    parent: "attachments",
    slug: "mining-equipment",
    titleFa: "تجهیزات معدن",
    titleEn: "Mining Equipment",
    listingType: "attachment",
    children: [
      "rock-ripper",
      "mine-bucket",
      "ore-grapple",
      "scaling-hammer",
      "drill-feed"
    ],
    active: true,
  },

{
    id: "rock-ripper",
    parent: "mining-equipment",
    slug: "rock-ripper",
    titleFa: "ریپر سنگ",
    titleEn: "Rock Ripper",
    listingType: "attachment",
    active: true,
  },

{
    id: "mine-bucket",
    parent: "mining-equipment",
    slug: "mine-bucket",
    titleFa: "باکت معدنی",
    titleEn: "Mining Bucket",
    listingType: "attachment",
    active: true,
  },

{
    id: "ore-grapple",
    parent: "mining-equipment",
    slug: "ore-grapple",
    titleFa: "گراپل سنگ معدن",
    titleEn: "Ore Grapple",
    listingType: "attachment",
    active: true,
  },

{
    id: "scaling-hammer",
    parent: "mining-equipment",
    slug: "scaling-hammer",
    titleFa: "چکش اسکیلینگ",
    titleEn: "Scaling Hammer",
    listingType: "attachment",
    active: true,
  },

{
    id: "drill-feed",
    parent: "mining-equipment",
    slug: "drill-feed",
    titleFa: "فید دریل",
    titleEn: "Drill Feed",
    listingType: "attachment",
    active: true,
  },

{
    id: "tunneling-equipment",
    parent: "attachments",
    slug: "tunneling-equipment",
    titleFa: "تجهیزات تونل",
    titleEn: "Tunneling Equipment",
    listingType: "attachment",
    children: [
      "tunnel-breaker",
      "tunnel-bucket",
      "tunnel-grapple",
      "rock-cutter",
      "shotcrete-nozzle"
    ],
    active: true,
  },

{
    id: "tunnel-breaker",
    parent: "tunneling-equipment",
    slug: "tunnel-breaker",
    titleFa: "چکش تونل",
    titleEn: "Tunnel Breaker",
    listingType: "attachment",
    active: true,
  },

{
    id: "tunnel-bucket",
    parent: "tunneling-equipment",
    slug: "tunnel-bucket",
    titleFa: "باکت تونل",
    titleEn: "Tunnel Bucket",
    listingType: "attachment",
    active: true,
  },

{
    id: "tunnel-grapple",
    parent: "tunneling-equipment",
    slug: "tunnel-grapple",
    titleFa: "گراپل تونل",
    titleEn: "Tunnel Grapple",
    listingType: "attachment",
    active: true,
  },

{
    id: "rock-cutter",
    parent: "tunneling-equipment",
    slug: "rock-cutter",
    titleFa: "برش سنگ",
    titleEn: "Rock Cutter",
    listingType: "attachment",
    active: true,
  },

{
    id: "shotcrete-nozzle",
    parent: "tunneling-equipment",
    slug: "shotcrete-nozzle",
    titleFa: "نازل شاتکریت",
    titleEn: "Shotcrete Nozzle",
    listingType: "attachment",
    active: true,
  },

{
    id: "utility-equipment",
    parent: "attachments",
    slug: "utility-equipment",
    titleFa: "تجهیزات شهری",
    titleEn: "Utility Equipment",
    listingType: "attachment",
    children: [
      "pole-setter",
      "cable-plow",
      "trencher-chain",
      "vacuum-excavator",
      "pipe-handler"
    ],
    active: true,
  },

{
    id: "pole-setter",
    parent: "utility-equipment",
    slug: "pole-setter",
    titleFa: "نصب تیر برق",
    titleEn: "Pole Setter",
    listingType: "attachment",
    active: true,
  },

{
    id: "cable-plow",
    parent: "utility-equipment",
    slug: "cable-plow",
    titleFa: "کابل کار",
    titleEn: "Cable Plow",
    listingType: "attachment",
    active: true,
  },

{
    id: "trencher-chain",
    parent: "utility-equipment",
    slug: "trencher-chain",
    titleFa: "زنجیر ترنچر",
    titleEn: "Trencher Chain",
    listingType: "attachment",
    active: true,
  },

{
    id: "vacuum-excavator",
    parent: "utility-equipment",
    slug: "vacuum-excavator",
    titleFa: "حفار وکیومی",
    titleEn: "Vacuum Excavator",
    listingType: "attachment",
    active: true,
  },

{
    id: "pipe-handler",
    parent: "utility-equipment",
    slug: "pipe-handler",
    titleFa: "لوله گیر",
    titleEn: "Pipe Handler",
    listingType: "attachment",
    active: true,
  },

{
    id: "oil-gas-equipment",
    parent: "attachments",
    slug: "oil-gas-equipment",
    titleFa: "تجهیزات نفت و گاز",
    titleEn: "Oil & Gas Equipment",
    listingType: "attachment",
    children: [
      "pipeline-bucket",
      "pipeline-clamp",
      "pipe-grapple",
      "coating-remover",
      "welding-platform"
    ],
    active: true,
  },

{
    id: "pipeline-bucket",
    parent: "oil-gas-equipment",
    slug: "pipeline-bucket",
    titleFa: "باکت خط لوله",
    titleEn: "Pipeline Bucket",
    listingType: "attachment",
    active: true,
  },

{
    id: "pipeline-clamp",
    parent: "oil-gas-equipment",
    slug: "pipeline-clamp",
    titleFa: "گیره خط لوله",
    titleEn: "Pipeline Clamp",
    listingType: "attachment",
    active: true,
  },

{
    id: "pipe-grapple",
    parent: "oil-gas-equipment",
    slug: "pipe-grapple",
    titleFa: "گراپل لوله",
    titleEn: "Pipe Grapple",
    listingType: "attachment",
    active: true,
  },

{
    id: "coating-remover",
    parent: "oil-gas-equipment",
    slug: "coating-remover",
    titleFa: "پاک کننده پوشش",
    titleEn: "Coating Remover",
    listingType: "attachment",
    active: true,
  },

{
    id: "welding-platform",
    parent: "oil-gas-equipment",
    slug: "welding-platform",
    titleFa: "سکوی جوشکاری",
    titleEn: "Welding Platform",
    listingType: "attachment",
    active: true,
  }

];
