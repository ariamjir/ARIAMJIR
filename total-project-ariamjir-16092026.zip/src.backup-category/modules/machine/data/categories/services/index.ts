import type { MachineCategoryItem } from "../CategoryTypes";

export const services: MachineCategoryItem[] = [



];
