import type { MachineCategoryItem } from "../CategoryTypes";

export const documents: MachineCategoryItem[] = [



];
