import type { MachineCategoryItem } from "../CategoryTypes";

export const machines: MachineCategoryItem[] = [

{
    id: "earthmoving",
    parent: "machines",
    slug: "earthmoving",
    titleFa: "ماشین آلات خاکبرداری",
    titleEn: "Earthmoving Equipment",
    listingType: "machine",
    children: [
      "crawler-excavator",
      "wheel-excavator",
      "mini-excavator",
      "long-reach-excavator",
      "amphibious-excavator",
      "backhoe-loader",
      "wheel-loader",
      "compact-loader",
      "skid-steer",
      "track-loader",
      "bulldozer",
      "crawler-dozer"
    ],
    active: true,
  },

{
    id: "crawler-excavator",
    parent: "earthmoving",
    slug: "crawler-excavator",
    titleFa: "بیل مکانیکی زنجیری",
    titleEn: "Crawler Excavator",
    listingType: "machine",
    active: true,
  },

{
    id: "wheel-excavator",
    parent: "earthmoving",
    slug: "wheel-excavator",
    titleFa: "بیل مکانیکی چرخی",
    titleEn: "Wheel Excavator",
    listingType: "machine",
    active: true,
  },

{
    id: "mini-excavator",
    parent: "earthmoving",
    slug: "mini-excavator",
    titleFa: "مینی بیل",
    titleEn: "Mini Excavator",
    listingType: "machine",
    active: true,
  },

{
    id: "long-reach-excavator",
    parent: "earthmoving",
    slug: "long-reach-excavator",
    titleFa: "بیل لانگ ریچ",
    titleEn: "Long Reach Excavator",
    listingType: "machine",
    active: true,
  },

{
    id: "amphibious-excavator",
    parent: "earthmoving",
    slug: "amphibious-excavator",
    titleFa: "بیل شناور",
    titleEn: "Amphibious Excavator",
    listingType: "machine",
    active: true,
  },

{
    id: "wheel-loader",
    parent: "earthmoving",
    slug: "wheel-loader",
    titleFa: "لودر چرخی",
    titleEn: "Wheel Loader",
    listingType: "machine",
    active: true,
  },

{
    id: "compact-loader",
    parent: "earthmoving",
    slug: "compact-loader",
    titleFa: "لودر کامپکت",
    titleEn: "Compact Loader",
    listingType: "machine",
    active: true,
  },

{
    id: "track-loader",
    parent: "earthmoving",
    slug: "track-loader",
    titleFa: "لودر زنجیری",
    titleEn: "Track Loader",
    listingType: "machine",
    active: true,
  },

{
    id: "skid-steer",
    parent: "earthmoving",
    slug: "skid-steer",
    titleFa: "بابکت",
    titleEn: "Skid Steer Loader",
    listingType: "machine",
    active: true,
  },

{
    id: "backhoe-loader",
    parent: "earthmoving",
    slug: "backhoe-loader",
    titleFa: "بکهو لودر",
    titleEn: "Backhoe Loader",
    listingType: "machine",
    active: true,
  },

{
    id: "bulldozer",
    parent: "earthmoving",
    slug: "bulldozer",
    titleFa: "بولدوزر",
    titleEn: "Bulldozer",
    listingType: "machine",
    active: true,
  },

{
    id: "crawler-dozer",
    parent: "earthmoving",
    slug: "crawler-dozer",
    titleFa: "بولدوزر زنجیری",
    titleEn: "Crawler Dozer",
    listingType: "machine",
    active: true,
  },

{
    id: "road",
    parent: "machines",
    slug: "road",
    titleFa: "ماشین آلات راهسازی",
    titleEn: "Road Construction Equipment",
    listingType: "machine",
    children: [
      "motor-grader",
      "road-roller",
      "asphalt-paver",
      "cold-planer",
      "soil-stabilizer",
      "chip-spreader",
      "asphalt-distributor",
      "road-reclaimer"
    ],
    active: true,
  },

{
    id: "motor-grader",
    parent: "road",
    slug: "motor-grader",
    titleFa: "گریدر",
    titleEn: "Motor Grader",
    listingType: "machine",
    active: true,
  },

{
    id: "road-roller",
    parent: "road",
    slug: "road-roller",
    titleFa: "غلتک",
    titleEn: "Road Roller",
    listingType: "machine",
    active: true,
  },

{
    id: "asphalt-paver",
    parent: "road",
    slug: "asphalt-paver",
    titleFa: "فینیشر آسفالت",
    titleEn: "Asphalt Paver",
    listingType: "machine",
    active: true,
  },

{
    id: "cold-planer",
    parent: "road",
    slug: "cold-planer",
    titleFa: "ویرتگن",
    titleEn: "Cold Planer",
    listingType: "machine",
    active: true,
  },

{
    id: "soil-stabilizer",
    parent: "road",
    slug: "soil-stabilizer",
    titleFa: "استابلایزر",
    titleEn: "Soil Stabilizer",
    listingType: "machine",
    active: true,
  },

{
    id: "chip-spreader",
    parent: "road",
    slug: "chip-spreader",
    titleFa: "چیپ اسپریدر",
    titleEn: "Chip Spreader",
    listingType: "machine",
    active: true,
  },

{
    id: "asphalt-distributor",
    parent: "road",
    slug: "asphalt-distributor",
    titleFa: "قیرپاش",
    titleEn: "Asphalt Distributor",
    listingType: "machine",
    active: true,
  },

{
    id: "road-reclaimer",
    parent: "road",
    slug: "road-reclaimer",
    titleFa: "بازیافت آسفالت",
    titleEn: "Road Reclaimer",
    listingType: "machine",
    active: true,
  },

{
    id: "mining",
    parent: "machines",
    slug: "mining",
    titleFa: "ماشین آلات معدنی",
    titleEn: "Mining Equipment",
    listingType: "machine",
    children: [
      "mining-excavator",
      "rigid-dump-truck",
      "articulated-dump-truck",
      "wheel-dozer",
      "track-drill",
      "rotary-drill",
      "underground-loader",
      "underground-truck",
      "crusher",
      "screening-plant",
      "stacker",
      "conveyor"
    ],
    active: true,
  },

{
    id: "mining-excavator",
    parent: "mining",
    slug: "mining-excavator",
    titleFa: "بیل معدنی",
    titleEn: "Mining Excavator",
    listingType: "machine",
    active: true,
  },

{
    id: "rigid-dump-truck",
    parent: "mining",
    slug: "rigid-dump-truck",
    titleFa: "دامپتراک",
    titleEn: "Rigid Dump Truck",
    listingType: "machine",
    active: true,
  },

{
    id: "articulated-dump-truck",
    parent: "mining",
    slug: "articulated-dump-truck",
    titleFa: "دامپ مفصلی",
    titleEn: "Articulated Dump Truck",
    listingType: "machine",
    active: true,
  },

{
    id: "wheel-dozer",
    parent: "mining",
    slug: "wheel-dozer",
    titleFa: "ویل دوزر",
    titleEn: "Wheel Dozer",
    listingType: "machine",
    active: true,
  },

{
    id: "track-drill",
    parent: "mining",
    slug: "track-drill",
    titleFa: "دریل واگن",
    titleEn: "Track Drill",
    listingType: "machine",
    active: true,
  },

{
    id: "rotary-drill",
    parent: "mining",
    slug: "rotary-drill",
    titleFa: "دریل روتاری",
    titleEn: "Rotary Drill",
    listingType: "machine",
    active: true,
  },

{
    id: "underground-loader",
    parent: "mining",
    slug: "underground-loader",
    titleFa: "لودر زیرزمینی",
    titleEn: "Underground Loader",
    listingType: "machine",
    active: true,
  },

{
    id: "underground-truck",
    parent: "mining",
    slug: "underground-truck",
    titleFa: "کامیون زیرزمینی",
    titleEn: "Underground Truck",
    listingType: "machine",
    active: true,
  },

{
    id: "crusher",
    parent: "mining",
    slug: "crusher",
    titleFa: "سنگ شکن",
    titleEn: "Crusher",
    listingType: "machine",
    active: true,
  },

{
    id: "jaw-crusher",
    parent: "crusher",
    slug: "jaw-crusher",
    titleFa: "سنگ شکن فکی",
    titleEn: "Jaw Crusher",
    listingType: "machine",
    active: true,
  },

{
    id: "cone-crusher",
    parent: "crusher",
    slug: "cone-crusher",
    titleFa: "سنگ شکن مخروطی",
    titleEn: "Cone Crusher",
    listingType: "machine",
    active: true,
  },

{
    id: "impact-crusher",
    parent: "crusher",
    slug: "impact-crusher",
    titleFa: "سنگ شکن ضربه ای",
    titleEn: "Impact Crusher",
    listingType: "machine",
    active: true,
  },

{
    id: "hammer-crusher",
    parent: "crusher",
    slug: "hammer-crusher",
    titleFa: "سنگ شکن چکشی",
    titleEn: "Hammer Crusher",
    listingType: "machine",
    active: true,
  },

{
    id: "screening-plant",
    parent: "mining",
    slug: "screening-plant",
    titleFa: "سرند",
    titleEn: "Screening Plant",
    listingType: "machine",
    active: true,
  },

{
    id: "mobile-screen",
    parent: "screening-plant",
    slug: "mobile-screen",
    titleFa: "سرند موبایل",
    titleEn: "Mobile Screen",
    listingType: "machine",
    active: true,
  },

{
    id: "vibrating-screen",
    parent: "screening-plant",
    slug: "vibrating-screen",
    titleFa: "سرند لرزشی",
    titleEn: "Vibrating Screen",
    listingType: "machine",
    active: true,
  },

{
    id: "stacker",
    parent: "mining",
    slug: "stacker",
    titleFa: "استاکر",
    titleEn: "Stacker",
    listingType: "machine",
    active: true,
  },

{
    id: "conveyor",
    parent: "mining",
    slug: "conveyor",
    titleFa: "نوار نقاله",
    titleEn: "Conveyor",
    listingType: "machine",
    active: true,
  },

{
    id: "lifting",
    parent: "machines",
    slug: "lifting",
    titleFa: "ماشین آلات بالابری",
    titleEn: "Lifting Equipment",
    listingType: "machine",
    children: [
      "mobile-crane",
      "crawler-crane",
      "tower-crane",
      "truck-crane",
      "rough-terrain-crane",
      "all-terrain-crane",
      "pick-carry-crane",
      "telescopic-handler",
      "reach-stacker",
      "container-handler"
    ],
    active: true,
  },

{
    id: "mobile-crane",
    parent: "lifting",
    slug: "mobile-crane",
    titleFa: "جرثقیل موبایل",
    titleEn: "Mobile Crane",
    listingType: "machine",
    active: true,
  },

{
    id: "crawler-crane",
    parent: "lifting",
    slug: "crawler-crane",
    titleFa: "جرثقیل زنجیری",
    titleEn: "Crawler Crane",
    listingType: "machine",
    active: true,
  },

{
    id: "tower-crane",
    parent: "lifting",
    slug: "tower-crane",
    titleFa: "تاور کرین",
    titleEn: "Tower Crane",
    listingType: "machine",
    active: true,
  },

{
    id: "truck-crane",
    parent: "lifting",
    slug: "truck-crane",
    titleFa: "جرثقیل کامیونی",
    titleEn: "Truck Crane",
    listingType: "machine",
    active: true,
  },

{
    id: "rough-terrain-crane",
    parent: "lifting",
    slug: "rough-terrain-crane",
    titleFa: "جرثقیل آفرود",
    titleEn: "Rough Terrain Crane",
    listingType: "machine",
    active: true,
  },

{
    id: "all-terrain-crane",
    parent: "lifting",
    slug: "all-terrain-crane",
    titleFa: "جرثقیل همه جارو",
    titleEn: "All Terrain Crane",
    listingType: "machine",
    active: true,
  },

{
    id: "pick-carry-crane",
    parent: "lifting",
    slug: "pick-carry-crane",
    titleFa: "پیک اند کری",
    titleEn: "Pick & Carry Crane",
    listingType: "machine",
    active: true,
  },

{
    id: "telescopic-handler",
    parent: "lifting",
    slug: "telescopic-handler",
    titleFa: "تله هندلر",
    titleEn: "Telescopic Handler",
    listingType: "machine",
    active: true,
  },

{
    id: "reach-stacker",
    parent: "lifting",
    slug: "reach-stacker",
    titleFa: "ریچ استاکر",
    titleEn: "Reach Stacker",
    listingType: "machine",
    active: true,
  },

{
    id: "container-handler",
    parent: "lifting",
    slug: "container-handler",
    titleFa: "کانتینر هندلر",
    titleEn: "Container Handler",
    listingType: "machine",
    active: true,
  },

{
    id: "material-handling",
    parent: "machines",
    slug: "material-handling",
    titleFa: "جابجایی مواد",
    titleEn: "Material Handling",
    listingType: "machine",
    children: [
      "forklift",
      "warehouse-forklift",
      "electric-forklift",
      "diesel-forklift",
      "container-forklift",
      "pallet-truck",
      "order-picker",
      "stacker-forklift"
    ],
    active: true,
  },

{
    id: "forklift",
    parent: "material-handling",
    slug: "forklift",
    titleFa: "لیفتراک",
    titleEn: "Forklift",
    listingType: "machine",
    active: true,
  },

{
    id: "warehouse-forklift",
    parent: "material-handling",
    slug: "warehouse-forklift",
    titleFa: "لیفتراک انباری",
    titleEn: "Warehouse Forklift",
    listingType: "machine",
    active: true,
  },

{
    id: "electric-forklift",
    parent: "material-handling",
    slug: "electric-forklift",
    titleFa: "لیفتراک برقی",
    titleEn: "Electric Forklift",
    listingType: "machine",
    active: true,
  },

{
    id: "diesel-forklift",
    parent: "material-handling",
    slug: "diesel-forklift",
    titleFa: "لیفتراک دیزلی",
    titleEn: "Diesel Forklift",
    listingType: "machine",
    active: true,
  },

{
    id: "container-forklift",
    parent: "material-handling",
    slug: "container-forklift",
    titleFa: "لیفتراک کانتینری",
    titleEn: "Container Forklift",
    listingType: "machine",
    active: true,
  },

{
    id: "stacker-forklift",
    parent: "material-handling",
    slug: "stacker-forklift",
    titleFa: "استاکر",
    titleEn: "Stacker",
    listingType: "machine",
    active: true,
  },

{
    id: "order-picker",
    parent: "material-handling",
    slug: "order-picker",
    titleFa: "اُردر پیکر",
    titleEn: "Order Picker",
    listingType: "machine",
    active: true,
  },

{
    id: "pallet-truck",
    parent: "material-handling",
    slug: "pallet-truck",
    titleFa: "پالت تراک",
    titleEn: "Pallet Truck",
    listingType: "machine",
    active: true,
  },

{
    id: "concrete",
    parent: "machines",
    slug: "concrete",
    titleFa: "ماشین آلات بتن",
    titleEn: "Concrete Equipment",
    listingType: "machine",
    children: [
      "concrete-mixer",
      "transit-mixer",
      "concrete-pump",
      "boom-pump",
      "line-pump",
      "batching-plant",
      "concrete-placer",
      "shotcrete-machine"
    ],
    active: true,
  },

{
    id: "concrete-mixer",
    parent: "concrete",
    slug: "concrete-mixer",
    titleFa: "میکسر بتن",
    titleEn: "Concrete Mixer",
    listingType: "machine",
    active: true,
  },

{
    id: "transit-mixer",
    parent: "concrete",
    slug: "transit-mixer",
    titleFa: "تراک میکسر",
    titleEn: "Transit Mixer",
    listingType: "machine",
    active: true,
  },

{
    id: "concrete-pump",
    parent: "concrete",
    slug: "concrete-pump",
    titleFa: "پمپ بتن",
    titleEn: "Concrete Pump",
    listingType: "machine",
    active: true,
  },

{
    id: "boom-pump",
    parent: "concrete",
    slug: "boom-pump",
    titleFa: "پمپ دکل",
    titleEn: "Boom Pump",
    listingType: "machine",
    active: true,
  },

{
    id: "line-pump",
    parent: "concrete",
    slug: "line-pump",
    titleFa: "پمپ زمینی",
    titleEn: "Line Pump",
    listingType: "machine",
    active: true,
  },

{
    id: "batching-plant",
    parent: "concrete",
    slug: "batching-plant",
    titleFa: "بچینگ پلانت",
    titleEn: "Batching Plant",
    listingType: "machine",
    active: true,
  },

{
    id: "concrete-placer",
    parent: "concrete",
    slug: "concrete-placer",
    titleFa: "بتن ریز",
    titleEn: "Concrete Placer",
    listingType: "machine",
    active: true,
  },

{
    id: "shotcrete-machine",
    parent: "concrete",
    slug: "shotcrete-machine",
    titleFa: "شاتکریت",
    titleEn: "Shotcrete Machine",
    listingType: "machine",
    active: true,
  },

{
    id: "compaction",
    parent: "machines",
    slug: "compaction",
    titleFa: "تجهیزات تراکم",
    titleEn: "Compaction Equipment",
    listingType: "machine",
    children: [
      "single-drum-roller",
      "double-drum-roller",
      "pneumatic-roller",
      "padfoot-roller",
      "vibratory-roller",
      "plate-compactor",
      "rammer"
    ],
    active: true,
  },

{
    id: "single-drum-roller",
    parent: "compaction",
    slug: "single-drum-roller",
    titleFa: "غلتک تک درام",
    titleEn: "Single Drum Roller",
    listingType: "machine",
    active: true,
  },

{
    id: "double-drum-roller",
    parent: "compaction",
    slug: "double-drum-roller",
    titleFa: "غلتک دو درام",
    titleEn: "Double Drum Roller",
    listingType: "machine",
    active: true,
  },

{
    id: "pneumatic-roller",
    parent: "compaction",
    slug: "pneumatic-roller",
    titleFa: "غلتک لاستیکی",
    titleEn: "Pneumatic Roller",
    listingType: "machine",
    active: true,
  },

{
    id: "padfoot-roller",
    parent: "compaction",
    slug: "padfoot-roller",
    titleFa: "غلتک پاچه بزی",
    titleEn: "Padfoot Roller",
    listingType: "machine",
    active: true,
  },

{
    id: "vibratory-roller",
    parent: "compaction",
    slug: "vibratory-roller",
    titleFa: "غلتک ویبره",
    titleEn: "Vibratory Roller",
    listingType: "machine",
    active: true,
  },

{
    id: "plate-compactor",
    parent: "compaction",
    slug: "plate-compactor",
    titleFa: "کمپکتور صفحه ای",
    titleEn: "Plate Compactor",
    listingType: "machine",
    active: true,
  },

{
    id: "rammer",
    parent: "compaction",
    slug: "rammer",
    titleFa: "قورباغه",
    titleEn: "Rammer",
    listingType: "machine",
    active: true,
  },

{
    id: "drilling",
    parent: "machines",
    slug: "drilling",
    titleFa: "ماشین آلات حفاری",
    titleEn: "Drilling Equipment",
    listingType: "machine",
    children: [
      "water-drilling-rig",
      "foundation-drill",
      "anchor-drill",
      "core-drill",
      "horizontal-drill"
    ],
    active: true,
  },

{
    id: "water-drilling-rig",
    parent: "drilling",
    slug: "water-drilling-rig",
    titleFa: "دکل حفاری آب",
    titleEn: "Water Well Drilling Rig",
    listingType: "machine",
    active: true,
  },

{
    id: "foundation-drill",
    parent: "drilling",
    slug: "foundation-drill",
    titleFa: "دکل شمع کوبی",
    titleEn: "Foundation Drill",
    listingType: "machine",
    active: true,
  },

{
    id: "anchor-drill",
    parent: "drilling",
    slug: "anchor-drill",
    titleFa: "دکل انکراژ",
    titleEn: "Anchor Drill",
    listingType: "machine",
    active: true,
  },

{
    id: "core-drill",
    parent: "drilling",
    slug: "core-drill",
    titleFa: "کرگیری",
    titleEn: "Core Drill",
    listingType: "machine",
    active: true,
  },

{
    id: "horizontal-drill",
    parent: "drilling",
    slug: "horizontal-drill",
    titleFa: "حفاری افقی",
    titleEn: "Horizontal Directional Drill",
    listingType: "machine",
    active: true,
  },

{
    id: "agriculture",
    parent: "machines",
    slug: "agriculture",
    titleFa: "ماشین آلات کشاورزی",
    titleEn: "Agricultural Equipment",
    listingType: "machine",
    children: [
      "tractor",
      "combine-harvester",
      "sprayer",
      "seeder",
      "planter",
      "cultivator",
      "disc-harrow",
      "rotary-tiller",
      "baler",
      "forage-harvester",
      "fertilizer-spreader",
      "grain-cart"
    ],
    active: true,
  },

{
    id: "tractor",
    parent: "agriculture",
    slug: "tractor",
    titleFa: "تراکتور",
    titleEn: "Tractor",
    listingType: "machine",
    active: true,
  },

{
    id: "combine-harvester",
    parent: "agriculture",
    slug: "combine-harvester",
    titleFa: "کمباین",
    titleEn: "Combine Harvester",
    listingType: "machine",
    active: true,
  },

{
    id: "sprayer",
    parent: "agriculture",
    slug: "sprayer",
    titleFa: "سمپاش",
    titleEn: "Sprayer",
    listingType: "machine",
    active: true,
  },

{
    id: "seeder",
    parent: "agriculture",
    slug: "seeder",
    titleFa: "بذرکار",
    titleEn: "Seeder",
    listingType: "machine",
    active: true,
  },

{
    id: "planter",
    parent: "agriculture",
    slug: "planter",
    titleFa: "کارنده",
    titleEn: "Planter",
    listingType: "machine",
    active: true,
  },

{
    id: "cultivator",
    parent: "agriculture",
    slug: "cultivator",
    titleFa: "کولتیواتور",
    titleEn: "Cultivator",
    listingType: "machine",
    active: true,
  },

{
    id: "disc-harrow",
    parent: "agriculture",
    slug: "disc-harrow",
    titleFa: "دیسک",
    titleEn: "Disc Harrow",
    listingType: "machine",
    active: true,
  },

{
    id: "rotary-tiller",
    parent: "agriculture",
    slug: "rotary-tiller",
    titleFa: "روتیواتور",
    titleEn: "Rotary Tiller",
    listingType: "machine",
    active: true,
  },

{
    id: "baler",
    parent: "agriculture",
    slug: "baler",
    titleFa: "بیلر",
    titleEn: "Baler",
    listingType: "machine",
    active: true,
  },

{
    id: "forage-harvester",
    parent: "agriculture",
    slug: "forage-harvester",
    titleFa: "علوفه چین",
    titleEn: "Forage Harvester",
    listingType: "machine",
    active: true,
  },

{
    id: "fertilizer-spreader",
    parent: "agriculture",
    slug: "fertilizer-spreader",
    titleFa: "کودپاش",
    titleEn: "Fertilizer Spreader",
    listingType: "machine",
    active: true,
  },

{
    id: "grain-cart",
    parent: "agriculture",
    slug: "grain-cart",
    titleFa: "واگن غله",
    titleEn: "Grain Cart",
    listingType: "machine",
    active: true,
  },

{
    id: "forestry",
    parent: "machines",
    slug: "forestry",
    titleFa: "ماشین آلات جنگلداری",
    titleEn: "Forestry Equipment",
    listingType: "machine",
    children: [
      "harvester",
      "forwarder",
      "skidder",
      "feller-buncher",
      "log-loader",
      "wood-chipper",
      "stump-grinder",
      "mulcher"
    ],
    active: true,
  },

{
    id: "harvester",
    parent: "forestry",
    slug: "harvester",
    titleFa: "هاروستر",
    titleEn: "Harvester",
    listingType: "machine",
    active: true,
  },

{
    id: "forwarder",
    parent: "forestry",
    slug: "forwarder",
    titleFa: "فورواردر",
    titleEn: "Forwarder",
    listingType: "machine",
    active: true,
  },

{
    id: "skidder",
    parent: "forestry",
    slug: "skidder",
    titleFa: "اسکیدر",
    titleEn: "Skidder",
    listingType: "machine",
    active: true,
  },

{
    id: "feller-buncher",
    parent: "forestry",
    slug: "feller-buncher",
    titleFa: "فلر بانچر",
    titleEn: "Feller Buncher",
    listingType: "machine",
    active: true,
  },

{
    id: "log-loader",
    parent: "forestry",
    slug: "log-loader",
    titleFa: "لودر چوب",
    titleEn: "Log Loader",
    listingType: "machine",
    active: true,
  },

{
    id: "wood-chipper",
    parent: "forestry",
    slug: "wood-chipper",
    titleFa: "چیپر",
    titleEn: "Wood Chipper",
    listingType: "machine",
    active: true,
  },

{
    id: "stump-grinder",
    parent: "forestry",
    slug: "stump-grinder",
    titleFa: "ریشه خردکن",
    titleEn: "Stump Grinder",
    listingType: "machine",
    active: true,
  },

{
    id: "mulcher",
    parent: "forestry",
    slug: "mulcher",
    titleFa: "مالچر",
    titleEn: "Mulcher",
    listingType: "machine",
    active: true,
  },

{
    id: "recycling",
    parent: "machines",
    slug: "recycling",
    titleFa: "ماشین آلات بازیافت",
    titleEn: "Recycling Equipment",
    listingType: "machine",
    children: [
      "shredder",
      "mobile-crusher",
      "mobile-screen",
      "waste-compactor",
      "waste-sorter"
    ],
    active: true,
  },

{
    id: "shredder",
    parent: "recycling",
    slug: "shredder",
    titleFa: "خردکن صنعتی",
    titleEn: "Industrial Shredder",
    listingType: "machine",
    active: true,
  },

{
    id: "mobile-crusher",
    parent: "recycling",
    slug: "mobile-crusher",
    titleFa: "سنگ شکن سیار",
    titleEn: "Mobile Crusher",
    listingType: "machine",
    active: true,
  },

{
    id: "waste-compactor",
    parent: "recycling",
    slug: "waste-compactor",
    titleFa: "کمپکتور زباله",
    titleEn: "Waste Compactor",
    listingType: "machine",
    active: true,
  },

{
    id: "waste-sorter",
    parent: "recycling",
    slug: "waste-sorter",
    titleFa: "تفکیک زباله",
    titleEn: "Waste Sorting Machine",
    listingType: "machine",
    active: true,
  },

{
    id: "special",
    parent: "machines",
    slug: "special",
    titleFa: "ماشین آلات ویژه",
    titleEn: "Special Equipment",
    listingType: "machine",
    children: [
      "snow-blower",
      "airport-equipment",
      "tunnel-equipment",
      "pipeline-equipment",
      "demolition-equipment"
    ],
    active: true,
  }

];
