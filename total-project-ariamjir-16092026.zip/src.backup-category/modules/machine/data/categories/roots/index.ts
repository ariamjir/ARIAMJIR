import type { MachineCategoryItem } from "../CategoryTypes";

export const roots: MachineCategoryItem[] = [

{
    id: "machines",
    slug: "machines",
    parent: "root",
    titleFa: "ماشین آلات",
    titleEn: "Machines",
    icon: "machine",
    listingType: "machine",
    children: [
      "earthmoving",
      "road",
      "mining",
      "lifting",
      "concrete",
      "material-handling",
      "compaction",
      "drilling",
      "forestry",
      "agriculture",
      "recycling",
      "special"
    ],
    active: true,
    featured: true,
  },

{
    id: "attachments",
    slug: "attachments",
    parent: "root",
    titleFa: "اتچمنت",
    titleEn: "Attachments",
    icon: "attachment",
    listingType: "attachment",
    children: [
      "bucket",
      "breaker",
      "auger",
      "grapple",
      "quick-coupler",
      "fork",
      "ripper",
      "plate-compactor",
      "vibratory",
      "shear",
      "pulverizer",
      "crusher-bucket",
      "screening-bucket"
    ],
    active: true,
  },

{
    id: "spare-parts",
    slug: "spare-parts",
    parent: "root",
    titleFa: "قطعات یدکی",
    titleEn: "Spare Parts",
    icon: "parts",
    listingType: "part",
    active: true,
  },

{
    id: "lubricants",
    slug: "lubricants",
    parent: "root",
    titleFa: "روغن و روانکار",
    titleEn: "Lubricants",
    icon: "oil",
    listingType: "product",
    active: true,
  },

{
    id: "tires",
    slug: "tires",
    parent: "root",
    titleFa: "لاستیک و زنجیر",
    titleEn: "Tires & Tracks",
    icon: "tire",
    listingType: "product",
    active: true,
  },

{
    id: "tools",
    slug: "tools",
    parent: "root",
    titleFa: "ابزار",
    titleEn: "Tools",
    icon: "tool",
    listingType: "product",
    active: true,
  },

{
    id: "services",
    slug: "services",
    parent: "root",
    titleFa: "خدمات",
    titleEn: "Services",
    icon: "service",
    listingType: "service",
    active: true,
  },

{
    id: "manufacturers",
    slug: "manufacturers",
    parent: "root",
    titleFa: "برندها",
    titleEn: "Manufacturers",
    icon: "brand",
    listingType: "brand",
    active: true,
  },

{
    id: "documents",
    slug: "documents",
    parent: "root",
    titleFa: "اسناد",
    titleEn: "Documents",
    icon: "document",
    listingType: "document",
    active: true,
  },

{
    id: "attachments",
    parent: "root",
    slug: "attachments",
    titleFa: "اتچمنت ها",
    titleEn: "Attachments",
    icon: "attachment",
    listingType: "attachment",
    children: [
      "buckets",
      "breakers",
      "grapples",
      "augers",
      "rippers",
      "forks",
      "quick-couplers",
      "shears",
      "pulverizers",
      "compactors",
      "sweepers",
      "snow-equipment",
      "crusher-attachments",
      "lifting",
      "special-attachments"
    ],
    active: true,
  }

];
