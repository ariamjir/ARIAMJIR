import type { MachineCategoryItem } from "../CategoryTypes";

export const manufacturers: MachineCategoryItem[] = [



];
