import type { MachineBrand } from "../../types/brand";

export const americaBrands: MachineBrand[] = [

  {
    id: "caterpillar",
    slug: "caterpillar",
    name: "Caterpillar",
    nameFa: "کاترپیلار",
    country: "USA",
    countryFa: "ایالات متحده",
    foundedYear: 1925,
    headquarters: "Irving, Texas",
    website: "https://www.cat.com",
    featured: true,
    active: true,
    categories: [
      "excavator",
      "wheel-loader",
      "dozer",
      "grader",
      "roller",
      "dump-truck",
      "mining",
      "engine",
      "generator"
    ]
  },

  {
    id: "john-deere",
    slug: "john-deere",
    name: "John Deere",
    nameFa: "جان دیر",
    country: "USA",
    countryFa: "ایالات متحده",
    foundedYear: 1837,
    headquarters: "Illinois",
    website: "https://www.deere.com",
    featured: true,
    active: true,
    categories: [
      "excavator",
      "wheel-loader",
      "grader",
      "dozer",
      "backhoe-loader",
      "skid-steer",
      "agriculture"
    ]
  },

  {
    id: "case",
    slug: "case",
    name: "CASE Construction",
    nameFa: "کیس",
    country: "USA",
    countryFa: "ایالات متحده",
    foundedYear: 1842,
    headquarters: "Wisconsin",
    website: "https://www.casece.com",
    featured: true,
    active: true,
    categories: [
      "excavator",
      "wheel-loader",
      "backhoe-loader",
      "grader",
      "dozer",
      "roller"
    ]
  },

  {
    id: "bobcat",
    slug: "bobcat",
    name: "Bobcat",
    nameFa: "بابکت",
    country: "USA",
    countryFa: "ایالات متحده",
    foundedYear: 1947,
    headquarters: "North Dakota",
    website: "https://www.bobcat.com",
    featured: true,
    active: true,
    categories: [
      "skid-steer",
      "mini-excavator",
      "telehandler",
      "loader"
    ]
  },

  {
    id: "terex",
    slug: "terex",
    name: "Terex",
    nameFa: "ترکس",
    country: "USA",
    countryFa: "ایالات متحده",
    foundedYear: 1933,
    headquarters: "Connecticut",
    website: "https://www.terex.com",
    featured: true,
    active: true,
    categories: [
      "crawler-crane",
      "truck-crane",
      "rough-terrain-crane",
      "tower-crane"
    ]
  },

  {
    id: "genie",
    slug: "genie",
    name: "Genie",
    nameFa: "جنی",
    country: "USA",
    countryFa: "ایالات متحده",
    foundedYear: 1966,
    headquarters: "Washington",
    website: "https://www.genielift.com",
    active: true,
    categories: [
      "telehandler"
    ]
  },

  {
    id: "vermeer",
    slug: "vermeer",
    name: "Vermeer",
    nameFa: "ورمیر",
    country: "USA",
    countryFa: "ایالات متحده",
    foundedYear: 1948,
    headquarters: "Iowa",
    website: "https://www.vermeer.com",
    active: true,
    categories: [
      "drill-rig",
      "agriculture"
    ]
  },

  {
    id: "ditch-witch",
    slug: "ditch-witch",
    name: "Ditch Witch",
    nameFa: "دیچ ویچ",
    country: "USA",
    countryFa: "ایالات متحده",
    foundedYear: 1949,
    headquarters: "Oklahoma",
    website: "https://www.ditchwitch.com",
    active: true,
    categories: [
      "drill-rig"
    ]
  },

  {
    id: "gradall",
    slug: "gradall",
    name: "Gradall",
    nameFa: "گرادال",
    country: "USA",
    countryFa: "ایالات متحده",
    foundedYear: 1946,
    headquarters: "Ohio",
    website: "https://www.gradall.com",
    active: true,
    categories: [
      "excavator"
    ]
  },

  {
    id: "link-belt",
    slug: "link-belt",
    name: "Link-Belt",
    nameFa: "لینک بلت",
    country: "USA",
    countryFa: "ایالات متحده",
    foundedYear: 1874,
    headquarters: "Kentucky",
    website: "https://www.linkbelt.com",
    active: true,
    categories: [
      "excavator",
      "crawler-crane"
    ]
  },

  {
    id: "grove",
    slug: "grove",
    name: "Grove",
    nameFa: "گروو",
    country: "USA",
    countryFa: "ایالات متحده",
    foundedYear: 1947,
    headquarters: "Pennsylvania",
    website: "https://www.manitowoc.com",
    active: true,
    categories: [
      "truck-crane",
      "rough-terrain-crane",
      "crawler-crane"
    ]
  },

  {
    id: "manitowoc",
    slug: "manitowoc",
    name: "Manitowoc",
    nameFa: "منیتووک",
    country: "USA",
    countryFa: "ایالات متحده",
    foundedYear: 1902,
    headquarters: "Wisconsin",
    website: "https://www.manitowoc.com",
    active: true,
    categories: [
      "crawler-crane",
      "tower-crane"
    ]
  },

  {
    id: "jlg",
    slug: "jlg",
    name: "JLG",
    nameFa: "جی ال جی",
    country: "USA",
    countryFa: "ایالات متحده",
    foundedYear: 1969,
    headquarters: "Pennsylvania",
    website: "https://www.jlg.com",
    active: true,
    categories: [
      "telehandler"
    ]
  },

  {
    id: "skytrak",
    slug: "skytrak",
    name: "SkyTrak",
    nameFa: "اسکای ترک",
    country: "USA",
    countryFa: "ایالات متحده",
    website: "https://www.jlg.com",
    active: true,
    categories: [
      "telehandler"
    ]
  },

  {
    id: "pettibone",
    slug: "pettibone",
    name: "Pettibone",
    nameFa: "پتی بون",
    country: "USA",
    countryFa: "ایالات متحده",
    foundedYear: 1881,
    headquarters: "Illinois",
    website: "https://www.gopettibone.com",
    active: true,
    categories: [
      "telehandler",
      "forklift"
    ]
  },

  {
    id: "mustang",
    slug: "mustang",
    name: "Mustang",
    nameFa: "ماستانگ",
    country: "USA",
    countryFa: "ایالات متحده",
    active: true,
    categories: [
      "skid-steer"
    ]
  },

  {
    id: "gehl",
    slug: "gehl",
    name: "Gehl",
    nameFa: "گهل",
    country: "USA",
    countryFa: "ایالات متحده",
    foundedYear: 1859,
    headquarters: "Wisconsin",
    website: "https://www.gehl.com",
    active: true,
    categories: [
      "skid-steer",
      "telehandler"
    ]
  },

  {
    id: "takeuchi-usa",
    slug: "takeuchi-usa",
    name: "Takeuchi USA",
    nameFa: "تاکئوچی آمریکا",
    country: "USA",
    countryFa: "ایالات متحده",
    website: "https://www.takeuchi-us.com",
    active: true,
    categories: [
      "mini-excavator",
      "skid-steer"
    ]
  },

  {
    id: "astec",
    slug: "astec",
    name: "Astec",
    nameFa: "استک",
    country: "USA",
    countryFa: "ایالات متحده",
    foundedYear: 1972,
    headquarters: "Tennessee",
    website: "https://www.astecindustries.com",
    active: true,
    categories: [
      "roller",
      "asphalt-paver",
      "cold-planer"
    ]
  },

  {
    id: "leeboy",
    slug: "leeboy",
    name: "LeeBoy",
    nameFa: "لی بوی",
    country: "USA",
    countryFa: "ایالات متحده",
    foundedYear: 1964,
    headquarters: "North Carolina",
    website: "https://www.leeboy.com",
    active: true,
    categories: [
      "asphalt-paver",
      "roller"
    ]
  },

  {
    id: "ingersoll-rand",
    slug: "ingersoll-rand",
    name: "Ingersoll Rand",
    nameFa: "اینگرسول رند",
    country: "USA",
    countryFa: "ایالات متحده",
    foundedYear: 1871,
    headquarters: "North Carolina",
    website: "https://www.irco.com",
    active: true,
    categories: [
      "compressor",
      "roller"
    ]
  },

  {
    id: "multiquip",
    slug: "multiquip",
    name: "Multiquip",
    nameFa: "مالتی کویپ",
    country: "USA",
    countryFa: "ایالات متحده",
    foundedYear: 1973,
    headquarters: "California",
    website: "https://www.multiquip.com",
    active: true,
    categories: [
      "generator",
      "roller",
      "compactor"
    ]
  },

  {
    id: "mec",
    slug: "mec",
    name: "MEC",
    nameFa: "ام ای سی",
    country: "USA",
    countryFa: "ایالات متحده",
    website: "https://www.mecawp.com",
    active: true,
    categories: [
      "telehandler"
    ]
  },

  {
    id: "broderson",
    slug: "broderson",
    name: "Broderson",
    nameFa: "برودرسون",
    country: "USA",
    countryFa: "ایالات متحده",
    website: "https://www.broderson.com",
    active: true,
    categories: [
      "truck-crane"
    ]
  },

  {
    id: "kobelco-usa",
    slug: "kobelco-usa",
    name: "Kobelco USA",
    nameFa: "کوبلکو آمریکا",
    country: "USA",
    countryFa: "ایالات متحده",
    website: "https://www.kobelco-usa.com",
    active: true,
    categories: [
      "excavator"
    ]
  },

    {
    id: "national-crane",
    slug: "national-crane",
    name: "National Crane",
    nameFa: "نشنال کرین",
    country: "USA",
    countryFa: "ایالات متحده",
    foundedYear: 1945,
    headquarters: "Nebraska",
    website: "https://www.manitowoc.com",
    active: true,
    categories: [
      "truck-crane"
    ]
  },

  {
    id: "elliott",
    slug: "elliott",
    name: "Elliott Equipment",
    nameFa: "الیوت",
    country: "USA",
    countryFa: "ایالات متحده",
    foundedYear: 1948,
    headquarters: "Nebraska",
    website: "https://elliottequip.com",
    active: true,
    categories: [
      "truck-crane"
    ]
  },

  {
    id: "hyster",
    slug: "hyster",
    name: "Hyster",
    nameFa: "هایستر",
    country: "USA",
    countryFa: "ایالات متحده",
    foundedYear: 1929,
    headquarters: "Ohio",
    website: "https://www.hyster.com",
    featured: true,
    active: true,
    categories: [
      "forklift"
    ]
  },

  {
    id: "yale",
    slug: "yale",
    name: "Yale",
    nameFa: "ییل",
    country: "USA",
    countryFa: "ایالات متحده",
    foundedYear: 1844,
    headquarters: "Ohio",
    website: "https://www.yale.com",
    featured: true,
    active: true,
    categories: [
      "forklift"
    ]
  },

  {
    id: "clark",
    slug: "clark",
    name: "Clark",
    nameFa: "کلارک",
    country: "USA",
    countryFa: "ایالات متحده",
    foundedYear: 1903,
    headquarters: "Kentucky",
    website: "https://www.clarkmhc.com",
    active: true,
    categories: [
      "forklift"
    ]
  },

  {
    id: "taylor",
    slug: "taylor",
    name: "Taylor Machine Works",
    nameFa: "تیلور",
    country: "USA",
    countryFa: "ایالات متحده",
    foundedYear: 1927,
    headquarters: "Mississippi",
    website: "https://www.taylorforklifts.com",
    active: true,
    categories: [
      "forklift"
    ]
  },

  {
    id: "skyjack-usa",
    slug: "skyjack-usa",
    name: "Skyjack USA",
    nameFa: "اسکای جک",
    country: "USA",
    countryFa: "ایالات متحده",
    website: "https://www.skyjack.com",
    active: true,
    categories: [
      "telehandler"
    ]
  },

  {
    id: "terex-utilities",
    slug: "terex-utilities",
    name: "Terex Utilities",
    nameFa: "ترکس یوتیلیتی",
    country: "USA",
    countryFa: "ایالات متحده",
    website: "https://www.terex.com/utilities",
    active: true,
    categories: [
      "truck-crane"
    ]
  },

  {
    id: "miller-industries",
    slug: "miller-industries",
    name: "Miller Industries",
    nameFa: "میلر",
    country: "USA",
    countryFa: "ایالات متحده",
    foundedYear: 1990,
    headquarters: "Tennessee",
    website: "https://www.millerind.com",
    active: true,
    categories: [
      "truck-crane"
    ]
  },

  {
    id: "peterson",
    slug: "peterson",
    name: "Peterson",
    nameFa: "پیترسون",
    country: "USA",
    countryFa: "ایالات متحده",
    website: "https://petersoncorp.com",
    active: true,
    categories: [
      "forestry",
      "attachment"
    ]
  },

  {
    id: "morbark",
    slug: "morbark",
    name: "Morbark",
    nameFa: "موربارک",
    country: "USA",
    countryFa: "ایالات متحده",
    foundedYear: 1957,
    headquarters: "Michigan",
    website: "https://www.morbark.com",
    active: true,
    categories: [
      "forestry",
      "attachment"
    ]
  },

  {
    id: "tigercat-usa",
    slug: "tigercat-usa",
    name: "Tigercat USA",
    nameFa: "تایگرکت",
    country: "USA",
    countryFa: "ایالات متحده",
    website: "https://www.tigercat.com",
    active: true,
    categories: [
      "forestry"
    ]
  },

  {
    id: "bandit",
    slug: "bandit",
    name: "Bandit Industries",
    nameFa: "بندیت",
    country: "USA",
    countryFa: "ایالات متحده",
    foundedYear: 1983,
    headquarters: "Michigan",
    website: "https://banditchippers.com",
    active: true,
    categories: [
      "forestry"
    ]
  },

  {
    id: "vacall",
    slug: "vacall",
    name: "Vacall",
    nameFa: "واکال",
    country: "USA",
    countryFa: "ایالات متحده",
    website: "https://www.vacall.com",
    active: true,
    categories: [
      "truck-crane"
    ]
  },

  {
    id: "altec",
    slug: "altec",
    name: "Altec",
    nameFa: "آلتک",
    country: "USA",
    countryFa: "ایالات متحده",
    foundedYear: 1929,
    headquarters: "Alabama",
    website: "https://www.altec.com",
    active: true,
    categories: [
      "truck-crane"
    ]
  },

  {
    id: "broce",
    slug: "broce",
    name: "Broce Broom",
    nameFa: "بروس",
    country: "USA",
    countryFa: "ایالات متحده",
    foundedYear: 1961,
    headquarters: "Kansas",
    website: "https://www.brocebroom.com",
    active: true,
    categories: [
      "sweeper"
    ]
  },

  {
    id: "schwarze",
    slug: "schwarze",
    name: "Schwarze",
    nameFa: "شوارتزه",
    country: "USA",
    countryFa: "ایالات متحده",
    website: "https://www.schwarze.com",
    active: true,
    categories: [
      "sweeper"
    ]
  },

  {
    id: "laymor",
    slug: "laymor",
    name: "LayMor",
    nameFa: "لیمور",
    country: "USA",
    countryFa: "ایالات متحده",
    website: "https://www.laymor.com",
    active: true,
    categories: [
      "sweeper"
    ]
  },

  {
    id: "lee-boy",
    slug: "lee-boy",
    name: "LeeBoy",
    nameFa: "لی بوی",
    country: "USA",
    countryFa: "ایالات متحده",
    website: "https://www.leeboy.com",
    active: true,
    categories: [
      "asphalt-paver",
      "roller"
    ]
  },

  {
    id: "roadtec",
    slug: "roadtec",
    name: "Roadtec",
    nameFa: "رودتک",
    country: "USA",
    countryFa: "ایالات متحده",
    website: "https://www.astecindustries.com",
    active: true,
    categories: [
      "cold-planer",
      "asphalt-paver"
    ]
  },

  {
    id: "cmi",
    slug: "cmi",
    name: "CMI",
    nameFa: "سی ام آی",
    country: "USA",
    countryFa: "ایالات متحده",
    active: true,
    categories: [
      "cold-planer",
      "stabilizer"
    ]
  },

  {
    id: "gomaco",
    slug: "gomaco",
    name: "GOMACO",
    nameFa: "گوماکو",
    country: "USA",
    countryFa: "ایالات متحده",
    foundedYear: 1965,
    headquarters: "Iowa",
    website: "https://www.gomaco.com",
    active: true,
    categories: [
      "concrete"
    ]
  },

  {
    id: "miller-curber",
    slug: "miller-curber",
    name: "Miller Curber",
    nameFa: "میلر کربر",
    country: "USA",
    countryFa: "ایالات متحده",
    active: true,
    categories: [
      "concrete"
    ]
  },

  {
    id: "advance",
    slug: "advance",
    name: "Advance",
    nameFa: "ادونس",
    country: "USA",
    countryFa: "ایالات متحده",
    active: true,
    categories: [
      "concrete"
    ]
  },

  {
    id: "allen-engineering",
    slug: "allen-engineering",
    name: "Allen Engineering",
    nameFa: "آلن",
    country: "USA",
    countryFa: "ایالات متحده",
    website: "https://www.alleneng.com",
    active: true,
    categories: [
      "concrete"
    ]
  },

  {
    id: "snorkel",
    slug: "snorkel",
    name: "Snorkel",
    nameFa: "اسنورکل",
    country: "USA",
    countryFa: "ایالات متحده",
    website: "https://www.snorkellifts.com",
    active: true,
    categories: [
      "telehandler"
    ]
  },

  {
    id: "haulotte-usa",
    slug: "haulotte-usa",
    name: "Haulotte USA",
    nameFa: "هالوت آمریکا",
    country: "USA",
    countryFa: "ایالات متحده",
    website: "https://www.haulotte-usa.com",
    active: true,
    categories: [
      "telehandler"
    ]
  },

  {
    id: "magni-usa",
    slug: "magni-usa",
    name: "Magni USA",
    nameFa: "مگنی آمریکا",
    country: "USA",
    countryFa: "ایالات متحده",
    website: "https://www.magnith.com",
    active: true,
    categories: [
      "telehandler"
    ]
  },

  {
    id: "xcmg-usa",
    slug: "xcmg-usa",
    name: "XCMG USA",
    nameFa: "ایکس سی ام جی آمریکا",
    country: "USA",
    countryFa: "ایالات متحده",
    website: "https://www.xcmgna.com",
    active: true,
    categories: [
      "excavator",
      "wheel-loader",
      "crane"
    ]
  },

  {
    id: "sany-usa",
    slug: "sany-usa",
    name: "SANY USA",
    nameFa: "سانی آمریکا",
    country: "USA",
    countryFa: "ایالات متحده",
    website: "https://www.sanyamerica.com",
    active: true,
    categories: [
      "excavator",
      "wheel-loader",
      "crane"
    ]
  }

];