import type { MachineBrand } from "../../types";
import { americaBrands } from "./america";
import { japanBrands } from "./japan";
import { chinaBrands } from "./china";
import { germanyBrands } from "./germany";
import { italyBrands } from "./italy";
import { franceBrands } from "./france";
import { ukBrands } from "./uk";
import { swedenBrands } from "./sweden";
import { finlandBrands } from "./finland";
import { southKoreaBrands } from "./south-korea";
import { indiaBrands } from "./india";
import { turkeyBrands } from "./turkey";
import { iranBrands } from "./iran";
import { otherBrands } from "./other";

export const machineBrands: MachineBrand[] = [

  ...americaBrands,

  ...japanBrands,

  ...chinaBrands,

  ...germanyBrands,

  ...italyBrands,

  ...franceBrands,

  ...ukBrands,

  ...swedenBrands,

  ...finlandBrands,

  ...southKoreaBrands,

  ...indiaBrands,

  ...turkeyBrands,

  ...iranBrands,

  ...otherBrands,

];

export default machineBrands;