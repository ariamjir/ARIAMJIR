import { FormProvider, useForm } from "react-hook-form";

import { zodResolver } from "@hookform/resolvers/zod";

import { machineDefaultValues } from "../data/defaultValues";

import {
  machineSchema,
  type MachineFormData,
} from "../schema";