"use client";

import { useEffect, useMemo, useState } from "react";

import { FormProvider } from "react-hook-form";

import useMachineForm from "../hooks/useMachineForm";

import MachineStepper from "./MachineStepper";

import MachineActions from "./MachineActions";

import Step01 from "../steps/Step01SelectPlan";
import Step02 from "../steps/Step02BasicInfo";
import Step03 from "../steps/Step03CategoryWizard";
import Step04 from "../steps/Step04Technical";
import Step05 from "../steps/Step05Features";
import Step06 from "../steps/Step06Location";
import Step07 from "../steps/Step07Pricing";
import Step08 from "../steps/Step08Media";
import Step09 from "../steps/Step09Seller";
import Step10 from "../steps/Step10Seo";
import Step11 from "../steps/Step11Settings";
import Step12 from "../steps/Step12Preview";
import Step13 from "../steps/Step13Submit";

import { validateStep } from "../utils/validateStep";

import { machineService } from "../services/machine.service";

/* ============================================================
   STEPS CONFIG
============================================================ */

const steps = [
  { id: 1, title: "پلن آگهی", description: "انتخاب نوع آگهی" },
  { id: 2, title: "اطلاعات پایه", description: "عنوان و مشخصات" },
  { id: 3, title: "دسته بندی", description: "برند و مدل" },
  { id: 4, title: "مشخصات فنی", description: "اطلاعات تخصصی" },
  { id: 5, title: "امکانات", description: "آپشن ها" },
  { id: 6, title: "موقعیت", description: "کشور و شهر" },
  { id: 7, title: "قیمت", description: "فروش و شرایط" },
  { id: 8, title: "رسانه", description: "تصاویر و ویدئو" },
  { id: 9, title: "فروشنده", description: "اطلاعات تماس" },
  { id: 10, title: "SEO", description: "بهینه سازی" },
  { id: 11, title: "تنظیمات", description: "وضعیت آگهی" },
  { id: 12, title: "پیش نمایش", description: "بررسی نهایی" },
  { id: 13, title: "ثبت", description: "انتشار آگهی" },
];

const LAST_STEP = 13;

const DRAFT_KEY = "machine-draft";

/* ============================================================
   COMPONENT
============================================================ */

export default function MachineWizard() {
  const form = useMachineForm();

  const [step, setStep] = useState<number>(1);

  const [loading, setLoading] = useState(false);

  const [draftRestored, setDraftRestored] = useState(false);

  /* ============================================================
      بازیابی پیش‌نویس ذخیره‌شده
      ------------------------------------------------------------
      قبلاً saveDraft فقط می‌نوشت ولی هیچ‌جا خوانده نمی‌شد؛
      حالا هنگام ورود، پیش‌نویس بازیابی می‌شود تا کاربر با
      یک reload یا خطا، زحمتش را از دست ندهد.
  ============================================================ */

  useEffect(() => {
    try {
      const raw = localStorage.getItem(DRAFT_KEY);
      if (!raw) return;

      const draft = JSON.parse(raw);

      /* ادغام با defaultها تا فیلدهای جدیدِ schema نشکنند */
      form.reset({ ...form.getValues(), ...draft });

      setDraftRestored(true);
    } catch {
      /* پیش‌نویس خراب — نادیده بگیر */
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const discardDraft = () => {
    try {
      localStorage.removeItem(DRAFT_KEY);
    } catch {
      /* ignore */
    }
    form.reset();
    setDraftRestored(false);
    setStep(1);
  };

  const progress = useMemo(() => {
    return Math.round((step / LAST_STEP) * 100);
  }, [step]);

  /* ============================================================
      SUBMIT
  ============================================================ */

  const submit = form.handleSubmit(
    async (data) => {
      try {
        setLoading(true);

        await machineService.create(data);

        localStorage.removeItem(DRAFT_KEY);

        alert("آگهی با موفقیت ثبت شد.");
      } catch (error) {
        console.error(error);

        alert("ثبت آگهی با خطا مواجه شد.");
      } finally {
        setLoading(false);
      }
    },
    (errors) => {
      console.warn("submit blocked:", errors);

      const confirmKeys = [
        "confirmAccuracy",
        "confirmRules",
        "confirmPublish",
        "confirmFinancial",
      ];

      const blockedByTerms = confirmKeys.some(
        (k) => errors[k as keyof typeof errors]
      );

      if (!blockedByTerms) {
        alert(
          "برخی اطلاعات هنوز ناقص است؛ لطفاً مراحل قبل را تکمیل کنید."
        );
      }
    }
  );

  /* ============================================================
      RENDER STEP
  ============================================================ */

  const renderStep = () => {
    switch (step) {
      case 1:
        return <Step01 />;
      case 2:
        return <Step02 />;
      case 3:
        return <Step03 />;
      case 4:
        return <Step04 />;
      case 5:
        return <Step05 />;
      case 6:
        return <Step06 />;
      case 7:
        return <Step07 />;
      case 8:
        return <Step08 />;
      case 9:
        return <Step09 />;
      case 10:
        return <Step10 />;
      case 11:
        return <Step11 />;
      case 12:
        return <Step12 />;
      case 13:
        return <Step13 onSubmit={submit} isAdmin />;
      default:
        return <Step01 />;
    }
  };

  /* ============================================================
      NEXT / PREVIOUS / GO TO
  ============================================================ */

  const nextStep = async () => {
    const valid = await validateStep(step, form);

    if (!valid) {
      return;
    }

    if (step < LAST_STEP) {
      setStep((prev) => prev + 1);
    }
  };

  const previousStep = () => {
    if (step > 1) {
      setStep((prev) => prev - 1);
    }
  };

  const goTo = async (targetStep: number) => {
    if (targetStep === step) return;
    if (targetStep < 1 || targetStep > LAST_STEP) return;

    if (targetStep > step) {
      for (let s = step; s < targetStep; s++) {
        const valid = await validateStep(s, form);
        if (!valid) {
          setStep(s);
          return;
        }
      }
    }

    setStep(targetStep);
  };

  /* ============================================================
      SAVE DRAFT
  ============================================================ */

  const saveDraft = () => {
    try {
      const values = form.getValues();

      localStorage.setItem(DRAFT_KEY, JSON.stringify(values));

      alert("پیش‌نویس ذخیره شد.");
    } catch (error) {
      console.error(error);
    }
  };

  /* ============================================================
      PREVIEW
  ============================================================ */

  const preview = async () => {
    for (let s = 1; s < 12; s++) {
      const valid = await validateStep(s, form);
      if (!valid) {
        setStep(s);
        return;
      }
    }

    setStep(12);
  };

  /* ============================================================
      RENDER
  ============================================================ */

  return (
    <FormProvider {...form}>
      <form onSubmit={submit} className="space-y-8">
        {/* ===== banner بازیابی پیش‌نویس ===== */}
        {draftRestored && (
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-emerald-200 bg-emerald-50 p-4">
            <p className="text-sm font-semibold text-emerald-800">
              پیش‌نویس قبلی شما بازیابی شد؛ می‌توانید ادامه دهید یا از نو شروع کنید.
            </p>
            <button
              type="button"
              onClick={discardDraft}
              className="rounded-lg border border-emerald-300 bg-white px-3 py-1.5 text-xs font-bold text-emerald-700 transition hover:bg-emerald-100"
            >
              شروع از نو
            </button>
          </div>
        )}

        <MachineStepper
          steps={steps}
          currentStep={step}
          progress={progress}
          onChange={goTo}
        />

        <div className="rounded-2xl border border-gray-200 bg-white p-6 shadow-sm">
          {renderStep()}
        </div>

        <MachineActions
          step={step}
          maxStep={LAST_STEP}
          loading={loading}
          onPrevious={previousStep}
          onNext={nextStep}
          onSaveDraft={saveDraft}
          onPreview={preview}
          onSubmit={submit}
        />
      </form>
    </FormProvider>
  );
}