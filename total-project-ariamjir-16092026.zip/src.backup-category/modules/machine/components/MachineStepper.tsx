"use client";

interface Step{

id:number;

title:string;

}

interface Props{

steps:Step[];

currentStep:number;

progress:number;

onChange?:(step:number)=>void;

}

export default function MachineStepper({

steps,

currentStep,

progress,

onChange,

}:Props){

return(

<div className="space-y-6">

    <div>

<div className="mb-2 flex items-center justify-between">

<h2 className="text-xl font-bold">

ثبت ماشین‌آلات

</h2>

<span className="text-sm text-gray-500">

{progress}%

</span>

</div>

<div className="h-2 w-full overflow-hidden rounded-full bg-gray-200">

<div

className="h-full rounded-full bg-orange-500 transition-all duration-300"

style={{

width:`${progress}%`

}}

/>

</div>

</div>

<div className="grid grid-cols-2 gap-3 md:grid-cols-4 lg:grid-cols-7">

{

steps.map(step=>(

<button

key={step.id}

type="button"

onClick={()=>onChange?.(step.id)}

className={`rounded-xl border p-3 text-center transition-all

${

step.id===currentStep

?"border-orange-500 bg-orange-500 text-white"

:step.id<currentStep

?"border-green-500 bg-green-50"

:"border-gray-300 hover:border-orange-300"

}

`}

>

    <div

className="mb-2 text-lg font-bold"

>

{step.id}

</div>

<div

className="text-xs"

>

{step.title}

</div>

</button>

))

}

</div>

</div>

);

}

