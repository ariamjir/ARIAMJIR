"use client";

interface Props {

  step: number;

  maxStep: number;

  loading?: boolean;

  onPrevious: () => void;

  onNext: () => void;

  onSaveDraft: () => void;

  onPreview: () => void;

  onSubmit: () => void;

}

export default function MachineActions({

  step,

  maxStep,

  loading,

  onPrevious,

  onNext,

  onSaveDraft,

  onPreview,

  onSubmit,

}: Props) {

    const isLastStep =

step === maxStep;

return (

<div className="mt-10 flex flex-wrap items-center justify-between gap-4">

    <div className="flex gap-3">

<button

type="button"

onClick={onPrevious}

disabled={step===1}

className="rounded-xl border px-5 py-3 disabled:opacity-40"

>

مرحله قبل

</button>

<button

type="button"

onClick={onSaveDraft}

className="rounded-xl border px-5 py-3 hover:bg-gray-50"

>

ذخیره پیش‌نویس

</button>

<button

type="button"

onClick={onPreview}

className="rounded-xl border px-5 py-3 hover:bg-gray-50"

>

پیش‌نمایش

</button>

</div>

<div>

{

!isLastStep ? (

<button

type="button"

onClick={onNext}

className="rounded-xl bg-orange-500 px-6 py-3 text-white"

>

مرحله بعد

</button>

) : (

    <button

type="button"

disabled={loading}

onClick={onSubmit}

className="rounded-xl bg-green-600 px-6 py-3 text-white disabled:opacity-50"

>

{

loading

? "در حال ثبت..."

: "ثبت نهایی آگهی"

}

</button>

)

}

</div>

</div>

);

}

