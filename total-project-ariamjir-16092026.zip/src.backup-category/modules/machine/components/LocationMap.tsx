"use client";

import {
  MapContainer,
  TileLayer,
  Marker,
  useMapEvents,
} from "react-leaflet";

import L from "leaflet";

import "leaflet/dist/leaflet.css";

/* Fix marker icon for Next.js */
const icon = L.icon({
  iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
  iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
  shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
  iconSize: [25, 41],
  iconAnchor: [12, 41],
});

function ClickHandler({
  onSelectRef,
}: {
  onSelectRef: React.MutableRefObject<
    ((lat: number, lng: number) => void) | null
  >;
}) {
  useMapEvents({
    click(e) {
      onSelectRef.current?.(e.latlng.lat, e.latlng.lng);
    },
  });
  return null;
}

interface LocationMapProps {
  lat?: number;
  lng?: number;
  onLocationSelect: (lat: number, lng: number) => void;
}

export default function LocationMap({
  lat,
  lng,
  onLocationSelect,
}: LocationMapProps) {
  /* نگه داشتن callback در ref تا به‌عنوان prop تابعی مستقیم
     به زیرکامپوننت نرود و حساسیت serialize را برنیانگیزد */
  const selectRef = (function () {
    // ساده و بدون نیاز به hook اضافه
    return { current: onLocationSelect };
  })();

  return (
    <MapContainer
      center={[lat || 35.6892, lng || 51.389]}
      zoom={lat && lng ? 13 : 5}
      style={{ height: "380px", width: "100%", borderRadius: "1rem" }}
    >
      <TileLayer
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
      />
      <ClickHandler onSelectRef={selectRef} />
      {lat && lng && <Marker position={[lat, lng]} icon={icon} />}
    </MapContainer>
  );
}