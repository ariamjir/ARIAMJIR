"use client";

import { useEffect, useState } from "react";
import { ArrowRight, ArrowLeft, Loader2, Save, Eye } from "lucide-react";
import { useWizard } from "@/modules/wizard/useWizard";
import { WIZARD_STEPS } from "@/modules/wizard/wizardConfig";
import { machineService } from "../services/machine.service";

import S1 from "../steps/S1CategoryIdentity";
import S2 from "../steps/S2DynamicDetails";
import S3 from "../steps/S3Media";
import S4 from "../steps/S4PriceLocation";
import S5 from "../steps/S5Contact";
import S6 from "../steps/S6ReviewPublish";

const DRAFT_KEY = "machine-draft-v2";

const slugify = (t: string) =>
  t.toLowerCase().trim().replace(/[^\w\s-]/g, "").replace(/\s+/g, "-").replace(/-+/g, "-");

const num = (v: any) => (v === "" || v == null ? undefined : Number(v));

/* فرم سبک → payload سازگار با API فعلی */
function buildPayload(v: any) {
  const sp = v.specs || {};
  return {
    title: v.title,
    slug: slugify(v.title),
    shortDescription: (v.description || "").slice(0, 200),
    description: v.description,
    listingType: v.listingType,
    condition: "used",
    status: v.status,
    active: true,
    featured: v.featured,
    ...(v.brandId ? { brandId: v.brandId } : {}),
    ...(v.categoryId ? { categoryId: v.categoryId } : {}),
    model: v.model,
    manufactureYear: num(v.year),
    price: num(v.price) ?? 0,
    currency: v.currency,
    priceType: v.priceType,
    negotiable: v.negotiable,
    installment: false,
    financing: false,
    country: "Iran",
    provinceId: v.provinceId,
    cityId: v.cityId,
    address: v.address,
    enginePower: num(sp.enginePower),
    operatingWeight: num(sp.operatingWeight),
    bucketCapacity: num(sp.bucketCapacity),
    workingHours: num(sp.workingHours),
    liftingCapacity: num(sp.liftingCapacity),
    boomLength: num(sp.boomLength),
    fuelType: "diesel",
    transmission: "manual",
    driveType: "wheeled",
    coverImage: v.coverImage,
    gallery: [v.coverImage, ...v.gallery].filter(Boolean),
    sellerMobile: v.sellerMobile,
    sellerEmail: v.sellerEmail,
    sellerFirstName: (v.sellerName || "").split(" ")[0] || "",
    sellerLastName: (v.sellerName || "").split(" ").slice(1).join(" ") || "",
    metaTitle: v.title,
    metaDescription: (v.description || "").slice(0, 160),
    metaKeywords: [],
    features: v.features,
    termsAccepted: v.termsAccepted,
    confirmAccuracy: v.confirmAccuracy,
    confirmRules: true,
    confirmPublish: true,
    confirmFinancial: true,
  };
}

export default function NewMachineWizard() {
  const w = useWizard();
  const [loading, setLoading] = useState(false);
  const [draftRestored, setDraftRestored] = useState(false);
  const last = WIZARD_STEPS.length - 1;

  /* بازیابی پیش‌نویس هنگام ورود */
  useEffect(() => {
    try {
      const raw = localStorage.getItem(DRAFT_KEY);
      if (!raw) return;
      const draft = JSON.parse(raw);
      Object.entries(draft).forEach(([k, val]) => w.set(k, val));
      setDraftRestored(true);
    } catch {
      /* پیش‌نویس خراب */
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const saveDraft = () => {
    localStorage.setItem(DRAFT_KEY, JSON.stringify(w.values));
    alert("پیش‌نویس ذخیره شد.");
  };

  const discardDraft = () => {
    localStorage.removeItem(DRAFT_KEY);
    window.location.reload();
  };

  const preview = () => w.setStep(last);

  const submit = async () => {
    if (!w.next()) return; // اعتبارسنجی استپ آخر؛ اگر نامعتبر باشد مسدود می‌شود
    try {
      setLoading(true);
      await machineService.create(buildPayload(w.values) as any);
      localStorage.removeItem(DRAFT_KEY);
      alert("آگهی با موفقیت ثبت شد.");
    } catch (e) {
      alert(e instanceof Error ? e.message : "خطا در ثبت.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* banner بازیابی پیش‌نویس */}
      {draftRestored && (
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-emerald-200 bg-emerald-50 p-4">
          <p className="text-sm font-semibold text-emerald-800">
            پیش‌نویس قبلی شما بازیابی شد.
          </p>
          <button type="button" onClick={discardDraft}
            className="rounded-lg border border-emerald-300 bg-white px-3 py-1.5 text-xs font-bold text-emerald-700 hover:bg-emerald-100">
            شروع از نو
          </button>
        </div>
      )}

      {/* Stepper */}
      <div className="flex flex-wrap items-center gap-2 rounded-2xl border bg-white p-4">
        {WIZARD_STEPS.map((s, i) => (
          <button key={s.id} type="button" onClick={() => w.goTo(i)}
            className={`flex items-center gap-2 rounded-xl px-3 py-2 text-sm font-bold transition ${
              i === w.step ? "bg-orange-500 text-white" : i < w.step ? "text-orange-600" : "text-gray-400"
            }`}>
            <span className={`flex h-6 w-6 items-center justify-center rounded-full text-xs ${i === w.step ? "bg-white/20" : "bg-gray-100"}`}>
              {i + 1}
            </span>
            {s.title}
          </button>
        ))}
      </div>

      {/* Content */}
      <div>
        {w.step === 0 && <S1 w={w} />}
        {w.step === 1 && <S2 w={w} />}
        {w.step === 2 && <S3 w={w} />}
        {w.step === 3 && <S4 w={w} />}
        {w.step === 4 && <S5 w={w} />}
        {w.step === 5 && <S6 w={w} />}
      </div>

      {/* Footer: قبلی | پیش‌نویس/پیش‌نمایش | بعدی یا ثبت */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border bg-white p-4">
        <button type="button" onClick={w.prev} disabled={w.step === 0}
          className="inline-flex items-center gap-2 rounded-xl border px-5 py-3 font-semibold text-gray-600 disabled:opacity-40">
          <ArrowRight className="h-4 w-4" /> قبلی
        </button>

        <div className="flex items-center gap-2">
          <button type="button" onClick={saveDraft}
            className="inline-flex items-center gap-1.5 rounded-xl border px-4 py-3 text-sm font-bold text-gray-600 hover:bg-gray-50">
            <Save className="h-4 w-4" /> ذخیره پیش‌نویس
          </button>
          <button type="button" onClick={preview}
            className="inline-flex items-center gap-1.5 rounded-xl border px-4 py-3 text-sm font-bold text-gray-600 hover:bg-gray-50">
            <Eye className="h-4 w-4" /> پیش‌نمایش
          </button>
        </div>

        {w.step < last ? (
          <button type="button" onClick={w.next}
            className="inline-flex items-center gap-2 rounded-xl bg-orange-500 px-6 py-3 font-bold text-white hover:bg-orange-600">
            بعدی <ArrowLeft className="h-4 w-4" />
          </button>
        ) : (
          <button type="button" onClick={submit} disabled={loading}
            className="inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-6 py-3 font-bold text-white hover:bg-emerald-700 disabled:opacity-60">
            {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : <ArrowLeft className="h-4 w-4" />}
            ثبت نهایی آگهی
          </button>
        )}
      </div>
    </div>
  );
}