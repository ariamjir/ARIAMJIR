"use client";

import { useCallback, useEffect, useState } from "react";
import { machineBrands } from "@/modules/machine/data";

export interface Brand {
  id: string;
  name: string;
  slug?: string;
  logo?: string | null;
  image?: string | null;
  icon?: string | null;
  description?: string | null;
  link?: string | null;
  country?: string | null;
  active?: boolean;
  featured?: boolean;
  sortOrder?: number;
  [key: string]: any;
}

export function useBrands() {
  const [brands, setBrands] = useState<Brand[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      setLoading(true);
      const res = await fetch("/api/admin/brands", { cache: "no-store" });
      if (!res.ok) throw new Error("load failed");
      const json = await res.json();
      setBrands(Array.isArray(json) ? json : json.data ?? json.brands ?? []);
      setError(null);
    } catch (e) {
      setBrands(machineBrands as Brand[]);
      setError(e instanceof Error ? e.message : "load failed");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const create = useCallback(async (data: any) => {
    setSaving(true);
    try {
      const res = await fetch("/api/admin/brands", {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to create brand.");
      const json = await res.json();
      const created = json.data ?? json;
      setBrands((p) => [...p, created]);
      return created;
    } finally { setSaving(false); }
  }, []);

  const update = useCallback(async (id: string, data: any) => {
    setSaving(true);
    try {
      const res = await fetch(`/api/admin/brands/${id}`, {
        method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to update brand.");
      const json = await res.json();
      const updated = json.data ?? json;
      setBrands((p) => p.map((b) => (b.id === id ? updated : b)));
      return updated;
    } finally { setSaving(false); }
  }, []);

  const remove = useCallback(async (id: string) => {
    await fetch(`/api/admin/brands/${id}`, { method: "DELETE" });
    setBrands((p) => p.filter((b) => b.id !== id));
  }, []);

  return { brands, loading, saving, error, reload: load, create, update, remove };
}