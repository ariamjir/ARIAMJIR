import type { SeedCategory } from "./categoryTree";

const n = (
  id: string,
  name: string,
  opts?: { nameEn?: string; code?: string; children?: SeedCategory[] }
): SeedCategory => ({
  id,
  name,
  slug: id,
  nameEn: opts?.nameEn,
  code: opts?.code,
  children: opts?.children,
});

export const miningDeep: SeedCategory = {
  id: "mining",
  name: "ماشین‌آلات معدنی",
  slug: "mining",
  nameEn: "Mining Equipment",
  icon: "⛏️",
  featured: true,
  showOnHomepage: true,
  children: [
    /* ---------- استخراج روباز ---------- */
    n("min-surface", "ماشین‌آلات استخراج روباز", {
      nameEn: "Surface Mining Equipment",
      children: [
        n("min-shovel-hyd", "شاول هیدرولیکی", {
          nameEn: "Hydraulic Shovel", code: "SHV-HYD",
          children: [
            n("shv-u100", "زیر ۱۰۰ تن"), n("shv-100-200", "۱۰۰ تا ۲۰۰ تن"),
            n("shv-200-300", "۲۰۰ تا ۳۰۰ تن"), n("shv-300p", "بالای ۳۰۰ تن"),
          ],
        }),
        n("min-shovel-cable", "شاول کابلی", { nameEn: "Electric Rope Shovel", code: "SHV-CBL" }),
        n("min-excavator", "بیل مکانیکی معدنی", { nameEn: "Mining Excavator", code: "EXC-MIN" }),
        n("min-loader", "لودر معدنی", { nameEn: "Mining Loader", code: "LDM" }),
        n("min-bulldozer", "بولدوزر معدنی", { nameEn: "Mining Dozer", code: "BDZ-MIN" }),
        n("min-dumptruck", "دامپتراک معدنی", {
          nameEn: "Mining Dump Truck", code: "RDT",
          children: [
            n("rdt-20-40", "۲۰ تا ۴۰ تن"), n("rdt-40-60", "۴۰ تا ۶۰ تن"),
            n("rdt-60-90", "۶۰ تا ۹۰ تن"), n("rdt-90-120", "۹۰ تا ۱۲۰ تن"),
            n("rdt-120-180", "۱۲۰ تا ۱۸۰ تن"), n("rdt-180-240", "۱۸۰ تا ۲۴۰ تن"),
            n("rdt-240-300", "۲۴۰ تا ۳۰۰ تن"), n("rdt-300p", "بالای ۳۰۰ تن"),
          ],
        }),
        n("min-grader", "گریدر معدنی", { nameEn: "Mining Grader", code: "MGR-MIN" }),
        n("min-ripper", "ریپر", { nameEn: "Ripper", code: "RPR" }),
        n("min-scraper", "اسکریپر معدنی", { nameEn: "Mining Scraper", code: "SCR-MIN" }),
        n("min-water-wagon", "واتر واگن", { nameEn: "Water Wagon", code: "WTW" }),
        n("min-tire-handler", "تایر هندلر", { nameEn: "Tire Handler", code: "TRH" }),
      ],
    }),

    /* ---------- استخراج زیرزمینی ---------- */
    n("min-underground", "ماشین‌آلات استخراج زیرزمینی", {
      nameEn: "Underground Mining Equipment",
      children: [
        n("min-lhd", "LHD (لودر بارگیری زیرزمینی)", { nameEn: "Load Haul Dump", code: "LHD" }),
        n("min-ug-truck", "کامیون زیرزمینی", { nameEn: "Underground Truck", code: "UGT" }),
        n("min-ug-drill", "دریل واگن زیرزمینی", { nameEn: "Underground Drill Rig", code: "UGD" }),
        n("min-roof-bolter", "Roof Bolter", { nameEn: "Roof Bolter", code: "RFB" }),
        n("min-scaling", "Scaling Machine", { nameEn: "Scaling Machine", code: "SCL" }),
        n("min-shotcrete", "شاتکریت معدنی", { nameEn: "Shotcrete Machine", code: "SHT-M" }),
        n("min-personnel", "خودرو حمل نفر", { nameEn: "Personnel Carrier", code: "PSC" }),
        n("min-utility", "خودرو خدماتی", { nameEn: "Utility Vehicle", code: "UTL" }),
      ],
    }),

    /* ---------- حفاری معدن ---------- */
    n("min-drilling", "ماشین‌آلات حفاری معدن", {
      nameEn: "Mining Drilling Equipment",
      children: [
        n("min-blasthole", "دریل چاه انفجار", { nameEn: "Blast Hole Drill", code: "BHD" }),
        n("min-rotary", "روتاری دریل", { nameEn: "Rotary Drill", code: "RTD" }),
        n("min-dth", "دریل DTH", { nameEn: "Down The Hole Drill", code: "DTH" }),
        n("min-tophammer", "دریل Top Hammer", { nameEn: "Top Hammer Drill", code: "THD" }),
        n("min-jumbo", "جامبو دریل", { nameEn: "Jumbo Drill", code: "JMB" }),
        n("min-raise-borer", "Raise Borer", { nameEn: "Raise Borer", code: "RBR" }),
        n("min-longhole", "دریل چاه بلند", { nameEn: "Long Hole Drill", code: "LHD-D" }),
        n("min-exploration", "دریل اکتشافی", { nameEn: "Exploration Drill", code: "EXD" }),
        n("min-core", "کر دریل معدنی", { nameEn: "Core Drill", code: "CRD" }),
        n("min-rc", "دریل RC", { nameEn: "Reverse Circulation Drill", code: "RCD" }),
      ],
    }),

    /* ---------- بارگیری معدن ---------- */
    n("min-loading", "ماشین‌آلات بارگیری معدن", {
      nameEn: "Mining Loading Equipment",
      children: [
        n("min-load-wheel", "لودر چرخی معدنی", { nameEn: "Wheel Loader", code: "WLO-M" }),
        n("min-load-track", "لودر زنجیری معدنی", { nameEn: "Track Loader", code: "LTR-M" }),
        n("min-load-excavator", "بیل مکانیکی بارگیری", { nameEn: "Loading Excavator", code: "EXC-LD" }),
        n("min-load-shovel", "شاول بارگیری", { nameEn: "Loading Shovel", code: "SHV-LD" }),
        n("min-load-material", "Material Handler", { nameEn: "Material Handler", code: "MHL" }),
        n("min-load-wheeldozer", "ویل دوزر", { nameEn: "Wheel Dozer", code: "WLD" }),
      ],
    }),

    /* ---------- حمل مواد معدنی ---------- */
    n("min-haulage", "ماشین‌آلات حمل مواد معدنی", {
      nameEn: "Mining Haulage Equipment",
      children: [
        n("min-haul-rigid", "دامپتراک صلب", { nameEn: "Rigid Dump Truck", code: "RDT-R" }),
        n("min-haul-artic", "دامپتراک مفصلی", { nameEn: "Articulated Dump Truck", code: "ADT" }),
        n("min-haul-belt", "نوار نقاله", { nameEn: "Belt Conveyor", code: "CVR" }),
        n("min-haul-overland", "Overland Conveyor", { nameEn: "Overland Conveyor", code: "OLC" }),
        n("min-haul-shuttle", "Shuttle Car", { nameEn: "Shuttle Car", code: "SHC" }),
        n("min-haul-wagon", "واگن معدنی", { nameEn: "Mine Wagon", code: "MGW" }),
        n("min-haul-rail", "Rail Haulage", { nameEn: "Rail Haulage", code: "RHL" }),
        n("min-haul-stacker", "استاکر", { nameEn: "Stacker", code: "STK" }),
        n("min-haul-reclaimer", "ریکلایمر", { nameEn: "Reclaimer", code: "RCL" }),
      ],
    }),

    /* ---------- خردایش ---------- */
    n("min-crushing", "ماشین‌آلات خردایش", {
      nameEn: "Crushing Equipment",
      children: [
        n("min-crush-jaw", "سنگ‌شکن فکی", { nameEn: "Jaw Crusher", code: "CRJ" }),
        n("min-crush-cone", "سنگ‌شکن مخروطی", { nameEn: "Cone Crusher", code: "CRC" }),
        n("min-crush-impact", "سنگ‌شکن ضربه‌ای", { nameEn: "Impact Crusher", code: "CRI" }),
        n("min-crush-hammer", "سنگ‌شکن چکشی", { nameEn: "Hammer Crusher", code: "CRH" }),
        n("min-crush-roll", "سنگ‌شکن غلتکی", { nameEn: "Roll Crusher", code: "CRR" }),
        n("min-crush-gyratory", "سنگ‌شکن ژیراتوری", { nameEn: "Gyratory Crusher", code: "CRG" }),
        n("min-crush-vsi", "سنگ‌شکن VSI", { nameEn: "VSI Crusher", code: "VSI" }),
        n("min-crush-mobile", "سنگ‌شکن سیار", { nameEn: "Mobile Crusher", code: "CRM" }),
        n("min-crush-stationary", "سنگ‌شکن ثابت", { nameEn: "Stationary Crusher", code: "CRS" }),
      ],
    }),

    /* ---------- دانه‌بندی ---------- */
    n("min-screening", "ماشین‌آلات دانه‌بندی", {
      nameEn: "Screening Equipment",
      children: [
        n("min-scr-vibrating", "سرند ویبره", { nameEn: "Vibrating Screen", code: "SCV" }),
        n("min-scr-grizzly", "سرند گریزلی", { nameEn: "Grizzly Screen", code: "SCG" }),
        n("min-scr-trommel", "سرند دوار (Trommel)", { nameEn: "Trommel Screen", code: "SCT" }),
        n("min-scr-dewatering", "سرند آبگیر", { nameEn: "Dewatering Screen", code: "SCD" }),
        n("min-scr-highfreq", "سرند فرکانس بالا", { nameEn: "High Frequency Screen", code: "SCH" }),
        n("min-scr-mobile", "سرند موبایل", { nameEn: "Mobile Screen", code: "SCM" }),
      ],
    }),

    /* ---------- فرآوری مواد معدنی ---------- */
    n("min-processing", "ماشین‌آلات فرآوری مواد معدنی", {
      nameEn: "Mineral Processing Equipment",
      children: [
        n("min-prc-ballmill", "آسیاب گلوله‌ای", { nameEn: "Ball Mill", code: "MLB" }),
        n("min-prc-sag", "آسیاب SAG", { nameEn: "SAG Mill", code: "MLS" }),
        n("min-prc-rodmill", "آسیاب میله‌ای", { nameEn: "Rod Mill", code: "MLR" }),
        n("min-prc-flotation", "فلوتاسیون", { nameEn: "Flotation Cell", code: "FLT" }),
        n("min-prc-thickener", "Thickener", { nameEn: "Thickener", code: "THK" }),
        n("min-prc-hydrocyclone", "Hydrocyclone", { nameEn: "Hydrocyclone", code: "HCY" }),
        n("min-prc-jig", "Jig", { nameEn: "Jig Concentrator", code: "JIG" }),
        n("min-prc-magnetic", "Magnetic Separator", { nameEn: "Magnetic Separator", code: "MGS" }),
        n("min-prc-filter", "Filter Press", { nameEn: "Filter Press", code: "FLP" }),
        n("min-prc-dryer", "خشک‌کن", { nameEn: "Dryer", code: "DRY" }),
      ],
    }),

    /* ---------- انتقال مواد ---------- */
    n("min-transfer", "ماشین‌آلات انتقال مواد", {
      nameEn: "Material Transfer Equipment",
      children: [
        n("min-trf-roller", "رولیک", { nameEn: "Roller", code: "RLR" }),
        n("min-trf-pulley", "پولی", { nameEn: "Pulley", code: "PLY" }),
        n("min-trf-hopper", "هاپر", { nameEn: "Hopper", code: "HPR" }),
        n("min-trf-vibfeeder", "فیدر ارتعاشی", { nameEn: "Vibrating Feeder", code: "FDV" }),
        n("min-trf-apron", "Apron Feeder", { nameEn: "Apron Feeder", code: "FDA" }),
        n("min-trf-screw", "Screw Conveyor", { nameEn: "Screw Conveyor", code: "SCA" }),
        n("min-trf-bucket", "Bucket Elevator", { nameEn: "Bucket Elevator", code: "BKE" }),
      ],
    }),

    /* ---------- ایمنی و پشتیبانی ---------- */
    n("min-safety", "تجهیزات ایمنی و پشتیبانی معادن", {
      nameEn: "Mining Safety & Support",
      children: [
        n("min-saf-ventilation", "سیستم تهویه معدن", { nameEn: "Mine Ventilation", code: "VNT" }),
        n("min-saf-fan", "فن معدن", { nameEn: "Mine Fan", code: "MNF" }),
        n("min-saf-gas", "گازسنج", { nameEn: "Gas Detector", code: "GSD" }),
        n("min-saf-dust", "غبارگیر", { nameEn: "Dust Collector", code: "DSC" }),
        n("min-saf-monitor", "سیستم مانیتورینگ", { nameEn: "Monitoring System", code: "MNS" }),
        n("min-saf-refuge", "پناهگاه نجات", { nameEn: "Refuge Chamber", code: "RFC" }),
      ],
    }),
  ],
};