/* ============================================================
   Domain — چهار مارکت‌پلیس موازی
   ============================================================ */
export type Domain = "MACHINE" | "PART" | "SERVICE" | "KNOWLEDGE";

/* ============================================================
   SeedCategory — تایپ گره‌های درخت دسته‌بندی
   ============================================================ */
export interface SeedCategory {
  id: string;
  name: string;
  slug: string;
  nameEn?: string;
  code?: string;
  description?: string;
  icon?: string;
  featured?: boolean;
  showOnHomepage?: boolean;
  showInMenu?: boolean;
  active?: boolean;
  sortOrder?: number;
  level?: number;
  domain?: Domain;
  children?: SeedCategory[];
}

/* ============================================================
   FlatCategory — ساختار تخت برای seed در Prisma
   ============================================================ */
export interface FlatCategory {
  id: string;
  parentId: string | null;
  name: string;
  nameEn: string | null;
  code: string | null;
  slug: string;
  description: string | null;
  icon: string | null;
  active: boolean;
  featured: boolean;
  showInMenu: boolean;
  showOnHomepage: boolean;
  sortOrder: number;
  level: number;
  domain: Domain;
}

/* ============================================================
   flattenCategoryTree — تبدیل درخت به آرایه تخت
   domain از ریشه به تمام فرزندان به ارث می‌رسد
   ============================================================ */
export function flattenCategoryTree(
  tree: SeedCategory[],
  parentId: string | null = null,
  level: number = 0,
  parentDomain: Domain = "MACHINE"
): FlatCategory[] {
  const result: FlatCategory[] = [];

  for (const node of tree) {
    const domain: Domain = node.domain ?? parentDomain;

    result.push({
      id: node.id,
      parentId,
      name: node.name,
      nameEn: node.nameEn ?? null,
      code: node.code ?? null,
      slug: node.slug,
      description: node.description ?? null,
      icon: node.icon ?? null,
      active: node.active ?? true,
      featured: node.featured ?? false,
      showInMenu: node.showInMenu ?? true,
      showOnHomepage: node.showOnHomepage ?? false,
      sortOrder: node.sortOrder ?? 0,
      level: node.level ?? level,
      domain,
    });

    if (node.children && node.children.length > 0) {
      result.push(
        ...flattenCategoryTree(node.children, node.id, level + 1, domain)
      );
    }
  }

  return result;
}