import type { SeedCategory } from "./categoryTree";

/* ============================================================
   SERVICES — 18 صنعت مادر خدمات
   (Maintenance, Rental, Training, Transport, Consulting, ...)
   ============================================================ */

const n = (
  id: string,
  name: string,
  opts: { nameEn?: string; code?: string; children?: SeedCategory[] } = {}
): SeedCategory => ({
  id,
  name,
  slug: id,
  nameEn: opts.nameEn,
  code: opts.code,
  children: opts.children,
});

export const servicesDeep: SeedCategory = {
  id: "services",
  name: "خدمات صنعتی و ماشین‌آلات",
  nameEn: "Industrial & Machinery Services",
  slug: "services",
  icon: "🛠️",
  domain: "SERVICE",
  featured: true,
  showOnHomepage: false, // پورتال /services بعداً می‌آید؛ صفحه اول فعلاً بدون تغییر
  showInMenu: true,
  sortOrder: 1,
  children: [
    /* ── 1 ── تعمیرات و نگهداری */
    n("svc-maintenance", "تعمیرات و نگهداری", { nameEn: "Maintenance & Repair Services", code: "SVC-01", children: [
      n("sm-engine", "تعمیر موتور"), n("sm-gearbox", "تعمیر گیربکس"), n("sm-axle", "تعمیر اکسل"),
      n("sm-hydraulic", "تعمیر هیدرولیک"), n("sm-electric", "تعمیر برق"), n("sm-ecu", "تعمیر ECU"),
      n("sm-fuel", "تعمیر سیستم سوخت"), n("sm-brake", "تعمیر سیستم ترمز"), n("sm-front", "تعمیر جلوبندی"),
      n("sm-cabin", "تعمیر کابین"), n("sm-chassis", "تعمیر شاسی"), n("sm-boom", "تعمیر بوم"),
      n("sm-bucket", "تعمیر باکت"), n("sm-drillarm", "تعمیر بازوی حفاری"), n("sm-pump", "تعمیر پمپ"),
      n("sm-compressor", "تعمیر کمپرسور"), n("sm-full", "تعمیر کامل ماشین"),
    ]}),
    /* ── 2 ── سرویس دوره‌ای */
    n("svc-periodic", "سرویس دوره‌ای", { nameEn: "Periodic Service", code: "SVC-02", children: [
      n("sp-250", "سرویس 250 ساعت"), n("sp-500", "سرویس 500 ساعت"), n("sp-1000", "سرویس 1000 ساعت"),
      n("sp-annual", "سرویس سالیانه"), n("sp-oil", "تعویض روغن"), n("sp-filter", "تعویض فیلتر"),
      n("sp-grease", "گریس کاری"), n("sp-tune", "تنظیم موتور"), n("sp-full", "سرویس کامل"),
    ]}),
    /* ── 3 ── نصب و راه‌اندازی */
    n("svc-installation", "نصب و راه‌اندازی", { nameEn: "Installation & Commissioning", code: "SVC-03", children: [
      n("si-machine", "نصب دستگاه"), n("si-factory", "نصب کارخانه"), n("si-line", "نصب خط تولید"),
      n("si-crane", "نصب جرثقیل"), n("si-batching", "نصب بچینگ"), n("si-powerplant", "نصب نیروگاه"),
      n("si-mining", "نصب تجهیزات معدن"), n("si-commissioning", "Commissioning"),
    ]}),
    /* ── 4 ── بازرسی و کارشناسی */
    n("svc-inspection", "بازرسی و کارشناسی", { nameEn: "Inspection & Appraisal", code: "SVC-04", children: [
      n("sin-prebuy", "کارشناسی قبل خرید"), n("sin-price", "کارشناسی قیمت"), n("sin-technical", "کارشناسی فنی"),
      n("sin-hydraulic", "تست هیدرولیک"), n("sin-engine", "تست موتور"), n("sin-gearbox", "تست گیربکس"),
      n("sin-chassis", "تست شاسی"), n("sin-machine", "بازرسی ماشین"), n("sin-factory", "بازرسی کارخانه"),
      n("sin-report", "گزارش رسمی"),
    ]}),
    /* ── 5 ── اجاره اپراتور و نیروی متخصص */
    n("svc-operator", "اجاره اپراتور و نیروی متخصص", { nameEn: "Operator & Specialist Crew", code: "SVC-05", children: [
      n("so-exc", "اپراتور بیل"), n("so-loader", "اپراتور لودر"), n("so-crane", "اپراتور جرثقیل"),
      n("so-drill", "اپراتور حفاری"), n("so-truck", "راننده کامیون"), n("so-electric", "تکنسین برق"),
      n("so-hydraulic", "تکنسین هیدرولیک"), n("so-mechanic", "مکانیک"), n("so-team", "تیم تعمیرات"),
    ]}),
    /* ── 6 ── آموزش */
    n("svc-training", "آموزش", { nameEn: "Training", code: "SVC-06", children: [
      n("st-operator", "آموزش اپراتوری"), n("st-repair", "آموزش تعمیرات"), n("st-plc", "آموزش PLC"),
      n("st-cnc", "آموزش CNC"), n("st-hydraulic", "آموزش هیدرولیک"), n("st-electric", "آموزش برق"),
      n("st-mining", "آموزش معدن"), n("st-safety", "آموزش ایمنی"), n("st-online", "آموزش آنلاین"),
      n("st-onsite", "آموزش حضوری"),
    ]}),
    /* ── 7 ── مشاوره */
    n("svc-consulting", "مشاوره", { nameEn: "Consulting", code: "SVC-07", children: [
      n("sc-buy", "مشاوره خرید"), n("sc-sell", "مشاوره فروش"), n("sc-import", "مشاوره واردات"),
      n("sc-export", "مشاوره صادرات"), n("sc-mining", "مشاوره معدن"), n("sc-factory", "مشاوره کارخانه"),
      n("sc-production", "مشاوره تولید"), n("sc-epc", "مشاوره EPC"), n("sc-investment", "مشاوره سرمایه گذاری"),
    ]}),
    /* ── 8 ── حمل و نقل */
    n("svc-transport", "حمل و نقل", { nameEn: "Transportation", code: "SVC-08", children: [
      n("str-domestic", "حمل داخلی"), n("str-international", "حمل بین المللی"), n("str-heavy", "حمل فوق سنگین"),
      n("str-traffic", "حمل ترافیکی"), n("str-sea", "حمل دریایی"), n("str-rail", "حمل ریلی"),
      n("str-air", "حمل هوایی"), n("str-clearance", "ترخیص و حمل"),
    ]}),
    /* ── 9 ── جرثقیل و جابه‌جایی */
    n("svc-lifting", "جرثقیل و جابه‌جایی", { nameEn: "Lifting & Rigging", code: "SVC-09", children: [
      n("sl-crane", "اجاره جرثقیل"), n("sl-install", "نصب تجهیزات"), n("sl-factory", "جابه جایی کارخانه"),
      n("sl-loading", "بارگیری"), n("sl-unloading", "تخلیه"), n("sl-lifting", "لیفتینگ"), n("sl-rigging", "Rigging"),
    ]}),
    /* ── 10 ── اجاره ماشین‌آلات */
    n("svc-rental", "اجاره ماشین‌آلات", { nameEn: "Machinery Rental", code: "SVC-10", children: [
      n("sr-exc", "اجاره بیل"), n("sr-loader", "اجاره لودر"), n("sr-dozer", "اجاره بلدوزر"),
      n("sr-grader", "اجاره گریدر"), n("sr-crane", "اجاره جرثقیل"), n("sr-forklift", "اجاره لیفتراک"),
      n("sr-compressor", "اجاره کمپرسور"), n("sr-generator", "اجاره ژنراتور"),
    ]}),
    /* ── 11 ── بازسازی و اورهال */
    n("svc-overhaul", "بازسازی و اورهال", { nameEn: "Overhaul & Remanufacturing", code: "SVC-11", children: [
      n("sov-engine", "بازسازی موتور"), n("sov-gearbox", "بازسازی گیربکس"), n("sov-hydraulic", "بازسازی هیدرولیک"),
      n("sov-full", "بازسازی کامل"), n("sov-rebuild", "Rebuild"), n("sov-reman", "Remanufacturing"),
      n("sov-refurb", "Refurbishment"),
    ]}),
    /* ── 12 ── ساخت و سفارشی‌سازی */
    n("svc-fabrication", "ساخت و سفارشی‌سازی", { nameEn: "Fabrication & Customization", code: "SVC-12", children: [
      n("sf-bucket", "ساخت باکت"), n("sf-boom", "ساخت بوم"), n("sf-chassis", "ساخت شاسی"),
      n("sf-tank", "ساخت مخزن"), n("sf-equipment", "ساخت تجهیزات"), n("sf-cnc", "CNC"),
      n("sf-machining", "ماشینکاری"), n("sf-welding", "جوشکاری"),
    ]}),
    /* ── 13 ── کالیبراسیون و آزمون */
    n("svc-calibration", "کالیبراسیون و آزمون", { nameEn: "Calibration & Testing", code: "SVC-13", children: [
      n("sca-tool", "کالیبراسیون ابزار"), n("sca-sensor", "کالیبراسیون سنسور"), n("sca-pressure", "تست فشار"),
      n("sca-temp", "تست دما"), n("sca-load", "تست بار"), n("sca-performance", "تست عملکرد"),
      n("sca-cert", "گواهینامه کالیبراسیون"),
    ]}),
    /* ── 14 ── خدمات دیجیتال */
    n("svc-digital", "خدمات دیجیتال", { nameEn: "Digital Services", code: "SVC-14", children: [
      n("sd-plc", "برنامه نویسی PLC"), n("sd-scada", "SCADA"), n("sd-hmi", "HMI"),
      n("sd-monitoring", "مانیتورینگ"), n("sd-iot", "IoT"), n("sd-ai", "هوش مصنوعی"),
      n("sd-twin", "Digital Twin"), n("sd-automation", "اتوماسیون"),
    ]}),
    /* ── 15 ── خدمات مالی و بیمه */
    n("svc-financial", "خدمات مالی و بیمه", { nameEn: "Financial & Insurance Services", code: "SVC-15", children: [
      n("sfi-insurance", "بیمه ماشین آلات"), n("sfi-leasing", "لیزینگ"), n("sfi-finance", "تامین مالی"),
      n("sfi-lc", "اعتبار اسنادی"), n("sfi-guarantee", "ضمانت نامه"), n("sfi-valuation", "ارزش گذاری"),
      n("sfi-assessor", "کارشناسی بیمه"),
    ]}),
    /* ── 16 ── خدمات بازرگانی */
    n("svc-trade", "خدمات بازرگانی", { nameEn: "Trade Services", code: "SVC-16", children: [
      n("sw-import", "واردات"), n("sw-export", "صادرات"), n("sw-clearance", "ترخیص"),
      n("sw-order", "ثبت سفارش"), n("sw-foreign", "خرید خارجی"), n("sw-sourcing", "سورسینگ"),
      n("sw-inspection", "بازرسی کالا"), n("sw-international", "حمل بین المللی"),
    ]}),
    /* ── 17 ── خدمات آزمایشگاهی و صدور گواهی */
    n("svc-testing", "خدمات آزمایشگاهی و صدور گواهی", { nameEn: "Testing & Certification", code: "SVC-17", children: [
      n("ste-material", "تست مواد"), n("ste-weld", "تست جوش"), n("ste-ndt", "تست غیرمخرب NDT"),
      n("ste-technical", "بازرسی فنی"), n("ste-quality", "گواهی کیفیت"), n("ste-ce", "گواهی CE"),
      n("ste-iso", "گواهی ISO"), n("ste-audit", "ممیزی فنی"),
    ]}),
    /* ── 18 ── خدمات اضطراری و پشتیبانی */
    n("svc-emergency", "خدمات اضطراری و پشتیبانی", { nameEn: "Emergency & Support Services", code: "SVC-18", children: [
      n("se-rescue", "امداد ماشین آلات"), n("se-onsite", "تعمیر در محل"), n("se-mechanic", "اعزام مکانیک"),
      n("se-electrician", "اعزام برقکار"), n("se-road", "امداد جاده ای"), n("se-parts", "تأمین قطعه فوری"),
      n("se-247", "پشتیبانی 24 ساعته"), n("se-amc", "قرارداد نگهداری (AMC)"),
    ]}),
  ],
};