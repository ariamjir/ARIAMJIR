import type { SeedCategory } from "./categoryTree";

/* ============================================================
   INDUSTRY 27 — تجهیزات صنعتی عمومی و ماشین‌آلات متفرقه
   (General Industrial Equipment & Miscellaneous Machinery)
   خانواده‌های 336 تا 352 — با تمام انواع ماشین (نسل آخر)
   ============================================================ */

const n = (
  id: string,
  name: string,
  opts: { nameEn?: string; code?: string; children?: SeedCategory[] } = {}
): SeedCategory => ({
  id,
  name,
  slug: id,
  nameEn: opts.nameEn,
  code: opts.code,
  children: opts.children,
});

export const generalIndustrialDeep: SeedCategory = {
  id: "general-industrial",
  name: "تجهیزات صنعتی عمومی و ماشین‌آلات متفرقه",
  nameEn: "General Industrial Equipment & Miscellaneous Machinery",
  slug: "general-industrial",
  icon: "⚙️",
  children: [
    /* ── FAMILY 336 ── پمپ‌های صنعتی */
    n("gen-pumps", "پمپ‌های صنعتی", { nameEn: "Industrial Pumps", code: "FAM-336", children: [
      n("gen-pu-centrifugal", "پمپ سانتریفیوژ"), n("gen-pu-gear", "پمپ دنده‌ای"),
      n("gen-pu-piston", "پمپ پیستونی"), n("gen-pu-diaphragm", "پمپ دیافراگمی"),
      n("gen-pu-screw", "پمپ اسکرو"), n("gen-pu-sludge", "پمپ لجن‌کش"),
      n("gen-pu-chemical", "پمپ شیمیایی"), n("gen-pu-system", "سیستم پمپاژ کامل"),
      n("gen-pu-submersible", "پمپ زیرآبی", { nameEn: "Submersible Pump" }),
    ]}),
    /* ── FAMILY 337 ── کمپرسورها */
    n("gen-compressors", "کمپرسورها", { nameEn: "Industrial Compressors", code: "FAM-337", children: [
      n("gen-co-screw", "کمپرسور اسکرو"), n("gen-co-piston", "کمپرسور پیستونی"),
      n("gen-co-centrifugal", "کمپرسور سانتریفیوژ"), n("gen-co-oilfree", "کمپرسور بدون روغن"),
      n("gen-co-gas", "کمپرسور گاز"), n("gen-co-portable", "کمپرسور پرتابل"),
      n("gen-co-system", "سیستم هوای فشرده"),
    ]}),
    /* ── FAMILY 338 ── تجهیزات خلأ صنعتی */
    n("gen-vacuum", "تجهیزات خلأ صنعتی", { nameEn: "Vacuum Equipment", code: "FAM-338", children: [
      n("gen-va-pump", "پمپ خلأ"), n("gen-va-booster", "بوستر خلأ"),
      n("gen-va-central", "سیستم وکیوم مرکزی"), n("gen-va-medical", "وکیوم پزشکی"),
      n("gen-va-industrial", "وکیوم صنعتی"), n("gen-va-system", "سیستم خلأ کامل"),
    ]}),
    /* ── FAMILY 339 ── موتورهای صنعتی */
    n("gen-motors", "موتورهای صنعتی", { nameEn: "Industrial Motors", code: "FAM-339", children: [
      n("gen-mo-electric", "موتور الکتریکی"), n("gen-mo-ac", "موتور AC"),
      n("gen-mo-dc", "موتور DC"), n("gen-mo-explosion", "موتور ضدانفجار"),
      n("gen-mo-servo", "موتور سروو"), n("gen-mo-induction", "موتور القایی"),
      n("gen-mo-drive", "سیستم محرکه صنعتی"),
    ]}),
    /* ── FAMILY 340 ── گیربکس و انتقال قدرت */
    n("gen-gearbox", "گیربکس و انتقال قدرت", { nameEn: "Gearboxes & Power Transmission", code: "FAM-340", children: [
      n("gen-ge-industrial", "گیربکس صنعتی"), n("gen-ge-worm", "گیربکس حلزونی"),
      n("gen-ge-helical", "گیربکس هلیکال"), n("gen-ge-planetary", "گیربکس سیاره‌ای"),
      n("gen-ge-coupling", "کوپلینگ"), n("gen-ge-chain", "زنجیر صنعتی"),
      n("gen-ge-belt", "تسمه انتقال"), n("gen-ge-system", "سیستم انتقال قدرت"),
    ]}),
    /* ── FAMILY 341 ── یاتاقان و قطعات انتقال حرکت */
    n("gen-bearing", "یاتاقان و قطعات انتقال حرکت", { nameEn: "Motion Components", code: "FAM-341", children: [
      n("gen-be-ball", "بلبرینگ"), n("gen-be-roller", "رولبرینگ"),
      n("gen-be-rail", "ریل خطی"), n("gen-be-screw", "بال اسکرو"),
      n("gen-be-shaft", "شفت صنعتی"), n("gen-be-seal", "آب‌بند صنعتی"),
      n("gen-be-precision", "قطعات حرکت دقیق"),
    ]}),
    /* ── FAMILY 342 ── تجهیزات انتقال مواد */
    n("gen-material", "تجهیزات انتقال مواد", { nameEn: "Material Handling Equipment", code: "FAM-342", children: [
      n("gen-ma-belt", "نوار نقاله"), n("gen-ma-screw", "اسکرو کانوایر"),
      n("gen-ma-lift", "بالابر مواد"), n("gen-ma-feeder", "فیدر صنعتی"),
      n("gen-ma-pneumatic", "سیستم انتقال پنوماتیک"), n("gen-ma-chain", "سیستم انتقال زنجیری"),
      n("gen-ma-line", "خطوط انتقال کامل"),
    ]}),
    /* ── FAMILY 343 ── تجهیزات انبارداری و لجستیک */
    n("gen-warehouse", "تجهیزات انبارداری و لجستیک", { nameEn: "Warehouse Equipment", code: "FAM-343", children: [
      n("gen-wa-forklift", "لیفتراک"), n("gen-wa-reach", "ریچتراک"),
      n("gen-wa-stacker", "استاکر"), n("gen-wa-pallet", "پالت‌تراک"),
      n("gen-wa-rack", "قفسه‌بندی صنعتی"), n("gen-wa-asrs", "سیستم AS/RS"),
      n("gen-wa-smart", "انبار هوشمند"),
    ]}),
    /* ── FAMILY 344 ── جرثقیل و تجهیزات جابه‌جایی صنعتی */
    n("gen-crane", "جرثقیل و تجهیزات جابه‌جایی صنعتی", { nameEn: "Cranes & Lifting", code: "FAM-344", children: [
      n("gen-cr-overhead", "جرثقیل سقفی"), n("gen-cr-gantry", "جرثقیل دروازه‌ای"),
      n("gen-cr-jib", "جرثقیل بازویی"), n("gen-cr-winch", "وینچ صنعتی"),
      n("gen-cr-hoist", "بالابر زنجیری"), n("gen-cr-magnet", "سیستم مگنت لیفت"),
      n("gen-cr-system", "سیستم جابه‌جایی کامل"),
    ]}),
    /* ── FAMILY 345 ── تجهیزات تهویه صنعتی */
    n("gen-hvac", "تجهیزات تهویه صنعتی", { nameEn: "HVAC Industrial", code: "FAM-345", children: [
      n("gen-hv-airhandler", "هواساز صنعتی"), n("gen-hv-chiller", "چیلر صنعتی"),
      n("gen-hv-tower", "برج خنک‌کن"), n("gen-hv-fan", "فن صنعتی"),
      n("gen-hv-exhaust", "اگزاست فن"), n("gen-hv-factory", "سیستم تهویه کارخانه"),
      n("gen-hv-complete", "HVAC کامل"),
    ]}),
    /* ── FAMILY 346 ── تجهیزات گرمایشی صنعتی */
    n("gen-heating", "تجهیزات گرمایشی صنعتی", { nameEn: "Industrial Heating Equipment", code: "FAM-346", children: [
      n("gen-he-furnace", "کوره صنعتی"), n("gen-he-heater", "هیتر صنعتی"),
      n("gen-he-boiler", "بویلر"), n("gen-he-burner", "مشعل صنعتی"),
      n("gen-he-element", "المنت صنعتی"), n("gen-he-process", "سیستم گرمایش فرآیندی"),
      n("gen-he-thermal", "تجهیزات حرارتی"),
    ]}),
    /* ── FAMILY 347 ── تجهیزات سرمایشی صنعتی */
    n("gen-cooling", "تجهیزات سرمایشی صنعتی", { nameEn: "Industrial Cooling", code: "FAM-347", children: [
      n("gen-cd-chiller", "چیلر"), n("gen-cd-tower", "برج خنک‌کن"),
      n("gen-cd-refrigeration", "سیستم تبرید صنعتی"), n("gen-cd-compressor", "کمپرسور سردخانه"),
      n("gen-cd-evaporator", "اواپراتور"), n("gen-cd-condenser", "کندانسور"),
      n("gen-cd-system", "سیستم سرمایش کامل"),
    ]}),
    /* ── FAMILY 348 ── تجهیزات تصفیه و فیلتراسیون عمومی */
    n("gen-filtration", "تجهیزات تصفیه و فیلتراسیون عمومی", { nameEn: "Industrial Filtration", code: "FAM-348", children: [
      n("gen-fi-air", "فیلتر هوا"), n("gen-fi-oil", "فیلتر روغن"),
      n("gen-fi-water", "فیلتر آب"), n("gen-fi-gas", "فیلتر گاز"),
      n("gen-fi-separator", "جداکننده صنعتی"), n("gen-fi-system", "سیستم تصفیه"),
      n("gen-fi-equipment", "تجهیزات فیلتراسیون"),
    ]}),
    /* ── FAMILY 349 ── تجهیزات روشنایی و برق صنعتی */
    n("gen-electric", "تجهیزات روشنایی و برق صنعتی", { nameEn: "Industrial Electrical", code: "FAM-349", children: [
      n("gen-el-panel", "تابلو برق"), n("gen-el-cable", "کابل صنعتی"),
      n("gen-el-lighting", "روشنایی کارخانه"), n("gen-el-ups", "UPS"),
      n("gen-el-battery", "باتری صنعتی"), n("gen-el-emergency", "سیستم برق اضطراری"),
      n("gen-el-factory", "تجهیزات برق کارخانه"),
    ]}),
    /* ── FAMILY 350 ── تجهیزات اندازه‌گیری و آزمایشگاهی صنعتی */
    n("gen-lab", "تجهیزات اندازه‌گیری و آزمایشگاهی صنعتی", { nameEn: "Industrial Testing", code: "FAM-350", children: [
      n("gen-la-material", "دستگاه تست مواد"), n("gen-la-pressure", "دستگاه تست فشار"),
      n("gen-la-heat", "دستگاه تست حرارت"), n("gen-la-calibration", "تجهیزات کالیبراسیون"),
      n("gen-la-quality", "تجهیزات کنترل کیفیت"), n("gen-la-lab", "آزمایشگاه صنعتی"),
    ]}),
    /* ── FAMILY 351 ── قطعات و تجهیزات جانبی ماشین‌آلات */
    n("gen-parts", "قطعات و تجهیزات جانبی ماشین‌آلات", { nameEn: "Machine Components", code: "FAM-351", children: [
      n("gen-pa-valve", "شیرآلات صنعتی"), n("gen-pa-fitting", "اتصالات"),
      n("gen-pa-hose", "شیلنگ صنعتی"), n("gen-pa-filter", "فیلترها"),
      n("gen-pa-pneumatic", "قطعات پنوماتیک"), n("gen-pa-hydraulic", "قطعات هیدرولیک"),
      n("gen-pa-mechanical", "قطعات مکانیکی"), n("gen-pa-consumable", "لوازم مصرفی صنعتی"),
    ]}),
    /* ── FAMILY 352 ── تجهیزات کارخانه کامل */
    n("gen-factory", "تجهیزات کارخانه کامل", { nameEn: "Complete Factory Equipment", code: "FAM-352", children: [
      n("gen-fa-line", "خطوط تولید"), n("gen-fa-utility", "تجهیزات Utility کارخانه"),
      n("gen-fa-air", "سیستم هوای فشرده"), n("gen-fa-electric", "سیستم برق صنعتی"),
      n("gen-fa-material", "سیستم انتقال مواد"), n("gen-fa-control", "سیستم کنترل"),
      n("gen-fa-turnkey", "کارخانه کامل Turnkey"),
    ]}),
  ],
};