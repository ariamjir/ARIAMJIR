import type { SeedCategory } from "./categoryTree";

/* ============================================================
   INDUSTRY 26 — ماشین‌آلات خدمات شهری، نظافت، محیط زیست و مدیریت پسماند
   (Municipal, Cleaning, Waste Management & Environmental Equipment)
   خانواده‌های 320 تا 335 — با تمام انواع ماشین (نسل آخر)
   ============================================================ */

const n = (
  id: string,
  name: string,
  opts: { nameEn?: string; code?: string; children?: SeedCategory[] } = {}
): SeedCategory => ({
  id,
  name,
  slug: id,
  nameEn: opts.nameEn,
  code: opts.code,
  children: opts.children,
});

export const municipalDeep: SeedCategory = {
  id: "municipal",
  name: "ماشین‌آلات خدمات شهری، نظافت، محیط زیست و مدیریت پسماند",
  nameEn: "Municipal, Cleaning, Waste & Environmental Equipment",
  slug: "municipal",
  icon: "🚒",
  children: [
    /* ── FAMILY 320 ── ماشین‌آلات نظافت شهری */
    n("mun-cleaning", "ماشین‌آلات نظافت شهری", { nameEn: "Municipal Cleaning Machines", code: "FAM-320", children: [
      n("mun-cl-sweeper", "جاروب خیابانی"), n("mun-cl-wash", "ماشین رفت‌وروب شهری"),
      n("mun-cl-waterjet", "واترجت خیابانی"), n("mun-cl-sidewalk", "ماشین شستشوی معابر"),
      n("mun-cl-soil", "ماشین جمع‌آوری خاک"), n("mun-cl-industrial", "ماشین نظافت صنعتی"),
      n("mun-cl-fleet", "ناوگان نظافت شهری"),
    ]}),
    /* ── FAMILY 321 ── ماشین‌های جاروب و رفت‌وروب صنعتی */
    n("mun-sweeper", "ماشین‌های جاروب و رفت‌وروب صنعتی", { nameEn: "Sweeper Machines", code: "FAM-321", children: [
      n("mun-sw-mechanical", "جاروب مکانیکی"), n("mun-sw-suction", "جاروب مکنده"),
      n("mun-sw-truck", "جاروب کامیونی"), n("mun-sw-airport", "جاروب فرودگاهی"),
      n("mun-sw-factory", "جاروب کارخانه"), n("mun-sw-small", "جاروب کوچک شهری"),
      n("mun-sw-vacuum", "سیستم مکش صنعتی"),
    ]}),
    /* ── FAMILY 322 ── تجهیزات شستشوی صنعتی */
    n("mun-indclean", "تجهیزات شستشوی صنعتی", { nameEn: "Industrial Cleaning Equipment", code: "FAM-322", children: [
      n("mun-ic-waterjet", "واترجت فشار قوی"), n("mun-ic-steam", "بخارشوی صنعتی"),
      n("mun-ic-floor", "کف‌شوی صنعتی"), n("mun-ic-scrubber", "اسکرابر"),
      n("mun-ic-polisher", "پولیشر صنعتی"), n("mun-ic-vacuum", "جاروبرقی صنعتی"),
      n("mun-ic-auto", "سیستم شستشوی اتوماتیک"),
    ]}),
    /* ── FAMILY 323 ── ماشین‌آلات جمع‌آوری پسماند */
    n("mun-waste-collect", "ماشین‌آلات جمع‌آوری پسماند", { nameEn: "Waste Collection Equipment", code: "FAM-323", children: [
      n("mun-wc-truck", "کامیون حمل زباله"), n("mun-wc-vehicle", "ماشین زباله‌کش"),
      n("mun-wc-compactor", "سیستم فشرده‌سازی زباله"), n("mun-wc-smartbin", "مخزن زباله هوشمند"),
      n("mun-wc-lifter", "بالابر مخزن"), n("mun-wc-container", "کانتینر پسماند"),
      n("mun-wc-fleet", "ناوگان جمع‌آوری"),
    ]}),
    /* ── FAMILY 324 ── ماشین‌آلات پردازش و بازیافت زباله */
    n("mun-waste-process", "ماشین‌آلات پردازش و بازیافت زباله", { nameEn: "Waste Recycling Machinery", code: "FAM-324", children: [
      n("mun-wp-shredder", "خردکن زباله"), n("mun-wp-screen", "سرند زباله"),
      n("mun-wp-magnetic", "جداکننده مغناطیسی"), n("mun-wp-plastic", "تفکیک پلاستیک"),
      n("mun-wp-press", "پرس ضایعات"), n("mun-wp-compost", "کمپوست‌ساز"),
      n("mun-wp-plant", "کارخانه بازیافت"),
    ]}),
    /* ── FAMILY 325 ── ماشین‌آلات بازیافت فلزات */
    n("mun-metal-recycle", "ماشین‌آلات بازیافت فلزات", { nameEn: "Metal Recycling Equipment", code: "FAM-325", children: [
      n("mun-mr-scrap-press", "پرس قراضه"), n("mun-mr-shear", "قیچی ضایعات"),
      n("mun-mr-shredder", "خردکن فلز"), n("mun-mr-car-press", "پرس خودرو"),
      n("mun-mr-separator", "جداکننده فلزی"), n("mun-mr-melt", "ذوب ضایعات"),
      n("mun-mr-line", "خط بازیافت فلز"),
    ]}),
    /* ── FAMILY 326 ── تجهیزات تصفیه آب */
    n("mun-water", "تجهیزات تصفیه آب", { nameEn: "Water Treatment Equipment", code: "FAM-326", children: [
      n("mun-wt-ro", "سیستم RO"), n("mun-wt-sand", "فیلتر شنی"),
      n("mun-wt-carbon", "فیلتر کربنی"), n("mun-wt-industrial", "تصفیه صنعتی آب"),
      n("mun-wt-pump", "پمپ تصفیه"), n("mun-wt-uv", "UV Sterilizer"),
      n("mun-wt-plant", "کارخانه تصفیه آب"),
    ]}),
    /* ── FAMILY 327 ── تجهیزات تصفیه فاضلاب */
    n("mun-wastewater", "تجهیزات تصفیه فاضلاب", { nameEn: "Wastewater Treatment", code: "FAM-327", children: [
      n("mun-ww-package", "پکیج تصفیه فاضلاب"), n("mun-ww-aeration", "هوادهی"),
      n("mun-ww-blower", "بلوئر"), n("mun-ww-settling", "تانک ته‌نشینی"),
      n("mun-ww-sludge", "لجن‌گیر"), n("mun-ww-press", "پرس لجن"),
      n("mun-ww-plant", "تصفیه‌خانه کامل"),
    ]}),
    /* ── FAMILY 328 ── ماشین‌آلات فضای سبز و نگهداری شهری */
    n("mun-landscape", "ماشین‌آلات فضای سبز و نگهداری شهری", { nameEn: "Landscaping Equipment", code: "FAM-328", children: [
      n("mun-ls-mower", "چمن‌زن صنعتی"), n("mun-ls-tractor", "تراکتور فضای سبز"),
      n("mun-ls-pruner", "هرس‌کن"), n("mun-ls-leaf", "برگ‌روب"),
      n("mun-ls-branch", "خردکن شاخه"), n("mun-ls-sprayer", "سم‌پاش"),
      n("mun-ls-park", "تجهیزات پارک و فضای سبز"),
    ]}),
    /* ── FAMILY 329 ── ماشین‌آلات جنگلداری و نگهداری منابع طبیعی */
    n("mun-forest", "ماشین‌آلات جنگلداری و نگهداری منابع طبیعی", { nameEn: "Forest & Environmental Equipment", code: "FAM-329", children: [
      n("mun-fs-shredder", "خردکن چوب"), n("mun-fs-chipper", "چیپر درخت"),
      n("mun-fs-chainsaw", "اره زنجیری صنعتی"), n("mun-fs-transport", "ماشین حمل چوب"),
      n("mun-fs-restore", "تجهیزات احیای جنگل"), n("mun-fs-resource", "ماشین‌آلات منابع طبیعی"),
    ]}),
    /* ── FAMILY 330 ── ماشین‌آلات برف‌روبی و یخ‌زدایی */
    n("mun-snow", "ماشین‌آلات برف‌روبی و یخ‌زدایی", { nameEn: "Snow Removal Equipment", code: "FAM-330", children: [
      n("mun-sn-truck", "برف‌روب کامیونی"), n("mun-sn-blade", "تیغه برف‌روب"),
      n("mun-sn-salt", "نمک‌پاش"), n("mun-sn-deice", "یخ‌زدا"),
      n("mun-sn-airport", "تجهیزات فرودگاهی"), n("mun-sn-fleet", "ناوگان زمستانی"),
    ]}),
    /* ── FAMILY 331 ── تجهیزات آتش‌نشانی و امداد */
    n("mun-fire", "تجهیزات آتش‌نشانی و امداد", { nameEn: "Fire & Rescue Equipment", code: "FAM-331", children: [
      n("mun-fr-truck", "خودرو آتش‌نشانی"), n("mun-fr-pump", "پمپ آتش‌نشانی"),
      n("mun-fr-ladder", "نردبان هیدرولیک"), n("mun-fr-rescue", "تجهیزات نجات"),
      n("mun-fr-extinguish", "سیستم اطفای حریق"), n("mun-fr-ambulance", "خودرو امدادی"),
    ]}),
    /* ── FAMILY 332 ── تجهیزات کنترل آلودگی هوا */
    n("mun-air", "تجهیزات کنترل آلودگی هوا", { nameEn: "Air Pollution Control", code: "FAM-332", children: [
      n("mun-ar-filter", "فیلتر صنعتی هوا"), n("mun-ar-dust", "غبارگیر"),
      n("mun-ar-bag", "Bag Filter"), n("mun-ar-scrubber", "Scrubber"),
      n("mun-ar-vent", "سیستم تهویه صنعتی"), n("mun-ar-smoke", "کنترل دود"),
      n("mun-ar-plant", "کارخانه کنترل آلایندگی"),
    ]}),
    /* ── FAMILY 333 ── تجهیزات انرژی از پسماند */
    n("mun-wte", "تجهیزات انرژی از پسماند", { nameEn: "Waste To Energy", code: "FAM-333", children: [
      n("mun-we-incinerator", "زباله‌سوز صنعتی"), n("mun-we-biogas", "تولید بیوگاز"),
      n("mun-we-digester", "هاضم بی‌هوازی"), n("mun-we-power", "سیستم تولید برق از زباله"),
      n("mun-we-gas", "تصفیه گاز"), n("mun-we-plant", "نیروگاه Waste-to-Energy"),
    ]}),
    /* ── FAMILY 334 ── تجهیزات محیط زیست هوشمند */
    n("mun-smart", "تجهیزات محیط زیست هوشمند", { nameEn: "Smart Environmental Systems", code: "FAM-334", children: [
      n("mun-se-sensor", "سنسور آلودگی"), n("mun-se-air-mon", "مانیتورینگ هوا"),
      n("mun-se-waste", "مدیریت هوشمند پسماند"), n("mun-se-iot", "IoT شهری"),
      n("mun-se-water", "کنترل مصرف آب"), n("mun-se-city", "شهر سبز هوشمند"),
    ]}),
    /* ── FAMILY 335 ── خطوط کامل خدمات شهری */
    n("mun-systems", "خطوط کامل خدمات شهری", { nameEn: "Municipal Systems", code: "FAM-335", children: [
      n("mun-sy-cleaning", "ناوگان نظافت شهری"), n("mun-sy-recycle", "کارخانه بازیافت"),
      n("mun-sy-water", "تصفیه‌خانه آب"), n("mun-sy-wastewater", "تصفیه‌خانه فاضلاب"),
      n("mun-sy-waste", "مرکز مدیریت پسماند"), n("mun-sy-smart", "شهر هوشمند"),
    ]}),
  ],
};