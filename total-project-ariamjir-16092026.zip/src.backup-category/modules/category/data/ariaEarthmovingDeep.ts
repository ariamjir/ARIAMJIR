import type { SeedCategory } from "./categoryTree";

const n = (
  id: string,
  name: string,
  opts?: { nameEn?: string; code?: string; children?: SeedCategory[] }
): SeedCategory => ({
  id,
  name,
  slug: id,
  nameEn: opts?.nameEn,
  code: opts?.code,
  children: opts?.children,
});

export const earthmovingDeep: SeedCategory = {
  id: "earthmoving",
  name: "ماشین‌آلات خاکبرداری",
  slug: "earthmoving",
  nameEn: "Earthmoving Equipment",
  icon: "🚜",
  featured: true,
  showOnHomepage: true,
  children: [
    n("earth-excavators", "بیل مکانیکی", {
      nameEn: "Excavators",
      children: [
        n("earth-exc-crawler", "بیل مکانیکی زنجیری", {
          nameEn: "Crawler Excavator", code: "EXC-CR",
          children: [
            n("exc-cr-u1", "کمتر از ۱ تن"), n("exc-cr-1-2", "۱ تا ۲ تن"),
            n("exc-cr-2-3", "۲ تا ۳ تن"), n("exc-cr-3-5", "۳ تا ۵ تن"),
            n("exc-cr-5-8", "۵ تا ۸ تن"), n("exc-cr-8-10", "۸ تا ۱۰ تن"),
            n("exc-cr-10-15", "۱۰ تا ۱۵ تن"), n("exc-cr-15-20", "۱۵ تا ۲۰ تن"),
            n("exc-cr-20-25", "۲۰ تا ۲۵ تن"), n("exc-cr-25-30", "۲۵ تا ۳۰ تن"),
            n("exc-cr-30-40", "۳۰ تا ۴۰ تن"), n("exc-cr-40-50", "۴۰ تا ۵۰ تن"),
            n("exc-cr-50-70", "۵۰ تا ۷۰ تن"), n("exc-cr-70-100", "۷۰ تا ۱۰۰ تن"),
            n("exc-cr-100p", "بالای ۱۰۰ تن"),
          ],
        }),
        n("earth-exc-wheel", "بیل مکانیکی چرخی", { nameEn: "Wheeled Excavator", code: "EXC-WH" }),
        n("earth-exc-mini", "مینی بیل مکانیکی", { nameEn: "Mini Excavator", code: "EXC-MINI" }),
        n("earth-exc-midi", "میدی بیل مکانیکی", { nameEn: "Midi Excavator", code: "EXC-MIDI" }),
        n("earth-exc-longreach", "بیل مکانیکی بلندبازو", { nameEn: "Long Reach Excavator", code: "EXC-LR" }),
        n("earth-exc-demolition", "بیل مکانیکی تخریب", { nameEn: "Demolition Excavator", code: "EXC-DEM" }),
        n("earth-exc-mining", "بیل مکانیکی معدن", { nameEn: "Mining Excavator", code: "EXC-MIN" }),
        n("earth-exc-material", "بیل مکانیکی حمل مواد", { nameEn: "Material Handler", code: "EXC-MH" }),
        n("earth-exc-amphibious", "بیل مکانیکی دوزیست", { nameEn: "Amphibious Excavator", code: "EXC-AMP" }),
        n("earth-exc-rail", "بیل مکانیکی ریلی", { nameEn: "Rail Excavator", code: "EXC-RAIL" }),
        n("earth-exc-vacuum", "بیل مکانیکی مکنده", { nameEn: "Vacuum Excavator", code: "EXC-VAC" }),
        n("earth-exc-electric", "بیل مکانیکی برقی", { nameEn: "Electric Excavator", code: "EXC-EL" }),
      ],
    }),
    n("earth-loaders", "لودر", {
      nameEn: "Loaders",
      children: [
        n("earth-load-wheel", "لودر چرخی", {
          nameEn: "Wheel Loader", code: "WLO",
          children: [
            n("load-wh-u2", "زیر ۲ تن"), n("load-wh-2-4", "۲ تا ۴ تن"),
            n("load-wh-4-6", "۴ تا ۶ تن"), n("load-wh-6-8", "۶ تا ۸ تن"),
            n("load-wh-8-10", "۸ تا ۱۰ تن"), n("load-wh-10-12", "۱۰ تا ۱۲ تن"),
            n("load-wh-12-15", "۱۲ تا ۱۵ تن"), n("load-wh-15-20", "۱۵ تا ۲۰ تن"),
            n("load-wh-20p", "بالای ۲۰ تن"),
          ],
        }),
        n("earth-load-crawler", "لودر زنجیری", { nameEn: "Crawler Loader", code: "LTR" }),
        n("earth-load-mini", "مینی لودر", { nameEn: "Mini Loader", code: "LMI" }),
        n("earth-load-skidsteer", "اسکید استیر", { nameEn: "Skid Steer Loader", code: "SSL" }),
        n("earth-load-compact", "کامپکت ترک لودر", { nameEn: "Compact Track Loader", code: "CTL" }),
        n("earth-load-backhoe", "بکهو لودر", { nameEn: "Backhoe Loader", code: "BHL" }),
        n("earth-load-mining", "لودر معدن", { nameEn: "Mining Loader", code: "LDM" }),
        n("earth-load-underground", "لودر زیرزمینی", { nameEn: "Underground Loader", code: "LUG" }),
      ],
    }),
    n("earth-bulldozers", "بولدوزر", {
      nameEn: "Bulldozers",
      children: [
        n("earth-bdz-crawler", "بولدوزر زنجیری", { nameEn: "Crawler Dozer", code: "BDZ-CR" }),
        n("earth-bdz-wheel", "بولدوزر چرخی", { nameEn: "Wheel Dozer", code: "BDZ-WH" }),
        n("earth-bdz-mining", "بولدوزر معدن", { nameEn: "Mining Dozer", code: "BDZ-MIN" }),
        n("earth-bdz-swamp", "بولدوزر باتلاقی", { nameEn: "Swamp Dozer", code: "BDZ-SW" }),
        n("earth-bdz-forestry", "بولدوزر جنگلداری", { nameEn: "Forestry Dozer", code: "BDZ-FOR" }),
      ],
    }),
    n("earth-graders", "موتور گریدر", {
      nameEn: "Motor Graders",
      children: [
        n("earth-mgr-light", "موتور گریدر سبک", { code: "MGR-L" }),
        n("earth-mgr-medium", "موتور گریدر متوسط", { code: "MGR-M" }),
        n("earth-mgr-heavy", "موتور گریدر سنگین", { code: "MGR-H" }),
        n("earth-mgr-mining", "موتور گریدر معدنی", { code: "MGR-MIN" }),
      ],
    }),
    n("earth-scrapers", "اسکریپر", {
      nameEn: "Scrapers",
      children: [
        n("earth-scr-towed", "اسکریپر کششی", { code: "SCR-TW" }),
        n("earth-scr-self", "اسکریپر خودکششی", { code: "SCR-SP" }),
        n("earth-scr-twin", "اسکریپر دو موتور", { code: "SCR-TWN" }),
      ],
    }),
    n("earth-dumpers", "دامپر", {
      nameEn: "Dumpers",
      children: [
        n("earth-dmp-artic", "دامپر مفصلی", { code: "DMP-ART" }),
        n("earth-dmp-rigid", "دامپر صلب", { code: "DMP-RIG" }),
        n("earth-dmp-site", "دامپر سایت", { code: "DMP-SITE" }),
      ],
    }),
    n("earth-trenchers", "ترنچر", {
      nameEn: "Trenchers",
      children: [
        n("earth-trn-chain", "ترنچر زنجیری", { code: "TRN-CH" }),
        n("earth-trn-wheel", "ترنچر چرخی", { code: "TRN-WH" }),
        n("earth-trn-rock", "ترنچر سنگ", { code: "TRN-RK" }),
      ],
    }),
    n("earth-skidsteer", "اسکید استیر", { nameEn: "Skid Steer", code: "SSL" }),
  ],
};