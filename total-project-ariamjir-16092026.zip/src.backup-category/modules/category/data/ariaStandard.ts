import type { SeedCategory } from "./categoryTree";
import { earthmovingDeep } from "./ariaEarthmovingDeep";
import { miningDeep } from "./ariaMiningDeep";
import { municipalDeep } from "./ariaMunicipalDeep";
import { generalIndustrialDeep } from "./ariaGeneralIndustrialDeep";
import { servicesDeep } from "./ariaServicesDeep";

/* ============================================================
   ARIA MJ — استاندارد مرجع دسته‌بندی (نسخه ۱.۲ — پاک‌سازی‌شده)
   ساختار: Industry → Family → Machine Type
   ============================================================ */

interface NodeOpts {
  nameEn?: string;
  code?: string;
  icon?: string;
  featured?: boolean;
  showOnHomepage?: boolean;
  showInMenu?: boolean;
  active?: boolean;
  sortOrder?: number;
  children?: SeedCategory[];
}

const ind = (id: string, name: string, opts: NodeOpts = {}): SeedCategory => ({
  id,
  name,
  nameEn: opts.nameEn || name,
  slug: id,
  icon: opts.icon || "🏭",
  featured: opts.featured ?? true,
  showOnHomepage: opts.showOnHomepage ?? true,
  showInMenu: opts.showInMenu ?? true,
  active: opts.active ?? true,
  sortOrder: opts.sortOrder ?? 0,
  children: opts.children || [],
});

const n = (id: string, name: string, opts: NodeOpts = {}): SeedCategory => ({
  id,
  name,
  nameEn: opts.nameEn || name,
  slug: id,
  code: opts.code || id.toUpperCase().replace(/-/g, "_"),
  icon: opts.icon,
  featured: opts.featured,
  showOnHomepage: opts.showOnHomepage,
  showInMenu: opts.showInMenu,
  active: opts.active ?? true,
  sortOrder: opts.sortOrder ?? 0,
  children: opts.children || [],
});

/* ============================================================
   1. ماشین‌آلات راهسازی
   ============================================================ */
const roadConstruction = ind("road-construction", "ماشین‌آلات راهسازی", {
  nameEn: "Road Construction Machinery", icon: "🛣️", featured: true, sortOrder: 1,
  children: [
    n("rc-grader", "گریدر", { nameEn: "Motor Grader", children: [
      n("rc-grader-small", "گریدر کوچک (زیر ۱۰۰ اسب)", { nameEn: "Small Motor Grader", code: "GRD-SM" }),
      n("rc-grader-medium", "گریدر متوسط (۱۰۰ تا ۲۰۰ اسب)", { nameEn: "Medium Motor Grader", code: "GRD-MD" }),
      n("rc-grader-large", "گریدر سنگین (بالای ۲۰۰ اسب)", { nameEn: "Large Motor Grader", code: "GRD-LG" }),
    ]}),
    n("rc-roller", "غلتک", { nameEn: "Road Roller", children: [
      n("rc-roller-single", "غلتک تک‌چرخ", { nameEn: "Single Drum Roller", code: "RLR-SD" }),
      n("rc-roller-tandem", "غلتک دوچرخ", { nameEn: "Tandem Roller", code: "RLR-TD" }),
      n("rc-roller-pneumatic", "غلتک پنوماتیک", { nameEn: "Pneumatic Roller", code: "RLR-PN" }),
      n("rc-roller-vibratory", "غلتک ارتعاشی", { nameEn: "Vibratory Roller", code: "RLR-VB" }),
      n("rc-roller-padfoot", "غلتک پایه‌دار (Sheepsfoot)", { nameEn: "Padfoot Roller", code: "RLR-PF" }),
    ]}),
    n("rc-paver", "فینیشر (آسفالت‌ریز)", { nameEn: "Asphalt Paver", children: [
      n("rc-paver-tracked", "فینیشر زنجیری", { nameEn: "Tracked Paver", code: "PVR-TR" }),
      n("rc-paver-wheeled", "فینیشر چرخی", { nameEn: "Wheeled Paver", code: "PVR-WH" }),
    ]}),
    n("rc-milling", "فرز آسفالت (Milling)", { nameEn: "Cold Planer", children: [
      n("rc-milling-small", "فرز کوچک", { nameEn: "Small Planer", code: "MLR-SM" }),
      n("rc-milling-large", "فرز بزرگ", { nameEn: "Large Planer", code: "MLR-LG" }),
    ]}),
    n("rc-asphalt-plant", "کارخانه آسفالت", { nameEn: "Asphalt Plant", children: [
      n("rc-asphalt-batch", "کارخانه آسفالت بچینگ", { nameEn: "Batch Mix Plant", code: "ASP-BT" }),
      n("rc-asphalt-drum", "کارخانه آسفالت درام", { nameEn: "Drum Mix Plant", code: "ASP-DR" }),
    ]}),
    n("rc-concrete-paver", "پاوه بتن (بتن‌ریز)", { nameEn: "Concrete Paver", children: [
      n("rc-concrete-slipform", "پاوه اسلیپ‌فرم", { nameEn: "Slipform Paver", code: "CVP-SF" }),
    ]}),
    n("rc-sweeper", "جارو مکانیکی", { nameEn: "Sweeper", code: "SWP" }),
    n("rc-line-marker", "خط‌کش جاده", { nameEn: "Line Marker", code: "LNM" }),
  ],
});

/* ============================================================
   7. جرثقیل و بالابری
   ============================================================ */
const crane = ind("crane", "جرثقیل و بالابری", {
  nameEn: "Cranes & Lifting Equipment", icon: "🏗️", featured: true, sortOrder: 6,
  children: [
    n("crane-mobile", "جرثقیل متحرک", { nameEn: "Mobile Crane", children: [
      n("crane-mobile-truck", "جرثقیل کامیونی", { nameEn: "Truck Crane", code: "CRN-TRK" }),
      n("crane-mobile-rough", "جرثقیل Rough Terrain", { nameEn: "Rough Terrain Crane", code: "CRN-RT" }),
      n("crane-mobile-all", "جرثقیل All-Terrain", { nameEn: "All-Terrain Crane", code: "CRN-AT" }),
      n("crane-mobile-crawler", "جرثقیل زنجیری", { nameEn: "Crawler Crane", code: "CRN-CR" }),
    ]}),
    n("crane-tower", "جرثقیل برجی", { nameEn: "Tower Crane", children: [
      n("crane-tower-luffing", "جرثقیل برجی Luffing", { nameEn: "Luffing Jib", code: "TW-LF" }),
      n("crane-tower-hammerhead", "جرثقیل برجی Hammerhead", { nameEn: "Hammerhead", code: "TW-HH" }),
      n("crane-tower-self", "جرثقیل برجی خودبرپا", { nameEn: "Self-Erecting", code: "TW-SE" }),
    ]}),
    n("crane-overhead", "جرثقیل سقفی", { nameEn: "Overhead Crane", children: [
      n("crane-overhead-single", "تک‌پل", { nameEn: "Single Girder", code: "OVH-SG" }),
      n("crane-overhead-double", "دوپل", { nameEn: "Double Girder", code: "OVH-DG" }),
      n("crane-overhead-gantry", "دروازه‌ای", { nameEn: "Gantry Crane", code: "OVH-GT" }),
    ]}),
    n("crane-hoist", "وینچ و بالابر", { nameEn: "Hoist & Winch", children: [
      n("crane-hoist-electric", "بالابر برقی", { nameEn: "Electric Hoist", code: "HST-EL" }),
      n("crane-hoist-manual", "بالابر دستی", { nameEn: "Manual Hoist", code: "HST-MN" }),
    ]}),
    n("crane-aerial", "بالابر هوایی", { nameEn: "Aerial Platform", children: [
      n("crane-aerial-scissor", "قیچی", { nameEn: "Scissor Lift", code: "AER-SC" }),
      n("crane-aerial-boom", "بوم‌دار", { nameEn: "Boom Lift", code: "AER-BM" }),
      n("crane-aerial-vertical", "عمودبر", { nameEn: "Vertical Mast", code: "AER-VM" }),
    ]}),
  ],
});

/* ============================================================
   4. بتن
   ============================================================ */
const concrete = ind("concrete", "ماشین‌آلات بتن", {
  nameEn: "Concrete Equipment", icon: "🏛️", featured: true, sortOrder: 4,
  children: [
    n("con-batching", "کارخانه بچینگ", { nameEn: "Batching Plant", code: "CBP" }),
    n("con-mixer", "میکسر", { nameEn: "Concrete Mixer", children: [
      n("con-mixer-truck", "تراک میکسر", { nameEn: "Mixer Truck", code: "CMX-TR" }),
      n("con-mixer-stationary", "ثابت", { nameEn: "Stationary Mixer", code: "CMX-ST" }),
    ]}),
    n("con-pump", "پمپ بتن", { nameEn: "Concrete Pump", children: [
      n("con-pump-boom", "بوم‌دار", { nameEn: "Boom Pump", code: "CPM-BM" }),
      n("con-pump-trailer", "یدک‌کش", { nameEn: "Trailer Pump", code: "CPM-TR" }),
      n("con-pump-placing", "پلاسینگ بوم", { nameEn: "Placing Boom", code: "CPM-PL" }),
    ]}),
    n("con-spraying", "شاتکریت", { nameEn: "Shotcrete Machine", code: "CSP" }),
    n("con-vibrator", "ویبراتور", { nameEn: "Concrete Vibrator", code: "CVB" }),
    n("con-screed", "ماساله‌کش", { nameEn: "Screed", code: "CSC" }),
    n("con-rebar", "تجهیزات آرماتوربندی", { nameEn: "Rebar Equipment", children: [
      n("con-rebar-bender", "خم‌کن", { nameEn: "Rebar Bender", code: "CRB-BN" }),
      n("con-rebar-cutter", "برش‌دهنده", { nameEn: "Rebar Cutter", code: "CRB-CT" }),
    ]}),
  ],
});

/* ============================================================
   6. حفاری
   ============================================================ */
const drilling = ind("drilling", "حفاری", {
  nameEn: "Drilling Equipment", icon: "🔩", featured: false, sortOrder: 5,
  children: [
    n("drl-rig-surface", "دریل سطحی", { nameEn: "Surface Drill Rig", code: "DRS" }),
    n("drl-rig-underground", "دریل زیرزمینی", { nameEn: "Underground Drill Rig", code: "DRU" }),
    n("drl-rig-water", "دریل چاه آب", { nameEn: "Water Well Drill", code: "DRW" }),
    n("drl-rig-geothermal", "دریل ژئوترمال", { nameEn: "Geothermal Drill", code: "DRG" }),
  ],
});

/* ============================================================
   18. تونل‌سازی
   ============================================================ */
const tunneling = ind("tunneling", "تونل‌سازی", {
  nameEn: "Tunneling Equipment", icon: "🕳️", featured: false, sortOrder: 13,
  children: [
    n("tun-tbm", "TBM", { nameEn: "Tunnel Boring Machine", code: "TTB" }),
    n("tun-roadheader", "Roadheader", { nameEn: "Roadheader", code: "TRH" }),
    n("tun-shotcrete", "Shotcrete Machine", { nameEn: "Shotcrete Machine", code: "TSC" }),
    n("tun-bolting", "Rock Bolting Rig", { nameEn: "Rock Bolting", code: "TRB" }),
  ],
});

/* ============================================================
   17. تخریب
   ============================================================ */
const demolition = ind("demolition", "تخریب", {
  nameEn: "Demolition Equipment", icon: "💥", featured: false, sortOrder: 14,
  children: [
    n("dem-excavator", "بیل تخریب", { nameEn: "Demolition Excavator", code: "DEX" }),
    n("dem-breaker", "Hydraulic Breaker", { nameEn: "Hydraulic Breaker", code: "DBK" }),
    n("dem-shear", "Hydraulic Shear", { nameEn: "Hydraulic Shear", code: "DSH" }),
    n("dem-pulverizer", "Pulverizer", { nameEn: "Pulverizer", code: "DPV" }),
  ],
});

/* ============================================================
   21. تراکم
   ============================================================ */
const compaction = ind("compaction", "تراکم", {
  nameEn: "Compaction Equipment", icon: "🔨", featured: false, sortOrder: 16,
  children: [
    n("cmp-plate", "Plate Compactor", { nameEn: "Plate Compactor", code: "CPL" }),
    n("cmp-rammer", "Jumping Jack", { nameEn: "Jumping Jack", code: "CRM" }),
    n("cmp-roller", "Compaction Roller", { nameEn: "Compaction Roller", code: "CRL" }),
  ],
});

/* ============================================================
   13. کامیون و حمل و نقل
   ============================================================ */
const truck = ind("truck", "کامیون و حمل و نقل", {
  nameEn: "Trucks & Transport", icon: "🚛", featured: true, sortOrder: 10,
  children: [
    n("trk-dump", "کمپرسی", { nameEn: "Dump Truck", children: [
      n("trk-dump-6x4", "۶ چرخ ۴ محور", { nameEn: "6x4 Dump", code: "DMT-64" }),
      n("trk-dump-8x4", "۸ چرخ ۴ محور", { nameEn: "8x4 Dump", code: "DMT-84" }),
      n("trk-dump-articulated", "کمرشکن", { nameEn: "Articulated", code: "DMT-AR" }),
    ]}),
    n("trk-tractor", "کشنده", { nameEn: "Tractor Truck", children: [
      n("trk-tractor-4x2", "۴x۲", { nameEn: "4x2 Tractor", code: "TTR-42" }),
      n("trk-tractor-6x4", "۶x۴", { nameEn: "6x4 Tractor", code: "TTR-64" }),
    ]}),
    n("trk-tanker", "تانکر", { nameEn: "Tanker", children: [
      n("trk-tanker-fuel", "سوخت", { nameEn: "Fuel Tanker", code: "TNK-FL" }),
      n("trk-tanker-water", "آب", { nameEn: "Water Tanker", code: "TNK-WT" }),
    ]}),
    n("trk-mixer", "میکسر حمل بتن", { nameEn: "Mixer Truck", code: "TMT" }),
    n("trk-flatbed", "کفی", { nameEn: "Flatbed", code: "TFB" }),
    n("trk-trailer", "تریلی", { nameEn: "Trailer", code: "TRL" }),
  ],
});

/* ============================================================
   12. کشاورزی
   ============================================================ */
const agriculture = ind("agriculture", "ماشین‌آلات کشاورزی", {
  nameEn: "Agricultural Machinery", icon: "🚜", featured: true, sortOrder: 8,
  children: [
    n("agr-tractor", "تراکتور کشاورزی", { nameEn: "Farm Tractor", children: [
      n("agr-tractor-2wd", "تک دیفرانسیل", { nameEn: "2WD Tractor", code: "ATR-2W" }),
      n("agr-tractor-4wd", "چهار چرخ", { nameEn: "4WD Tractor", code: "ATR-4W" }),
    ]}),
    n("agr-combine", "کمباین", { nameEn: "Combine Harvester", children: [
      n("agr-combine-grain", "غلات", { nameEn: "Grain Combine", code: "CMB-GR" }),
      n("agr-combine-corn", "ذرت", { nameEn: "Corn Combine", code: "CMB-CN" }),
    ]}),
    n("agr-harvester", "برداشت‌کننده", { nameEn: "Harvester", code: "AHR" }),
    n("agr-seeder", "بذرکار", { nameEn: "Seeder", code: "ASD" }),
    n("agr-plow", "گاوآهن", { nameEn: "Plow", code: "APL" }),
    n("agr-sprayer", "سم‌پاش", { nameEn: "Sprayer", code: "ASP" }),
    n("agr-irrigation", "تجهیزات آبیاری", { nameEn: "Irrigation", code: "AIR" }),
  ],
});

/* ============================================================
   12ب. جنگلداری
   ============================================================ */
const forestry = ind("forestry", "ماشین‌آلات جنگلداری", {
  nameEn: "Forestry Equipment", icon: "🌲", featured: false, sortOrder: 9,
  children: [
    n("for-harvester", "Harvester", { nameEn: "Harvester", code: "FHV" }),
    n("for-forwarder", "Forwarder", { nameEn: "Forwarder", code: "FFW" }),
    n("for-skidder", "Skidder", { nameEn: "Skidder", code: "FSK" }),
    n("for-feller", "Feller Buncher", { nameEn: "Feller Buncher", code: "FFB" }),
    n("for-chipper", "Chipper", { nameEn: "Wood Chipper", code: "FCH" }),
  ],
});

/* ============================================================
   14. دریایی
   ============================================================ */
const marine = ind("marine", "تجهیزات دریایی", {
  nameEn: "Marine Equipment", icon: "🚢", featured: false, sortOrder: 11,
  children: [
    n("mar-crane", "Marine Crane", { nameEn: "Marine Crane", code: "MCR" }),
    n("mar-dredger", "Dredger", { nameEn: "Dredger", code: "MDR" }),
    n("mar-winch", "Marine Winch", { nameEn: "Marine Winch", code: "MWN" }),
    n("mar-tug", "Tug Boat", { nameEn: "Tug Boat", code: "MTG" }),
  ],
});

/* ============================================================
   14ب. ریلی
   ============================================================ */
const railway = ind("railway", "تجهیزات ریلی", {
  nameEn: "Railway Equipment", icon: "🚂", featured: false, sortOrder: 12,
  children: [
    n("rail-tamping", "Tamping Machine", { nameEn: "Tamping Machine", code: "RTM" }),
    n("rail-ballast", "Ballast Regulator", { nameEn: "Ballast Regulator", code: "RBR" }),
    n("rail-grinder", "Rail Grinder", { nameEn: "Rail Grinder", code: "RGR" }),
    n("rail-crane", "Railway Crane", { nameEn: "Railway Crane", code: "RCR" }),
  ],
});

/* ============================================================
   10. نفت، گاز و انرژی
   ============================================================ */
const oilGas = ind("oil-gas", "نفت، گاز و انرژی", {
  nameEn: "Oil, Gas & Energy Equipment", icon: "🛢️", featured: true, sortOrder: 7,
  children: [
    n("oil-drilling", "تجهیزات حفاری", { nameEn: "Drilling Equipment", children: [
      n("oil-drilling-rig", "دکل حفاری", { nameEn: "Drilling Rig", code: "ODR-RG" }),
      n("oil-drilling-top", "Top Drive", { nameEn: "Top Drive", code: "ODR-TD" }),
    ]}),
    n("oil-well-service", "خدمات چاه", { nameEn: "Well Service", code: "OWS" }),
    n("oil-production", "تجهیزات تولید", { nameEn: "Production Equipment", code: "OPD" }),
    n("oil-pipeline", "خط لوله", { nameEn: "Pipeline Equipment", children: [
      n("oil-pipeline-welding", "جوشکاری خط لوله", { nameEn: "Pipeline Welding", code: "OPL-WD" }),
      n("oil-pipeline-bending", "خم‌کاری", { nameEn: "Pipe Bending", code: "OPL-BN" }),
    ]}),
    n("oil-refinery", "پالایشگاهی", { nameEn: "Refinery Equipment", code: "ORF" }),
    n("oil-petrochem", "پتروشیمی", { nameEn: "Petrochemical", code: "OPC" }),
  ],
});

/* ============================================================
   22. تولید برق و انرژی (ژنراتور هم ادغام شد)
   ============================================================ */
const power = ind("power-generation", "تولید برق و انرژی", {
  nameEn: "Power Generation & Energy", icon: "⚡", featured: false, sortOrder: 15,
  children: [
    n("pwr-diesel-gen", "دیزل ژنراتور", { nameEn: "Diesel Generator", code: "PDG" }),
    n("pwr-gas-gen", "ژنراتور گازی", { nameEn: "Gas Generator", code: "PGG" }),
    n("pwr-portable", "ژنراتور پرتابل", { nameEn: "Portable Generator", code: "PPT" }),
    n("pwr-light-tower", "برج نور", { nameEn: "Light Tower", code: "PLT" }),
    n("pwr-turbine", "توربین", { nameEn: "Turbine", code: "PTB" }),
    n("pwr-transformer", "ترانسفورماتور", { nameEn: "Transformer", code: "PTR" }),
  ],
});

/* ============================================================
   23. جوشکاری
   ============================================================ */
const welding = ind("welding", "جوشکاری", {
  nameEn: "Welding Equipment", icon: "🔥", featured: false, sortOrder: 17,
  children: [
    n("wld-arc", "MMA Welder", { nameEn: "MMA Welder", code: "WAR" }),
    n("wld-mig", "MIG Welder", { nameEn: "MIG Welder", code: "WMG" }),
    n("wld-tig", "TIG Welder", { nameEn: "TIG Welder", code: "WTG" }),
    n("wld-plasma", "Plasma Cutter", { nameEn: "Plasma Cutter", code: "WPL" }),
  ],
});

/* ============================================================
   10ب. تجهیزات فرودگاهی
   ============================================================ */
const airport = ind("airport", "تجهیزات فرودگاهی", {
  nameEn: "Airport Ground Support", icon: "✈️", featured: false, sortOrder: 18,
  children: [
    n("air-baggage", "Baggage Conveyor", { nameEn: "Baggage Conveyor", code: "ABG" }),
    n("air-cart", "Baggage Cart", { nameEn: "Baggage Cart", code: "ACT" }),
    n("air-cargo-loader", "Cargo Loader", { nameEn: "Cargo Loader", code: "ACL" }),
    n("air-belt", "Belt Loader", { nameEn: "Belt Loader", code: "ABL" }),
    n("air-dolly", "Container Dolly", { nameEn: "Container Dolly", code: "ADL" }),
    n("air-tow", "Tow Tractor", { nameEn: "Tow Tractor", code: "ATW" }),
    n("air-gse", "GSE", { nameEn: "Ground Support Equipment", code: "AGSE" }),
  ],
});

/* ============================================================
   11ب. کارخانه و خط تولید
   ============================================================ */
const factory = ind("factory", "کارخانه و خط تولید", {
  nameEn: "Factory & Production", icon: "🏭", featured: false, sortOrder: 19,
  children: [
    n("fac-crane-overhead", "جرثقیل سقفی", { nameEn: "Overhead Crane", code: "FCR-OH" }),
    n("fac-crane-gantry", "جرثقیل دروازه‌ای", { nameEn: "Gantry Crane", code: "FCR-GT" }),
    n("fac-monorail", "مونوریل", { nameEn: "Monorail", code: "FMR" }),
    n("fac-air-transfer", "سیستم انتقال هوایی", { nameEn: "Air Transfer", code: "FAT" }),
    n("fac-fixture", "فیکسچر حمل", { nameEn: "Carrying Fixture", code: "FFX" }),
    n("fac-robot", "ربات انتقال قطعه", { nameEn: "Transfer Robot", code: "FRB" }),
    n("fac-lift-table", "میز بالابر", { nameEn: "Lift Table", code: "FLT" }),
  ],
});

/* ============================================================
   سایر
   ============================================================ */
const other = ind("other", "سایر و ویژه", {
  nameEn: "Other & Specialty", icon: "🔧", featured: false, sortOrder: 20,
  children: [
    n("oth-workshop", "کارگاه سیار", { nameEn: "Mobile Workshop", code: "OWS" }),
    n("oth-welder-gen", "دستگاه جوش-ژنراتور", { nameEn: "Welder Generator", code: "OWG" }),
    n("oth-combo", "ترکیبی", { nameEn: "Combo Machine", code: "OCM" }),
  ],
});

/* ============================================================
   LEVEL 0 — والد اصلی (Super Root)
   ============================================================ */
const heavyMachinery = ind("heavy-machinery", "ماشین‌آلات سنگین", {
  nameEn: "Heavy Machinery",
  icon: "🏗️",
  featured: true,
  showOnHomepage: false,
  showInMenu: true,
  sortOrder: 0,
  children: [
    roadConstruction,
    { ...earthmovingDeep, featured: true, showOnHomepage: true, showInMenu: true, sortOrder: 2 },
    miningDeep && { ...miningDeep, featured: true, showOnHomepage: true, showInMenu: true, sortOrder: 3 },
    concrete,
    drilling,
    crane,
    oilGas,
    agriculture,
    forestry,
    truck,
    marine,
    railway,
    tunneling,
    demolition,
    power,
    compaction,
    welding,
    airport,
    factory,
    other,
    { ...municipalDeep, featured: false, showOnHomepage: true, showInMenu: true, sortOrder: 21 },
    { ...generalIndustrialDeep, featured: false, showOnHomepage: true, showInMenu: true, sortOrder: 22 },
  ].filter(Boolean) as SeedCategory[],
});

/* ============================================================
   EXPORT
   ============================================================ */
export const ariaCategoryTree: SeedCategory[] = [
  heavyMachinery,  // دامنه MACHINE
  servicesDeep,    // دامنه SERVICE
];

export const ARIA_STATS = {
  industries: 40,   // 22 ماشین + 18 خدمات
  families: 172,
  totalNodes: 789,
  version: "1.3.0",
  lastUpdated: "2026-08-05",
};