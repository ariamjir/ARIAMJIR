"use client";

import {
  useCallback,
  useEffect,
  useMemo,
  useState,
} from "react";

import type {
  Category,
  CategoryFormData,
} from "../types";

import {
  categoryService,
} from "../services/category.service";

export function useCategories() {
  const [
    categories,
    setCategories,
  ] = useState<Category[]>([]);

  const [
    loading,
    setLoading,
  ] = useState(true);

  const [
    saving,
    setSaving,
  ] = useState(false);

  const [
    error,
    setError,
  ] = useState<string | null>(
    null
  );

  /* ============================================================
     LOAD
  ============================================================ */

  const loadCategories =
    useCallback(
      async () => {
        try {
          setLoading(true);

          const data =
            await categoryService.getAll();

          setCategories(data);

          setError(null);
        } catch (
          err
        ) {
          console.error(
            err
          );

          setError(
            err instanceof Error
              ? err.message
              : "Failed to load categories."
          );
        } finally {
          setLoading(false);
        }
      },
      []
    );

  const reload =
    useCallback(
      async () => {
        await loadCategories();
      },
      [
        loadCategories,
      ]
    );

  useEffect(() => {
    loadCategories();
  }, [
    loadCategories,
  ]);

  /* ============================================================
     LISTS
  ============================================================ */

  const rootCategories =
    useMemo(() => {
      return categories.filter(
        (item) =>
          !item.parentId
      );
    }, [
      categories,
    ]);

  const activeCategories =
    useMemo(() => {
      return categories.filter(
        (item) =>
          item.active
      );
    }, [
      categories,
    ]);

  const featuredCategories =
    useMemo(() => {
      return categories.filter(
        (item) =>
          item.featured
      );
    }, [
      categories,
    ]);

  // ✅ جدید — دسته‌های غیرفعال (برای پنل ادمین)
  const inactiveCategories =
    useMemo(() => {
      return categories.filter(
        (item) => !item.active
      );
    }, [
      categories,
    ]);

  // ✅ جدید — همهٔ دسته‌ها مرتب‌شده بر اساس sortOrder
  const sortedCategories =
    useMemo(() => {
      return [
        ...categories,
      ].sort(
        (a, b) =>
          a.sortOrder - b.sortOrder
      );
    }, [
      categories,
    ]);

  // ✅ جدید — دسته‌های قابل نمایش در منو (فعال + showInMenu)
  const menuCategories =
    useMemo(() => {
      return categories
        .filter(
          (item) =>
            item.active === true &&
            item.showInMenu === true
        )
        .sort(
          (a, b) =>
            a.sortOrder - b.sortOrder
        );
    }, [
      categories,
    ]);

  // ✅ جدید — دسته‌های قابل نمایش در صفحه اصلی (فعال + showOnHomepage)
  const homepageCategories =
    useMemo(() => {
      return categories
        .filter(
          (item) =>
            item.active === true &&
            item.showOnHomepage === true
        )
        .sort(
          (a, b) =>
            a.sortOrder - b.sortOrder
        );
    }, [
      categories,
    ]);

  /* ============================================================
     FIND
  ============================================================ */

  const getById =
    useCallback(
      (
        id: string
      ) => {
        return categories.find(
          (
            item
          ) =>
            item.id === id
        );
      },
      [
        categories,
      ]
    );

  const getBySlug =
    useCallback(
      (
        slug: string
      ) => {
        return categories.find(
          (
            item
          ) =>
            item.slug === slug
        );
      },
      [
        categories,
      ]
    );

  const getChildren =
    useCallback(
      (
        parentId: string
      ) => {
        return categories.filter(
          (
            item
          ) =>
            item.parentId ===
            parentId
        );
      },
      [
        categories,
      ]
    );

  const getParent =
    useCallback(
      (
        id: string
      ) => {
        const current =
          categories.find(
            (
              item
            ) =>
              item.id === id
          );

        if (
          !current?.parentId
        ) {
          return undefined;
        }

        return categories.find(
          (
            item
          ) =>
            item.id ===
            current.parentId
        );
      },
      [
        categories,
      ]
    );

  const getTree =
    useCallback(() => {
      return rootCategories.map(
        (
          parent
        ) => ({
          ...parent,

          children:
            categories.filter(
              (
                item
              ) =>
                item.parentId ===
                parent.id
            ),
        })
      );
    }, [
      categories,
      rootCategories,
    ]);

  const exists =
    useCallback(
      (
        slug: string
      ) => {
        return categories.some(
          (
            item
          ) =>
            item.slug === slug
        );
      },
      [
        categories,
      ]
    );

  // ✅ جدید — همهٔ اجداد یک دسته (از ریشه تا والد مستقیم)
  const getAncestors =
    useCallback(
      (
        id: string
      ): Category[] => {
        const ancestors: Category[] =
          [];

        let current =
          categories.find(
            (item) => item.id === id
          );

        while (current?.parentId) {
          const parent =
            categories.find(
              (item) =>
                item.id ===
                current!.parentId
            );

          if (!parent) {
            break;
          }

          ancestors.unshift(parent);
          current = parent;
        }

        return ancestors;
      },
      [
        categories,
      ]
    );

  // ✅ جدید — مسیر کامل breadcrumb (اجداد + خود دسته)
  const getBreadcrumb =
    useCallback(
      (
        id: string
      ): Category[] => {
        const current =
          categories.find(
            (item) => item.id === id
          );

        if (!current) {
          return [];
        }

        return [
          ...getAncestors(id),
          current,
        ];
      },
      [
        categories,
        getAncestors,
      ]
    );

  // ✅ جدید — دسته‌های هم‌سطح (برای «دسته‌های مرتبط»)
  const getSiblings =
    useCallback(
      (
        id: string
      ): Category[] => {
        const current =
          categories.find(
            (item) => item.id === id
          );

        if (!current) {
          return [];
        }

        return categories.filter(
          (item) =>
            item.parentId ===
              current.parentId &&
            item.id !== id
        );
      },
      [
        categories,
      ]
    );

  // ✅ جدید — همهٔ نوادگان (زیرمجموعه‌های تو در تو)
  const getDescendants =
    useCallback(
      (
        id: string
      ): Category[] => {
        const descendants: Category[] =
          [];

        const collect = (
          parentId: string
        ) => {
          const children =
            categories.filter(
              (item) =>
                item.parentId ===
                parentId
            );

          for (const child of children) {
            descendants.push(child);
            collect(child.id);
          }
        };

        collect(id);

        return descendants;
      },
      [
        categories,
      ]
    );

  // ✅ جدید — جستجوی دسته‌ها بر اساس نام / slug / توضیحات
  const search =
    useCallback(
      (
        keyword: string
      ): Category[] => {
        const query =
          keyword.trim().toLowerCase();

        if (!query) {
          return categories;
        }

        return categories.filter(
          (item) =>
            item.name
              .toLowerCase()
              .includes(query) ||
            item.slug
              .toLowerCase()
              .includes(query) ||
            (
              item.description
                ?.toLowerCase()
                .includes(query) ?? false
            )
        );
      },
      [
        categories,
      ]
    );

  // ✅ جدید — عمق یک دسته در درخت (۰ برای ریشه)
  const getLevel =
    useCallback(
      (
        id: string
      ): number => {
        return getAncestors(id).length;
      },
      [
        getAncestors,
      ]
    );

  /* ============================================================
     CREATE
  ============================================================ */

  const create =
    useCallback(
      async (
        data: CategoryFormData
      ) => {
        try {
          setSaving(true);

          const created =
            await categoryService.create(
              data
            );

          setCategories(
            (
              previous
            ) => [
              ...previous,
              created,
            ]
          );

          return created;
        } finally {
          setSaving(false);
        }
      },
      []
    );

  /* ============================================================
     UPDATE
  ============================================================ */

  const update =
    useCallback(
      async (
        id: string,
        data: Partial<CategoryFormData>
      ) => {
        try {
          setSaving(true);

          const updated =
            await categoryService.update(
              id,
              data
            );

          setCategories(
            (
              previous
            ) =>
              previous.map(
                (
                  item
                ) =>
                  item.id ===
                  id
                    ? updated
                    : item
              )
          );

          return updated;
        } finally {
          setSaving(false);
        }
      },
      []
    );

  /* ============================================================
     DELETE
  ============================================================ */

  const remove =
    useCallback(
      async (
        id: string
      ) => {
        try {
          setSaving(true);

          await categoryService.remove(
            id
          );

          setCategories(
            (
              previous
            ) =>
              previous.filter(
                (
                  item
                ) =>
                  item.id !==
                  id
              )
          );
        } finally {
          setSaving(false);
        }
      },
      []
    );

  /* ============================================================
     STATUS
  ============================================================ */

  const toggleActive =
    useCallback(
      async (
        id: string,
        active: boolean
      ) => {
        try {
          setSaving(true);

          const updated =
            await categoryService.toggleActive(
              id,
              active
            );

          setCategories(
            (
              previous
            ) =>
              previous.map(
                (
                  item
                ) =>
                  item.id ===
                  id
                    ? updated
                    : item
              )
          );

          return updated;
        } finally {
          setSaving(false);
        }
      },
      []
    );

  const toggleFeatured =
    useCallback(
      async (
        id: string,
        featured: boolean
      ) => {
        try {
          setSaving(true);

          const updated =
            await categoryService.toggleFeatured(
              id,
              featured
            );

          setCategories(
            (
              previous
            ) =>
              previous.map(
                (
                  item
                ) =>
                  item.id ===
                  id
                    ? updated
                    : item
              )
          );

          return updated;
        } finally {
          setSaving(false);
        }
      },
      []
    );

  // ✅ جدید — کنترل نمایش در منو
  const toggleShowInMenu =
    useCallback(
      async (
        id: string,
        showInMenu: boolean
      ) => {
        try {
          setSaving(true);

          const updated =
            await categoryService.toggleShowInMenu(
              id,
              showInMenu
            );

          setCategories(
            (
              previous
            ) =>
              previous.map(
                (
                  item
                ) =>
                  item.id ===
                  id
                    ? updated
                    : item
              )
          );

          return updated;
        } finally {
          setSaving(false);
        }
      },
      []
    );

  // ✅ جدید — کنترل نمایش در صفحه اصلی
  const toggleShowOnHomepage =
    useCallback(
      async (
        id: string,
        showOnHomepage: boolean
      ) => {
        try {
          setSaving(true);

          const updated =
            await categoryService.toggleShowOnHomepage(
              id,
              showOnHomepage
            );

          setCategories(
            (
              previous
            ) =>
              previous.map(
                (
                  item
                ) =>
                  item.id ===
                  id
                    ? updated
                    : item
              )
          );

          return updated;
        } finally {
          setSaving(false);
        }
      },
      []
    );

  /* ============================================================
     RETURN
  ============================================================ */

  return {

    /* -----------------------------
       STATE
    ----------------------------- */

    categories,

    loading,

    saving,

    error,

    /* -----------------------------
       RELOAD
    ----------------------------- */

    reload,

    /* -----------------------------
       LISTS
    ----------------------------- */

    rootCategories,

    activeCategories,

    featuredCategories,

    inactiveCategories,

    sortedCategories,

    menuCategories,

    homepageCategories,

    /* -----------------------------
       FIND
    ----------------------------- */

    getById,

    getBySlug,

    getChildren,

    getParent,

    getTree,

    exists,

    getAncestors,

    getBreadcrumb,

    getSiblings,

    getDescendants,

    search,

    getLevel,

    /* -----------------------------
       CRUD
    ----------------------------- */

    create,

    update,

    remove,

    toggleActive,

    toggleFeatured,

    toggleShowInMenu,

    toggleShowOnHomepage,

    /* -----------------------------
       COUNTS
    ----------------------------- */

    totalCount:
      categories.length,

    activeCount:
      activeCategories.length,

    featuredCount:
      featuredCategories.length,

    rootCount:
      rootCategories.length,

    inactiveCount:
      inactiveCategories.length,

    menuCount:
      menuCategories.length,

    homepageCount:
      homepageCategories.length,

    totalMachinesCount:
      categories.reduce(
        (sum, item) =>
          sum + (item.machinesCount ?? 0),
        0
      ),

    childCount: (
      parentId: string
    ) =>
      getChildren(parentId)
        .length,

    /* -----------------------------
       FLAGS
    ----------------------------- */

    isEmpty:
      categories.length === 0,
  };
}