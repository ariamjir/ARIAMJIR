import type { z } from "zod";

import type {
  categorySchema,
} from "../schema/category.schema";

/* ============================================================
   ENTITY
============================================================ */

export interface Category {
  id: string;

  parentId: string | null;

  parent?: Category | null;

  children: Category[];

  name: string;

  slug: string;

  description: string | null;

  icon: string | null;

  image: string | null;

  sortOrder: number;

  active: boolean;

  featured: boolean;

  showInMenu: boolean;

  showOnHomepage: boolean;

  metaTitle: string | null;

  metaDescription: string | null;

  // ✅ هماهنگ با Prisma (String?) — رشته به جای آرایه
  keywords: string | null;

  machinesCount: number;

  childrenCount: number;

  createdAt: string;

  updatedAt: string;
}

/* ============================================================
   FORM
============================================================ */

export type CategoryFormData =
  z.infer<typeof categorySchema>;

export type CategoryUpdateData =
  Partial<CategoryFormData>;

/* ============================================================
   TREE
============================================================ */

export interface CategoryTree
  extends Category {
  children: CategoryTree[];
}

/* ============================================================
   FILTERS
============================================================ */

export interface CategoryFilters {
  keyword?: string;

  active?: boolean;

  featured?: boolean;

  parentId?: string | null;
}

/* ============================================================
   TABLE
============================================================ */

export interface CategoryTableRow
  extends Category {
  level?: number;

  hasChildren?: boolean;
}