import type {
  Category,
  CategoryFormData,
} from "../types";

import categoryRepository from "../repositories/category.repository";

class CategoryService {

  /* ============================================================
     GET
  ============================================================ */

  async getAll(): Promise<Category[]> {
    return categoryRepository.getAll();
  }

  async getById(
    id: string
  ): Promise<Category> {
    return categoryRepository.getById(
      id
    );
  }

  // ✅ جدید — یافتن دسته بر اساس Slug (برای صفحات عمومی)
  async getBySlug(
    slug: string
  ): Promise<Category | null> {
    const items =
      await this.getAll();

    return (
      items.find(
        (item) => item.slug === slug
      ) ?? null
    );
  }

  async getParents(): Promise<
    Category[]
  > {
    return categoryRepository.getParents();
  }

  async getChildren(
    parentId: string
  ): Promise<Category[]> {
    return categoryRepository.getChildren(
      parentId
    );
  }

  async getTree(): Promise<
    Category[]
  > {
    return categoryRepository.getTree();
  }

  // ✅ جدید — درخت دسته‌های فعال (برای نمایش عمومی)
  async getActiveTree(): Promise<
    Category[]
  > {
    const items =
      await this.getAll();

    return items.filter(
      (item) => item.active === true
    );
  }

  async getHomeCategories(): Promise<
    Category[]
  > {
    return categoryRepository.getHomeCategories();
  }

  /* ============================================================
     CREATE
  ============================================================ */

  async create(
    data: CategoryFormData
  ): Promise<Category> {
    return categoryRepository.create(
      data
    );
  }

  /* ============================================================
     UPDATE
  ============================================================ */

  async update(
    id: string,
    data: Partial<CategoryFormData>
  ): Promise<Category> {
    return categoryRepository.update(
      id,
      data
    );
  }

  /* ============================================================
     STATUS
  ============================================================ */

  async toggleActive(
    id: string,
    active: boolean
  ): Promise<Category> {
    return categoryRepository.toggleActive(
      id,
      active
    );
  }

  async toggleFeatured(
    id: string,
    featured: boolean
  ): Promise<Category> {
    return categoryRepository.toggleFeatured(
      id,
      featured
    );
  }

  // ✅ جدید — کنترل نمایش در منو
  async toggleShowInMenu(
    id: string,
    showInMenu: boolean
  ): Promise<Category> {
    return this.update(id, {
      showInMenu,
    });
  }

  // ✅ جدید — کنترل نمایش در صفحه اصلی
  async toggleShowOnHomepage(
    id: string,
    showOnHomepage: boolean
  ): Promise<Category> {
    return this.update(id, {
      showOnHomepage,
    });
  }

  /* ============================================================
     DELETE
  ============================================================ */

  async remove(
    id: string
  ): Promise<void> {
    return categoryRepository.remove(
      id
    );
  }

  /* ============================================================
     HELPERS
  ============================================================ */

  async exists(
    slug: string
  ): Promise<boolean> {
    return categoryRepository.exists(
      slug
    );
  }

  async getRootCategories(): Promise<
    Category[]
  > {
    return categoryRepository.getRootCategories();
  }

  async getSubCategories(
    parentId: string
  ): Promise<Category[]> {
    return categoryRepository.getSubCategories(
      parentId
    );
  }

  async getFeatured(): Promise<
    Category[]
  > {
    return categoryRepository.getFeatured();
  }

  async getActive(): Promise<
    Category[]
  > {
    return categoryRepository.getActive();
  }

  // ✅ جدید — دسته‌های قابل نمایش در منو (فعال + showInMenu)
  async getMenuCategories(): Promise<
    Category[]
  > {
    const items =
      await this.getAll();

    return items
      .filter(
        (item) =>
          item.active === true &&
          item.showInMenu === true
      )
      .sort(
        (a, b) => a.sortOrder - b.sortOrder
      );
  }

  // ✅ جدید — دسته‌های قابل نمایش در صفحه اصلی (فعال + showOnHomepage)
  async getHomepageCategories(): Promise<
    Category[]
  > {
    const items =
      await this.getAll();

    return items
      .filter(
        (item) =>
          item.active === true &&
          item.showOnHomepage === true
      )
      .sort(
        (a, b) => a.sortOrder - b.sortOrder
      );
  }

  // ✅ جدید — جستجوی دسته‌ها بر اساس نام / slug / توضیحات
  async search(
    keyword: string
  ): Promise<Category[]> {
    const items =
      await this.getAll();

    const query =
      keyword.trim().toLowerCase();

    if (!query) {
      return items;
    }

    return items.filter(
      (item) =>
        item.name
          .toLowerCase()
          .includes(query) ||
        item.slug
          .toLowerCase()
          .includes(query) ||
        (
          item.description
            ?.toLowerCase()
            .includes(query) ?? false
        )
    );
  }

  /* ============================================================
     HIERARCHY  (مشابه سایت‌های بزرگ — breadcrumb و روابط درختی)
  ============================================================ */

  // ✅ جدید — همهٔ اجداد یک دسته (از ریشه تا والد مستقیم)
  async getAncestors(
    categoryId: string
  ): Promise<Category[]> {
    const items =
      await this.getAll();

    const ancestors: Category[] = [];

    let current =
      items.find(
        (item) => item.id === categoryId
      );

    while (current?.parentId) {
      const parent =
        items.find(
          (item) =>
            item.id === current!.parentId
        );

      if (!parent) {
        break;
      }

      ancestors.unshift(parent);
      current = parent;
    }

    return ancestors;
  }

  // ✅ جدید — مسیر کامل breadcrumb (اجداد + خود دسته)
  async getBreadcrumb(
    categoryId: string
  ): Promise<Category[]> {
    const ancestors =
      await this.getAncestors(categoryId);

    const current =
      await this.getById(categoryId);

    return [
      ...ancestors,
      current,
    ];
  }

  // ✅ جدید — دسته‌های هم‌سطح (برای «دسته‌های مرتبط»)
  async getSiblings(
    categoryId: string
  ): Promise<Category[]> {
    const items =
      await this.getAll();

    const current =
      items.find(
        (item) => item.id === categoryId
      );

    if (!current) {
      return [];
    }

    return items.filter(
      (item) =>
        item.parentId ===
          current.parentId &&
        item.id !== categoryId
    );
  }

  // ✅ جدید — همهٔ نوادگان (زیرمجموعه‌های تو در تو)
  async getDescendants(
    categoryId: string
  ): Promise<Category[]> {
    const items =
      await this.getAll();

    const descendants: Category[] = [];

    const collect = (parentId: string) => {
      const children =
        items.filter(
          (item) =>
            item.parentId === parentId
        );

      for (const child of children) {
        descendants.push(child);
        collect(child.id);
      }
    };

    collect(categoryId);

    return descendants;
  }

  /* ============================================================
     COUNT
  ============================================================ */

  async count(): Promise<number> {
    return categoryRepository.count();
  }

  async countActive(): Promise<number> {
    return categoryRepository.countActive();
  }

  async countFeatured(): Promise<number> {
    return categoryRepository.countFeatured();
  }

  async countRoot(): Promise<number> {
    return categoryRepository.countRoot();
  }

  async countChildren(
    parentId: string
  ): Promise<number> {
    return categoryRepository.countChildren(
      parentId
    );
  }
}

export const categoryService =
  new CategoryService();

export default categoryService;