import type {
  Category,
  CategoryFormData,
} from "../types";

class CategoryRepository {
  private readonly adminUrl =
    "/api/admin/categories";

  private readonly homeUrl =
    "/api/home/categories";

  /* ============================================================
     GET
  ============================================================ */

  async getAll(): Promise<Category[]> {
    const res = await fetch(
      this.adminUrl,
      {
        cache: "no-store",
      }
    );

    if (!res.ok) {
      throw new Error(
        "Failed to load categories."
      );
    }

    return res.json();
  }

  async getById(
    id: string
  ): Promise<Category> {
    const res = await fetch(
      `${this.adminUrl}/${id}`,
      {
        cache: "no-store",
      }
    );

    if (!res.ok) {
      throw new Error(
        "Failed to load category."
      );
    }

    return res.json();
  }

  async getParents(): Promise<Category[]> {
    const items =
      await this.getAll();

    return items.filter(
      (item) => !item.parentId
    );
  }

  async getChildren(
    parentId: string
  ): Promise<Category[]> {
    const items =
      await this.getAll();

    return items.filter(
      (item) =>
        item.parentId === parentId
    );
  }

  async getTree(): Promise<Category[]> {
    return this.getAll();
  }

  async getHomeCategories(): Promise<Category[]> {
    const res = await fetch(
      this.homeUrl,
      {
        cache: "no-store",
      }
    );

    if (!res.ok) {
      throw new Error(
        "Failed to load home categories."
      );
    }

    return res.json();
  }

    /* ============================================================
     CREATE
  ============================================================ */

  async create(
    data: CategoryFormData
  ): Promise<Category> {
    const res = await fetch(
      this.adminUrl,
      {
        method: "POST",
        headers: {
          "Content-Type":
            "application/json",
        },
        body: JSON.stringify(data),
      }
    );

    if (!res.ok) {
      throw new Error(
        "Failed to create category."
      );
    }

    return res.json();
  }

  /* ============================================================
     UPDATE
  ============================================================ */

  async update(
    id: string,
    data: Partial<CategoryFormData>
  ): Promise<Category> {
    const res = await fetch(
      `${this.adminUrl}/${id}`,
      {
        method: "PUT",
        headers: {
          "Content-Type":
            "application/json",
        },
        body: JSON.stringify(data),
      }
    );

    if (!res.ok) {
      throw new Error(
        "Failed to update category."
      );
    }

    return res.json();
  }

  /* ============================================================
     STATUS
  ============================================================ */

  async toggleActive(
    id: string,
    active: boolean
  ): Promise<Category> {
    return this.update(id, {
      active,
    });
  }

  async toggleFeatured(
    id: string,
    featured: boolean
  ): Promise<Category> {
    return this.update(id, {
      featured,
    });
  }

    /* ============================================================
     DELETE
  ============================================================ */

  async remove(
    id: string
  ): Promise<void> {
    const res = await fetch(
      `${this.adminUrl}/${id}`,
      {
        method: "DELETE",
      }
    );

    if (!res.ok) {
      throw new Error(
        "Failed to delete category."
      );
    }
  }

  /* ============================================================
     HELPERS
  ============================================================ */

  async exists(
    slug: string
  ): Promise<boolean> {
    const items =
      await this.getAll();

    return items.some(
      (item) =>
        item.slug === slug
    );
  }

  async getRootCategories(): Promise<
    Category[]
  > {
    const items =
      await this.getAll();

    return items.filter(
      (item) => !item.parentId
    );
  }

  async getSubCategories(
    parentId: string
  ): Promise<Category[]> {
    const items =
      await this.getAll();

    return items.filter(
      (item) =>
        item.parentId === parentId
    );
  }

  async getFeatured(): Promise<
    Category[]
  > {
    const items =
      await this.getAll();

    return items.filter(
      (item) =>
        item.featured === true &&
        item.active === true
    );
  }

  async getActive(): Promise<
    Category[]
  > {
    const items =
      await this.getAll();

    return items.filter(
      (item) =>
        item.active === true
    );
  }

    /* ============================================================
     COUNT
  ============================================================ */

  async count(): Promise<number> {
    const items =
      await this.getAll();

    return items.length;
  }

  async countActive(): Promise<number> {
    const items =
      await this.getAll();

    return items.filter(
      (item) =>
        item.active === true
    ).length;
  }

  async countFeatured(): Promise<number> {
    const items =
      await this.getAll();

    return items.filter(
      (item) =>
        item.featured === true
    ).length;
  }

  async countRoot(): Promise<number> {
    const items =
      await this.getAll();

    return items.filter(
      (item) =>
        !item.parentId
    ).length;
  }

  async countChildren(
    parentId: string
  ): Promise<number> {
    const items =
      await this.getChildren(
        parentId
      );

    return items.length;
  }
}

export const categoryRepository =
  new CategoryRepository();

export default categoryRepository;