import { z } from "zod";

export const categorySchema = z.object({
  parentId: z.string().nullable().optional(),

  name: z
    .string()
    .min(2, "نام دسته‌بندی الزامی است")
    .max(120),

  slug: z
    .string()
    .min(2)
    .max(120)
    .regex(
      /^[a-z0-9-]+$/,
      "Slug معتبر نیست"
    ),

  icon: z
    .string()
    .nullable()
    .optional(),

  image: z
    .string()
    .nullable()
    .optional(),

  description: z
    .string()
    .max(1000)
    .nullable()
    .optional(),

  sortOrder: z
    .number()
    .default(0),

  active: z
    .boolean()
    .default(true),

  featured: z
    .boolean()
    .default(false),

  showInMenu: z
    .boolean()
    .default(true),

  showOnHomepage: z
    .boolean()
    .default(false),

  metaTitle: z
    .string()
    .max(120)
    .nullable()
    .optional(),

  metaDescription: z
    .string()
    .max(300)
    .nullable()
    .optional(),

  // ✅ هماهنگ با Prisma (String?) — رشته به جای آرایه
  keywords: z
    .string()
    .max(500)
    .nullable()
    .optional(),
});

export type CategoryFormData =
  z.infer<typeof categorySchema>;