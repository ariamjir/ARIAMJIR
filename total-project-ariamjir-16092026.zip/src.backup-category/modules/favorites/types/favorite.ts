export interface FavoriteMachine {

  id: string;

  slug: string;

  title: string;

  image: string;

  brand: string;

  model: string;

  category: string;

  year?: number;

  condition?: string;

  priceLabel?: string;

}

export interface FavoriteState {

  machines: FavoriteMachine[];

}

export interface FavoriteContextType {

  machines: FavoriteMachine[];

  add: (machine: FavoriteMachine) => void;

  remove: (id: string) => void;

  clear: () => void;

  exists: (id: string) => boolean;

}

export const FAVORITE_STORAGE_KEY =

"ariamj_favorites";