"use client";

import {

FavoriteMachine,

} from "../types/favorite";

import {

FAVORITE_STORAGE_KEY,

} from "../types/favorite";

function read(): FavoriteMachine[] {

if(typeof window==="undefined"){

return [];

}

const raw=

localStorage.getItem(

FAVORITE_STORAGE_KEY

);

if(!raw){

return [];

}

try{

return JSON.parse(raw);

}catch{

return [];

}

}

function write(

machines:FavoriteMachine[]

){

localStorage.setItem(

FAVORITE_STORAGE_KEY,

JSON.stringify(machines)

);

}

export function getFavorites(){

return read();

}

export function existsInFavorites(

id:string

){

return read().some(

item=>item.id===id

);

}

export function addFavorite(

machine:FavoriteMachine

){

const machines=

read();

if(

machines.find(

m=>m.id===machine.id

)

){

return machines;

}

machines.unshift(

machine

);

write(

machines

);

return machines;

}

export function removeFavorite(

id:string

){

const machines=

read().filter(

item=>item.id!==id

);

write(

machines

);

return machines;

}

export function clearFavorites(){

write([]);

}

export default{

getFavorites,

existsInFavorites,

addFavorite,

removeFavorite,

clearFavorites,

};