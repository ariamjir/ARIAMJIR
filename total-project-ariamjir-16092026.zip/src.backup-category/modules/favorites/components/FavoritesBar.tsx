"use client";

import Link from "next/link";

import { Heart, Trash2 } from "lucide-react";

import useFavorites from "../hooks/useFavorites";

export default function FavoritesBar() {

const {

machines,

count,

clear,

}=useFavorites();

if(count===0){

return null;

}

return(

<div

className="fixed bottom-6 left-1/2 z-50 w-[95%] max-w-5xl -translate-x-1/2 rounded-2xl border bg-white shadow-2xl"

>

<div className="flex flex-wrap items-center justify-between gap-4 p-5">

    <div className="flex items-center gap-3">

<div className="rounded-xl bg-red-100 p-3">

<Heart

className="h-6 w-6 text-red-600"

/>

</div>

<div>

<h3 className="font-bold">

علاقه‌مندی‌ها

</h3>

<p className="text-sm text-gray-500">

{count} دستگاه ذخیره شده

</p>

</div>

</div>

<div className="hidden items-center gap-2 md:flex">

{

machines.slice(0,5).map(machine=>(

<span

key={machine.id}

className="rounded-full bg-gray-100 px-3 py-1 text-xs"

>

{machine.brand}

</span>

))

}

</div>

<div className="flex items-center gap-3">

<button

type="button"

onClick={clear}

className="inline-flex items-center gap-2 rounded-xl border px-4 py-2 transition hover:border-red-500 hover:text-red-600"

>

<Trash2 className="h-4 w-4"/>

پاک کردن

</button>

<Link

href="/favorites"

className="rounded-xl bg-red-500 px-6 py-3 text-white transition hover:bg-red-600"

>

مشاهده علاقه‌مندی‌ها

</Link>

</div>

</div>

</div>

);

}