"use client";

import { Heart } from "lucide-react";

import useFavorites from "../hooks/useFavorites";

import { FavoriteMachine } from "../types/favorite";

interface Props {

  machine: FavoriteMachine;

}

export default function FavoriteButton({

  machine,

}: Props) {

const {

add,

remove,

exists,

}=useFavorites();

const active=

exists(machine.id);

const handleClick=()=>{

if(active){

remove(machine.id);

}else{

add(machine);

}

};

return(

<button

type="button"

onClick={handleClick}

className={`

inline-flex

items-center

justify-center

rounded-full

p-2

transition-all

${

active

?

"bg-red-500 text-white"

:

"bg-white text-gray-600 hover:bg-red-50 hover:text-red-500"

}

`}

title={

active

?

"حذف از علاقه‌مندی"

:

"افزودن به علاقه‌مندی"

}

>

    <Heart

className={`h-5 w-5 ${active ? "fill-current" : ""}`}

/>

</button>

);

}