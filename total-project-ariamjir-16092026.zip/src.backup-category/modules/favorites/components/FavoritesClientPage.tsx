"use client";

import useFavorites from "../hooks/useFavorites";

import FavoritesGrid from "./FavoritesGrid";

export default function FavoritesClientPage(){

const{

machines,

count,

clear,

}=useFavorites();

return(

<div className="space-y-6">

<div className="flex flex-wrap items-center justify-between gap-4">

<div>

<p className="font-bold">

{count} دستگاه ذخیره شده

</p>

</div>

<div>

<button

onClick={clear}

className="rounded-xl border px-5 py-2 hover:bg-red-50 hover:text-red-600"

>

پاک کردن همه

</button>

</div>

</div>

<FavoritesGrid

machines={machines}

/>

</div>

);

}