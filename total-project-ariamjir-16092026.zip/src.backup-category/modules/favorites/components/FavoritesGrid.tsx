"use client";

import MachineCard from "@/components/machine/card/MachineCard";
import EmptyState from "@/components/machine/shared/EmptyState";

interface Props {

  machines:any[];

}

export default function FavoritesGrid({

  machines,

}:Props){

    if(

machines.length===0

){

return(

<EmptyState

title="علاقه‌مندی خالی است"

description="هنوز هیچ دستگاهی را به علاقه‌مندی اضافه نکرده‌اید."

/>

);

}

return(

<div className="space-y-8">

<div className="flex items-center justify-between">

<h2 className="text-2xl font-bold">

ماشین‌های ذخیره شده

</h2>

<p className="text-sm text-gray-500">

{machines.length} دستگاه

</p>

</div>

<div

className="grid grid-cols-1 gap-6 md:grid-cols-2 xl:grid-cols-3"

>

    {

machines.map(

(machine)=>(

<MachineCard

key={machine.id}

machine={machine}

/>

)

)

}

</div>

</div>

);

}