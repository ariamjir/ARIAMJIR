"use client";

import { useCallback, useEffect, useState } from "react";

import {

FavoriteMachine,

} from "../types/favorite";

import {

getFavorites,

addFavorite,

removeFavorite,

clearFavorites,

existsInFavorites,

} from "../store/favoriteStore";

export default function useFavorites(){

const[

machines,

setMachines

]=useState<FavoriteMachine[]>([]);

useEffect(()=>{

setMachines(

getFavorites()

);

},[]);

const add=

useCallback(

(machine:FavoriteMachine)=>{

const result=

addFavorite(machine);

setMachines(result);

},

[]

);

const remove=

useCallback(

(id:string)=>{

const result=

removeFavorite(id);

setMachines(result);

},

[]

);

const clear=

useCallback(()=>{

clearFavorites();

setMachines([]);

},[]);

const exists=

useCallback(

(id:string)=>{

return existsInFavorites(id);

},

[]

);

return{

machines,

count:

machines.length,

add,

remove,

clear,

exists,

};

}