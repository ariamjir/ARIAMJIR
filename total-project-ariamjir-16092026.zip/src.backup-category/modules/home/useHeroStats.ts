"use client";

import { useMemo } from "react";

import { Building2, Briefcase, FolderTree, Wrench } from "lucide-react";
import type { LucideIcon } from "lucide-react";

import { useCategories } from "@/modules/category";
import { useBrands } from "@/modules/brand";

export interface HeroStat {
  icon: LucideIcon;
  label: string;
  value: number;
}

/* ============================================================
   آمار زندهٔ Hero — صفرها حذف می‌شوند
   (بعداً با API واقعی، فقط همین هوک تغییر می‌کند)
============================================================ */
export function useHeroStats(): HeroStat[] {
  const categoriesApi: any = useCategories();
  const brandsApi: any = useBrands();

  const categories: any[] = categoriesApi.categories ?? [];
  const brands: any[] =
    brandsApi.brands ?? brandsApi.activeBrands ?? brandsApi.allBrands ?? [];

  const childrenMap = useMemo(() => {
    const m: Record<string, any[]> = {};
    for (const c of categories) {
      if (c.parentId) (m[c.parentId] ||= []).push(c);
    }
    return m;
  }, [categories]);

  return useMemo(() => {
    const countTree = (id: string): number =>
      (childrenMap[id] ?? []).reduce((n, ch) => n + 1 + countTree(ch.id), 0);

    const servicesRoot = categories.find((c) => c.slug === "services");
    const machinesCount = categories.reduce(
      (s: number, c: any) => s + (c.machinesCount ?? 0),
      0
    );

    return [
      { icon: Wrench, label: "ماشین‌آلات", value: machinesCount },
      { icon: FolderTree, label: "دسته‌بندی فعال", value: categories.length },
      {
        icon: Building2,
        label: "برند معتبر",
        value: brands.filter((b: any) => b.active !== false).length,
      },
      {
        icon: Briefcase,
        label: "خدمات تخصصی",
        value: servicesRoot ? countTree(servicesRoot.id) : 0,
      },
    ].filter((s) => s.value > 0);
  }, [categories, brands, childrenMap]);
}