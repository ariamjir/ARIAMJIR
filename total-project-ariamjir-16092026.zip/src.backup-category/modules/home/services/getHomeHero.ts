import { prisma } from "@/lib/prisma";

import type {
  Hero,
} from "../types";


/**
 * دریافت Hero فعال صفحه اصلی
 * منبع اصلی داده Homepage Hero
 */
export async function getHomeHero(): Promise<Hero | null> {

  const hero = await prisma.hero.findFirst({

    where: {
      active: true,
    },

    include: {

      slides: {

        where: {
          active: true,
        },

        orderBy: {
          sortOrder: "asc",
        },

      },


      stats: {

        where: {
          active: true,
        },

        orderBy: {
          sortOrder: "asc",
        },

      },

    },

    orderBy: {
      createdAt: "desc",
    },

  });



  if (!hero) {
    return null;
  }



  return hero;

}