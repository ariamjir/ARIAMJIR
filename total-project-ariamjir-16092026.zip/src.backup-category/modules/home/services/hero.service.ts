import type {
  Hero,
  HeroSlide,
  HeroStat,
} from "../types";

import {
  heroRepository,
} from "../repositories";


/* ============================================================
   DTO TYPES
============================================================ */


export type CreateHeroInput = {

  title: string;

  subtitle?: string;

  description?: string;

  badge?: string;

  buttonText?: string;

  buttonLink?: string;

  secondButtonText?: string;

  secondButtonLink?: string;

  active?: boolean;

};



export type UpdateHeroInput = {

  title?: string;

  subtitle?: string;

  description?: string;

  badge?: string;

  buttonText?: string;

  buttonLink?: string;

  secondButtonText?: string;

  secondButtonLink?: string;

  active?: boolean;

};




class HeroService {


  /* ============================================================
     HOMEPAGE HERO
  ============================================================ */


  async getHero(): Promise<Hero | null> {

    return heroRepository.getHero();

  }





  /* ============================================================
     CREATE
  ============================================================ */


  async createHero(
    data: CreateHeroInput,
  ) {

    return heroRepository.createHero(
      data,
    );

  }





  /* ============================================================
     UPDATE
  ============================================================ */


  async updateHero(

    id:string,

    data: UpdateHeroInput,

  ) {


    return heroRepository.updateHero(

      id,

      data,

    );


  }





  /* ============================================================
     DELETE
  ============================================================ */


  async deleteHero(
    id:string,
  ) {

    return heroRepository.deleteHero(
      id,
    );

  }





  /* ============================================================
     SLIDES
  ============================================================ */


  async createSlide(

    heroId:string,

    slide:Partial<HeroSlide>,

  ) {


    return heroRepository.createSlide(

      heroId,

      slide,

    );


  }





  /* ============================================================
     STATS
  ============================================================ */


  async createStat(

    heroId:string,

    stat:Partial<HeroStat>,

  ) {


    return heroRepository.createStat(

      heroId,

      stat,

    );


  }


}



export const heroService =
  new HeroService();