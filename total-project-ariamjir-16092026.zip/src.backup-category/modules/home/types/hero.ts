export interface HeroSlide {
  id: string;
  image: string;
  title?: string | null;
  subtitle?: string | null;
  link?: string | null;
  sortOrder: number;
}

export interface HeroStat {

  id: string;

  title: string;

  value?: string | null;

  sortOrder: number;

  active: boolean;

  icon?: string | null;

  type?: string;

  source?: string;

}

export interface Hero {
  id: string;

  badge?: string | null;

  title: string;

  subtitle?: string | null;

  description?: string | null;

  buttonText?: string | null;

  buttonLink?: string | null;

  secondButtonText?: string | null;

  secondButtonLink?: string | null;

  active: boolean;

  slides: HeroSlide[];

  stats: HeroStat[];
}