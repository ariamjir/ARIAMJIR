"use client";

import { useEffect, useState } from "react";

import { heroService } from "../services";

import type { Hero } from "../types";

export function useHero() {
  const [hero, setHero] = useState<Hero | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    heroService
      .getHero()
      .then(setHero)
      .finally(() => setLoading(false));
  }, []);

  return {
    hero,
    loading,
  };
}