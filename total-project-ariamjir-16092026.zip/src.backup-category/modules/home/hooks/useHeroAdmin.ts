"use client";

import { useEffect, useState } from "react";

import type { Hero } from "../types";

import { heroService } from "../services";

export function useHeroAdmin() {
  const [hero, setHero] = useState<Hero | null>(null);
  const [loading, setLoading] = useState(true);

  async function refresh() {
    try {
      const data = await heroService.getHero();
      setHero(data);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    refresh();
  }, []);

  return {
    hero,
    loading,
    refresh,
  };
}