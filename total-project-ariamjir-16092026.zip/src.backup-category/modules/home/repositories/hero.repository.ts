import { prisma } from "@/lib/prisma";

import type {
  Hero,
  HeroSlide,
  HeroStat,
} from "../types";


class HeroRepository {


  /* ============================================================
     GET ACTIVE HERO FOR HOMEPAGE
  ============================================================ */

  async getHero(): Promise<Hero | null> {

    const hero = await prisma.hero.findFirst({
      where: {
        active: true,
      },

      include: {
        slides: {
          where: {
            active: true,
          },

          orderBy: {
            sortOrder: "asc",
          },
        },

        stats: {
          where: {
            active: true,
          },

          orderBy: {
            sortOrder: "asc",
          },
        },
      },
    });


    if (!hero) {
      return null;
    }


    return {
      ...hero,

      slides: hero.slides.map(
        (slide): HeroSlide => ({
          id: slide.id,
          image: slide.image,
          title: slide.title,
          subtitle: slide.subtitle,
          link: slide.link,
          sortOrder: slide.sortOrder,
        })
      ),


      stats: hero.stats.map(
        (stat): HeroStat => ({
          id: stat.id,
          title: stat.title,
          value: stat.value ?? "",
          sortOrder: stat.sortOrder,
          active: stat.active,
        })
      ),
    };

  }





  /* ============================================================
     CREATE
  ============================================================ */


  async createHero(
  data: {
    title: string;
    subtitle?: string;
    description?: string;
    badge?: string;
    buttonText?: string;
    buttonLink?: string;
    secondButtonText?: string;
    secondButtonLink?: string;
    active?: boolean;
  },
) {

  return prisma.hero.create({

    data: {

      title: data.title,

      subtitle:
        data.subtitle,

      description:
        data.description,

      badge:
        data.badge,

      buttonText:
        data.buttonText,

      buttonLink:
        data.buttonLink,

      secondButtonText:
        data.secondButtonText,

      secondButtonLink:
        data.secondButtonLink,

      active:
        data.active ?? true,

    },

  });

}





  /* ============================================================
     UPDATE
  ============================================================ */


  async updateHero(
  id:string,

  data:{
    title?: string;
    subtitle?: string;
    description?: string;
    badge?: string;
    buttonText?: string;
    buttonLink?: string;
    secondButtonText?: string;
    secondButtonLink?: string;
    active?: boolean;
  },

) {


 return prisma.hero.update({

   where:{
     id,
   },


   data,

 });


}





  /* ============================================================
     DELETE
  ============================================================ */


  async deleteHero(
    id:string,
  ) {

    return prisma.hero.delete({

      where:{
        id,
      },

    });

  }





  /* ============================================================
     CREATE SLIDE
  ============================================================ */


  async createSlide(
    heroId:string,
    slide:Partial<HeroSlide>,
  ) {


    return prisma.heroSlide.create({

      data:{
        heroId,

        image:
          slide.image ?? "",

        title:
          slide.title,

        subtitle:
          slide.subtitle,

        link:
          slide.link,

        sortOrder:
          slide.sortOrder ?? 0,

      },

    });


  }





  /* ============================================================
     CREATE STAT
  ============================================================ */


  async createStat(
    heroId:string,
    stat:Partial<HeroStat>,
  ) {


    return prisma.heroStat.create({

      data:{

        heroId,

        title:
          stat.title ?? "",

        value:
          stat.value,

        sortOrder:
          stat.sortOrder ?? 0,

        active:
          stat.active ?? true,

      },

    });


  }


}


export const heroRepository =
  new HeroRepository();