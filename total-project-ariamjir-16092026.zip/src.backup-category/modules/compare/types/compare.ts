export interface CompareMachine {

  id: string;

  slug: string;

  title: string;

  image: string;

  brand: string;

  model: string;

  category: string;

  year?: number;

  condition?: string;

}

export interface CompareSpecification {

  label: string;

  key: string;

  unit?: string;

}

export interface CompareState {

  machines: CompareMachine[];

}

export interface CompareContextType {

  machines: CompareMachine[];

  add: (machine: CompareMachine) => void;

  remove: (id: string) => void;

  clear: () => void;

  exists: (id: string) => boolean;

}

export const MAX_COMPARE_ITEMS = 4;

export default CompareMachine;