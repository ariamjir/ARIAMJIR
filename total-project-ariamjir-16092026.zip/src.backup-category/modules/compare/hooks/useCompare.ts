"use client";

import { useCallback, useEffect, useState } from "react";

import {

CompareMachine,

} from "../types/compare";

import {

getCompareMachines,

addToCompare,

removeFromCompare,

clearCompare,

existsInCompare,

} from "../store/compareStore";

export default function useCompare(){

const[

machines,

setMachines

]=useState<CompareMachine[]>([]);

useEffect(()=>{

setMachines(

getCompareMachines()

);

},[]);

const add=

useCallback(

(machine:CompareMachine)=>{

const result=

addToCompare(machine);

setMachines(result);

},

[]

);

const remove=

useCallback(

(id:string)=>{

const result=

removeFromCompare(id);

setMachines(result);

},

[]

);

const clear=

useCallback(()=>{

clearCompare();

setMachines([]);

},[]);

const exists=

useCallback(

(id:string)=>{

return existsInCompare(id);

},

[]

);

return{

machines,

count:

machines.length,

add,

remove,

clear,

exists,

};

}