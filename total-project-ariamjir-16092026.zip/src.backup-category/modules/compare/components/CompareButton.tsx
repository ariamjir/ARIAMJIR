"use client";

import { GitCompare, Check } from "lucide-react";

import useCompare from "../hooks/useCompare";

import { CompareMachine } from "../types/compare";

interface Props {

  machine: CompareMachine;

}

export default function CompareButton({

  machine,

}: Props) {

const {

add,

remove,

exists,

}=useCompare();

const active=

exists(machine.id);

const handleClick=()=>{

if(active){

remove(machine.id);

}else{

add(machine);

}

};

return(

<button

type="button"

onClick={handleClick}

className={`

inline-flex items-center gap-2

rounded-xl

border

px-4

py-2

transition-all

${

active

?

"border-green-600 bg-green-600 text-white"

:

"border-gray-300 bg-white hover:border-orange-500 hover:text-orange-600"

}

`}

>

{

active

?

<Check className="h-4 w-4"/>

:

<GitCompare className="h-4 w-4"/>

}

<span>

{

active

?

"در لیست مقایسه"

:

"افزودن به مقایسه"

}

</span>

</button>

);

}