"use client";

import { X } from "lucide-react";

import CompareTable from "./CompareTable";

import { CompareMachine } from "../types/compare";

interface Props{

open:boolean;

machines:CompareMachine[];

onClose:()=>void;

}

export default function CompareDialog({

open,

machines,

onClose,

}:Props){

if(!open){

return null;

}

return(

<div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-6">

<div className="flex max-h-[95vh] w-full max-w-7xl flex-col overflow-hidden rounded-2xl bg-white shadow-2xl">

    <div className="flex items-center justify-between border-b px-6 py-4">

<h2 className="text-xl font-bold">

مقایسه ماشین‌ها

</h2>

<button

type="button"

onClick={onClose}

className="rounded-lg p-2 transition hover:bg-gray-100"

>

<X className="h-5 w-5"/>

</button>

</div>

<div className="flex-1 overflow-auto p-6">

<CompareTable

machines={machines}

/>

</div>

<div className="flex items-center justify-end gap-3 border-t px-6 py-4">

<button

type="button"

onClick={onClose}

className="rounded-xl border px-5 py-2 transition hover:bg-gray-50"

>

بستن

</button>

</div>

</div>

</div>

);

}