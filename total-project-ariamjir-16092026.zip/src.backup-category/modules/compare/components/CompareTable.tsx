"use client";

import Image from "next/image";

import { CompareMachine } from "../types/compare";

interface Props {

  machines: CompareMachine[];

}

const rows = [

["برند","brand"],

["مدل","model"],

["دسته‌بندی","category"],

["سال ساخت","year"],

["وضعیت","condition"],

["کشور سازنده","country"],

["قدرت موتور","enginePower"],

["سوخت","fuelType"],

["وزن","weight"],

["قیمت","priceLabel"],

];

export default function CompareTable({

machines,

}:Props){

if(machines.length===0){

return null;

}

return(

<div className="overflow-x-auto rounded-2xl border bg-white shadow-sm">

<table className="min-w-full border-collapse">

<thead>

<tr>

<th className="sticky left-0 bg-gray-50 p-4 text-right">

مشخصات

</th>

{

machines.map(machine=>(

<th

key={machine.id}

className="min-w-[260px] border-r p-4"

>

    <div className="relative mx-auto mb-3 aspect-[4/3] w-full overflow-hidden rounded-xl">

<Image

src={machine.image}

alt={machine.title}

fill

className="object-cover"

/>

</div>

<h3 className="font-bold">

{machine.title}

</h3>

<p className="mt-1 text-sm text-gray-500">

{machine.brand}

</p>

</th>

))

}

</tr>

</thead>

<tbody>

{

rows.map(

([label,key])=>(

<tr

key={String(key)}

className="border-t"

>

<td className="sticky left-0 bg-white p-4 font-semibold">

{label}

</td>

{

machines.map(machine=>(

<td

key={machine.id}

className="border-r p-4 text-center"

>

{

(machine as any)[key]

??

"-"

}

</td>

))

}

</tr>

)

)

}

</tbody>

</table>

</div>

);

}