"use client";

import { useState } from "react";

import useCompare from "../hooks/useCompare";

import CompareTable from "./CompareTable";

import CompareDialog from "./CompareDialog";

export default function CompareClientPage(){

const{

machines,

clear,

count,

}=useCompare();

const[

open,

setOpen

]=useState(false);

if(count===0){

return(

<div className="rounded-2xl border bg-white p-12 text-center">

<h2 className="text-2xl font-bold">

هیچ دستگاهی برای مقایسه انتخاب نشده است.

</h2>

<p className="mt-3 text-gray-500">

از صفحات ماشین‌آلات، گزینه «افزودن به مقایسه» را انتخاب کنید.

</p>

</div>

);

}

return(

<>

<div className="mb-6 flex flex-wrap items-center justify-between gap-3">

<div>

<p className="font-bold">

{count} دستگاه آماده مقایسه

</p>

</div>

<div className="flex gap-3">

<button

onClick={()=>setOpen(true)}

className="rounded-xl bg-orange-500 px-5 py-2 text-white hover:bg-orange-600"

>

نمایش تمام صفحه

</button>

<button

onClick={clear}

className="rounded-xl border px-5 py-2"

>

پاک کردن

</button>

</div>

</div>

<CompareTable

machines={machines}

/>

<CompareDialog

open={open}

machines={machines}

onClose={()=>setOpen(false)}

/>

</>

);

}