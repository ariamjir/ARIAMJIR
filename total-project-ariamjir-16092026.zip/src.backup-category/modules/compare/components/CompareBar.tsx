"use client";

import Link from "next/link";

import { usePathname } from "next/navigation";

import { GitCompare, Trash2, X, ArrowLeft } from "lucide-react";

import useCompare from "../hooks/useCompare";

/* ============================================================
   نوار مقایسه — شناور پایین صفحه
   ✅ در پنل ادمین پنهان می‌شود
   ✅ تم تیره هم‌خانواده با سایت
   ✅ حذف تکی هر ماشین از نوار
============================================================ */

export default function CompareBar() {
  const pathname = usePathname();
  const { machines, count, clear, remove } = useCompare();

  if (!pathname || pathname.startsWith("/admin") || count === 0) return null;

  return (
    <div className="fixed bottom-6 left-1/2 z-50 w-[95%] max-w-3xl -translate-x-1/2">
      <div className="rounded-2xl border border-[#F58220]/30 bg-[#141414]/95 shadow-2xl shadow-black/60 backdrop-blur-md">
        <div className="flex flex-wrap items-center justify-between gap-4 p-4">
          {/* عنوان */}
          <div className="flex items-center gap-3">
            <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-[#F58220]/15 text-[#F58220]">
              <GitCompare className="h-5 w-5" />
            </span>
            <div>
              <div className="text-sm font-black text-white">مقایسهٔ ماشین‌ها</div>
              <div className="text-[11px] text-white/50">
                {count.toLocaleString("fa-IR")} دستگاه انتخاب شده
              </div>
            </div>
          </div>

          {/* ماشین‌های انتخاب‌شده */}
          <div className="flex flex-1 flex-wrap items-center justify-center gap-2">
            {machines.map((m: any) => (
              <span
                key={m.id}
                className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-3 py-1 text-[10px] font-bold text-white/70"
              >
                {m.brand}
                {m.model ? ` ${m.model}` : ""}
                <button
                  type="button"
                  onClick={() => remove(m.id)}
                  className="text-white/40 transition hover:text-red-400"
                  aria-label="حذف از مقایسه"
                >
                  <X className="h-3 w-3" />
                </button>
              </span>
            ))}
          </div>

          {/* اکشن‌ها */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={clear}
              className="inline-flex h-10 w-10 items-center justify-center rounded-xl border border-white/10 text-white/50 transition hover:border-red-400/40 hover:text-red-400"
              title="پاک کردن همه"
            >
              <Trash2 className="h-4 w-4" />
            </button>
            <Link
              href="/compare"
              className="inline-flex h-10 items-center gap-2 rounded-xl bg-[#F58220] px-5 text-sm font-black text-white transition hover:bg-[#d96f15]"
            >
              مشاهدهٔ مقایسه
              <ArrowLeft className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}