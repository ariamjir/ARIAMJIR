"use client";

import {

CompareMachine,

MAX_COMPARE_ITEMS,

} from "../types/compare";

const STORAGE_KEY =

"ariamj_compare";

function read(): CompareMachine[] {

if(typeof window==="undefined"){

return [];

}

const raw=

localStorage.getItem(

STORAGE_KEY

);

if(!raw){

return [];

}

try{

return JSON.parse(raw);

}catch{

return [];

}

}

function write(

machines:CompareMachine[]

){

localStorage.setItem(

STORAGE_KEY,

JSON.stringify(machines)

);

}

export function getCompareMachines(){

return read();

}

export function existsInCompare(

id:string

){

return read().some(

item=>item.id===id

);

}

export function addToCompare(

machine:CompareMachine

){

const machines=

read();

if(

machines.find(

m=>m.id===machine.id

)

){

return machines;

}

if(

machines.length>=

MAX_COMPARE_ITEMS

){

machines.shift();

}

machines.push(machine);

write(machines);

return machines;

}

export function removeFromCompare(

id:string

){

const machines=

read().filter(

item=>item.id!==id

);

write(machines);

return machines;

}

export function clearCompare(){

write([]);

}

export default{

getCompareMachines,

existsInCompare,

addToCompare,

removeFromCompare,

clearCompare,

};