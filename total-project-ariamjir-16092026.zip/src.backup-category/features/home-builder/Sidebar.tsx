"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

import {
  Image,
  Building2,
  Wrench,
  Newspaper,
  BarChart3,
  PanelBottom,
  ShieldCheck,
} from "lucide-react";

const items = [
  {
    title: "هیرو",
    href: "/admin/home/hero",
    icon: Image,
  },
  {
    title: "برندها",
    href: "/admin/home/brands",
    icon: Building2,
  },
  {
    title: "خدمات",
    href: "/admin/home/services",
    icon: Wrench,
  },
  {
    title: "اخبار",
    href: "/admin/home/news",
    icon: Newspaper,
  },
  {
    title: "چرا آریا ماشین جم",
    href: "/admin/home/why-us",
    icon: ShieldCheck,
  },
  {
    title: "آمار",
    href: "/admin/home/stats",
    icon: BarChart3,
  },
  {
    title: "فوتر",
    href: "/admin/home/footer",
    icon: PanelBottom,
  },
];

export default function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="w-72 rounded-2xl border border-zinc-200 bg-white p-4 shadow-sm">

      <h2 className="mb-6 text-xl font-bold text-zinc-800">
        مدیریت صفحه اصلی
      </h2>

      <nav className="space-y-2">

        {items.map((item) => {
          const Icon = item.icon;

          const active = pathname === item.href;

          return (
            <Link
              key={item.href}
              href={item.href}
              className={
                (active
                  ? "bg-orange-500 text-white "
                  : "text-zinc-700 hover:bg-zinc-100 ") +
                "flex items-center gap-3 rounded-xl px-4 py-3 transition"
              }
            >
              <Icon size={20} />

              {item.title}

            </Link>
          );
        })}

      </nav>

    </aside>
  );
}