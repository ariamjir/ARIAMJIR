import { LucideIcon } from "lucide-react";
import Link from "next/link";

type Props = {
  title: string;
  description: string;
  href: string;
  color: string;
  icon: LucideIcon;
};

export default function SectionCard({
  title,
  description,
  href,
  color,
  icon: Icon,
}: Props) {
  return (
    <Link
      href={href}
      className="rounded-2xl border border-zinc-200 bg-white p-6 shadow-sm transition duration-300 hover:-translate-y-1 hover:shadow-lg"
    >
      <div
        className={
          color + " inline-flex rounded-xl p-4 text-white"
        }
      >
        <Icon size={28} />
      </div>

      <h2 className="mt-5 text-xl font-bold text-zinc-800">
        {title}
      </h2>

      <p className="mt-2 text-sm text-zinc-500">
        {description}
      </p>
    </Link>
  );
}