export interface HeroSection {
  id: string;
  title: string;
  subtitle: string;
  buttonText: string;
  buttonLink: string;
  image: string;
  active: boolean;
}

export interface BrandSection {
  id: string;
  title: string;
  logo: string;
  link: string;
  active: boolean;
}

export interface ServiceSection {
  id: string;
  title: string;
  description: string;
  icon: string;
  active: boolean;
}

export interface NewsSection {
  id: string;
  title: string;
  description: string;
  image: string;
  date: string;
  active: boolean;
}

export interface StatsSection {
  id: string;
  title: string;
  value: string;
  active: boolean;
}

export interface FooterSection {
  companyName: string;
  address: string;
  phone: string;
  email: string;
  instagram: string;
  telegram: string;
  whatsapp: string;
}