"use client";

import {
  useCallback,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";

import {
  AlertCircle,
  BarChart3,
  CheckCircle2,
  ChevronDown,
  ClipboardCheck,
  Cog,
  Droplets,
  FileText,
  Gauge,
  HardHat,
  Layers,
  Loader2,
  LockKeyhole,
  Phone,
  Send,
  ShieldCheck,
  Sparkles,
  TrendingUp,
  Truck,
  Wrench,
  Zap,
} from "lucide-react";

/* ============================================================
   TYPES
============================================================ */

type OptionItem = {
  id: string;
  name: string;
  slug?: string | null;
  icon?: string | null;
  image?: string | null;
  description?: string | null;
  parentId?: string | null;
};

type Brand = {
  id: string;
  name: string;
  slug?: string | null;
  logo?: string | null;
  website?: string | null;
  countryId?: string | null;
};

type ModelOption = {
  model: string;
  machineCount: number;
  latestMachineId: string;
  latestTitle: string;
  latestSlug: string;
  image: string | null;
};

type Condition = "excellent" | "good" | "fair" | "poor";

type ComponentCondition = {
  id: string;
  label: string;
  percentage: number;
  condition: Condition | "critical";
  hasIssue: boolean;
  issueDescription: string;
};

type EstimationResult = {
  available: boolean;
  message?: string;
  minPrice?: number;
  maxPrice?: number;
  averagePrice?: number;
  currency?: string;
  confidence: "high" | "medium" | "low";
  sampleSize?: number;
  breakdown?: {
    basePrice: number;
    yearAdjustment: number;
    hoursAdjustment: number;
    conditionAdjustment: number;
    marketAdjustment: number;
  };
  criticalIssues?: string[];
  recommendations?: string[];
  methodology?: {
    marketSamples: number;
    marketAverageHours: number;
    componentAverage: number;
  };
};

/* ============================================================
   CONSTANTS
============================================================ */

const DEFAULT_COMPONENTS: ComponentCondition[] = [
  {
    id: "engine",
    label: "موتور و پیشرانه",
    percentage: 85,
    condition: "good",
    hasIssue: false,
    issueDescription: "",
  },
  {
    id: "hydraulic_pump",
    label: "پمپ هیدرولیک اصلی",
    percentage: 80,
    condition: "good",
    hasIssue: false,
    issueDescription: "",
  },
  {
    id: "hydraulic_cylinders",
    label: "سیلندرهای هیدرولیک",
    percentage: 85,
    condition: "good",
    hasIssue: false,
    issueDescription: "",
  },
  {
    id: "undercarriage",
    label: "زیربندی",
    percentage: 70,
    condition: "good",
    hasIssue: false,
    issueDescription: "",
  },
  {
    id: "final_drive",
    label: "موتورهای حرکت / Final Drive",
    percentage: 90,
    condition: "good",
    hasIssue: false,
    issueDescription: "",
  },
  {
    id: "transmission",
    label: "گیربکس و انتقال قدرت",
    percentage: 85,
    condition: "good",
    hasIssue: false,
    issueDescription: "",
  },
  {
    id: "cab_controls",
    label: "کابین و سیستم کنترل",
    percentage: 90,
    condition: "good",
    hasIssue: false,
    issueDescription: "",
  },
  {
    id: "electrical",
    label: "برق و الکترونیک",
    percentage: 85,
    condition: "good",
    hasIssue: false,
    issueDescription: "",
  },
];

const CONDITION_OPTIONS = [
  { value: "excellent" as const, label: "در حد نو", percentage: 95 },
  { value: "good" as const, label: "خوب", percentage: 80 },
  { value: "fair" as const, label: "متوسط", percentage: 60 },
  { value: "poor" as const, label: "ضعیف", percentage: 35 },
];

const COMPONENT_CONDITIONS = [
  { value: "excellent", label: "عالی", percentage: 95 },
  { value: "good", label: "خوب", percentage: 80 },
  { value: "fair", label: "متوسط", percentage: 60 },
  { value: "poor", label: "ضعیف", percentage: 35 },
  { value: "critical", label: "بحرانی", percentage: 10 },
];

/* ============================================================
   HELPERS
============================================================ */

function formatNumber(value?: number | null) {
  if (value === null || value === undefined || Number.isNaN(value)) {
    return "—";
  }

  return Number(value).toLocaleString("fa-IR");
}

function conditionClass(condition: string) {
  switch (condition) {
    case "excellent":
      return "bg-emerald-500 text-white";
    case "good":
      return "bg-green-500 text-white";
    case "fair":
      return "bg-amber-500 text-white";
    case "poor":
      return "bg-orange-500 text-white";
    case "critical":
      return "bg-red-500 text-white";
    default:
      return "bg-white/10 text-white/70";
  }
}

function normalizeIranMobile(value: string) {
  const digits = value.replace(/[^0-9+]/g, "").replace(/^\+/, "");

  if (/^09\d{9}$/.test(digits)) return digits;
  if (/^989\d{9}$/.test(digits)) return `0${digits.slice(2)}`;
  if (/^9\d{9}$/.test(digits)) return `0${digits}`;

  return null;
}

function currencyLabel(currency?: string | null) {
  switch (currency) {
    case "USD":
      return "دلار";
    case "EUR":
      return "یورو";
    case "AED":
      return "درهم";
    case "IRR":
    default:
      return "تومان";
  }
}

/* ============================================================
   COMPONENT
============================================================ */

export default function PriceEstimatorClient() {
  /* ----------------------------------------------------------
     DATA
  ---------------------------------------------------------- */

  const [categories, setCategories] = useState<OptionItem[]>([]);
  const [activities, setActivities] = useState<OptionItem[]>([]);
  const [machineTypes, setMachineTypes] = useState<OptionItem[]>([]);
  const [brands, setBrands] = useState<Brand[]>([]);
  const [models, setModels] = useState<ModelOption[]>([]);

  /* ----------------------------------------------------------
     SELECTIONS
  ---------------------------------------------------------- */

  const [categoryId, setCategoryId] = useState("");
  const [activityId, setActivityId] = useState("");
  const [machineTypeId, setMachineTypeId] = useState("");
  const [brandId, setBrandId] = useState("");
  const [model, setModel] = useState("");

  /* ----------------------------------------------------------
     MACHINE DATA
  ---------------------------------------------------------- */

  const currentYear = useMemo(() => new Date().getFullYear(), []);
  const [manufactureYear, setManufactureYear] = useState("");
  const [workingHours, setWorkingHours] = useState("");
  const [machineCondition, setMachineCondition] = useState<Condition>("good");

  /* ----------------------------------------------------------
     TECHNICAL
  ---------------------------------------------------------- */

  const [componentConditions, setComponentConditions] = useState<ComponentCondition[]>(
    DEFAULT_COMPONENTS,
  );

  /* ----------------------------------------------------------
     DOCUMENTS
  ---------------------------------------------------------- */

  const [hasDocuments, setHasDocuments] = useState<"complete" | "partial" | "none">(
    "complete",
  );
  const [customsStatus, setCustomsStatus] = useState<
    "cleared" | "in_process" | "uncleared"
  >("cleared");
  const [hasInspectionReport, setHasInspectionReport] = useState(false);

  /* ----------------------------------------------------------
     UI
  ---------------------------------------------------------- */

  const [activeTab, setActiveTab] = useState<"basic" | "technical" | "documents">("basic");
  const [loadingCategories, setLoadingCategories] = useState(false);
  const [loadingActivities, setLoadingActivities] = useState(false);
  const [loadingMachineTypes, setLoadingMachineTypes] = useState(false);
  const [loadingBrands, setLoadingBrands] = useState(false);
  const [loadingModels, setLoadingModels] = useState(false);
  const [loadingCalculation, setLoadingCalculation] = useState(false);
  const [error, setError] = useState("");
  const [estimation, setEstimation] = useState<EstimationResult | null>(null);

  /* ----------------------------------------------------------
     SELL LEAD
  ---------------------------------------------------------- */

  const [leadMobile, setLeadMobile] = useState("");
  const [leadConsent, setLeadConsent] = useState(false);
  const [leadSubmitting, setLeadSubmitting] = useState(false);
  const [leadSubmitted, setLeadSubmitted] = useState(false);
  const [leadError, setLeadError] = useState("");

  /* ============================================================
     API
  ============================================================ */

  const fetchOptions = useCallback(async (params: Record<string, string>) => {
    const query = new URLSearchParams({ mode: "machine", ...params });
    const response = await fetch(`/api/price-estimator/options?${query.toString()}`, {
      method: "GET",
      cache: "no-store",
    });

    const data = await response.json();

    if (!response.ok || !data?.success) {
      throw new Error(data?.message || "خطا در دریافت اطلاعات");
    }

    return data;
  }, []);

  /* ============================================================
     LOAD ROOT CATEGORIES
  ============================================================ */

  useEffect(() => {
    let cancelled = false;

    async function loadCategories() {
      try {
        setLoadingCategories(true);
        const data = await fetchOptions({});
        if (!cancelled) {
          setCategories(Array.isArray(data.items) ? data.items : []);
        }
      } catch (err) {
        if (!cancelled) {
          console.error(err);
          setError("دسته‌بندی‌های ماشین‌آلات بارگذاری نشدند.");
        }
      } finally {
        if (!cancelled) setLoadingCategories(false);
      }
    }

    void loadCategories();
    return () => {
      cancelled = true;
    };
  }, [fetchOptions]);

  /* ============================================================
     CATEGORY → ACTIVITY
  ============================================================ */

  useEffect(() => {
    if (!categoryId) {
      setActivities([]);
      return;
    }

    let cancelled = false;

    async function loadActivities() {
      try {
        setLoadingActivities(true);
        const data = await fetchOptions({ categoryId });
        if (!cancelled) {
          setActivities(Array.isArray(data.items) ? data.items : []);
        }
      } catch (err) {
        if (!cancelled) {
          console.error(err);
          setActivities([]);
          setError("فعالیت‌ها و کاربردهای این دسته بارگذاری نشدند.");
        }
      } finally {
        if (!cancelled) setLoadingActivities(false);
      }
    }

    void loadActivities();
    return () => {
      cancelled = true;
    };
  }, [categoryId, fetchOptions]);

  /* ============================================================
     ACTIVITY → MACHINE TYPE
  ============================================================ */

  useEffect(() => {
    if (!categoryId || !activityId) {
      setMachineTypes([]);
      return;
    }

    let cancelled = false;

    async function loadMachineTypes() {
      try {
        setLoadingMachineTypes(true);
        const data = await fetchOptions({ categoryId, activityId });
        if (!cancelled) {
          setMachineTypes(Array.isArray(data.items) ? data.items : []);
        }
      } catch (err) {
        if (!cancelled) {
          console.error(err);
          setMachineTypes([]);
          setError("نوع دستگاه برای این فعالیت بارگذاری نشد.");
        }
      } finally {
        if (!cancelled) setLoadingMachineTypes(false);
      }
    }

    void loadMachineTypes();
    return () => {
      cancelled = true;
    };
  }, [categoryId, activityId, fetchOptions]);

  /* ============================================================
     MACHINE TYPE → BRAND
  ============================================================ */

  useEffect(() => {
    if (!categoryId || !activityId || !machineTypeId) {
      setBrands([]);
      return;
    }

    let cancelled = false;

    async function loadBrands() {
      try {
        setLoadingBrands(true);
        const data = await fetchOptions({ categoryId, activityId, machineTypeId });
        if (!cancelled) {
          setBrands(Array.isArray(data.items) ? data.items : []);
        }
      } catch (err) {
        if (!cancelled) {
          console.error(err);
          setBrands([]);
          setError("برندهای این نوع دستگاه بارگذاری نشدند.");
        }
      } finally {
        if (!cancelled) setLoadingBrands(false);
      }
    }

    void loadBrands();
    return () => {
      cancelled = true;
    };
  }, [categoryId, activityId, machineTypeId, fetchOptions]);

  /* ============================================================
     BRAND → MODEL
  ============================================================ */

  useEffect(() => {
    if (!categoryId || !activityId || !machineTypeId || !brandId) {
      setModels([]);
      return;
    }

    let cancelled = false;

    async function loadModels() {
      try {
        setLoadingModels(true);
        const data = await fetchOptions({
          categoryId,
          activityId,
          machineTypeId,
          brandId,
        });
        if (!cancelled) {
          setModels(Array.isArray(data.items) ? data.items : []);
        }
      } catch (err) {
        if (!cancelled) {
          console.error(err);
          setModels([]);
          setError("مدل‌های واقعی این برند بارگذاری نشدند.");
        }
      } finally {
        if (!cancelled) setLoadingModels(false);
      }
    }

    void loadModels();
    return () => {
      cancelled = true;
    };
  }, [categoryId, activityId, machineTypeId, brandId, fetchOptions]);

  /* ============================================================
     CASCADING RESET
  ============================================================ */

  function resetLead() {
    setLeadMobile("");
    setLeadConsent(false);
    setLeadSubmitted(false);
    setLeadError("");
  }

  function clearEstimation() {
    setEstimation(null);
    resetLead();
    setError("");
  }

  function handleCategoryChange(value: string) {
    setCategoryId(value);
    setActivityId("");
    setMachineTypeId("");
    setBrandId("");
    setModel("");
    setActivities([]);
    setMachineTypes([]);
    setBrands([]);
    setModels([]);
    clearEstimation();
  }

  function handleActivityChange(value: string) {
    setActivityId(value);
    setMachineTypeId("");
    setBrandId("");
    setModel("");
    setMachineTypes([]);
    setBrands([]);
    setModels([]);
    clearEstimation();
  }

  function handleMachineTypeChange(value: string) {
    setMachineTypeId(value);
    setBrandId("");
    setModel("");
    setBrands([]);
    setModels([]);
    clearEstimation();
  }

  function handleBrandChange(value: string) {
    setBrandId(value);
    setModel("");
    setModels([]);
    clearEstimation();
  }

  function handleModelChange(value: string) {
    setModel(value);
    clearEstimation();
  }

  function updateComponent(id: string, updates: Partial<ComponentCondition>) {
    setComponentConditions((current) =>
      current.map((component) =>
        component.id === id ? { ...component, ...updates } : component,
      ),
    );
  }

  /* ============================================================
     CALCULATE
  ============================================================ */

  async function calculateEstimation() {
    setError("");
    setEstimation(null);
    resetLead();

    const year = Number(manufactureYear);
    const hours = Number(workingHours);

    if (!categoryId) {
      setError("لطفاً دسته ماشین‌آلات را انتخاب کنید.");
      setActiveTab("basic");
      return;
    }
    if (!activityId) {
      setError("لطفاً نوع فعالیت / کاربرد را انتخاب کنید.");
      setActiveTab("basic");
      return;
    }
    if (!machineTypeId) {
      setError("لطفاً نوع دستگاه را انتخاب کنید.");
      setActiveTab("basic");
      return;
    }
    if (!brandId) {
      setError("لطفاً برند دستگاه را انتخاب کنید.");
      setActiveTab("basic");
      return;
    }
    if (!model) {
      setError("لطفاً مدل دستگاه را انتخاب کنید.");
      setActiveTab("basic");
      return;
    }
    if (!Number.isInteger(year) || year < 1950 || year > currentYear + 2) {
      setError("سال ساخت دستگاه معتبر نیست.");
      setActiveTab("basic");
      return;
    }
    if (!Number.isFinite(hours) || hours < 0) {
      setError("ساعت کارکرد معتبر نیست.");
      setActiveTab("basic");
      return;
    }

    try {
      setLoadingCalculation(true);

      const response = await fetch("/api/price-estimator/calculate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          categoryId,
          activityId,
          machineTypeId,
          brandId,
          model,
          manufactureYear: year,
          workingHours: hours,
          machineCondition,
          componentConditions,
          hasDocuments,
          customsStatus,
          hasInspectionReport,
        }),
      });

      const data = await response.json();

      if (!response.ok || !data?.success) {
        throw new Error(data?.message || "خطا در محاسبه قیمت");
      }

      setEstimation(data.data);

      window.setTimeout(() => {
        document.getElementById("estimation-result")?.scrollIntoView({
          behavior: "smooth",
          block: "center",
        });
      }, 150);
    } catch (err) {
      console.error(err);
      setError(err instanceof Error ? err.message : "خطا در محاسبه قیمت.");
    } finally {
      setLoadingCalculation(false);
    }
  }

  /* ============================================================
     SELL LEAD
  ============================================================ */

  async function submitSellLead() {
    setLeadError("");

    const mobile = normalizeIranMobile(leadMobile);

    if (!mobile) {
      setLeadError("لطفاً یک شماره موبایل معتبر ایرانی وارد کنید.");
      return;
    }

    if (!leadConsent) {
      setLeadError("برای ثبت درخواست فروش، تأیید استفاده از اطلاعات دستگاه لازم است.");
      return;
    }

    try {
      setLeadSubmitting(true);

      const response = await fetch("/api/price-estimator/leads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          mobile,
          consent: true,
          categoryId,
          activityId,
          machineTypeId,
          brandId,
          model,
          manufactureYear: Number(manufactureYear),
          workingHours: Number(workingHours),
          machineCondition,
          hasDocuments,
          customsStatus,
          hasInspectionReport,
          componentConditions,
          estimation,
          source: "PRICE_ESTIMATOR",
        }),
      });

      const data = await response.json();

      if (!response.ok || !data?.success) {
        throw new Error(data?.message || "ثبت درخواست فروش انجام نشد.");
      }

      setLeadSubmitted(true);
    } catch (err) {
      console.error(err);
      setLeadError(
        err instanceof Error
          ? err.message
          : "ثبت درخواست فروش انجام نشد. دوباره تلاش کنید.",
      );
    } finally {
      setLeadSubmitting(false);
    }
  }

  /* ============================================================
     DERIVED SELECTIONS
  ============================================================ */

  const selectedCategory = categories.find((item) => item.id === categoryId);
  const selectedActivity = activities.find((item) => item.id === activityId);
  const selectedMachineType = machineTypes.find((item) => item.id === machineTypeId);
  const selectedBrand = brands.find((item) => item.id === brandId);
  const selectedModel = models.find((item) => item.model === model);

  const formReady = Boolean(
    categoryId &&
      activityId &&
      machineTypeId &&
      brandId &&
      model &&
      manufactureYear &&
      workingHours,
  );

  const selectionPath = [
    selectedCategory?.name,
    selectedActivity?.name,
    selectedMachineType?.name,
    selectedBrand?.name,
    model,
  ].filter(Boolean) as string[];

  /* ============================================================
     RENDER
  ============================================================ */

  return (
    <main
      dir="rtl"
      className="min-h-screen w-full bg-[#090909] px-4 pb-24 pt-28 text-white sm:px-6"
    >
      <div className="mx-auto w-full max-w-[1120px]">
        {/* HEADER */}
        <header className="mx-auto mb-10 max-w-4xl text-center">
          <div className="mx-auto mb-5 flex h-20 w-20 items-center justify-center rounded-[26px] border border-orange-400/20 bg-gradient-to-br from-orange-500 via-amber-500 to-yellow-500 text-white shadow-[0_20px_70px_rgba(245,130,32,0.22)]">
            <TrendingUp className="h-10 w-10" />
          </div>

          <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-orange-400/20 bg-orange-500/[0.07] px-4 py-2 text-[10px] font-black tracking-[0.18em] text-orange-300">
            <Sparkles className="h-3.5 w-3.5" />
            ARIA MJ PRICE INTELLIGENCE
          </div>

          <h1 className="text-3xl font-black tracking-tight sm:text-4xl md:text-5xl">
            کارشناسی و تخمین قیمت
          </h1>

          <h2 className="mt-3 bg-gradient-to-r from-orange-400 to-amber-300 bg-clip-text text-2xl font-black text-transparent sm:text-3xl">
            ماشین‌آلات سنگین
          </h2>

          <p className="mx-auto mt-5 max-w-3xl text-sm leading-8 text-white/50 sm:text-[15px]">
            قیمت دستگاه بر اساس داده‌های واقعی بازار ARIA MJ، مشخصات فنی، سال ساخت،
            کارکرد، وضعیت قطعات و شرایط معامله محاسبه می‌شود.
          </p>
        </header>

        {/* SELECTION PATH */}
        {selectionPath.length > 0 && (
          <div className="mb-6 rounded-2xl border border-orange-500/20 bg-orange-500/[0.045] p-4 shadow-[0_12px_45px_rgba(0,0,0,0.16)]">
            <div className="mb-3 text-[10px] font-black tracking-wider text-orange-300">
              مسیر انتخاب دستگاه
            </div>

            <div className="flex flex-wrap items-center gap-2 text-xs sm:text-sm">
              {selectionPath.map((item, index) => (
                <div key={`${item}-${index}`} className="flex items-center gap-2">
                  {index > 0 && <span className="text-white/25">←</span>}
                  <span
                    className={
                      index === selectionPath.length - 1
                        ? "rounded-lg bg-orange-500/15 px-3 py-1.5 font-black text-orange-300"
                        : "rounded-lg bg-white/[0.06] px-3 py-1.5 text-white/70"
                    }
                  >
                    {item}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {error && (
          <div className="mb-6 flex items-start gap-3 rounded-2xl border border-red-500/25 bg-red-500/[0.07] p-4 text-sm text-red-200">
            <AlertCircle className="mt-0.5 h-5 w-5 shrink-0 text-red-400" />
            <span>{error}</span>
          </div>
        )}

        {/* MAIN FORM */}
        <section className="overflow-hidden rounded-[28px] border border-white/[0.08] bg-gradient-to-br from-white/[0.055] to-white/[0.018] shadow-[0_30px_100px_rgba(0,0,0,0.35)] backdrop-blur-xl">
          {/* TABS */}
          <div className="grid grid-cols-3 border-b border-white/[0.08] bg-white/[0.025]">
            <TabButton
              active={activeTab === "basic"}
              icon={<ClipboardCheck className="h-4 w-4" />}
              label="مشخصات دستگاه"
              onClick={() => setActiveTab("basic")}
            />
            <TabButton
              active={activeTab === "technical"}
              icon={<Wrench className="h-4 w-4" />}
              label="بررسی فنی"
              onClick={() => setActiveTab("technical")}
            />
            <TabButton
              active={activeTab === "documents"}
              icon={<FileText className="h-4 w-4" />}
              label="مدارک و گمرک"
              onClick={() => setActiveTab("documents")}
            />
          </div>

          <div className="p-5 sm:p-8 md:p-10">
            {/* BASIC */}
            {activeTab === "basic" && (
              <div className="space-y-7">
                <div className="rounded-[22px] border border-orange-500/15 bg-orange-500/[0.025] p-5 sm:p-6">
                  <div className="mb-6 text-center sm:text-right">
                    <h3 className="text-base font-black sm:text-lg">مشخصات دقیق دستگاه</h3>
                    <p className="mt-2 text-xs leading-6 text-white/40">
                      انتخاب‌ها کاملاً وابسته به یکدیگر هستند و دقیقاً از ساختار واقعی
                      دسته‌بندی ARIA MJ پیروی می‌کنند.
                    </p>
                  </div>

                  <div className="grid gap-5 md:grid-cols-2">
                    <SelectField
                      label="دسته ماشین‌آلات"
                      required
                      icon={<HardHat className="h-4 w-4 text-orange-400" />}
                      value={categoryId}
                      disabled={loadingCategories}
                      onChange={handleCategoryChange}
                      placeholder={
                        loadingCategories ? "در حال بارگذاری..." : "انتخاب دسته ماشین‌آلات..."
                      }
                      options={categories.map((item) => ({ value: item.id, label: item.name }))}
                    />

                    <SelectField
                      label="نوع فعالیت / کاربرد"
                      required
                      icon={<HardHat className="h-4 w-4 text-amber-400" />}
                      value={activityId}
                      disabled={!categoryId || loadingActivities}
                      onChange={handleActivityChange}
                      placeholder={
                        !categoryId
                          ? "ابتدا دسته ماشین‌آلات را انتخاب کنید"
                          : loadingActivities
                            ? "در حال بارگذاری فعالیت‌ها..."
                            : activities.length === 0
                              ? "فعالیتی برای این دسته ثبت نشده"
                              : "انتخاب نوع فعالیت / کاربرد..."
                      }
                      options={activities.map((item) => ({ value: item.id, label: item.name }))}
                    />

                    <SelectField
                      label="نوع دستگاه"
                      required
                      icon={<Wrench className="h-4 w-4 text-orange-400" />}
                      value={machineTypeId}
                      disabled={!activityId || loadingMachineTypes}
                      onChange={handleMachineTypeChange}
                      placeholder={
                        !activityId
                          ? "ابتدا نوع فعالیت / کاربرد را انتخاب کنید"
                          : loadingMachineTypes
                            ? "در حال بارگذاری انواع دستگاه..."
                            : machineTypes.length === 0
                              ? "نوع دستگاهی برای این فعالیت ثبت نشده"
                              : "انتخاب نوع دستگاه..."
                      }
                      options={machineTypes.map((item) => ({ value: item.id, label: item.name }))}
                    />

                    <SelectField
                      label="برند"
                      required
                      icon={<ShieldCheck className="h-4 w-4 text-sky-400" />}
                      value={brandId}
                      disabled={!machineTypeId || loadingBrands}
                      onChange={handleBrandChange}
                      placeholder={
                        !machineTypeId
                          ? "ابتدا نوع دستگاه را انتخاب کنید"
                          : loadingBrands
                            ? "در حال بارگذاری برندها..."
                            : brands.length === 0
                              ? "برندی برای این نوع دستگاه ثبت نشده"
                              : "انتخاب برند..."
                      }
                      options={brands.map((item) => ({ value: item.id, label: item.name }))}
                    />

                    <div className="md:col-span-2">
                      <SelectField
                        label="مدل دستگاه"
                        required
                        icon={<Cog className="h-4 w-4 text-emerald-400" />}
                        value={model}
                        disabled={!brandId || loadingModels}
                        onChange={handleModelChange}
                        placeholder={
                          !brandId
                            ? "ابتدا برند را انتخاب کنید"
                            : loadingModels
                              ? "در حال بارگذاری مدل‌ها..."
                              : models.length === 0
                                ? "مدلی برای این برند ثبت نشده"
                                : "انتخاب مدل واقعی..."
                        }
                        options={models.map((item) => ({
                          value: item.model,
                          label: `${item.model} (${formatNumber(item.machineCount)} دستگاه)`,
                        }))}
                      />
                    </div>
                  </div>
                </div>

                {selectedModel && (
                  <div className="rounded-2xl border border-emerald-500/20 bg-emerald-500/[0.045] p-4">
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <div>
                        <div className="text-[10px] text-white/35">دستگاه انتخاب‌شده</div>
                        <div className="mt-1 text-lg font-black">
                          {selectedBrand?.name} {selectedModel.model}
                        </div>
                      </div>
                      <div className="rounded-xl bg-emerald-500/10 px-4 py-2 text-xs font-bold text-emerald-300">
                        {formatNumber(selectedModel.machineCount)} دستگاه مشابه در دیتای بازار
                      </div>
                    </div>
                  </div>
                )}

                <div className="grid gap-5 md:grid-cols-2">
                  <NumberField
                    label="سال ساخت میلادی"
                    required
                    value={manufactureYear}
                    min={1950}
                    max={currentYear + 2}
                    placeholder={String(currentYear)}
                    onChange={(value) => {
                      setManufactureYear(value);
                      clearEstimation();
                    }}
                  />
                  <NumberField
                    label="ساعت کارکرد"
                    required
                    value={workingHours}
                    min={0}
                    placeholder="مثلاً ۵۰۰۰"
                    onChange={(value) => {
                      setWorkingHours(value);
                      clearEstimation();
                    }}
                  />
                </div>

                <div>
                  <label className="mb-3 block text-sm font-bold text-white/80">
                    وضعیت کلی دستگاه
                  </label>
                  <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
                    {CONDITION_OPTIONS.map((option) => (
                      <button
                        key={option.value}
                        type="button"
                        onClick={() => {
                          setMachineCondition(option.value);
                          clearEstimation();
                        }}
                        className={`rounded-2xl border p-4 text-center transition ${
                          machineCondition === option.value
                            ? "border-orange-500 bg-orange-500/10 text-orange-300 shadow-[0_8px_30px_rgba(245,130,32,0.12)]"
                            : "border-white/10 bg-white/[0.025] text-white/50 hover:border-white/20 hover:text-white"
                        }`}
                      >
                        <div className="text-sm font-bold">{option.label}</div>
                        <div className="mt-1 text-[10px] opacity-50">
                          حدود {formatNumber(option.percentage)}٪ سلامت
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* TECHNICAL */}
            {activeTab === "technical" && (
              <div className="space-y-6">
                <div className="rounded-2xl border border-sky-500/20 bg-sky-500/[0.045] p-4 text-sm leading-7 text-sky-200">
                  وضعیت واقعی هر بخش را وارد کنید. این اطلاعات مستقیماً در ضریب فنی قیمت اثر می‌گذارد.
                </div>

                <div className="grid gap-4 md:grid-cols-2">
                  {componentConditions.map((component) => (
                    <div
                      key={component.id}
                      className="rounded-2xl border border-white/10 bg-white/[0.025] p-5"
                    >
                      <div className="mb-5 flex items-center gap-3">
                        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-orange-500/10 text-orange-400">
                          {component.id === "engine" && <Cog className="h-5 w-5" />}
                          {component.id.includes("hydraulic") && <Droplets className="h-5 w-5" />}
                          {component.id === "undercarriage" && <Layers className="h-5 w-5" />}
                          {component.id === "electrical" && <Zap className="h-5 w-5" />}
                          {component.id !== "engine" &&
                            !component.id.includes("hydraulic") &&
                            component.id !== "undercarriage" &&
                            component.id !== "electrical" && <Wrench className="h-5 w-5" />}
                        </div>
                        <div>
                          <h3 className="text-sm font-bold">{component.label}</h3>
                          <p className="mt-1 text-xs text-white/35">
                            وضعیت سلامت: {formatNumber(component.percentage)}٪
                          </p>
                        </div>
                      </div>

                      <div className="grid grid-cols-5 gap-1.5">
                        {COMPONENT_CONDITIONS.map((option) => (
                          <button
                            key={option.value}
                            type="button"
                            onClick={() =>
                              updateComponent(component.id, {
                                condition: option.value as ComponentCondition["condition"],
                                percentage: option.percentage,
                              })
                            }
                            className={`rounded-lg px-1 py-2 text-[10px] font-bold transition ${
                              component.condition === option.value
                                ? conditionClass(option.value)
                                : "bg-white/5 text-white/40 hover:bg-white/10"
                            }`}
                          >
                            {option.label}
                          </button>
                        ))}
                      </div>

                      <div className="mt-5">
                        <div className="mb-2 flex justify-between text-xs">
                          <span className="text-white/45">درصد سلامت</span>
                          <span className="font-bold text-orange-400">
                            {formatNumber(component.percentage)}٪
                          </span>
                        </div>
                        <input
                          type="range"
                          min="0"
                          max="100"
                          value={component.percentage}
                          onChange={(event) =>
                            updateComponent(component.id, {
                              percentage: Number(event.target.value),
                            })
                          }
                          className="w-full accent-orange-500"
                        />
                      </div>

                      <label className="mt-5 flex cursor-pointer items-center gap-2 text-xs text-white/60">
                        <input
                          type="checkbox"
                          checked={component.hasIssue}
                          onChange={(event) =>
                            updateComponent(component.id, {
                              hasIssue: event.target.checked,
                            })
                          }
                          className="h-4 w-4 accent-orange-500"
                        />
                        این بخش مشکل دارد
                      </label>

                      {component.hasIssue && (
                        <textarea
                          value={component.issueDescription}
                          onChange={(event) =>
                            updateComponent(component.id, {
                              issueDescription: event.target.value,
                            })
                          }
                          rows={3}
                          placeholder="شرح مشکل، خرابی یا نیاز به تعمیر..."
                          className="mt-3 w-full resize-none rounded-xl border border-red-500/20 bg-red-500/5 px-3 py-2 text-sm text-white outline-none placeholder:text-white/25 focus:border-red-500/50"
                        />
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* DOCUMENTS */}
            {activeTab === "documents" && (
              <div className="grid gap-6 md:grid-cols-2">
                <OptionPanel
                  title="وضعیت مدارک"
                  icon={<FileText className="h-5 w-5 text-purple-400" />}
                  options={[
                    { value: "complete", label: "مدارک کامل" },
                    { value: "partial", label: "مدارک ناقص" },
                    { value: "none", label: "بدون مدارک" },
                  ]}
                  value={hasDocuments}
                  onChange={(value) => {
                    setHasDocuments(value as typeof hasDocuments);
                    clearEstimation();
                  }}
                  activeClass="border-purple-500 bg-purple-500/10 text-purple-300"
                />

                <OptionPanel
                  title="وضعیت گمرک"
                  icon={<Truck className="h-5 w-5 text-sky-400" />}
                  options={[
                    { value: "cleared", label: "ترخیص شده" },
                    { value: "in_process", label: "در حال ترخیص" },
                    { value: "uncleared", label: "ترخیص نشده" },
                  ]}
                  value={customsStatus}
                  onChange={(value) => {
                    setCustomsStatus(value as typeof customsStatus);
                    clearEstimation();
                  }}
                  activeClass="border-sky-500 bg-sky-500/10 text-sky-300"
                />

                <label className="flex cursor-pointer items-start gap-3 rounded-2xl border border-white/10 bg-white/[0.025] p-5 transition hover:border-orange-500/30 md:col-span-2">
                  <input
                    type="checkbox"
                    checked={hasInspectionReport}
                    onChange={(event) => {
                      setHasInspectionReport(event.target.checked);
                      clearEstimation();
                    }}
                    className="mt-1 h-5 w-5 accent-orange-500"
                  />
                  <div>
                    <div className="flex items-center gap-2 font-bold">
                      <ClipboardCheck className="h-4 w-4 text-orange-400" />
                      گزارش کارشناسی معتبر دارد
                    </div>
                    <p className="mt-2 text-xs leading-6 text-white/40">
                      دستگاه توسط کارشناس یا مرکز معتبر بازرسی شده و گزارش کارشناسی موجود است.
                    </p>
                  </div>
                </label>
              </div>
            )}
          </div>

          {/* ACTION */}
          <div className="border-t border-white/10 bg-white/[0.02] p-5 sm:p-6">
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
              <div className="flex items-center gap-3 text-xs leading-6 text-white/40">
                <BarChart3 className="h-5 w-5 shrink-0 text-orange-400" />
                محاسبه بر اساس داده‌های واقعی ماشین‌آلات ثبت‌شده در ARIA MJ
              </div>

              <button
                type="button"
                onClick={() => void calculateEstimation()}
                disabled={loadingCalculation || !formReady}
                className="flex min-h-14 items-center justify-center gap-3 rounded-2xl bg-gradient-to-r from-orange-500 via-amber-500 to-yellow-500 px-8 text-base font-black text-white shadow-xl shadow-orange-500/20 transition hover:scale-[1.01] disabled:cursor-not-allowed disabled:opacity-40"
              >
                {loadingCalculation ? (
                  <>
                    <Loader2 className="h-5 w-5 animate-spin" />
                    در حال محاسبه...
                  </>
                ) : (
                  <>
                    <TrendingUp className="h-5 w-5" />
                    محاسبه قیمت هوشمند
                  </>
                )}
              </button>
            </div>
          </div>
        </section>

        {/* RESULT */}
        {estimation && (
          <section
            id="estimation-result"
            className="mt-8 rounded-[28px] border border-emerald-500/20 bg-gradient-to-br from-emerald-500/10 via-white/[0.03] to-transparent p-5 shadow-[0_25px_90px_rgba(0,0,0,0.28)] sm:p-8"
          >
            <div className="mb-7 flex items-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-emerald-500/10 text-emerald-400">
                <TrendingUp className="h-6 w-6" />
              </div>
              <div>
                <h2 className="text-2xl font-black">نتیجه کارشناسی هوشمند</h2>
                <p className="mt-1 text-xs leading-6 text-white/40">
                  {selectionPath.join(" ← ")}
                </p>
              </div>
            </div>

            {!estimation.available ? (
              <div className="rounded-2xl border border-amber-500/20 bg-amber-500/5 p-6 text-center">
                <AlertCircle className="mx-auto mb-3 h-8 w-8 text-amber-400" />
                <h3 className="font-bold text-amber-200">هنوز داده کافی وجود ندارد</h3>
                <p className="mx-auto mt-2 max-w-2xl text-sm leading-7 text-white/50">
                  {estimation.message ||
                    "برای این مدل هنوز نمونه قیمت کافی در بازار ARIA MJ ثبت نشده است."}
                </p>
              </div>
            ) : (
              <>
                <div className="grid gap-5 md:grid-cols-3">
                  <div className="rounded-2xl border border-emerald-500/20 bg-emerald-500/5 p-6 md:col-span-2">
                    <div className="text-sm text-white/45">بازه قیمت منصفانه</div>
                    <div className="mt-4 flex flex-wrap items-baseline gap-3">
                      <span className="text-3xl font-black text-emerald-400 sm:text-4xl">
                        {formatNumber(estimation.minPrice)}
                      </span>
                      <span className="text-white/30">تا</span>
                      <span className="text-3xl font-black text-emerald-400 sm:text-4xl">
                        {formatNumber(estimation.maxPrice)}
                      </span>
                      <span className="text-sm text-white/40">
                        {currencyLabel(estimation.currency)}
                      </span>
                    </div>
                    <div className="mt-5 border-t border-white/10 pt-4">
                      <div className="flex items-center justify-between gap-4">
                        <span className="text-sm text-white/45">قیمت متوسط</span>
                        <span className="text-xl font-black">
                          {formatNumber(estimation.averagePrice)} {currencyLabel(estimation.currency)}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
                      <div className="mb-3 text-xs text-white/40">سطح اطمینان</div>
                      <div
                        className={`inline-flex items-center gap-2 rounded-xl px-4 py-2 text-sm font-bold ${
                          estimation.confidence === "high"
                            ? "bg-emerald-500/10 text-emerald-400"
                            : estimation.confidence === "medium"
                              ? "bg-amber-500/10 text-amber-400"
                              : "bg-red-500/10 text-red-400"
                        }`}
                      >
                        <CheckCircle2 className="h-4 w-4" />
                        {estimation.confidence === "high"
                          ? "بالا"
                          : estimation.confidence === "medium"
                            ? "متوسط"
                            : "پایین"}
                      </div>
                    </div>

                    <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
                      <div className="text-xs text-white/40">نمونه‌های بازار</div>
                      <div className="mt-2 text-2xl font-black text-orange-400">
                        {formatNumber(estimation.sampleSize)}
                      </div>
                      <div className="mt-1 text-xs text-white/30">دستگاه مشابه در دیتابیس</div>
                    </div>
                  </div>
                </div>

                {estimation.breakdown && (
                  <div className="mt-6 rounded-2xl border border-white/10 bg-white/[0.03] p-5">
                    <h3 className="mb-5 font-bold">جزئیات محاسبه</h3>
                    <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
                      <BreakdownItem label="قیمت پایه" value={estimation.breakdown.basePrice} />
                      <BreakdownItem label="تأثیر سال ساخت" value={estimation.breakdown.yearAdjustment} />
                      <BreakdownItem label="تأثیر کارکرد" value={estimation.breakdown.hoursAdjustment} />
                      <BreakdownItem label="تأثیر وضعیت فنی" value={estimation.breakdown.conditionAdjustment} />
                      <BreakdownItem label="تأثیر بازار و مدارک" value={estimation.breakdown.marketAdjustment} />
                    </div>
                  </div>
                )}

                {estimation.methodology && (
                  <div className="mt-6 grid gap-4 md:grid-cols-3">
                    <MethodItem
                      label="نمونه بازار"
                      value={`${formatNumber(estimation.methodology.marketSamples)} دستگاه`}
                    />
                    <MethodItem
                      label="میانگین کارکرد بازار"
                      value={`${formatNumber(estimation.methodology.marketAverageHours)} ساعت`}
                    />
                    <MethodItem
                      label="میانگین سلامت قطعات"
                      value={`${formatNumber(estimation.methodology.componentAverage)}٪`}
                    />
                  </div>
                )}

                {estimation.criticalIssues && estimation.criticalIssues.length > 0 && (
                  <div className="mt-6 rounded-2xl border border-red-500/20 bg-red-500/5 p-5">
                    <h3 className="mb-4 flex items-center gap-2 font-bold text-red-300">
                      <AlertCircle className="h-5 w-5" />
                      موارد مهم فنی
                    </h3>
                    <ul className="space-y-2">
                      {estimation.criticalIssues.map((issue, index) => (
                        <li key={index} className="text-sm leading-7 text-red-200/80">
                          • {issue}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {estimation.recommendations && estimation.recommendations.length > 0 && (
                  <div className="mt-6 rounded-2xl border border-sky-500/20 bg-sky-500/5 p-5">
                    <h3 className="mb-4 flex items-center gap-2 font-bold text-sky-300">
                      <CheckCircle2 className="h-5 w-5" />
                      توصیه کارشناسی
                    </h3>
                    <div className="grid gap-3 md:grid-cols-3">
                      {estimation.recommendations.map((recommendation, index) => (
                        <div
                          key={index}
                          className="rounded-xl bg-sky-500/10 p-4 text-sm leading-7 text-sky-100/80"
                        >
                          {recommendation}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </>
            )}

            {/* SELL LEAD */}
            <div className="mt-8 overflow-hidden rounded-[24px] border border-orange-500/25 bg-gradient-to-br from-orange-500/[0.12] via-orange-500/[0.045] to-transparent p-5 sm:p-7">
              {leadSubmitted ? (
                <div className="flex flex-col items-center text-center">
                  <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-emerald-500/10 text-emerald-400">
                    <CheckCircle2 className="h-8 w-8" />
                  </div>
                  <h3 className="mt-4 text-xl font-black">درخواست شما ثبت شد</h3>
                  <p className="mt-2 max-w-2xl text-sm leading-7 text-white/50">
                    اطلاعات دستگاه شما در فهرست فرصت‌های فروش ARIA MJ ثبت شد. تیم ما برای بررسی
                    امکان فروش و معرفی دستگاه به خریداران و دیلرهای مناسب با شما تماس خواهد گرفت.
                  </p>
                </div>
              ) : (
                <div className="grid gap-7 lg:grid-cols-[1.15fr_0.85fr] lg:items-center">
                  <div>
                    <div className="inline-flex items-center gap-2 rounded-full bg-orange-500/10 px-3 py-1.5 text-[10px] font-black text-orange-300">
                      <Sparkles className="h-3.5 w-3.5" />
                      فرصت فروش دستگاه
                    </div>
                    <h3 className="mt-4 text-xl font-black sm:text-2xl">
                      می‌خواهید دستگاه خود را با ارزش حقیقی بازار بفروشید؟
                    </h3>
                    <p className="mt-3 max-w-2xl text-sm leading-7 text-white/50">
                      شماره موبایل خود را ثبت کنید تا دستگاه شما وارد بانک فرصت‌های فروش ARIA MJ
                      شود و در صورت تناسب، برای خریداران حرفه‌ای، واسطه‌ها و دیلرهای مرتبط معرفی شود.
                    </p>
                    <div className="mt-4 flex flex-wrap gap-3 text-[10px] text-white/45">
                      <span className="rounded-lg bg-white/[0.045] px-3 py-2">بدون تعهد برای فروش</span>
                      <span className="rounded-lg bg-white/[0.045] px-3 py-2">ثبت مشخصات دستگاه</span>
                      <span className="rounded-lg bg-white/[0.045] px-3 py-2">تماس کارشناسی</span>
                    </div>
                  </div>

                  <div className="rounded-2xl border border-white/10 bg-[#111]/70 p-5 shadow-xl">
                    <div className="mb-4 flex items-center gap-2 text-sm font-black">
                      <Phone className="h-4 w-4 text-orange-400" />
                      شماره موبایل برای فروش دستگاه
                    </div>

                    <div className="relative">
                      <Phone className="pointer-events-none absolute right-4 top-1/2 h-4 w-4 -translate-y-1/2 text-white/25" />
                      <input
                        value={leadMobile}
                        onChange={(event) => setLeadMobile(event.target.value)}
                        inputMode="tel"
                        dir="ltr"
                        placeholder="0912 123 4567"
                        className="h-12 w-full rounded-xl border border-white/10 bg-white/[0.04] px-4 pr-11 text-sm text-white outline-none placeholder:text-white/20 focus:border-orange-500/50 focus:ring-2 focus:ring-orange-500/10"
                      />
                    </div>

                    <label className="mt-4 flex cursor-pointer items-start gap-2 text-[10px] leading-5 text-white/45">
                      <input
                        type="checkbox"
                        checked={leadConsent}
                        onChange={(event) => setLeadConsent(event.target.checked)}
                        className="mt-0.5 h-4 w-4 shrink-0 accent-orange-500"
                      />
                      <span>
                        موافقم اطلاعات دستگاه و شماره موبایل من برای بررسی فروش، کارشناسی و ارتباط
                        با خریداران یا دیلرهای مرتبط در ARIA MJ استفاده شود.
                      </span>
                    </label>

                    {leadError && (
                      <div className="mt-3 rounded-xl border border-red-500/20 bg-red-500/5 px-3 py-2 text-[10px] text-red-300">
                        {leadError}
                      </div>
                    )}

                    <button
                      type="button"
                      onClick={() => void submitSellLead()}
                      disabled={leadSubmitting}
                      className="mt-4 flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-[#F58220] text-xs font-black text-white transition hover:bg-[#ff8d2b] disabled:cursor-not-allowed disabled:opacity-50"
                    >
                      {leadSubmitting ? (
                        <>
                          <Loader2 className="h-4 w-4 animate-spin" />
                          در حال ثبت...
                        </>
                      ) : (
                        <>
                          <Send className="h-4 w-4" />
                          ثبت دستگاه برای فروش
                        </>
                      )}
                    </button>

                    <div className="mt-3 flex items-center justify-center gap-1.5 text-[9px] text-white/25">
                      <LockKeyhole className="h-3 w-3" />
                      اطلاعات تماس شما عمومی نمایش داده نمی‌شود.
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div className="mt-6 rounded-xl border border-amber-500/20 bg-amber-500/5 p-4 text-center text-xs leading-6 text-amber-200/70">
              این نتیجه یک تخمین هوشمند بر اساس داده‌های موجود است و جایگزین کارشناسی حضوری دستگاه برای معامله قطعی نیست.
            </div>
          </section>
        )}
      </div>
    </main>
  );
}

/* ============================================================
   UI HELPERS
============================================================ */

function TabButton({
  active,
  icon,
  label,
  onClick,
}: {
  active: boolean;
  icon: ReactNode;
  label: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`flex items-center justify-center gap-2 px-3 py-4 text-sm font-bold transition ${
        active
          ? "border-b-2 border-orange-500 bg-orange-500/10 text-orange-400"
          : "text-white/50 hover:bg-white/5 hover:text-white"
      }`}
    >
      {icon}
      {label}
    </button>
  );
}

function SelectField({
  label,
  required,
  icon,
  value,
  disabled,
  placeholder,
  options,
  onChange,
}: {
  label: string;
  required?: boolean;
  icon?: ReactNode;
  value: string;
  disabled?: boolean;
  placeholder: string;
  options: { value: string; label: string }[];
  onChange: (value: string) => void;
}) {
  return (
    <div>
      <label className="mb-2 flex items-center gap-2 text-sm font-bold text-white/80">
        {icon}
        {label}
        {required && <span className="text-red-400">*</span>}
      </label>

      <div className="relative">
        <select
          value={value}
          disabled={disabled}
          onChange={(event) => onChange(event.target.value)}
          className="h-12 w-full appearance-none rounded-xl border border-white/10 bg-[#141414] px-4 pl-10 text-sm text-white outline-none transition focus:border-orange-500/50 focus:ring-2 focus:ring-orange-500/10 disabled:cursor-not-allowed disabled:opacity-40"
        >
          <option value="">{placeholder}</option>
          {options.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
        <ChevronDown className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-white/30" />
      </div>
    </div>
  );
}

function NumberField({
  label,
  required,
  value,
  min,
  max,
  placeholder,
  onChange,
}: {
  label: string;
  required?: boolean;
  value: string;
  min?: number;
  max?: number;
  placeholder?: string;
  onChange: (value: string) => void;
}) {
  return (
    <div>
      <label className="mb-2 block text-sm font-bold text-white/80">
        {label}
        {required && <span className="mr-1 text-red-400">*</span>}
      </label>
      <div className="relative">
        <Gauge className="pointer-events-none absolute right-4 top-1/2 h-4 w-4 -translate-y-1/2 text-white/25" />
        <input
          type="number"
          dir="ltr"
          value={value}
          min={min}
          max={max}
          placeholder={placeholder}
          onChange={(event) => onChange(event.target.value)}
          className="h-12 w-full rounded-xl border border-white/10 bg-white/[0.04] py-3 pl-4 pr-11 text-white outline-none transition placeholder:text-white/20 focus:border-orange-500/50 focus:ring-2 focus:ring-orange-500/10"
        />
      </div>
    </div>
  );
}

function OptionPanel({
  title,
  icon,
  options,
  value,
  onChange,
  activeClass,
}: {
  title: string;
  icon: ReactNode;
  options: { value: string; label: string }[];
  value: string;
  onChange: (value: string) => void;
  activeClass: string;
}) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/[0.025] p-5">
      <div className="mb-4 flex items-center gap-2">
        {icon}
        <h3 className="font-bold">{title}</h3>
      </div>
      <div className="space-y-2">
        {options.map((option) => (
          <button
            key={option.value}
            type="button"
            onClick={() => onChange(option.value)}
            className={`w-full rounded-xl border p-4 text-right text-sm font-bold transition ${
              value === option.value
                ? activeClass
                : "border-white/10 bg-white/[0.02] text-white/60 hover:border-white/20"
            }`}
          >
            {option.label}
          </button>
        ))}
      </div>
    </div>
  );
}

function BreakdownItem({
  label,
  value,
}: {
  label: string;
  value: number;
}) {
  const positive = value >= 0;

  return (
    <div className="rounded-xl bg-white/[0.03] p-4">
      <div className="text-xs text-white/35">{label}</div>
      <div className={`mt-2 text-sm font-black ${positive ? "text-emerald-400" : "text-red-400"}`}>
        {positive ? "+" : ""}
        {formatNumber(value)}
      </div>
    </div>
  );
}

function MethodItem({
  label,
  value,
}: {
  label: string;
  value: string;
}) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/[0.025] p-5">
      <div className="text-xs text-white/35">{label}</div>
      <div className="mt-2 text-lg font-black text-white">{value}</div>
    </div>
  );
}
