"use client";

import GlassPanel from "@/components/ui/GlassPanel";

import { ICON_MAP } from "../constants/serviceIcons";

interface ServiceCardProps {
  icon: string;
  title: string;
  description: string;
}

export default function ServiceCard({
  icon,
  title,
  description,
}: ServiceCardProps) {
  /* اگر icon یک کلید معتبر در نگاشت باشد، آیکون lucide؛ وگرنه همان متن (ایموجی) */
  const Icon = ICON_MAP[icon];

  return (
    <GlassPanel
      className="p-8 transition-all duration-300 hover:-translate-y-2 hover:border-[#F58220]/40"
    >
      {Icon ? (
        /* حالت جدید: آیکون lucide در قاب نارنجی نرم */
        <div className="mb-8 flex h-14 w-14 items-center justify-center rounded-2xl bg-[#F58220]/15 text-[#F58220] transition-transform duration-300 group-hover:scale-110">
          <Icon className="h-7 w-7" />
        </div>
      ) : (
        /* حالت سازگار با قبل: ایموجی یا متن ساده */
        <div className="text-5xl mb-8">{icon}</div>
      )}

      <h3 className="text-white text-2xl font-bold">{title}</h3>

      <p className="mt-5 text-white/70 leading-8">{description}</p>
    </GlassPanel>
  );
}