"use client";

import { useMemo } from "react";
import Link from "next/link";

import {
  ArrowLeft,
  Wrench,
  Cog,
  Truck,
  KeyRound,
  Users,
  ClipboardCheck,
  GraduationCap,
  ShieldCheck,
  Banknote,
  Headphones,
  Briefcase,
} from "lucide-react";

import SectionTitle from "@/components/ui/SectionTitle";

import { ServiceCard } from "./components";
import { useServices } from "./hooks/useServices";
import { useCategories } from "@/modules/category";

interface CmsConfig {
  title?: string;
  subtitle?: string;
  description?: string;
  config?: any;
}

const ICON_RULES: { keys: string[]; icon: any }[] = [
  { keys: ["تعمیر", "repair", "بازسازی"], icon: Wrench },
  { keys: ["قطعه", "part", "یدکی"], icon: Cog },
  { keys: ["حمل", "نقل", "transport", "لجستیک"], icon: Truck },
  { keys: ["اجاره", "rent", "کرایه"], icon: KeyRound },
  { keys: ["اپراتور", "operator", "نیرو"], icon: Users },
  { keys: ["کارشناسی", "ارزیابی", "inspection"], icon: ClipboardCheck },
  { keys: ["آموزش", "training"], icon: GraduationCap },
  { keys: ["بیمه", "insurance", "ضمانت"], icon: ShieldCheck },
  { keys: ["مالی", "بازرگانی", "finance", "واردات", "import"], icon: Banknote },
  { keys: ["مشاوره", "consult"], icon: Headphones },
];

function pickIcon(c: any) {
  const hay = `${c?.slug ?? ""} ${c?.name ?? ""}`.toLowerCase();
  for (const r of ICON_RULES) {
    if (r.keys.some((k) => hay.includes(k))) return r.icon;
  }
  return Briefcase;
}

export default function ServicesSection({
  cmsConfig,
}: {
  cmsConfig?: CmsConfig;
}) {
  const { services, loading } = useServices();
    const limit = cmsConfig?.config?.limit ?? 8;
  const { categories }: any = useCategories();

  const { industries, childrenMap } = useMemo(() => {
    const list: any[] = categories ?? [];
    const root = list.find((c) => c.slug === "services" && !c.parentId);
    const m: Record<string, any[]> = {};
    for (const c of list) {
      if (c.parentId) (m[c.parentId] ||= []).push(c);
    }
    const inds = list
      .filter((c) => c.parentId === root?.id)
      .sort((a: any, b: any) => (a.sortOrder ?? 0) - (b.sortOrder ?? 0));
    return { industries: inds, childrenMap: m };
  }, [categories]);

  return (
    <section className="relative py-24">
      <div className="mx-auto max-w-[1600px] px-8">
        <SectionTitle
          align="center"
          subtitle={cmsConfig?.subtitle || "SERVICES"}
          title={cmsConfig?.title || "خدمات ARIA MJ"}
          description={
            cmsConfig?.description ||
            "خدمات تخصصی خرید، فروش، تعمیرات و پشتیبانی ماشین‌آلات سنگین"
          }
        />

        {/* کارت‌های اصلی — از دیتابیس (با fallback استاتیک) */}
        {!loading && (
          <div className="mt-12 grid gap-8 md:grid-cols-2 xl:grid-cols-4">
                        {services.slice(0, limit).map((service: any) => (
              <ServiceCard
                key={service.id ?? service.title}
                icon={service.icon}
                title={service.title}
                description={service.description}
              />
            ))}
          </div>
        )}

        {/* صنعت‌های تخصصی از درخت خدمات */}
        {industries.length > 0 && (
          <div className="mt-14">
            <div className="mb-5 text-center text-[10px] font-bold uppercase tracking-[0.3em] text-white/35">
              صنعت‌های تخصصی
            </div>

            <div className="flex flex-wrap items-center justify-center gap-3">
              {industries.slice(0, 10).map((ind: any) => {
                const Icon = pickIcon(ind);
                const count = (childrenMap[ind.id] ?? []).length;
                return (
                  <Link
                    key={ind.id}
                    href="/services"
                    className="group inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.04] px-4 py-2.5 text-xs font-bold text-white/70 transition-all duration-300 hover:border-[#F58220]/60 hover:bg-[#F58220]/10 hover:text-[#F58220]"
                  >
                    <Icon className="h-3.5 w-3.5 text-[#F58220]" />
                    {ind.name}
                    {count > 0 && (
                      <span className="rounded-full bg-white/[0.06] px-2 py-0.5 text-[9px] text-white/40 transition group-hover:bg-[#F58220]/15 group-hover:text-[#F58220]">
                        {count.toLocaleString("fa-IR")}
                      </span>
                    )}
                  </Link>
                );
              })}
            </div>
          </div>
        )}

        {/* CTA */}
        <div className="mt-12 flex flex-wrap items-center justify-center gap-4">
          <Link
            href="/machines/new?listingType=OFFER"
            className="inline-flex items-center gap-2 rounded-2xl bg-[#F58220] px-8 py-3.5 text-sm font-black text-white shadow-lg shadow-orange-500/25 transition hover:bg-orange-600"
          >
            ثبت درخواست خدمت
            <ArrowLeft className="h-4 w-4" />
          </Link>
          <Link
            href="/services"
            className="inline-flex items-center gap-2 rounded-2xl border border-white/15 bg-white/[0.04] px-8 py-3.5 text-sm font-bold text-white/80 transition hover:border-[#F58220] hover:text-[#F58220]"
          >
            مشاهدهٔ همهٔ خدمات
          </Link>
        </div>
      </div>
    </section>
  );
}