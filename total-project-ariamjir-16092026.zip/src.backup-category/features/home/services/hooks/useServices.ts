"use client";

import { useEffect, useState } from "react";

import { servicesData } from "../constants/services.data";

/* خواندن خدمات از API با fallback به دادهٔ استاتیک */
export function useServices() {
  const [services, setServices] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/services")
      .then((r) => r.json())
      .then((j) => {
        if (j.success && Array.isArray(j.data) && j.data.length > 0) {
          setServices(j.data);
        } else {
          setServices(servicesData);
        }
      })
      .catch(() => setServices(servicesData))
      .finally(() => setLoading(false));
  }, []);

  return { services, loading };
}