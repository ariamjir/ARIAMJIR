export const servicesData = [
  {
    icon: "🛒",
    title: "خرید و فروش",
    description:
      "ثبت آگهی تخصصی ماشین‌آلات صنعتی",
  },

  {
    icon: "🔧",
    title: "تعمیرات",
    description:
      "شبکه تخصصی تعمیرکاران ماشین‌آلات",
  },

  {
    icon: "⚙️",
    title: "قطعات یدکی",
    description:
      "تامین قطعات اصلی و وارداتی",
  },

  {
    icon: "📦",
    title: "اجاره تجهیزات",
    description:
      "اجاره ماشین‌آلات در سراسر کشور",
  },
];