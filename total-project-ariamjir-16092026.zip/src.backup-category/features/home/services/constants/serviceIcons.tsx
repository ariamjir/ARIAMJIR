import {
  ShoppingCart,
  Wrench,
  Cog,
  Package,
  Truck,
  Users,
  GraduationCap,
  ShieldCheck,
  Banknote,
  Headphones,
  ClipboardCheck,
  KeyRound,
} from "lucide-react";

/* نگاشت کلید → آیکون lucide (جایگزین ایموجی) */
export const ICON_MAP: Record<string, any> = {
  cart: ShoppingCart,
  trade: ShoppingCart,
  wrench: Wrench,
  repair: Wrench,
  cog: Cog,
  parts: Cog,
  package: Package,
  box: Package,
  rent: KeyRound,
  key: KeyRound,
  truck: Truck,
  users: Users,
  graduation: GraduationCap,
  shield: ShieldCheck,
  banknote: Banknote,
  headphones: Headphones,
  clipboard: ClipboardCheck,
};

/* گزینه‌های انتخاب آیکون در پنل مدیریت */
export const ICON_OPTIONS = [
  { key: "cart", label: "خرید و فروش" },
  { key: "wrench", label: "تعمیرات" },
  { key: "cog", label: "قطعات" },
  { key: "package", label: "بسته / تجهیزات" },
  { key: "key", label: "اجاره" },
  { key: "truck", label: "حمل و نقل" },
  { key: "users", label: "نیروی انسانی" },
  { key: "graduation", label: "آموزش" },
  { key: "shield", label: "بیمه / ضمانت" },
  { key: "banknote", label: "مالی" },
  { key: "headphones", label: "مشاوره" },
  { key: "clipboard", label: "کارشناسی" },
];