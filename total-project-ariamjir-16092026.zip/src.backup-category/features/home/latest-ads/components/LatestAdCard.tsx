"use client";

import Image from "next/image";
import Link from "next/link";

interface LatestAdCardProps {
  id: string;
  slug: string;

  title: string;

  brand?: string | null;

  image: string;

  price: string;

  year?: number | null;

  location?: string | null;

  workingHours?: number | null;

  featured?: boolean;

  createdAt?: string;
}

export default function LatestAdCard({
  slug,
  title,
  brand,
  image,
  price,
  year,
  location,
  workingHours,
  featured = false,
  createdAt,
}: LatestAdCardProps) {
  return (
    <Link
      href={`/machines/${slug}`}
      className="group block h-full"
    >
      <article
        className="
          h-full
          overflow-hidden
          rounded-3xl

          border
          border-white/10

          bg-[#111]

          transition-all
          duration-500

          hover:-translate-y-2
          hover:border-[#F58220]/40
          hover:shadow-[0_25px_60px_rgba(0,0,0,.45)]
        "
      >
        {/* IMAGE */}

        <div className="relative aspect-[16/10] overflow-hidden">

          <Image
            src={image}
            alt={title}
            fill
            sizes="(max-width:768px)100vw,(max-width:1200px)50vw,25vw"
            className="
              object-cover
              transition-transform
              duration-700
              group-hover:scale-110
            "
          />

          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />

          {featured && (
            <div
              className="
                absolute
                top-4
                right-4

                rounded-full

                bg-[#F58220]

                px-4
                py-1

                text-xs
                font-bold

                text-white
              "
            >
              ویژه
            </div>
          )}

          {createdAt && (
            <div
              className="
                absolute
                top-4
                left-4

                rounded-full

                bg-black/60

                px-3
                py-1

                text-xs

                text-white
              "
            >
              {createdAt}
            </div>
          )}

        </div>

        {/* CONTENT */}

        <div className="p-6">

          {/* BRAND */}

          <div
            className="
              text-xs

              uppercase

              tracking-[3px]

              text-[#F58220]
            "
          >
            {brand ?? "بدون برند"}
          </div>

          {/* TITLE */}

          <h3
            className="
              mt-3

              line-clamp-2

              min-h-[64px]

              text-xl

              font-bold

              leading-8

              text-white

              transition-colors

              group-hover:text-[#F58220]
            "
          >
            {title}
          </h3>

          {/* INFO */}

          <div
            className="
              mt-5

              grid

              grid-cols-2

              gap-y-3

              text-sm

              text-white/60
            "
          >
            <div>
              📍 {location ?? "-"}
            </div>

            <div>
              📅 {year ?? "-"}
            </div>

            <div>
              ⏱{" "}
              {workingHours
                ? workingHours.toLocaleString("fa-IR")
                : "-"}
            </div>

            <div>
              🏷 {brand ?? "-"}
            </div>
          </div>

          {/* Divider */}

          <div className="my-6 border-t border-white/10" />

          {/* PRICE */}

          <div className="text-xs text-white/50">
            قیمت
          </div>

          <div
            className="
              mt-2

              text-2xl

              font-black

              text-[#F58220]
            "
          >
            {price}
          </div>

          {/* BUTTON */}

          <div
            className="
              mt-7

              flex

              h-12

              items-center
              justify-center

              rounded-xl

              bg-[#F58220]

              font-bold

              text-white

              transition

              group-hover:bg-[#ff9736]
            "
          >
            مشاهده آگهی
          </div>

        </div>
      </article>
    </Link>
  );
}