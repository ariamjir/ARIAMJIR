import { getLatestMachines } from "@/lib/services/machine.service";

import LatestAdCard from "./LatestAdCard";

export default async function LatestAdsSlider() {
  const ads = await getLatestMachines(6);

  if (ads.length === 0) {
    return (
      <div
        className="
          rounded-3xl
          border
          border-white/10
          bg-white/5
          py-20
          text-center
          text-white/70
        "
      >
        هنوز هیچ آگهی منتشر نشده است.
      </div>
    );
  }

  return (
    <div
      className="
        grid
        gap-8

        grid-cols-1
        md:grid-cols-2
        xl:grid-cols-3
      "
    >
      {ads.map((ad) => (
        <LatestAdCard
          key={ad.id}
          id={ad.id}
          slug={ad.slug}
          title={ad.title}
          brand={ad.brand?.name ?? "بدون برند"}
          image={
            ad.images[0]?.url ??
            "/images/machines/default.jpg"
          }
          price={
            ad.price?.price
              ? `${Number(ad.price.price).toLocaleString("fa-IR")} تومان`
              : "تماس بگیرید"
          }
          year={ad.specification?.manufactureYear}
          location={ad.specification?.location}
          workingHours={ad.specification?.workingHours}
        />
      ))}
    </div>
  );
}