import Link from "next/link";

export default function LatestAdsEmpty() {
  return (
    <div className="rounded-3xl border border-white/10 bg-white/5 py-20 text-center">

      <div className="text-5xl">📢</div>

      <h3 className="mt-6 text-3xl font-bold text-white">
        هنوز آگهی ثبت نشده است
      </h3>

      <p className="mt-3 text-white/60">
        اولین آگهی ماشین‌آلات را ثبت کنید.
      </p>

      <Link
        href="/machines"
        className="mt-8 inline-flex rounded-xl bg-[#F58220] px-7 py-3 text-white"
      >
        مشاهده ماشین‌آلات
      </Link>

    </div>
  );
}