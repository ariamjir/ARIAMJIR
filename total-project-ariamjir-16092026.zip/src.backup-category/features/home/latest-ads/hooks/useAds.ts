"use client";

import { useMemo } from "react";

import { ads } from "@/data/ads";

export default function useAds() {
  const featuredAds = useMemo(() => {
    return ads.filter((item) => item.featured);
  }, []);

  return {
    ads,
    featuredAds,
  };
}