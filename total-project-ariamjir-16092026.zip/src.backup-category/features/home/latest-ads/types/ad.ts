import {
  Currency,
  FuelType,
  ListingType,
  MachineCondition,
  PriceType,
  RecordStatus,
  TransmissionType,
} from "@prisma/client";

export interface Ad {
  id: string;

  slug: string;

  title: string;

  shortDescription?: string | null;
  description?: string | null;

  listingType?: ListingType | null;

  status: RecordStatus;

  featured: boolean;
  urgent?: boolean;
  verified?: boolean;
  active: boolean;

  createdAt: Date;
  updatedAt: Date;
  publishedAt?: Date | null;

  brand?: {
    id: string;
    name: string;
    slug: string;
    logo?: string | null;
  } | null;

  category?: {
  id: string;

  name: string;

  slug: string;

  logo?: string | null;
} | null;

  specification?: {
    model?: string | null;

    manufactureYear?: number | null;

    condition?: MachineCondition | null;

    engine?: string | null;

    workingHours?: number | null;

    fuelType?: FuelType | null;

    transmission?: TransmissionType | null;

    location?: string | null;

    province?: string | null;
    city?: string | null;

    provinceId?: string | null;
    cityId?: string | null;

    power?: number | null;
    weight?: number | null;

    serialNumber?: string | null;
  } | null;

  seller?: {
  id?: string | null;

  name?: string | null;

  type?: "company" | "dealer" | "person";

  phone?: string | null;

  whatsapp?: string | null;
} | null;

  price?: {
    price?: number | null;

    currency: Currency;

    priceType: PriceType;

    installment: boolean;

    exchangePossible: boolean;
  } | null;

  image?: string | null;

  gallery: string[];

  viewCount?: number;

  favoriteCount?: number;
}