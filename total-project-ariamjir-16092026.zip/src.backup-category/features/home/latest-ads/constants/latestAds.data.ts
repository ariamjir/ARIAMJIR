export const latestAdsDefaultConfig = {
  title: "جدیدترین آگهی‌ها",

  description:
    "جدیدترین ماشین‌آلات ثبت شده در آریا ماشین جم",

  limit: 8,
};