"use client";

import {
  useEffect,
  useState,
} from "react";

import {
  ads,
} from "@/data/ads";


import {
  LatestAdCard,
} from "./components";


import {
  latestAdsDefaultConfig,
} from "./constants/latestAds.data";



interface CmsConfig {
  title?: string;
  subtitle?: string;
  description?: string;

  config?: {
    limit?: number;
    [key: string]: any;
  };
}


interface Props {
  cmsConfig?: CmsConfig;
}



/* fallback استاتیک — هم‌شکل با خروجی API */
const staticItems = ads
  .filter(
    (ad) =>
      ad.active &&
      ad.status === "PUBLISHED"
  )
  .map((ad: any) => ({
    id: ad.id,
    slug: ad.slug,
    title: ad.title,
    brand: ad.brand?.name ?? "-",
    price: ad.price?.price
      ? `${ad.price.price.toLocaleString("fa-IR")} تومان`
      : "تماس بگیرید",
    image:
      ad.image ??
      "/images/machines/placeholder.png",
    year: ad.specification?.manufactureYear,
    location:
      ad.specification?.city ??
      ad.specification?.province ??
      "-",
    workingHours:
      ad.specification?.workingHours,
    featured: ad.featured,
  }));



export default function LatestAdsSection({
  cmsConfig,
}: Props) {


  const title =
    cmsConfig?.title ||
    latestAdsDefaultConfig.title;



  const description =
    cmsConfig?.description ||
    latestAdsDefaultConfig.description;



  const limit =
    cmsConfig?.config?.limit ??
    latestAdsDefaultConfig.limit;



  /* ✅ اتصال به پنل مدیریت (دیتابیس) با fallback استاتیک */
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/ads/latest")
      .then((r) => r.json())
      .then((j) => {
        if (j.success && j.data?.length) {
          setItems(j.data);
        } else {
          setItems(staticItems.slice(0, limit));
        }
      })
      .catch(() =>
        setItems(staticItems.slice(0, limit))
      )
      .finally(() => setLoading(false));
  }, [limit]);



  /* تکرار لیست برای حرکت بی‌پایان و یکدست */
  const repeat =
    Math.max(
      2,
      Math.ceil(12 / Math.max(1, items.length))
    );

  const seq =
    Array.from({ length: repeat }).flatMap(
      () => items
    );

  const track = [...seq, ...seq];



  return (
    <section
      className="
        relative
        overflow-hidden
        py-24
      "
    >

      <div
        className="
          mx-auto
          max-w-[1600px]
          px-8
        "
      >


                <div
          className="
            mb-12
            text-center
          "
        >

          <h2
            className="
              text-3xl
              font-black
              text-white
            "
          >
            {title}
          </h2>


          <p
                        className="
              mt-3
              max-w-2xl
              mx-auto
              text-sm
              leading-7
              text-white/45
            "
          >
            {description}
          </p>

        </div>
      </div>


      {/* ✅ نوار متحرک ساده — حرکت از چپ به راست */}
      <div
        dir="ltr"
        className="
          overflow-hidden
        "
      >
        <div
          className="
            flex
            w-max
            animate-[marquee-ltr_70s_linear_infinite]
            hover:[animation-play-state:paused]
          "
        >
          {track.map((ad, i) => (
            <div
              key={`${ad.id}-${i}`}
              dir="rtl"
              className="
                mx-4
                w-[320px]
                shrink-0
              "
            >
              <LatestAdCard
                id={ad.id}
                slug={ad.slug}
                title={ad.title}
                brand={ad.brand}
                price={ad.price}
                image={ad.image}
                year={ad.year}
                location={ad.location}
                workingHours={ad.workingHours}
                featured={!!ad.featured}
              />
            </div>
          ))}
        </div>
      </div>

    </section>
  );
}