export interface KnowledgeItem {
  id: string;
  slug: string;
  title: string;
  summary: string;
  category: string;
  image: string;
  author: string;
  readTime: number;
  featured: boolean;
  publishedAt: string;
  tags: string[];
}