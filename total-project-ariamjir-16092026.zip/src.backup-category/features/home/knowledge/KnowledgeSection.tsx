import Link from "next/link";

import { prisma } from "@/lib/prisma";

import { BookOpen, ArrowLeft } from "lucide-react";

import JsonLd from "@/components/seo/JsonLd";

import KnowledgeCard from "@/components/knowledge/KnowledgeCard";

import { SITE_URL } from "@/lib/seo";

/* ============================================================
   ARIA MJ — KNOWLEDGE SECTION
   Desktop:
   Featured / Big Card  ← سمت چپ
   Small Cards           → سمت راست

   این سکشن عمداً قرینهٔ سکشن اخبار طراحی شده است.
============================================================ */

export default async function KnowledgeSection({
  cmsConfig,
}: {
  cmsConfig?: any;
}) {
  const items = await prisma.knowledgePost.findMany({
    where: {
      status: "PUBLISHED",
    },
    orderBy: {
      publishedAt: "desc",
    },
    take: 5,
    include: {
      category: true,
    },
  });

  const featured =
    items.find((item) => item.featured) ?? items[0];

  const rest = items
    .filter((item) => item.id !== featured?.id)
    .slice(0, 4);

  const title =
    cmsConfig?.title ?? "مرکز دانش ARIA MJ";

  return (
    <section
      className="relative py-24"
      aria-label={title}
    >
      {/* ======================================================
          SEO
      ====================================================== */}

      <JsonLd
        data={{
          "@context": "https://schema.org",
          "@type": "ItemList",
          name: title,
          itemListElement: items.map((post, index) => ({
            "@type": "ListItem",
            position: index + 1,
            item: {
              "@type": "Article",
              headline: post.title,
              url: `${SITE_URL}/knowledge/${post.slug}`,
            },
          })),
        }}
      />

      {/* ======================================================
          HEADER
      ====================================================== */}

      <div className="mx-auto flex max-w-[1440px] flex-col items-center px-6 text-center lg:px-10">
        <div className="inline-flex items-center gap-2 text-xs font-black tracking-[0.3em] text-emerald-400">
          <BookOpen className="h-4 w-4" />
          ARIA MJ ACADEMY
        </div>

        <h2 className="mt-3 text-center text-3xl font-black text-white lg:text-4xl">
          {title}
        </h2>

        <p className="mt-3 max-w-2xl text-center text-sm leading-7 text-white/45">
          {cmsConfig?.description ??
            "راهنماها و مقالات آموزشی تخصصی برای خرید، نگهداری و بهره‌برداری از ماشین‌آلات سنگین"}
        </p>
      </div>

      {/* ======================================================
          CONTENT

          نکته مهم:
          در RTL، اولین ستون Grid در سمت راست قرار می‌گیرد.
          بنابراین در دسکتاپ direction:ltr روی Grid قرار داده‌ایم
          تا Featured دقیقاً در سمت چپ قرار بگیرد.

          محتوای هر ستون مجدداً RTL است تا متن فارسی صحیح بماند.
      ====================================================== */}

      {featured ? (
        <div
          className="
            mx-auto
            mt-12
            grid
            max-w-[1440px]
            gap-6
            px-6
            lg:grid-cols-5
            lg:px-10
            lg:[direction:ltr]
          "
        >
          {/* ==================================================
              FEATURED — LEFT
              تصویر اصلی بزرگ
          ================================================== */}

          <div
            className="
              lg:col-span-3
              lg:[direction:rtl]
            "
          >
            <KnowledgeCard
              post={featured}
              variant="big"
            />
          </div>

          {/* ==================================================
              SMALL CARDS — RIGHT
          ================================================== */}

          <div
            className="
              grid
              content-start
              gap-4
              sm:grid-cols-2
              lg:col-span-2
              lg:grid-cols-1
              lg:[direction:rtl]
            "
          >
            {rest.map((post) => (
              <KnowledgeCard
                key={post.id}
                post={post}
                variant="row"
              />
            ))}
          </div>
        </div>
      ) : (
        /* ====================================================
           EMPTY STATE
        ==================================================== */

        <div className="mx-auto mt-12 max-w-[1440px] px-6 lg:px-10">
          <div
            className="
              rounded-2xl
              border
              border-dashed
              border-white/15
              bg-white/[0.02]
              p-10
              text-center
            "
          >
            <BookOpen className="mx-auto h-10 w-10 text-white/20" />

            <p className="mt-3 text-center text-sm font-bold text-white/50">
              هنوز مقاله‌ای منتشر نشده است.
            </p>
          </div>
        </div>
      )}

      {/* ======================================================
          ALL ARTICLES BUTTON
      ====================================================== */}

      <div className="mt-12 flex justify-center">
        <Link
          href="/knowledge"
          className="
            inline-flex
            h-12
            items-center
            gap-2
            rounded-xl
            border
            border-white/10
            bg-white/5
            px-8
            text-sm
            font-bold
            text-white
            transition-all
            duration-300
            hover:border-emerald-400/40
            hover:bg-emerald-400/10
            hover:text-emerald-400
          "
        >
          همهٔ مقالات

          <ArrowLeft className="h-4 w-4" />
        </Link>
      </div>
    </section>
  );
}