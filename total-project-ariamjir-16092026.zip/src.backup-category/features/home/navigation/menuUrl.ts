export type MenuUrlItem = {
  href?: string | null;

  category?: {
    slug?: string | null;
    link?: string | null;
  } | null;
};

export function getMenuHref(
  item: MenuUrlItem,
): string {
  const href =
    item.href?.trim();

  if (href) {
    return href;
  }

  const categoryLink =
    item.category?.link?.trim();

  if (categoryLink) {
    return categoryLink;
  }

  const categorySlug =
    item.category?.slug?.trim();

  if (categorySlug) {
    return `/machines/category/${categorySlug}`;
  }

  return "#";
}