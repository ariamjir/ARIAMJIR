import { Fragment } from "react";

import {
  Hero,
  CategoriesSection,
  FeaturedMachinesSection,
  ExclusiveSaleSection,
  ServicesSection,
  BrandsSection,
  LatestAdsSection,
  LatestNewsSection,
  KnowledgeSection,
  WhyUsSection,
  StatsSection,
  HeroSearch,
} from "@/features/home";

import type { Hero as HeroType } from "@/modules/home";

interface HomepageSection {
  id: string;
  key: string;
  title: string;
  subtitle?: string | null;
  description?: string | null;
  order: number;
  active: boolean;
  type?: string;
  config?: any;
}

interface Props {
  sections: HomepageSection[];
  hero: HeroType | null;
}

/* ============================================================
   رندرر سکشن‌های صفحهٔ اول — همهٔ کلیدهای شناخته‌شده:
   hero, categories, featured-machines, exclusive-sale, services,
   stats, brands, latest-ads, latest-news, knowledge, why-us,
   header (خالی — هدر از SiteChrome می‌آید),
   home-brands (خالی — فقط نگهدارندهٔ تنظیمات انتخاب برندهاست)
============================================================ */

export default function HomepageSectionsRenderer({
  sections,
  hero,
}: Props) {
  return (
    <div className="flex flex-col gap-8">
      {sections
        .filter((section) => section.active)
        .sort((a, b) => a.order - b.order)
        .map((section) => {
          switch (section.key) {
            /* ===== هیرو ===== */
            case "hero":
              return hero ? (
                <Fragment key={section.id}>
                  <Hero hero={hero} />
                  <HeroSearch hero={hero} />
                </Fragment>
              ) : null;

            /* ===== دسته‌بندی‌ها ===== */
            case "categories":
              return <CategoriesSection key={section.id} />;

            /* ===== ماشین‌آلات ویژه / تایید شده ===== */
            case "verified-machines":
            case "featured-machines":
              return <FeaturedMachinesSection key={section.id} />;

            /* ===== فروش ویژه ===== */
            case "exclusive-sale":
              return <ExclusiveSaleSection key={section.id} />;

            /* ===== خدمات ===== */
            case "services":
              return <ServicesSection key={section.id} />;

            /* ===== آمار ===== */
            case "stats":
              return (
                <StatsSection
                  key={section.id}
                  cmsConfig={{
                    title: section.title,
                    subtitle: section.subtitle ?? undefined,
                    description: section.description ?? undefined,
                    config: section.config ?? {},
                  }}
                />
              );

            /* ===== home-brands: فقط نگهدارندهٔ تنظیمات انتخاب برندهاست — رندر نشود ===== */
            case "home-brands":
              return null;

            /* ===== برندهای معتبر ===== */
            case "brands":
              return (
                <BrandsSection
                  key={section.id}
                  cmsConfig={{
                    title: section.title,
                    subtitle: section.subtitle ?? undefined,
                    description: section.description ?? undefined,
                    config: section.config ?? {},
                  }}
                />
              );

            /* ===== آگهی‌های اخیر ===== */
            case "latest-ads":
              return (
                <LatestAdsSection
                  key={section.id}
                  cmsConfig={{
                    title: section.title,
                    subtitle: section.subtitle ?? undefined,
                    description: section.description ?? undefined,
                    config: section.config ?? {},
                  }}
                />
              );

            /* ===== آخرین اخبار ===== */
            case "latest-news":
              return <LatestNewsSection key={section.id} />;

            /* ===== مرکز دانش ===== */
            case "knowledge":
              return (
                <KnowledgeSection
                  key={section.id}
                  cmsConfig={{
                    title: section.title,
                    subtitle: section.subtitle ?? undefined,
                    description: section.description ?? undefined,
                    config: section.config ?? {},
                  }}
                />
              );

            /* ===== چرا ما ===== */
            case "why-us":
              return (
                <WhyUsSection
                  key={section.id}
                  cmsConfig={{
                    title: section.title,
                    subtitle: section.subtitle ?? undefined,
                    description: section.description ?? undefined,
                    config: section.config ?? {},
                  }}
                />
              );

            /* ===== هدر (رندر نمی‌شود — SiteChrome از /api/header می‌خواند) ===== */
            case "header":
              return null;

            default:
              /* سکشن‌های ناشناخته را بی‌سروصدا رد کن */
              return null;
          }
        })}
    </div>
  );
}