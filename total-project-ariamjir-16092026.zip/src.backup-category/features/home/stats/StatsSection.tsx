import {
  DEFAULT_ITEMS,
  resolveStats,
} from "@/lib/home-stats";

/* ============================================================
   سکشن آمار صفحه اول — اعداد زنده از دیتابیس
============================================================ */

export default async function StatsSection({
  cmsConfig,
}: {
  cmsConfig?: any;
}) {
  const items = (cmsConfig?.config as any)?.items ?? DEFAULT_ITEMS;

  const resolved = await resolveStats(items);

  if (resolved.length === 0) return null;

  return (
    <section className="relative py-16">
      <div className="mx-auto max-w-[1200px] px-6 lg:px-10">
        <div
          className="
            grid
            gap-10
            rounded-3xl
            border
            border-white/10
            bg-gradient-to-l
            from-[#F58220]/10
            via-[#141414]
            to-[#141414]
            p-10
            sm:grid-cols-2
            lg:grid-cols-4
          "
        >
          {resolved.map((s) => (
            <div key={s.title} className="text-center">
              <div className="text-4xl font-black text-[#F58220] lg:text-5xl">
                {s.display}
              </div>
              <div className="mt-3 text-sm text-white/60">{s.title}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}