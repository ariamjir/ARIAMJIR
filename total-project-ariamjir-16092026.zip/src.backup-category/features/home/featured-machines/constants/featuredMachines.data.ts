import type {
  FeaturedMachine,
} from "../types/featuredMachines.types";


export const featuredMachinesMock: FeaturedMachine[] = [
  {
    id: "1",
    title: "لودر معدنی ARIA MJ 958",
    brand: "ARIA MJ",
    model: "958",
    year: 2026,
    condition: "نو",
    price: "تماس بگیرید",
    currency: "IRR",
    location: "ایران",
    image: "/images/machines/loader-958.jpg",
    slug: "aria-mj-958-loader",
  },
  {
    id: "2",
    title: "بیل مکانیکی ARIA MJ 220",
    brand: "ARIA MJ",
    model: "220",
    year: 2026,
    condition: "نو",
    price: "تماس بگیرید",
    currency: "IRR",
    location: "ایران",
    image: "/images/machines/excavator-220.jpg",
    slug: "aria-mj-220-excavator",
  },
];