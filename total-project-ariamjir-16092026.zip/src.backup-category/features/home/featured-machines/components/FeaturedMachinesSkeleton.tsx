import FeaturedMachineCardSkeleton from "./FeaturedMachineCardSkeleton";

export default function FeaturedMachinesSkeleton() {
  return (
    <section
      className="
        mx-auto
        max-w-[1440px]
        px-6
        lg:px-10
        py-28
      "
    >
      <div className="mb-14">

        <div className="h-4 w-40 rounded bg-white/10 animate-pulse" />

        <div className="mt-5 h-12 w-80 rounded bg-white/10 animate-pulse" />

        <div className="mt-4 h-5 w-[520px] rounded bg-white/10 animate-pulse" />

      </div>

      <div
        className="
          grid
          gap-7

          grid-cols-1
          sm:grid-cols-2
          xl:grid-cols-4
        "
      >
        {Array.from({ length: 4 }).map((_, i) => (
          <FeaturedMachineCardSkeleton key={i} />
        ))}
      </div>
    </section>
  );
}