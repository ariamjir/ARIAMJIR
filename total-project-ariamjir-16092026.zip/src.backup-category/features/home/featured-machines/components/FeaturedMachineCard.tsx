"use client";

import Image from "next/image";
import Link from "next/link";

import {
  MapPin,
  Calendar,
  Gauge,
  Tag,
  Star,
} from "lucide-react";

import GlassPanel from "@/components/ui/GlassPanel";
import Button from "@/components/ui/Button";

export interface FeaturedMachineCardProps {
  id: string;
  slug: string;
  title: string;
  brand: string;
  price: string;
  image: string;
  year?: number | null;
  location?: string | null;
  workingHours?: number | null;
}

export default function FeaturedMachineCard({
  slug,
  title,
  brand,
  price,
  image,
  year,
  location,
  workingHours,
}: FeaturedMachineCardProps) {
  return (
    <GlassPanel
      className="
        group
        h-full
        overflow-hidden
        rounded-3xl

        border
        border-white/10

        transition-all
        duration-500

        hover:-translate-y-2
        hover:border-[#F58220]/40
        hover:shadow-[0_20px_60px_rgba(0,0,0,.35)]
      "
    >
      {/* Image */}
      <Link href={`/machines/${slug}`}>
        <div className="relative aspect-[16/10] overflow-hidden">
          <Image
            src={image}
            alt={title}
            fill
            sizes="(max-width:768px) 100vw, (max-width:1280px) 50vw, 25vw"
            className="
              object-cover
              transition-transform
              duration-700
              group-hover:scale-110
            "
          />

          <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />

          <div
            className="
              absolute
              top-4
              right-4

              inline-flex
              items-center
              gap-1

              rounded-full
              bg-[#F58220]

              px-3.5
              py-1.5

              text-xs
              font-bold
              text-white
            "
          >
            <Star className="h-3 w-3 fill-current" />
            ویژه
          </div>
        </div>
      </Link>

      {/* Content — دقیقاً هم‌ساختار با کارت آخرین آگهی‌ها */}
      <div className="p-6">
        <div className="text-sm font-semibold uppercase tracking-wide text-[#F58220]">
          {brand}
        </div>

        <Link href={`/machines/${slug}`}>
          <h3
            className="
              mt-2

              line-clamp-2

              text-xl
              font-bold

              leading-8

              text-white

              transition-colors

              group-hover:text-[#F58220]
            "
          >
            {title}
          </h3>
        </Link>

        {/* Meta — جدول دوستونه مثل آخرین آگهی‌ها */}
        <div
          className="
            mt-5
            grid
            grid-cols-2

            gap-x-4
            gap-y-2

            text-xs
            text-white/55
          "
        >
          <span className="inline-flex items-center gap-1.5 justify-start">
            <MapPin className="h-3.5 w-3.5 text-[#F58220]" />
            {location ?? "-"}
          </span>

          <span className="inline-flex items-center gap-1.5 justify-end">
            {year ?? "-"}
            <Calendar className="h-3.5 w-3.5 text-[#F58220]" />
          </span>

          <span className="inline-flex items-center gap-1.5 justify-start">
            <Gauge className="h-3.5 w-3.5 text-[#F58220]" />
            {workingHours
              ? workingHours.toLocaleString("fa-IR")
              : "-"}
          </span>

          <span className="inline-flex items-center gap-1.5 justify-end">
            {brand}
            <Tag className="h-3.5 w-3.5 text-[#F58220]" />
          </span>
        </div>

        <div className="mt-6">
          <div className="text-xs text-white/50">قیمت</div>
          <div className="mt-1 text-2xl font-black text-[#F58220]">
            {price}
          </div>
        </div>

        {/* ✅ دکمه: جزئیات (نه مشاهده آگهی) */}
        <Link href={`/machines/${slug}`} className="mt-7 block">
          <Button className="w-full">مشاهده جزئیات</Button>
        </Link>
      </div>
    </GlassPanel>
  );
}