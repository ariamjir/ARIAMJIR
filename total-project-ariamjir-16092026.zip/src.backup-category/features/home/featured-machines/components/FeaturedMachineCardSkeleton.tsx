export default function FeaturedMachineCardSkeleton() {
  return (
    <div
      className="
        overflow-hidden
        rounded-3xl
        border
        border-white/10
        bg-white/[0.03]
        animate-pulse
      "
    >
      {/* Image */}

      <div className="aspect-[16/10] bg-white/10" />

      {/* Content */}

      <div className="p-6">

        <div className="h-4 w-24 rounded bg-white/10" />

        <div className="mt-4 h-8 rounded bg-white/10" />

        <div className="mt-6 grid grid-cols-2 gap-3">
          <div className="h-4 rounded bg-white/10" />
          <div className="h-4 rounded bg-white/10" />
          <div className="h-4 rounded bg-white/10" />
          <div className="h-4 rounded bg-white/10" />
        </div>

        <div className="mt-7 h-7 w-40 rounded bg-white/10" />

        <div className="mt-8 h-12 rounded-xl bg-white/10" />

      </div>
    </div>
  );
}