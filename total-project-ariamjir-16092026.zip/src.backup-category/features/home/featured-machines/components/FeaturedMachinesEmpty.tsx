import Link from "next/link";

export default function FeaturedMachinesEmpty() {
  return (
    <div
      className="
        rounded-3xl
        border
        border-dashed
        border-white/10
        bg-white/[0.03]
        py-24
        text-center
      "
    >
      <div className="text-6xl">🚜</div>

      <h3 className="mt-6 text-3xl font-bold text-white">
        هنوز ماشین ویژه‌ای ثبت نشده است
      </h3>

      <p className="mt-4 text-white/60">
        اولین آگهی ویژه به‌زودی در این بخش نمایش داده خواهد شد.
      </p>

      <Link
        href="/machines"
        className="
          mt-8
          inline-flex
          h-12
          items-center
          rounded-xl
          bg-[#F58220]
          px-8
          font-bold
          text-white
          transition
          hover:bg-[#dd6f18]
        "
      >
        مشاهده همه ماشین‌آلات
      </Link>
    </div>
  );
}