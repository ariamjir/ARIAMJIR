import Link from "next/link";

import { getFeaturedMachines } from "@/lib/services/machine.service";

import SectionTitle from "@/components/ui/SectionTitle";

import FeaturedMachinesCarousel from "./FeaturedMachinesCarousel";
import FeaturedMachinesEmpty from "./components/FeaturedMachinesEmpty";

import type {
  FeaturedMachineCardProps,
} from "./components/FeaturedMachineCard";


interface CmsConfig {
  title?: string;
  subtitle?: string;
  description?: string;
  config?: {
    limit?: number;
    [key: string]: any;
  };
}


interface Props {
  cmsConfig?: CmsConfig;
}


export default async function FeaturedMachinesSection({
  cmsConfig,
}: Props) {


  const title =
    cmsConfig?.title ||
    "ماشین‌آلات تأییدشدهٔ آریا";


  const subtitle =
    cmsConfig?.subtitle ||
    "ARIA VERIFIED MACHINES";


  const description =
    cmsConfig?.description ||
    "دستگاه‌های کارشناسی‌شده، ارزش‌گذاری‌شده و تضمینی از مسیر فروش ویژهٔ ARIA MJ.";


  const limit =
    cmsConfig?.config?.limit ?? 8;


  const machines =
    await getFeaturedMachines(limit);



  const items: FeaturedMachineCardProps[] =
    machines.map((machine) => ({
      id: machine.id,
      slug: machine.slug,

      title: machine.title,

      brand:
        machine.brand?.name ??
        "بدون برند",

      image:
        machine.images?.[0]?.url ??
        "/images/machines/default.jpg",


      price:
        machine.price?.price
          ? `${Number(
              machine.price.price
            ).toLocaleString("fa-IR")} تومان`
          : "تماس بگیرید",


      year:
        machine.specification?.manufactureYear,


      location:
        machine.specification?.location,


      workingHours:
        machine.specification?.workingHours,
    }));



  if (machines.length === 0) {
    return (
      <FeaturedMachinesEmpty />
    );
  }



  return (
    <section
      className="
        relative
        overflow-hidden
        py-24
      "
    >

      <div
        className="
          mx-auto
          max-w-[1600px]
          px-8
        "
      >

        {/* ✅ هدر وسط‌چین — بدون دکمه */}
        <SectionTitle
          align="center"
          subtitle={subtitle}
          title={title}
          description={description}
        />


        {/* کاروسل (افکت فعلی حفظ شد) */}
        <FeaturedMachinesCarousel
          items={items}
        />


        {/* ✅ قانون جدید: «مشاهده همه» بعد از کارت‌ها */}
        <div
          className="
            mt-10
            flex
            justify-center
          "
        >
          <Link
            href="/machines"
            className="
              inline-flex
              h-12
              items-center
              justify-center
              rounded-xl
              border
              border-white/10
              bg-white/5
              px-8
              text-white
              transition-all
              duration-300
              hover:border-[#F58220]/30
              hover:bg-white/10
            "
          >
            مشاهده همه
          </Link>
        </div>

      </div>

    </section>
  );
}