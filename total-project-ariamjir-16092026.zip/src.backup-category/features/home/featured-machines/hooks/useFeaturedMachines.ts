"use client";

import {
  useMemo,
} from "react";

import {
  featuredMachinesMock,
} from "../constants/featuredMachines.data";


export function useFeaturedMachines(
  items?: any[]
) {

  return useMemo(() => {

    if (items?.length) {
      return items;
    }


    return featuredMachinesMock;

  }, [items]);

}