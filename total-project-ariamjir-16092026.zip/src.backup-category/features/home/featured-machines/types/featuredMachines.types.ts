export interface FeaturedMachine {
  id: string;
  title: string;
  brand: string;
  model: string;
  year?: number;
  condition?: string;
  price?: string;
  currency?: string;
  location?: string;
  image?: string;
  slug?: string;
}


export interface FeaturedMachinesResponse {
  items: FeaturedMachine[];
  total: number;
}