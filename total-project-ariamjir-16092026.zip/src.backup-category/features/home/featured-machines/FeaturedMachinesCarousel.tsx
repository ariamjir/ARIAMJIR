"use client";

import {
  useCallback,
  useEffect,
  useRef,
  useState,
} from "react";

import {
  ChevronLeft,
  ChevronRight,
} from "lucide-react";

import FeaturedMachineCard from "./components/FeaturedMachineCard";

import type {
  FeaturedMachineCardProps,
} from "./components/FeaturedMachineCard";


interface FeaturedMachinesCarouselProps {
  items: FeaturedMachineCardProps[];
}


export default function FeaturedMachinesCarousel({
  items,
}: FeaturedMachinesCarouselProps) {

  const n = items.length;


  const [active, setActive] = useState(0);
  const [paused, setPaused] = useState(false);


  const reducedRef = useRef(false);

  const touchXRef =
    useRef<number | null>(null);



  useEffect(() => {

    const mq = window.matchMedia(
      "(prefers-reduced-motion: reduce)"
    );


    reducedRef.current = mq.matches;


    const onChange = () => {
      reducedRef.current = mq.matches;
    };


    mq.addEventListener(
      "change",
      onChange
    );


    return () =>
      mq.removeEventListener(
        "change",
        onChange
      );

  }, []);




  const go = useCallback(
    (dir: number) => {

      if (n === 0) return;


      setActive(
        (prev) =>
          (prev + dir + n) % n
      );

    },
    [n]
  );




  useEffect(() => {

    if (
      n <= 1 ||
      paused ||
      reducedRef.current
    ) {
      return;
    }


    const timer =
      setInterval(() => {

        setActive(
          (prev) =>
            (prev + 1) % n
        );

      }, 4200);


    return () =>
      clearInterval(timer);

  }, [
    n,
    paused,
  ]);




  if (n === 0) {
    return null;
  }




  const half =
    Math.floor(n / 2);



  const styleFor = (
    i: number
  ) => {


    let offset =
      i - active;


    if (offset > half)
      offset -= n;


    if (offset < -half)
      offset += n;



    const abs =
      Math.abs(offset);



    /* ✅ حالت تلویزیون بزرگ */
    const translateX =
      offset * 500;


    const translateZ =
      -abs * 280;


    const rotateY =
      offset * -38;


    const scale =
      Math.max(
        0.75,
        1.3 - abs * 0.18
      );


    const opacity =
      Math.max(
        0,
        1 - abs * 0.32
      );


    const blur =
      abs > 1
        ? Math.min(
            (abs - 1) * 2.2,
            6
          )
        : 0;


    const brightness =
      Math.max(
        0.5,
        1 - abs * 0.18
      );



    return {
      transform:
        `translate(-50%, -50%) 
        translateX(${translateX}px)
        translateZ(${translateZ}px)
        rotateY(${rotateY}deg)
        scale(${scale})`,

      opacity,

      filter:
        `${
          blur > 0
            ? `blur(${blur.toFixed(1)}px) `
            : ""
        }brightness(${brightness.toFixed(2)})`,

      zIndex:
        100 - abs,


      pointerEvents:
        offset === 0
          ? ("auto" as const)
          : ("none" as const),
    };

  };





  const onTouchStart = (
    e: React.TouchEvent
  ) => {

    touchXRef.current =
      e.touches[0].clientX;

  };




  const onTouchEnd = (
    e: React.TouchEvent
  ) => {


    if (
      touchXRef.current == null
    ) {
      return;
    }


    const dx =
      e.changedTouches[0].clientX -
      touchXRef.current;



    if (
      Math.abs(dx) > 50
    ) {

      go(
        dx < 0
          ? 1
          : -1
      );

    }

    touchXRef.current = null;

  };





  return (
    <div>


      {/* Desktop Coverflow */}

      <div
        className="
          relative
          hidden
          md:block
        "
        onMouseEnter={() =>
          setPaused(true)
        }
        onMouseLeave={() =>
          setPaused(false)
        }
        onFocusCapture={() =>
          setPaused(true)
        }
        onBlurCapture={() =>
          setPaused(false)
        }
        onTouchStart={onTouchStart}
        onTouchEnd={onTouchEnd}
      >


        <div
          className="
            relative
            mx-auto
            h-[840px]
            w-full
            max-w-[2200px]
          "
          style={{
            perspective:
              "2200px",
          }}
        >


          <div
            className="
              absolute
              inset-0
            "
            style={{
              transformStyle:
                "preserve-3d",
            }}
          >


            {items.map(
              (item, i) => (

                <div
                  key={item.id}
                  className="
                    absolute
                    left-1/2
                    top-1/2
                    w-[300px]
                    md:w-[420px]
                  "
                  style={
                    styleFor(i)
                  }
                >

                  <FeaturedMachineCard
                    {...item}
                  />

                </div>

              )
            )}



            {n > 1 && (
              <>


                <button
                  type="button"
                  aria-label="قبلی"
                  onClick={() =>
                    go(-1)
                  }
                  className="
                    absolute
                    left-2
                    top-1/2
                    z-[200]
                    flex
                    h-12
                    w-12
                    -translate-y-1/2
                    items-center
                    justify-center
                    rounded-full
                    border
                    border-white/15
                    bg-black/40
                    text-white
                    backdrop-blur
                    transition
                    hover:bg-[#F58220]
                  "
                >

                  <ChevronLeft
                    className="h-5 w-5"
                  />

                </button>



                <button
                  type="button"
                  aria-label="بعدی"
                  onClick={() =>
                    go(1)
                  }
                  className="
                    absolute
                    right-2
                    top-1/2
                    z-[200]
                    flex
                    h-12
                    w-12
                    -translate-y-1/2
                    items-center
                    justify-center
                    rounded-full
                    border
                    border-white/15
                    bg-black/40
                    text-white
                    backdrop-blur
                    transition
                    hover:bg-[#F58220]
                  "
                >

                  <ChevronRight
                    className="h-5 w-5"
                  />

                </button>


              </>
            )}


          </div>

        </div>


      </div>





      {/* Mobile */}

      <div
        className="
          flex
          gap-4
          overflow-x-auto
          pb-4
          snap-x
          snap-mandatory
          md:hidden
          [scrollbar-width:none]
          [&::-webkit-scrollbar]:hidden
        "
      >

        {items.map(
          (item) => (

            <div
              key={item.id}
              className="
                w-[82%]
                shrink-0
                snap-center
                sm:w-[46%]
              "
            >

              <FeaturedMachineCard
                {...item}
              />

            </div>

          )
        )}

      </div>





      {/* Dots */}

      {n > 1 && (

        <div
          className="
            mt-8
            flex
            justify-center
            gap-2
          "
        >

          {items.map(
            (item, i) => (

              <button
                key={item.id}
                type="button"
                aria-label={`رفتن به مورد ${i + 1}`}
                onClick={() =>
                  setActive(i)
                }
                className={`
                  h-2
                  rounded-full
                  transition-all
                  ${
                    i === active
                      ? "w-7 bg-[#F58220]"
                      : "w-2 bg-white/25"
                  }
                `}
              />

            )
          )}

        </div>

      )}


    </div>
  );
}