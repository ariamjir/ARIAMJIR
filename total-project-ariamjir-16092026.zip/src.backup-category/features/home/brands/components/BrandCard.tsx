"use client";

import type { Brand } from "@/modules/brand";

interface BrandCardProps {
  brand: Brand;
}

export default function BrandCard({ brand }: BrandCardProps) {
  const logo =
    typeof brand.logo === "string" && brand.logo.trim().length > 0
      ? brand.logo
      : typeof brand.image === "string" && brand.image.trim().length > 0
        ? brand.image
        : null;

  const fallback =
    typeof brand.icon === "string" && brand.icon.trim().length > 0
      ? brand.icon
      : brand.name?.charAt(0) || "B";

  return (
    <div
      className="
        group
        flex
        h-[120px]
        w-[220px]
        shrink-0
        items-center
        justify-center
        rounded-[28px]
        border
        border-white/10
        bg-black/35
        backdrop-blur-2xl
        transition-all
        duration-500
        hover:-translate-y-1
        hover:border-[#F58220]/60
        hover:bg-black/55
        hover:shadow-[0_0_45px_rgba(245,130,32,.25)]
      "
    >
      <div className="flex flex-col items-center justify-center gap-3">
        {logo ? (
          <img
            src={logo}
            alt={brand.name}
            className="
              h-[42px]
              w-auto
              max-w-[150px]
              object-contain
              transition-transform
              duration-500
              group-hover:scale-110
            "
          />
        ) : (
          <span
            className="
              flex
              h-[42px]
              w-[42px]
              items-center
              justify-center
              rounded-xl
              bg-white/5
              text-2xl
              text-white
            "
          >
            {fallback}
          </span>
        )}

        <span
          className="
            text-[15px]
            font-semibold
            tracking-wide
            text-white
            transition-colors
            duration-300
            group-hover:text-[#F58220]
          "
        >
          {brand.name}
        </span>
      </div>
    </div>
  );
}