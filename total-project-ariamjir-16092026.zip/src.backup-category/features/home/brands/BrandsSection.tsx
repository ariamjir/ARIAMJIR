import Link from "next/link";

import { prisma } from "@/lib/prisma";

import JsonLd from "@/components/seo/JsonLd";

import BrandTicker from "@/components/ui/BrandTicker";

import { SITE_URL } from "@/lib/seo";

/* ============================================================
   برندهای معتبر — نوار پیوسته با تیکر پله‌ای پایدار
   ✅ متن قدیمی ذخیره‌شده در CMS خودکار با متن جدید جایگزین می‌شود
============================================================ */

const NEW_DESC =
  "بزرگ‌ترین برندهای سازندهٔ قطعات، تجهیزات و ماشین‌آلات سنگین جهان";

export async function BrandsSection({
  cmsConfig,
}: {
  cmsConfig?: any;
}) {
  const [brands, row] = await Promise.all([
    prisma.brand.findMany({
      orderBy: { name: "asc" },
      include: { _count: { select: { machines: true } } },
    }),
    prisma.homePageSection.findFirst({ where: { key: "home-brands" } }),
  ]);

  const ids: string[] = (row?.config as any)?.ids ?? [];
  const byId = new Map(brands.map((b: any) => [b.id, b]));
  const picked = ids.map((id) => byId.get(id)).filter(Boolean) as any[];
  const list = picked.length ? picked : (brands.slice(0, 20) as any[]);

  if (list.length === 0) return null;

  const title = cmsConfig?.title ?? "برندهای معتبر";

  /* ✅ اگر توضیحات CMS خالی بود یا همان متن قدیمی بود → متن جدید */
  const rawDesc: string = cmsConfig?.description ?? "";
  const description =
    !rawDesc.trim() || rawDesc.includes("سازنده ماشین‌آلات")
      ? NEW_DESC
      : rawDesc;

  return (
    <section className="relative py-20" aria-label={title}>
      {/* سئوی ساختاریافته */}
      <JsonLd
        data={{
          "@context": "https://schema.org",
          "@type": "ItemList",
          name: title,
          itemListElement: list.map((b, i) => ({
            "@type": "ListItem",
            position: i + 1,
            item: {
              "@type": "Brand",
              name: b.name,
              url: `${SITE_URL}/brands/${b.slug}`,
            },
          })),
        }}
      />

      {/* ✅ سربرگ کاملاً وسط‌چین */}
      <div className="mx-auto flex max-w-[1440px] flex-col items-center px-6 text-center lg:px-10">
        <div className="text-xs font-black tracking-[0.3em] text-[#F58220]">TOP BRANDS</div>
        <h2 className="mt-3 text-center text-3xl font-black text-white lg:text-4xl">{title}</h2>
        <p className="mt-3 max-w-2xl text-center text-sm leading-7 text-white/45">
          {description}
        </p>
      </div>

      {/* نوار پیوستهٔ برندها */}
      <div className="mt-10">
        <BrandTicker brands={list} />
      </div>

      {/* دکمهٔ وسط‌چین */}
      <div className="mt-10 flex justify-center">
        <Link
          href="/brands"
          className="inline-flex h-12 items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-8 text-sm font-bold text-white transition-all duration-300 hover:border-[#F58220]/40 hover:bg-[#F58220]/10 hover:text-[#F58220]"
        >
          همهٔ برندها ({brands.length.toLocaleString("fa-IR")})
        </Link>
      </div>
    </section>
  );
}

export default BrandsSection;