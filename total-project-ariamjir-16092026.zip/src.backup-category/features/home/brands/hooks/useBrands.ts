"use client";

import { useMemo } from "react";

import { brands } from "@/data/brands";

export default function useBrands() {
  const featuredBrands = useMemo(() => {
    return brands.filter((brand) => brand.featured);
  }, []);

  return {
    brands: featuredBrands,
  };
}