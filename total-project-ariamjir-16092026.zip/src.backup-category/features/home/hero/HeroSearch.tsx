"use client";

import { useEffect, useState } from "react";

import { useRouter } from "next/navigation";

import { Search, Wrench, ChevronLeft } from "lucide-react";

import { useCategories } from "@/modules/category";

import { mergeHeroConfig } from "@/lib/hero-config";

import LoaderRig from "@/components/industrial/LoaderRig";
import GraderRig from "@/components/industrial/GraderRig";
import RollerRig from "@/components/industrial/RollerRig";

/* ============================================================
   کنسول استعلام صنعتی — سرچ هیرو
   ✅ برندها و دسته‌ها از دیتابیس (کشویی)
   ✅ پارامترها هم‌نام با searchParams.ts + صفحهٔ ماشین‌آلات
   ✅ کاروان راه‌سازی (لودر ← گرایدر ← غلطک) + نوار نقاله
   ✅ حفاری لودر هنگام تایپ · توقف کاروان با hover
============================================================ */

const PRICE_RANGES: { label: string; min?: number; max?: number }[] = [
  { label: "محدودهٔ قیمت" },
  { label: "تا ۵ میلیارد", max: 5000000000 },
  { label: "۵ تا ۱۰ میلیارد", min: 5000000000, max: 10000000000 },
  { label: "۱۰ تا ۲۵ میلیارد", min: 10000000000, max: 25000000000 },
  { label: "بالای ۲۵ میلیارد", min: 25000000000 },
];

const GAUGE =
  "h-12 w-full rounded-lg border border-white/10 bg-black/50 px-3 text-xs text-white outline-none transition focus:border-[#F58220] focus:shadow-[0_0_0_3px_rgba(245,130,32,.15)] placeholder:text-white/25";

const LABEL =
  "mb-1.5 block text-[9px] font-black uppercase tracking-[0.25em] text-white/40";

export default function HeroSearch({
  hero,
}: {
  hero: any;
}) {
  const cfg = mergeHeroConfig(hero?.config);
  const s = cfg.search;

  const router = useRouter();
  const { categories }: any = useCategories();

  const [q, setQ] = useState("");
  const [cat, setCat] = useState("");
  const [brand, setBrand] = useState("");
  const [yearFrom, setYearFrom] = useState("");
  const [yearTo, setYearTo] = useState("");
  const [price, setPrice] = useState("");

  /* ✅ هنگام تایپ، باکت لودر حفاری می‌کند */
  const [typing, setTyping] = useState(false);

  /* ✅ برندهای واقعی پروژه */
  const [brands, setBrands] = useState<any[]>([]);

  const [liveCount, setLiveCount] = useState("");

  useEffect(() => {
    fetch("/api/brands/list")
      .then((r) => r.json())
      .then((j) => {
        if (j.success) setBrands(j.data ?? []);
      })
      .catch(() => {});

    fetch("/api/stats")
      .then((r) => r.json())
      .then((j) => {
        if (j.success && j.data?.[0]) setLiveCount(j.data[0].display);
      })
      .catch(() => {});
  }, []);

  if (!s.visible) return null;

  const list: any[] = categories ?? [];
  const roots = list.filter((c: any) => !c.parentId);

  const submit = (e: any) => {
    e.preventDefault();

    const params = new URLSearchParams();

    /* متن آزاد — هر دو قرارداد */
    if (q.trim()) {
      params.set("q", q.trim());
      params.set("search", q.trim());
    }

    /* دسته — هر دو قرارداد */
    if (cat) {
      params.set("categories", cat);
      params.set("category", cat);
    }

    /* برند — هر دو قرارداد */
    if (brand) {
      params.set("brands", brand);
      params.set("brand", brand);
    }

    if (yearFrom) params.set("yearFrom", yearFrom);
    if (yearTo) params.set("yearTo", yearTo);

    if (price) {
      const r = PRICE_RANGES.find((p) => p.label === price);
      if (r) {
        if (r.min !== undefined) params.set("minPrice", String(r.min));
        if (r.max !== undefined) params.set("maxPrice", String(r.max));
      }
    }

    router.push(`/machines?${params.toString()}`);
  };

  return (
    <div className="relative z-20 -mt-10 flex justify-center px-4 lg:-mt-14">
      <form
        onSubmit={submit}
        aria-label="جستجوی ماشین‌آلات"
        className="
          relative
          w-full
          max-w-[1240px]
          overflow-hidden
          border
          border-white/10
          bg-gradient-to-b
          from-[#1c1c1c]
          to-[#0e0e0e]
          shadow-[0_40px_100px_-30px_rgba(0,0,0,1)]
          [clip-path:polygon(0_0,calc(100%-28px)_0,100%_28px,100%_100%,28px_100%,0_calc(100%-28px))]
        "
      >
        {/* نوار هشدار صنعتی */}
        <div className="h-2 w-full bg-[repeating-linear-gradient(-45deg,#F58220_0_14px,#141414_14px_28px)]" />

        {/* واترماک آچار */}
        <Wrench className="pointer-events-none absolute -left-8 -bottom-10 h-44 w-44 rotate-12 text-white/[0.03]" />

        {/* پیچ‌های گوشه */}
        <span className="absolute right-3 top-5 h-1.5 w-1.5 rounded-full bg-white/20" />
        <span className="absolute left-3 top-5 h-1.5 w-1.5 rounded-full bg-white/20" />
        <span className="absolute bottom-3 right-3 h-1.5 w-1.5 rounded-full bg-white/20" />
        <span className="absolute bottom-3 left-3 h-1.5 w-1.5 rounded-full bg-white/20" />

        <div className="p-5 lg:p-6">
          {/* سربرگ کنسول */}
          <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
            <div>
              <div className="text-base font-black tracking-wide text-white lg:text-lg">
                {s.title}
              </div>
              <div className="mt-1 text-[10px] text-white/40">{s.subtitle}</div>
            </div>

            <div className="flex items-center gap-1.5">
              <span className="h-2 w-2 animate-pulse rounded-full bg-green-500" />
              <span className="h-2 w-2 rounded-full bg-[#F58220]" />
              <span className="h-2 w-2 rounded-full bg-red-500/60" />
              <span className="mr-2 text-[9px] font-black tracking-[0.2em] text-white/40">
                سامانهٔ استعلام آنلاین
                {liveCount && (
                  <span className="mr-2 text-[#F58220]">
                    {liveCount} دستگاه فعال
                  </span>
                )}
              </span>
            </div>
          </div>

          {/* گیج‌های ورودی */}
          <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-7">
            {/* جستجوی آزاد */}
            <div className="lg:col-span-2">
              <span className={LABEL}>جستجوی آزاد</span>
              <div className="relative">
                <Search className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[#F58220]/60" />
                <input
                  value={q}
                  onChange={(e) => setQ(e.target.value)}
                  onFocus={() => setTyping(true)}
                  onBlur={() => setTyping(false)}
                  placeholder="مدل، توضیحات یا برند... مثلاً PC220"
                  autoComplete="off"
                  className={`${GAUGE} pr-9`}
                />
              </div>
            </div>

            {/* کشوی دسته‌ها */}
            <div>
              <span className={LABEL}>دسته‌بندی</span>
              <select
                value={cat}
                onChange={(e) => setCat(e.target.value)}
                className={GAUGE}
              >
                <option value="">همه</option>
                {roots.map((r: any) => {
                  const kids = list.filter((c: any) => c.parentId === r.id);
                  return kids.length > 0 ? (
                    <optgroup key={r.id} label={r.name}>
                      {kids.map((k: any) => (
                        <option key={k.id} value={k.slug}>
                          {k.name}
                        </option>
                      ))}
                    </optgroup>
                  ) : (
                    <option key={r.id} value={r.slug}>
                      {r.name}
                    </option>
                  );
                })}
              </select>
            </div>

            {/* کشوی برندهای واقعی پروژه */}
            <div>
              <span className={LABEL}>برند</span>
              <select
                value={brand}
                onChange={(e) => setBrand(e.target.value)}
                className={GAUGE}
              >
                <option value="">همه</option>
                {brands.map((b: any) => (
                  <option key={b.id} value={b.slug}>
                    {b.name}
                  </option>
                ))}
              </select>
            </div>

            {/* سال ساخت */}
            <div>
              <span className={LABEL}>سال ساخت</span>
              <div className="flex gap-1">
                <input
                  value={yearFrom}
                  onChange={(e) => setYearFrom(e.target.value)}
                  placeholder="از"
                  dir="ltr"
                  autoComplete="off"
                  className={GAUGE}
                />
                <input
                  value={yearTo}
                  onChange={(e) => setYearTo(e.target.value)}
                  placeholder="تا"
                  dir="ltr"
                  autoComplete="off"
                  className={GAUGE}
                />
              </div>
            </div>

            {/* قیمت */}
            <div>
              <span className={LABEL}>قیمت</span>
              <select
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                className={GAUGE}
              >
                {PRICE_RANGES.map((p) => (
                  <option key={p.label} value={p.label}>
                    {p.label}
                  </option>
                ))}
              </select>
            </div>

            {/* دکمهٔ جستجو */}
            <div className="flex items-end">
              <button
                type="submit"
                className="
                  inline-flex
                  h-12
                  w-full
                  items-center
                  justify-center
                  gap-2
                  bg-[#F58220]
                  text-sm
                  font-black
                  text-white
                  shadow-[0_15px_40px_-12px_rgba(245,130,32,.7)]
                  transition
                  hover:bg-orange-600
                  [clip-path:polygon(0_0,calc(100%-12px)_0,100%_12px,100%_100%,12px_100%,0_calc(100%-12px))]
                "
              >
                <Search className="h-4 w-4" />
                {s.buttonText}
              </button>
            </div>
          </div>

          {/* نوار نقالهٔ متحرک */}
          <div className="conveyor mt-5" />

          {/* لینک‌های سریع */}
          {s.quickLinks.length > 0 && (
            <div className="mt-4 flex flex-wrap items-center gap-2">
              <span className="text-[9px] font-black tracking-[0.2em] text-white/35">
                استعلام سریع:
              </span>
              {s.quickLinks.map((l: any) => (
                <a
                  key={l.label}
                  href={l.href}
                  className="
                    inline-flex
                    items-center
                    gap-1
                    rounded-sm
                    border
                    border-white/10
                    bg-white/[0.03]
                    px-3
                    py-1.5
                    text-[10px]
                    font-bold
                    text-white/55
                    transition
                    hover:border-[#F58220]/60
                    hover:bg-[#F58220]/10
                    hover:text-[#F58220]
                  "
                >
                  {l.label}
                  <ChevronLeft className="h-3 w-3" />
                </a>
              ))}
            </div>
          )}

          {/* ✅ کاروان راه‌سازی: لودر ← گرایدر ← غلطک (توقف با hover) */}
          <div className="group pointer-events-none relative mt-4 h-28 overflow-hidden">
            <div className="absolute inset-x-0 bottom-4 border-t border-dashed border-white/10" />
                        <div className="rig-track group-hover:[animation-play-state:paused]">
              <div dir="ltr" className="flex items-end gap-12">
                <LoaderRig active={typing} />
                <GraderRig />
                <RollerRig />
              </div>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
}