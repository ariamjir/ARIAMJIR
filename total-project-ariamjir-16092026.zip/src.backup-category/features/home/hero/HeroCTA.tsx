"use client";


/* ============================================================
   ARIA MJ — HERO CTA
============================================================ */


import Link from "next/link";


import type {
  Hero,
} from "@/modules/home";



interface Props {

  hero: Hero;

}



export default function HeroCTA({
  hero,
}: Props) {


  return (

    <div

      className="
        flex
        flex-wrap
        gap-4
      "

      dir="rtl"

    >



      {hero.buttonText && hero.buttonLink && (

        <Link

          href={hero.buttonLink}

          className="
            rounded-xl

            bg-[#F47C20]

            px-6

            py-3

            text-sm

            font-bold

            text-white

            transition

            hover:bg-[#ff8c38]
          "

        >

          {hero.buttonText}


        </Link>

      )}






      {hero.secondButtonText && hero.secondButtonLink && (

        <Link

          href={hero.secondButtonLink}

          className="
            rounded-xl

            border

            border-white/20

            bg-white/5

            px-6

            py-3

            text-sm

            font-bold

            text-white

            backdrop-blur

            transition

            hover:bg-white/10
          "

        >

          {hero.secondButtonText}


        </Link>

      )}



    </div>

  );

}