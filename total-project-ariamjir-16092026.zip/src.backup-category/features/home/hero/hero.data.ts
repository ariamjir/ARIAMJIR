import type { Hero } from "@/modules/home";

import {
  mergeHeroConfig,
  CARD_SIZES,
} from "@/lib/hero-config";

import type {
  HeroCardData,
} from "./hero.types";

export const CARD_BASE =
  "group relative block shrink-0 overflow-hidden rounded-2xl border border-[#F58220]/35 bg-[#141414] shadow-[0_25px_60px_-18px_rgba(0,0,0,.95)] transition-all duration-500 hover:border-[#F58220]/70";

export function getHeroImages(hero: Hero): string[] {
  const imgs = (hero.slides ?? [])
    .filter((s: any) => s.active !== false)
    .map((s: any) => s.image)
    .filter(Boolean);

  return imgs.length ? imgs : ["/images/hero/hero-bg.webp"];
}

export function getHeroBackground(hero: Hero): string {
  return getHeroImages(hero)[0];
}

export function buildHeroCards(hero: Hero): HeroCardData[] {
  const cfg = mergeHeroConfig((hero as any).config);
  const sz = CARD_SIZES[cfg.cards.size] ?? CARD_SIZES.md;
  const items = cfg.cards.items ?? {};
  const o = (k: string) => items[k] ?? {};
  const slides = hero.slides ?? [];
  const tilt = cfg.cards.tilt;

  /* ✅ سایز پیکسلی سفارشی */
  const custom = cfg.cards.sizeMode === "custom";
  const sideStyle = custom
    ? { width: cfg.cards.custom.sideW, height: cfg.cards.custom.sideH }
    : undefined;
  const midStyle = custom
    ? { width: cfg.cards.custom.midW, height: cfg.cards.custom.midH }
    : undefined;

  const cards: HeroCardData[] = [
    {
      key: "services",
      tag: o("services").tag ?? "SERVICES",
      title: o("services").title ?? "خدمات",
      fa: o("services").title ?? "خدمات",
      desc:
        o("services").desc ??
        "هر آنچه برای ماشین‌آلات سنگین نیاز دارید.",
      href: o("services").href ?? "/services",
      img: o("services").img || slides[2]?.image,
      active: o("services").active !== false,
      cls: `${sz.side} ${tilt ? "lg:-rotate-2 lg:translate-y-2" : ""}`,
      style: sideStyle,
    },
    {
      key: "featured",
      tag: o("featured").tag ?? "FEATURED",
      title: o("featured").title ?? "آگهی ویژه",
      fa: o("featured").title ?? "آگهی ویژه",
      desc:
        o("featured").desc ??
        "ویژه‌ترین ماشین‌آلات منتخب آریا MJ",
      href: o("featured").href ?? "/machines?featured=true",
      img: o("featured").img || slides[1]?.image,
      active: o("featured").active !== false,
      cls: `z-10 ${sz.mid} ${tilt ? "lg:scale-[1.04]" : ""}`,
      style: midStyle,
    },
    {
      key: "exclusive",
      tag: o("exclusive").tag ?? "EXCLUSIVE",
      title: o("exclusive").title ?? hero.title,
      fa: o("exclusive").title ?? hero.badge ?? "ARIA MJ",
      desc: o("exclusive").desc ?? hero.description ?? "",
      href: o("exclusive").href ?? hero.buttonLink ?? "/machines",
      img: o("exclusive").img || slides[0]?.image,
      active: o("exclusive").active !== false,
      cls: `${sz.side} ${tilt ? "lg:rotate-2 lg:translate-y-2" : ""}`,
      style: sideStyle,
    },
  ];

  return cards.filter((c) => c.active !== false);
}