import type { CSSProperties } from "react";

import type { Hero } from "@/modules/home";

export interface HeroProps {
  hero: Hero;
}

export interface HeroCardData {
  key: string;
  tag: string;
  title: string;
  fa: string;
  desc: string;
  href: string;
  img?: string;
  cls: string;
  style?: CSSProperties;
  active?: boolean;
}