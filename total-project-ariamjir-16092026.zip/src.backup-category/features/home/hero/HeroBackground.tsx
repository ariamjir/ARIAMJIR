"use client";

import { useEffect, useState } from "react";

import Image from "next/image";

interface Props {
  images: string[];
  mode: "single" | "slider";
  interval: number;
  zoom: boolean;
  overlay: number;
}

export default function HeroBackground({
  images,
  mode,
  interval,
  zoom,
  overlay,
}: Props) {
  const [idx, setIdx] = useState(0);

  const list = images.length ? images : ["/images/hero/hero-bg.webp"];

  /* اسلایدر پس‌زمینه */
  useEffect(() => {
    if (mode !== "slider" || list.length < 2) return;

    const t = setInterval(
      () => setIdx((i) => (i + 1) % list.length),
      Math.max(2, interval) * 1000
    );

    return () => clearInterval(t);
  }, [mode, interval, list.length]);

  return (
    <>
      {/* تصویر / اسلایدر */}
      <div className="absolute inset-0 -z-20">
        {mode === "slider" && list.length > 1 ? (
          list.map((src, i) => (
            <div
              key={src + i}
              className={`absolute inset-0 transition-opacity duration-1000 ${
                i === idx ? "opacity-100" : "opacity-0"
              }`}
            >
              <Image
                src={src}
                alt=""
                fill
                priority={i === 0}
                sizes="100vw"
                className={`object-cover ${zoom ? "hero-image" : ""}`}
                style={{ opacity: overlay / 100 }}
              />
            </div>
          ))
        ) : (
          <Image
            src={list[0]}
            alt="ARIA MJ machinery"
            fill
            priority
            sizes="100vw"
            className={`object-cover ${zoom ? "hero-image" : ""}`}
            style={{ opacity: overlay / 100 }}
          />
        )}
      </div>

      {/* Overlay گرادیان */}
      <div
        className="
          absolute
          inset-0
          -z-10
          bg-gradient-to-r
          from-[#111111]
          via-[#111111]/90
          to-transparent
        "
      />
    </>
  );
}