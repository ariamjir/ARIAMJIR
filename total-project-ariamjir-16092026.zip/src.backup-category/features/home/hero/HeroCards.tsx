"use client";


/* ============================================================
   ARIA MJ — HERO CARDS
============================================================ */


import Image from "next/image";

import Link from "next/link";


import {
  buildHeroCards,
  CARD_BASE,
} from "./hero.data";


import type {
  HeroProps,
} from "./hero.types";




export default function HeroCards({
  hero,
}: HeroProps) {



  const cards =
    buildHeroCards(hero);




  return (

    <div

      className="
        flex

        items-center

        justify-center

        gap-4

      "

      dir="rtl"

    >


      {cards.map((card) => (


        <Link

          key={card.key}

          href={card.href}

                    className={`
            ${CARD_BASE}

            ${card.cls}
          `}

          style={card.style}
        >



          {card.img && (

            <Image

              src={card.img}

              alt={card.title}

              fill

              sizes="
                (max-width:768px) 50vw,
                280px
              "

              className="
                object-cover

                transition-transform

                duration-700

                group-hover:scale-105
              "

            />

          )}





          {/* Overlay */}

          <div

            className="
              absolute

              inset-0

              bg-gradient-to-t

              from-black/90

              via-black/30

              to-transparent
            "

          />






          {/* Content */}

          <div

            className="
              absolute

              bottom-0

              left-0

              right-0

              z-10

              p-5

              text-right
            "

          >



            <span

              className="
                text-xs

                font-bold

                text-[#F47C20]
              "

            >

              {card.tag}


            </span>





            <h3

              className="
                mt-2

                text-xl

                font-black

                text-white
              "

            >

              {card.title}


            </h3>




            <p

              className="
                mt-2

                text-sm

                leading-6

                text-white/60
              "

            >

              {card.desc}


            </p>



          </div>



        </Link>


      ))}



    </div>

  );

}