"use client";

import Image from "next/image";

import { Swiper, SwiperSlide } from "swiper/react";
import { EffectFade, Autoplay } from "swiper/modules";

import type { Hero, HeroSlide } from "@/modules/home";

import "swiper/css";
import "swiper/css/effect-fade";

interface Props {
  hero: Hero;
}

function normalizeImage(src?: string | null) {
  if (!src) {
    return "/images/hero/hero-1.jpg";
  }

  const value = src.trim();

  // مسیر صحیح
  if (value.startsWith("/images/hero/")) {
    return value;
  }

  // hero-1.jpg
  if (/^hero-\d+\.jpg$/i.test(value)) {
    return `/images/hero/${value}`;
  }

  // hero1.jpg
  if (/^hero\d+\.jpg$/i.test(value)) {
    const number = value.match(/\d+/)?.[0];

    return `/images/hero/hero-${number}.jpg`;
  }

  // uploads/hero4.jpg
  if (/^uploads\/hero\d+\.jpg$/i.test(value)) {
    const number = value.match(/\d+/)?.[0];

    return `/images/hero/hero-${number}.jpg`;
  }

  // /images/hero4.jpg
  if (/^\/images\/hero\d+\.jpg$/i.test(value)) {
    const number = value.match(/\d+/)?.[0];

    return `/images/hero/hero-${number}.jpg`;
  }

  return "/images/hero/hero-1.jpg";
}

export default function HeroSlider({ hero }: Props) {
  const slides: HeroSlide[] =
    hero.slides.length > 0
      ? hero.slides
      : [
          {
            id: "default",
            image: "/images/hero/hero-1.jpg",
            title: hero.title,
            subtitle: null,
            link: null,
            sortOrder: 0,
          },
        ];

  console.log(
    "SLIDES FROM HERO",
    slides.map((s) => ({
      id: s.id,
      db: s.image,
      normalized: normalizeImage(s.image),
    }))
  );

  return (
    <div className="absolute inset-0 overflow-hidden">
      <Swiper
        modules={[EffectFade, Autoplay]}
        effect="fade"
        loop
        speed={1800}
        autoplay={{
          delay: 5000,
          disableOnInteraction: false,
        }}
        className="h-full w-full"
      >
        {slides.map((slide) => (
          <SwiperSlide key={slide.id}>
            <div className="relative h-full w-full overflow-hidden">
              <Image
                src={normalizeImage(slide.image)}
                alt={slide.title ?? hero.title}
                fill
                priority
                sizes="100vw"
                className="hero-image object-cover"
              />
            </div>
          </SwiperSlide>
        ))}
      </Swiper>
    </div>
  );
}