"use client";

import {
  mergeHeroConfig,
} from "@/lib/hero-config";

import type {
  Hero,
} from "@/modules/home";



interface Props {

  hero: Hero;

}



export default function HeroHeadline({
  hero,
}: Props) {

  /* ✅ فاصلهٔ بین بج/عنوان/توضیحات از پنل کنترل می‌شود */
  const cfg = mergeHeroConfig((hero as any).config);

  return (

    <div

      className="flex flex-col"

      style={{ gap: cfg.content.lineGap }}

    >



      {hero.badge && (

        <span

          className="
            w-fit

            rounded-full

            border

            border-[#F47C20]/40

            bg-[#F47C20]/10

            px-4

            py-1.5

            text-xs

            font-bold

            text-[#F47C20]
          "

        >

          {hero.badge}

        </span>

      )}





      <h1

        className="
          text-3xl

          font-black

          leading-[1.4]

          text-white


          md:text-5xl


          xl:text-6xl
        "

      >

        {hero.title}

      </h1>





      {hero.subtitle && (

        <h2

          className="
            text-xl

            font-bold

            text-white/80
          "

        >

          {hero.subtitle}

        </h2>

      )}





      {hero.description && (

        <p

          className="
            max-w-xl

            text-base

            leading-8

            text-white/65


            md:text-lg
          "

        >

          {hero.description}

        </p>

      )}



    </div>

  );

}