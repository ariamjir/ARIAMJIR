"use client";


/* ============================================================
   ARIA MJ — HERO STATS
============================================================ */


import type {
  HeroStat,
} from "@/modules/home";



interface Props {

  stats: HeroStat[];

}



export default function HeroStats({
  stats,
}: Props) {


  if (!stats?.length) {

    return null;

  }



  return (

    <div

      className="
        mt-8

        grid

        grid-cols-2

        gap-4


        md:grid-cols-3
      "

      dir="rtl"

    >

      {stats.map((stat) => (

        <div

          key={stat.id}

          className="
            rounded-2xl

            border

            border-white/10

            bg-white/5

            px-4

            py-4

            backdrop-blur
          "

        >


          <p

            className="
              text-xs

              text-white/50
            "

          >

            {stat.title}


          </p>



          <strong

            className="
              mt-1

              block

              text-2xl

              font-black

              text-[#F47C20]
            "

          >

            {stat.value}


          </strong>


        </div>

      ))}


    </div>

  );

}