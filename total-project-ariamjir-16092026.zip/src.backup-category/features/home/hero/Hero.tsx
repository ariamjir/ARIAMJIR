"use client";

import {
  getHeroImages,
} from "./hero.data";

import {
  mergeHeroConfig,
} from "@/lib/hero-config";

import HeroBackground from "./HeroBackground";
import HeroCards from "./HeroCards";
import HeroContent from "./HeroContent";
import HeroStatsPanel from "./HeroStatsPanel";

import type {
  HeroProps,
} from "./hero.types";

export default function Hero({
  hero,
}: HeroProps) {

  const cfg = mergeHeroConfig((hero as any).config);

  /* ✅ موقعیت عمودی اجزا از پنل */
  const vCls =
    cfg.content.vertical === "top"
      ? "justify-start lg:items-start"
      : cfg.content.vertical === "bottom"
        ? "justify-end lg:items-end"
        : "justify-center lg:items-center";

  return (
    <section
      className="
        relative
        isolate
        min-h-[clamp(620px,85vh,900px)]
        overflow-hidden
        bg-[#111111]
      "
    >

      <HeroBackground
        images={getHeroImages(hero)}
        mode={cfg.background.mode}
        interval={cfg.background.interval}
        zoom={cfg.background.zoom}
        overlay={cfg.background.overlay}
      />

      <div
        className={`
          relative
          z-10
          mx-auto
          flex
          min-h-[clamp(620px,85vh,900px)]
          max-w-[1440px]
          flex-col
          gap-12
          px-5
          py-20
          lg:flex-row
          lg:px-10
          xl:px-16
          ${vCls}
        `}
      >

        {/* Content */}
        <div className="order-1 flex-1 lg:order-2 lg:max-w-xl">
          <HeroContent hero={hero} />
        </div>

        {/* Cards */}
        {cfg.cards.visible && (
          <div className="order-2 flex flex-1 justify-center lg:order-3 lg:justify-end">
            <div className="w-full max-w-[580px]">
              <HeroCards hero={hero} />
            </div>
          </div>
        )}

        {/* Stats Panel */}
        {cfg.stats.visible && (
          <div className="order-3 flex justify-center lg:order-1 lg:justify-start">
            <HeroStatsPanel />
          </div>
        )}

      </div>

      {/* Bottom Brand Accent */}
      <div
        className="
          absolute
          bottom-0
          left-0
          h-1
          w-full
          bg-gradient-to-r
          from-transparent
          via-[#F47C20]
          to-transparent
        "
      />

    </section>
  );
}