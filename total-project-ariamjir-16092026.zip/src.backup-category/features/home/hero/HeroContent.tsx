"use client";

import HeroHeadline from "./HeroHeadline";
import HeroCTA from "./HeroCTA";

import { mergeHeroConfig } from "@/lib/hero-config";

import type { HeroProps } from "./hero.types";

export default function HeroContent({
  hero,
}: HeroProps) {

  const cfg = mergeHeroConfig((hero as any).config);

  const alignCls =
    cfg.content.align === "center"
      ? "items-center text-center"
      : cfg.content.align === "left"
        ? "items-start text-left"
        : "items-end text-right";

  return (
    <div
      dir="rtl"
      className={`flex flex-col ${alignCls}`}
      style={{ gap: cfg.content.gap }}
    >
      <HeroHeadline hero={hero} />
      <HeroCTA hero={hero} />
    </div>
  );
}