"use client";

import { useEffect, useState } from "react";

import {
  Tractor,
  Wrench,
  Users,
  Megaphone,
  Building2,
  FolderTree,
  Star,
  Activity,
} from "lucide-react";

import Sparkline from "@/components/Sparkline";

/* ============================================================
   پنل باریک «آمار لحظه‌ای» داخل هیرو — اعداد زندهٔ دیتابیس
============================================================ */

const ICONS: Record<string, any> = {
  machines: Tractor,
  services: Wrench,
  users: Users,
  adsPublished: Megaphone,
  brands: Building2,
  categories: FolderTree,
  manual: Star,
};

export default function HeroStatsPanel() {
  const [stats, setStats] = useState<any[]>([]);

  useEffect(() => {
    fetch("/api/stats")
      .then((r) => r.json())
      .then((j) => {
        if (j.success) setStats(j.data ?? []);
      })
      .catch(() => {});
  }, []);

  if (stats.length === 0) return null;

  return (
    <aside
      className="
        w-[clamp(60px,8vw,100px)]
        shrink-0
        rounded-2xl
        border
        border-white/10
        bg-[#0c0c0c]/90
        p-3
        backdrop-blur
      "
    >
      {/* سربرگ */}
      <div className="mb-2.5 flex items-center gap-2 border-b border-white/10 pb-2.5">
        <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full border-2 border-[#F58220] text-[#F58220]">
          <Activity className="h-3 w-3" />
        </span>
        <div className="min-w-0">
          <div className="text-[10px] font-black text-white">
            آمار لحظه‌ای
          </div>
          <div className="mt-0.5 truncate text-[8px] text-white/40">
          </div>
        </div>
      </div>

      {/* ردیف‌های آمار */}
      <div className="space-y-2">
        {stats.slice(0, 4).map((s, i) => {
          const Icon = ICONS[s.source] ?? Star;
          return (
            <div
              key={s.title}
              className="
                rounded-lg
                border
                border-white/5
                bg-white/[0.03]
                px-2.5
                py-2
              "
            >
              <div className="flex items-center gap-2">
                <Icon className="h-3.5 w-3.5 shrink-0 text-[#F58220]" />
                <div className="min-w-0">
                  <div className="text-sm font-black leading-5 text-white">
                    {s.display}
                  </div>
                  <div className="truncate text-[8px] text-white/40">
                    {s.title}
                  </div>
                </div>
              </div>
              <div className="mt-1">
                <Sparkline variant={i} className="h-3 w-full" />
              </div>
            </div>
          );
        })}
      </div>

      {/* پاورقی */}
      <div className="mt-2 flex items-center gap-1 text-[8px] font-bold text-[#F58220]">
        + آپدیت لحظه‌ای
      </div>
    </aside>
  );
}