"use client";

const selectClass = `
h-14
w-full

rounded-2xl

border border-white/10

bg-white/5

backdrop-blur-xl

px-5

text-white

outline-none

transition-all
duration-300

hover:bg-white/10

focus:border-[#F58220]
focus:ring-4
focus:ring-[#F58220]/20
`;

export default function SearchFilters() {
  return (
    <div
      className="
        grid

        grid-cols-1
        md:grid-cols-2
        xl:grid-cols-5

        gap-4
      "
    >
      <select className={selectClass}>
        <option>دسته‌بندی</option>
      </select>

      <select className={selectClass}>
        <option>استان</option>
      </select>

      <select className={selectClass}>
        <option>برند</option>
      </select>

      <select className={selectClass}>
        <option>وضعیت</option>
      </select>

      <button
        className="
          h-14

          rounded-2xl

          bg-[#F58220]

          text-white

          font-bold

          transition-all
          duration-300

          hover:bg-[#ff972f]

          hover:shadow-[0_10px_30px_rgba(245,130,32,.35)]

          active:scale-95
        "
      >
        جستجو
      </button>
    </div>
  );
}