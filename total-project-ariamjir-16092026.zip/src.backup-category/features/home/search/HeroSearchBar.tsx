"use client";

import { useMemo, useState } from "react";

import { Search } from "lucide-react";
import { useRouter } from "next/navigation";

import {
  PROVINCES,
  PRICE_RANGES,
  YEAR_RANGES,
} from "@/modules/search/constants";

import { useCategories } from "@/modules/category";
import { useBrands } from "@/modules/brand";

/* ============================================================
   نوار جستجوی Hero — ارسال به /machines با QueryString
============================================================ */
export default function HeroSearchBar() {
  const router = useRouter();
  const categoriesApi: any = useCategories();
  const brandsApi: any = useBrands();

  const categories: any[] = categoriesApi.categories ?? [];
  const brands: any[] =
    brandsApi.brands ?? brandsApi.activeBrands ?? brandsApi.allBrands ?? [];

  const [catId, setCatId] = useState("");
  const [type, setType] = useState("");
  const [province, setProvince] = useState("");
  const [brandId, setBrandId] = useState("");
  const [price, setPrice] = useState("");
  const [year, setYear] = useState("");

  const rootCategories = useMemo(
    () =>
      categories
        .filter((c: any) => !c.parentId && c.active !== false)
        .sort((a: any, b: any) => (a.sortOrder ?? 0) - (b.sortOrder ?? 0)),
    [categories]
  );

  const brandOptions = useMemo(
    () => brands.filter((b: any) => b.active !== false),
    [brands]
  );

  const doSearch = () => {
    const params = new URLSearchParams();
    if (catId) {
      const cat = categories.find((c: any) => String(c.id) === catId);
      if (cat?.slug) params.set("category", cat.slug);
    }
    if (type) params.set("listingType", type);
    if (province) params.set("province", province);
    if (brandId) params.set("brand", brandId);
    if (price) {
      const [min, max] = price.split("|");
      if (min) params.set("priceMin", min);
      if (max) params.set("priceMax", max);
    }
    if (year) {
      const [min, max] = year.split("|");
      if (min) params.set("yearMin", min);
      if (max) params.set("yearMax", max);
    }
    router.push(`/machines?${params.toString()}`);
  };

  return (
    <div className="mx-auto mt-4 w-[68%] min-w-[300px] max-w-[980px] rounded-xl border border-white/10 bg-[#101010]/95 p-1.5">
      <div className="flex flex-wrap items-stretch lg:flex-nowrap">
        <Seg label="دسته‌بندی">
          <select value={catId} onChange={(e) => setCatId(e.target.value)} className={segCls}>
            <option value="">همه دسته‌ها</option>
            {rootCategories.map((c: any) => (
              <option key={c.id} value={String(c.id)}>{c.name}</option>
            ))}
          </select>
        </Seg>

        <Seg label="نوع آگهی">
          <select value={type} onChange={(e) => setType(e.target.value)} className={segCls}>
            <option value="">همه موارد</option>
            <option value="SALE">فروش</option>
            <option value="RENT">اجاره</option>
            <option value="AUCTION">مزایده</option>
            <option value="OFFER">خدمات</option>
            <option value="BUY">خرید (تقاضا)</option>
          </select>
        </Seg>

        <Seg label="موقعیت">
          <select value={province} onChange={(e) => setProvince(e.target.value)} className={segCls}>
            <option value="">همه موارد</option>
            {PROVINCES.map((p) => (
              <option key={p} value={p}>{p}</option>
            ))}
          </select>
        </Seg>

        <Seg label="برند">
          <select value={brandId} onChange={(e) => setBrandId(e.target.value)} className={segCls}>
            <option value="">همه برندها</option>
            {brandOptions.map((b: any) => (
              <option key={b.id} value={String(b.id)}>{b.name}</option>
            ))}
          </select>
        </Seg>

        <Seg label="قیمت">
          <select value={price} onChange={(e) => setPrice(e.target.value)} className={segCls}>
            <option value="">همه قیمت‌ها</option>
            {PRICE_RANGES.map((p) => (
              <option key={p.value} value={p.value}>{p.label}</option>
            ))}
          </select>
        </Seg>

        <Seg label="سال" last>
          <select value={year} onChange={(e) => setYear(e.target.value)} className={segCls}>
            <option value="">همه سال‌ها</option>
            {YEAR_RANGES.map((y) => (
              <option key={y.value} value={y.value}>{y.label}</option>
            ))}
          </select>
        </Seg>

        <button
          type="button"
          onClick={doSearch}
          className="ml-1 inline-flex shrink-0 items-center justify-center gap-1 rounded-lg bg-[#F58220] px-5 py-2.5 text-[10px] font-black text-white shadow-lg shadow-orange-500/25 transition hover:bg-orange-600"
        >
          جستجو
          <Search className="h-3.5 w-3.5" />
        </button>
      </div>
    </div>
  );
}

const segCls =
  "w-full bg-transparent py-1 text-[10px] font-bold text-white/85 outline-none [&>option]:bg-[#141414]";

function Seg({
  label,
  last,
  children,
}: {
  label: string;
  last?: boolean;
  children: React.ReactNode;
}) {
  return (
    <div
      className={`min-w-[95px] flex-1 px-2.5 py-1 ${
        last ? "" : "border-b border-white/10 lg:border-b-0 lg:border-l"
      }`}
    >
      <div className="text-[8px] font-bold text-white/35">{label}</div>
      {children}
    </div>
  );
}