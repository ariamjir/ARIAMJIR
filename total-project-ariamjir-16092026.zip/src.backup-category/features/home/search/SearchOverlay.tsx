"use client";

import SearchInput from "./SearchInput";
import SearchFilters from "./SearchFilters";
import SearchResults from "./SearchResults";
import SearchHistory from "./SearchHistory";
import useSearch from "./useSearch";

export default function SearchOverlay() {
  const { open, setOpen } = useSearch();

  if (!open) return null;

  return (
    <>
      {/* Backdrop */}

      <div
        onClick={() => setOpen(false)}
        className="
          fixed
          inset-0
          z-[190]

          bg-black/70
          backdrop-blur-md
        "
      />

      {/* Panel */}

      <div
        className="
          fixed

          left-1/2
          top-[110px]

          -translate-x-1/2

          z-[200]

          w-[95%]
          max-w-[1550px]
        "
      >
        <div
          className="
            rounded-[30px]

            border
            border-white/10

            bg-[#0b0b0bdd]

            backdrop-blur-2xl

            shadow-[0_40px_120px_rgba(0,0,0,.55)]

            p-10
          "
        >
          {/* Header */}

          <div className="flex items-center justify-between mb-8">

            <h2
              className="
                text-white

                text-3xl

                font-black
              "
            >
              جستجوی پیشرفته
            </h2>

            <button
              onClick={() => setOpen(false)}
              className="
                h-12
                w-12

                rounded-xl

                border
                border-white/10

                bg-white/5

                text-white

                transition

                hover:bg-white/10
              "
            >
              ✕
            </button>

          </div>

          {/* Search */}

          <SearchInput />

          <div className="mt-8">
            <SearchFilters />
          </div>

          <div className="mt-8">
            <SearchHistory />
          </div>

          <div className="mt-8">
            <SearchResults />
          </div>
        </div>
      </div>
    </>
  );
}