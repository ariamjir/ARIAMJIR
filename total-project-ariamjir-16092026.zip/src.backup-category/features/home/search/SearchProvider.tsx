"use client";

import { useState } from "react";
import SearchContext from "./SearchContext";

export default function SearchProvider({
  children,
}: {
  children: React.ReactNode;
}) {
  const [open, setOpen] = useState(false);

  return (
    <SearchContext.Provider
      value={{
        open,
        setOpen,
      }}
    >
      {children}
    </SearchContext.Provider>
  );
}