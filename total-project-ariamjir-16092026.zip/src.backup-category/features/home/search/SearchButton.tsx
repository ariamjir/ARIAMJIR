"use client";

import { Search } from "lucide-react";
import useSearch from "./useSearch";

export default function SearchButton() {
  const { setOpen } = useSearch();

  return (
    <button
      onClick={() => setOpen(true)}
      aria-label="جستجو"
      className="
        flex
        items-center
        justify-center

        h-12
        w-12

        rounded-2xl

        border
        border-white/10

        bg-white/5
        backdrop-blur-xl

        text-white

        transition-all
        duration-300

        hover:bg-[#F7931E]
        hover:border-[#F7931E]
        hover:scale-105
        active:scale-95
      "
    >
      <Search size={20} strokeWidth={2.2} />
    </button>
  );
}