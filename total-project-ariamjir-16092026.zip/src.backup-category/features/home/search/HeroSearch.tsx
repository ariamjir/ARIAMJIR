"use client";

import SearchInput from "./SearchInput";
import SearchFilters from "./SearchFilters";

export default function HeroSearch() {
  return (
    <section
  className="
    absolute

    left-1/2

    bottom-20

    z-30

    w-[95%]

    max-w-[1000px]

    -translate-x-1/2
  "
>
      <div
        className="
rounded-[28px]

border
border-white/15

bg-white/[0.08]

backdrop-blur-[24px]

shadow-[0_30px_70px_rgba(0,0,0,.30)]

p-6
"
      >
        <SearchInput />

        <div className="mt-7">
          <SearchFilters />
        </div>
      </div>
    </section>
  );
}