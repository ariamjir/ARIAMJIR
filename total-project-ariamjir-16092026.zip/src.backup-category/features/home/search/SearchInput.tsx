"use client";

import { Search } from "lucide-react";

export default function SearchInput() {
  return (
    <div className="relative">
      <input
        type="text"
        placeholder="جستجوی ماشین‌آلات، قطعات، برند یا خدمات..."
        className="
          h-16
          w-full

          rounded-2xl

          border border-white/10

          bg-white/5
          backdrop-blur-xl

          pr-14
          pl-36

          text-lg
          text-white

          placeholder:text-gray-400

          outline-none

          transition-all
          duration-300

          focus:border-[#F58220]
          focus:ring-4
          focus:ring-[#F58220]/20
          focus:bg-white/[0.08]
        "
      />

      <Search
        size={22}
        className="
          absolute
          right-5
          top-1/2
          -translate-y-1/2
          text-gray-400
          pointer-events-none
        "
      />

      <button
        className="
          absolute
          left-2
          top-2
          bottom-2

          px-8

          rounded-xl

          bg-[#F58220]
          text-white
          font-medium

          transition-all
          duration-300

          hover:bg-[#ff9b3d]
          active:scale-95
        "
      >
        
      </button>
    </div>
  );
}