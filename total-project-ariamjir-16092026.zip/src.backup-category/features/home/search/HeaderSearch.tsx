"use client";

import { SearchButton } from ".";

export default function HeaderSearch() {
  return <SearchButton />;
}