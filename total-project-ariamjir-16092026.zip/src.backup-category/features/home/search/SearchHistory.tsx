"use client";

export default function SearchHistory() {
  return (
    <div
      className="
        hidden

        mt-6

        rounded-2xl

        border
        border-white/10

        bg-black/50

        backdrop-blur-xl

        p-6
      "
    >
      <div className="text-white/70 text-lg">
        سابقه جستجو خالی است.
      </div>
    </div>
  );
}