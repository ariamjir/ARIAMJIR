"use client";

import { useMemo } from "react";

import { useCategories } from "@/modules/category";

// ✅ بررسی کن این فایل‌ها در پوشه components هستند یا مستقیم در categories
// اگر در components نیستند، مسیر را اصلاح کن
import CategoryRing from "./components/CategoryRing";
import CategoryRingCard from "./components/CategoryRingCard";
import CategoryCard from "./components/CategoryCard";

interface CmsConfig {
  title?: string;
  subtitle?: string;
  description?: string;
  config?: {
    ringMax?: number;
    [key: string]: any;
  };
}

interface Props {
  cmsConfig?: CmsConfig;
}

export default function CategoriesSection({ cmsConfig }: Props) {
  const { categories, rootCategories, loading, error } = useCategories();

  const title = cmsConfig?.title || "دسته‌بندی ماشین‌آلات";
  const subtitle = cmsConfig?.subtitle || "Categories";
  const description =
    cmsConfig?.description ||
    "ماشین‌آلات موردنظر خود را بر اساس گروه‌های تخصصی انتخاب کنید.";
  const ringMax = cmsConfig?.config?.ringMax ?? 18;

  function SectionHeader() {
    return (
      <div className="text-center">
        <span className="text-xs font-bold uppercase tracking-[0.25em] text-[#F58220]">
          {subtitle}
        </span>
        <h2 className="mt-3 text-3xl font-black text-white md:text-4xl">
          {title}
        </h2>
        <p className="mx-auto mt-4 max-w-2xl text-sm leading-7 text-white/45">
          {description}
        </p>
      </div>
    );
  }

  const visibleCategories = useMemo(() => {
    const homepageItems = categories.filter(
      (item) => item.active && item.showOnHomepage
    );
    const fallbackItems = rootCategories.filter((item) => item.active);
    const source = homepageItems.length > 0 ? homepageItems : fallbackItems;

    return source.sort((a, b) => {
      if (!!b.featured !== !!a.featured) return a.featured ? -1 : 1;
      return (a.sortOrder ?? 0) - (b.sortOrder ?? 0);
    });
  }, [categories, rootCategories]);

  const ringItems = useMemo(
    () => visibleCategories.slice(0, ringMax),
    [visibleCategories, ringMax]
  );

  const useRing = ringItems.length >= 4;

  if (loading) {
    return (
      <section className="bg-[#0a0a0a] py-24">
        <div className="mx-auto max-w-[1600px] px-8">
          <SectionHeader />
          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <div
                key={i}
                className="h-[320px] animate-pulse rounded-2xl border border-white/10 bg-white/[0.03]"
              />
            ))}
          </div>
        </div>
      </section>
    );
  }

  if (error) {
    return (
      <section className="bg-[#0a0a0a] py-24">
        <div className="mx-auto max-w-[1600px] px-8 text-center">
          <SectionHeader />
          <div className="mx-auto mt-10 max-w-xl rounded-2xl border border-red-500/30 bg-red-500/[0.06] p-8">
            <p className="font-bold text-red-400">
              خطا در بارگذاری دسته‌بندی‌ها
            </p>
            <p className="mt-2 text-sm text-white/45">
              لطفاً اتصال خود را بررسی و دوباره تلاش کنید.
            </p>
          </div>
        </div>
      </section>
    );
  }

  if (visibleCategories.length === 0) return null;

  return (
    <section className="relative overflow-hidden bg-[#0a0a0a] py-24">
      <div className="mx-auto max-w-[1600px] px-8">
        <SectionHeader />

        {useRing ? (
          <div className="mt-10 hidden md:block">
            <CategoryRing categories={ringItems} />
          </div>
        ) : (
          <div className="mt-12 hidden flex-wrap justify-center gap-6 md:flex">
            {ringItems.map((category) => (
              <div key={category.id} className="w-[220px]">
                <div className="h-[275px]">
                  <CategoryRingCard category={category} />
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="mt-10 flex snap-x snap-mandatory gap-4 overflow-x-auto pb-4 md:hidden [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
          {ringItems.map((category) => (
            <div
              key={category.id}
              className="w-[78%] shrink-0 snap-center sm:w-[44%]"
            >
              <CategoryCard category={category} />
            </div>
          ))}
        </div>

        <div className="mt-10 text-center">
          <a
            href="/categories"
            className="inline-flex items-center gap-2 rounded-xl border border-white/15 bg-white/[0.04] px-6 py-3 text-sm font-bold text-white/80 transition hover:border-[#F58220] hover:text-[#F58220]"
          >
            مشاهدهٔ همهٔ دسته‌بندی‌ها
          </a>
        </div>
      </div>
    </section>
  );
}