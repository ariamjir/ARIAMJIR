"use client";

import { useState } from "react";

import Image from "next/image";
import Link from "next/link";

import { ArrowLeft, Star, Layers } from "lucide-react";

import type { Category } from "@/modules/category";

interface CategoryCardProps {
  category: Category;
}

/* ============================================================
   تشخیص نوع src
   ------------------------------------------------------------
   - isImageUrl: فقط آدرس‌های واقعی تصویر (شروع با / یا http)
   - isEmojiOrText: هر مقدار غیرخالی که URL نیست (ایموجی/متن)
============================================================ */

function isImageUrl(value: unknown): value is string {
  if (typeof value !== "string") return false;
  const v = value.trim();
  if (v.length === 0) return false;
  if (v.startsWith("blob:")) return false;
  return (
    v.startsWith("/") ||
    v.startsWith("http://") ||
    v.startsWith("https://")
  );
}

function isEmojiOrText(value: unknown): value is string {
  if (typeof value !== "string") return false;
  const v = value.trim();
  return v.length > 0 && !isImageUrl(v);
}

export default function CategoryCard({
  category,
}: CategoryCardProps) {
  /* fallback اگر <Image> لود نشد (404 / خطای optimize) */
  const [imgFailed, setImgFailed] = useState(false);

  /* تصویر اصلی (اگر URL معتبر باشد و load شده باشد) */
  const hasImage = !imgFailed && isImageUrl(category.image);

  /* آیکون: یا URL تصویر است، یا ایموجی/متن */
  const iconIsImage = isImageUrl(category.icon);
  const iconIsEmoji = !iconIsImage && isEmojiOrText(category.icon);

  const childrenArray = category.children ?? [];
  const childrenCount =
    category.childrenCount ?? childrenArray.length;

  return (
    <Link
      href={`/machines?category=${category.slug}`}
      aria-label={`مشاهده ماشین‌آلات دستهٔ ${category.name}`}
      className="group block h-full focus:outline-none"
    >
      <article
        className="
          relative
          flex
          h-full
          flex-col
          overflow-hidden
          rounded-2xl
          border
          border-white/10
          bg-[#141414]
          transition-all
          duration-300
          hover:-translate-y-1
          hover:border-[#F58220]/60
          hover:shadow-xl
          hover:shadow-black/40
        "
      >
        <span
          className="
            absolute
            inset-x-0
            top-0
            z-20
            h-0.5
            origin-right
            scale-x-0
            bg-[#F58220]
            transition-transform
            duration-300
            group-hover:scale-x-100
          "
        />

        {category.featured && (
          <span
            className="
              absolute
              right-3
              top-3
              z-20
              inline-flex
              items-center
              gap-1
              rounded-md
              bg-[#F58220]
              px-2
              py-0.5
              text-[10px]
              font-extrabold
              text-white
              shadow
            "
          >
            <Star className="h-3 w-3 fill-current" />
            ویژه
          </span>
        )}

        {/* ===== تصویر بزرگ و تمام‌عرض (با fallback ایمن) ===== */}
        <div className="relative aspect-[16/10] w-full overflow-hidden bg-[#1c1c1c]">
          {hasImage ? (
            <Image
              src={category.image as string}
              alt={category.name}
              fill
              sizes="(max-width:640px) 100vw, (max-width:1024px) 50vw, 25vw"
              onError={() => setImgFailed(true)}
              className="
                object-cover
                transition-transform
                duration-500
                group-hover:scale-105
              "
            />
          ) : iconIsImage ? (
            <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-[#1f1f1f] to-[#121212]">
              <Image
                src={category.icon as string}
                alt={category.name}
                width={120}
                height={120}
                onError={() => setImgFailed(true)}
                className="h-24 w-24 object-contain opacity-90 transition-transform duration-500 group-hover:scale-110"
              />
            </div>
          ) : iconIsEmoji ? (
            <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-[#1f1f1f] to-[#121212]">
              <span className="select-none text-6xl leading-none transition-transform duration-500 group-hover:scale-110">
                {category.icon}
              </span>
            </div>
          ) : (
            <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-[#F58220]/15 to-[#121212]">
              <span className="text-6xl transition-transform duration-500 group-hover:scale-110">🚜</span>
            </div>
          )}

          <span className="pointer-events-none absolute inset-x-0 bottom-0 h-10 bg-gradient-to-t from-[#141414] to-transparent" />
        </div>

        {/* ===== بدنه ===== */}
        <div className="flex flex-1 flex-col p-5">
          <h3
            className="
              text-center
              font-bold
              text-white
              transition-colors
              duration-300
              group-hover:text-[#F58220]
            "
          >
            {category.name}
          </h3>

          {category.description && (
            <p className="text-center mt-1.5 line-clamp-2 text-sm leading-6 text-white/45">
              {category.description}
            </p>
          )}

          <p className="text-center mt-3 text-sm font-bold text-[#F58220]">
            {category.machinesCount > 0
              ? `${category.machinesCount.toLocaleString("fa-IR")} آگهی فعال`
              : "بدون آگهی"}
          </p>

          {childrenArray.length > 0 ? (
            <div className="mt-3 flex flex-wrap gap-1.5">
              {childrenArray.slice(0, 3).map((child) => (
                <span
                  key={child.id}
                  className="rounded-md bg-white/5 px-2 py-0.5 text-[11px] text-white/55"
                >
                  {child.name}
                </span>
              ))}
              {childrenCount > 3 && (
                <span className="rounded-md bg-[#F58220]/15 px-2 py-0.5 text-[11px] font-bold text-[#F58220]">
                  +{(childrenCount - 3).toLocaleString("fa-IR")}
                </span>
              )}
            </div>
          ) : childrenCount > 0 ? (
            <div className="mt-3">
              <span className="inline-flex items-center gap-1 rounded-md bg-white/5 px-2 py-0.5 text-[11px] text-white/55">
                <Layers className="h-3 w-3" />
                {childrenCount.toLocaleString("fa-IR")} زیردسته
              </span>
            </div>
          ) : null}

          <div
            className="
              mt-auto
              flex
              items-center
              gap-1.5
              pt-5
              text-sm
              font-bold
              text-[#F58220]
              opacity-60
              transition-opacity
              duration-300
              group-hover:opacity-100
            "
          >
            مشاهده ماشین‌آلات
            <ArrowLeft
              className="
                h-4
                w-4
                transition-transform
                duration-300
                group-hover:-translate-x-1
              "
            />
          </div>
        </div>
      </article>
    </Link>
  );
}