export interface HomeCategory {
  id: string;

  title: string;

  slug: string;

  description?: string | null;

  image?: string | null;

  icon?: string | null;

  active: boolean;

  sortOrder: number;

  machineCount?: number;
}