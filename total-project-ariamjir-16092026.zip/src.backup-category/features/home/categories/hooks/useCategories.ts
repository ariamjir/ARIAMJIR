"use client";


import {
  useEffect,
  useState,
} from "react";


import {
  categoryService,
} from "../services/category.service";


import type {
  HomeCategory,
} from "../types/category";



export function useCategories(){

  const [
    categories,
    setCategories,
  ] = useState<HomeCategory[]>([]);


  const [
    loading,
    setLoading,
  ] = useState(true);



  useEffect(()=>{


    categoryService
      .getCategories()
      .then(setCategories)
      .finally(()=>{
        setLoading(false);
      });


  },[]);



  return {
    categories,
    loading,
  };

}