import type {
  HomeCategory,
} from "../types/category";


class CategoryService {

  async getCategories(): Promise<HomeCategory[]> {

    const res = await fetch(
      "/api/home/categories",
      {
        cache: "no-store",
      }
    );


    if (!res.ok) {
      throw new Error(
        "Failed to load categories"
      );
    }


    return res.json();

  }

}


export const categoryService =
  new CategoryService();