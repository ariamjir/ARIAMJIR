export interface WhyItem {
  id: string;
  title: string;
  description: string;
  icon: string;
  featured: boolean;
}