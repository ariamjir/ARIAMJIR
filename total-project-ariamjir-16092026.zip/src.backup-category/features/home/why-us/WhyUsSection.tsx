import { prisma } from "@/lib/prisma";

import JsonLd from "@/components/seo/JsonLd";

import WhyUsClient from "./WhyUsClient";

import { SITE_URL } from "@/lib/seo";

/* ============================================================
   چرا ARIA MJ؟ — Bento-Grid جهانی‌کلاس
   ✅ SSR برای سئو · JSON-LD · افکت‌های کلاینت در WhyUsClient
============================================================ */

export default async function WhyUsSection({ cmsConfig }: { cmsConfig?: any }) {
  const items = await prisma.whyUsItem.findMany({
    where: { active: true },
    orderBy: { sortOrder: "asc" },
  });

  if (items.length === 0) return null;

  const title = cmsConfig?.title ?? "چرا ARIA MJ؟";
  const subtitle = cmsConfig?.subtitle ?? "مزیت‌هایی که ما را متمایز می‌کند";

  return (
    <section className="relative py-24" aria-label={title}>
      <JsonLd
        data={{
          "@context": "https://schema.org",
          "@type": "Organization",
          name: "آریا ماشین جم",
          url: SITE_URL,
          slogan: subtitle,
          areaServed: "IR",
        }}
      />

      <div className="mx-auto max-w-[1440px] px-6 lg:px-10">
        <div className="mx-auto flex max-w-3xl flex-col items-center text-center">
          <div className="text-xs font-black tracking-[0.3em] text-[#F58220]">
            WHY ARIA MJ
          </div>
          <h2 className="mt-3 text-3xl font-black text-white lg:text-5xl">
            {title}
          </h2>
          <p className="mt-4 text-sm leading-7 text-white/55 lg:text-base">
            {subtitle}
          </p>
        </div>

        {/* ✅ Bento-Grid */}
        <div className="mt-16">
          <WhyUsClient items={items} />
        </div>
      </div>
    </section>
  );
}