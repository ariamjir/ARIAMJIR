export interface NewsItem {
  id: string;
  slug: string;

  title: string;
  summary: string;
  content: string;

  category: string;

  image: string;

  featured: boolean;

  author: string;

  publishedAt: string;

  readTime: number;

  tags: string[];
}