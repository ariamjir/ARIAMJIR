"use client";

import LatestNewsCard from "./LatestNewsCard";
import useNews from "../hooks/useNews";

export default function LatestNewsSlider() {
  const { news } = useNews();

  return (
    <div className="grid gap-8 md:grid-cols-2 xl:grid-cols-3">
      {news.map((item) => (
        <LatestNewsCard
          key={item.id}
          news={item}
        />
      ))}
    </div>
  );
}