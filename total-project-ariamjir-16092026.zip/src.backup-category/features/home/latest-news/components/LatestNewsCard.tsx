"use client";

import type { NewsItem } from "../types/news";

interface Props {
  news: NewsItem;
}

export default function LatestNewsCard({ news }: Props) {
  return (
    <article className="group overflow-hidden rounded-[28px] border border-white/10 bg-black/40 backdrop-blur-xl transition-all duration-300 hover:-translate-y-2 hover:border-[#F58220]/40">

      <div className="relative h-56 overflow-hidden">

        <img
          src={news.image}
          alt={news.title}
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
        />

        <div className="absolute left-4 top-4 rounded-full bg-[#F58220] px-4 py-1 text-xs font-bold text-white">
          {news.category}
        </div>

      </div>

      <div className="space-y-4 p-6">

        <div className="text-sm text-gray-400">
          {news.publishedAt}
        </div>

        <h3 className="text-xl font-bold leading-8 text-white">
          {news.title}
        </h3>

        <p className="line-clamp-3 text-gray-300">
          {news.summary}
        </p>

        <button className="font-bold text-[#F58220] transition hover:text-white">
          مطالعه خبر →
        </button>

      </div>

    </article>
  );
}