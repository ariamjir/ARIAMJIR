"use client";

import { news } from "@/data/news";

export default function useNews() {
  return {
    news,
  };
}