"use client";

import { useEffect, useState } from "react";

import Link from "next/link";

import { Loader2, Newspaper, ArrowLeft } from "lucide-react";

import NewsCard from "@/components/news/NewsCard";

/* ============================================================
   آخرین اخبار — Newsroom وسط‌چین با ویترین چرخشی
   ✅ هر ۱۰ ثانیه خبر بعدی به ویترین بزرگ می‌رود (توقف با hover)
============================================================ */

export default function LatestNewsSection() {
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [idx, setIdx] = useState(0);
  const [paused, setPaused] = useState(false);

  useEffect(() => {
    fetch("/api/news/latest")
      .then((r) => r.json())
      .then((j) => {
        if (j.success) setItems(j.data ?? []);
      })
      .finally(() => setLoading(false));
  }, []);

  /* ✅ چرخش خودکار ویترین */
  useEffect(() => {
    if (paused || items.length < 2) return;
    const t = setInterval(() => setIdx((i) => (i + 1) % items.length), 10000);
    return () => clearInterval(t);
  }, [paused, items.length]);

  const active = items[idx];
  const rows = items.filter((x) => x.id !== active?.id).slice(0, 4);

  return (
    <section className="relative py-24">
      <div className="mx-auto max-w-[1440px] px-6 lg:px-10">
        {/* سربرگ وسط‌چین */}
        <div className="text-center">
          <div className="text-xs font-black tracking-[0.3em] text-[#F58220]">
            ARIA MJ NEWSROOM
          </div>
          <h2 className="mt-3 text-3xl font-black text-white lg:text-4xl">آخرین اخبار</h2>
          <p className="mx-auto mt-3 max-w-2xl text-sm leading-7 text-white/45">
            تازه‌های بازار ماشین‌آلات سنگین، تحلیل‌ها و رویدادهای صنعت از ایران و جهان
          </p>
        </div>

        {loading ? (
          <div className="mt-12 flex h-64 items-center justify-center">
            <Loader2 className="h-8 w-8 animate-spin text-orange-500" />
          </div>
        ) : !active ? (
          <div className="mt-12 rounded-2xl border border-dashed border-white/15 bg-white/[0.02] p-10 text-center">
            <Newspaper className="mx-auto h-10 w-10 text-white/20" />
            <p className="mt-3 text-sm font-bold text-white/50">هنوز خبری منتشر نشده است.</p>
          </div>
        ) : (
          <div
            onMouseEnter={() => setPaused(true)}
            onMouseLeave={() => setPaused(false)}
            className="mt-12 grid gap-6 lg:grid-cols-5"
          >
            {/* ✅ ویترین چرخشی */}
            <div className="lg:col-span-3">
              <div key={active.id} className="news-swap">
                <NewsCard post={active} variant="big" />
              </div>

              {/* نشانگرهای چرخش */}
              <div className="mt-4 flex items-center justify-center gap-2">
                {items.map((x, i) => (
                  <button
                    key={x.id}
                    onClick={() => setIdx(i)}
                    aria-label={`خبر ${i + 1}`}
                    className={`h-1.5 rounded-full transition-all duration-500 ${
                      i === idx ? "w-8 bg-[#F58220]" : "w-2 bg-white/20 hover:bg-white/40"
                    }`}
                  />
                ))}
              </div>
            </div>

            {/* ۴ خبر ردیفی */}
            <div className="grid content-start gap-4 sm:grid-cols-2 lg:col-span-2 lg:grid-cols-1">
              {rows.map((p) => (
                <button key={p.id} onClick={() => setIdx(items.findIndex((x) => x.id === p.id))} className="text-right">
                  <NewsCard post={p} variant="row" />
                </button>
              ))}
            </div>
          </div>
        )}

        {/* دکمهٔ وسط‌چین */}
        <div className="mt-12 flex justify-center">
          <Link
            href="/news"
            className="inline-flex h-12 items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-8 text-sm font-bold text-white transition-all duration-300 hover:border-[#F58220]/40 hover:bg-[#F58220]/10 hover:text-[#F58220]"
          >
            همهٔ اخبار
            <ArrowLeft className="h-4 w-4" />
          </Link>
        </div>
      </div>
    </section>
  );
}