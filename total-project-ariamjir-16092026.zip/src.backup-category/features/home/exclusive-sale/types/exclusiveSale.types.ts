export interface ExclusiveSaleStep {
  num: string;
  fa: string;
  en: string;
  desc: string;
}

export interface ExclusiveSaleConfig {
  ctaText?: string;
  ctaUrl?: string;
  trustChips?: string[];
  steps?: ExclusiveSaleStep[];
}

export interface ExclusiveSaleCMS {
  title?: string;
  subtitle?: string;
  description?: string;
  config?: ExclusiveSaleConfig;
}