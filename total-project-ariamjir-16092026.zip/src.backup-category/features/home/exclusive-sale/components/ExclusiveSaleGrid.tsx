import ExclusiveSaleCard from "./ExclusiveSaleCard";

import type {
  ExclusiveSaleStep,
} from "../types/exclusiveSale.types";


interface Props {
  steps: ExclusiveSaleStep[];
}


export default function ExclusiveSaleGrid({
  steps,
}: Props) {

  return (
    <div
      className="
        mt-14
        grid
        gap-6
        sm:grid-cols-2
        lg:grid-cols-4
      "
    >
      {steps.map((step) => (
        <ExclusiveSaleCard
          key={step.num}
          step={step}
        />
      ))}
    </div>
  );
}