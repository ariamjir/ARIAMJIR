import {
  ClipboardList,
  ShieldCheck,
  BadgeDollarSign,
  FileSignature,
} from "lucide-react";

import type {
  ExclusiveSaleStep,
} from "../types/exclusiveSale.types";


const ICON_MAP = {
  "Register & Reserve": ClipboardList,
  Inspection: ShieldCheck,
  Valuation: BadgeDollarSign,
  "Contract & Settlement": FileSignature,
};


interface Props {
  step: ExclusiveSaleStep;
}


export default function ExclusiveSaleCard({
  step,
}: Props) {

  const Icon =
    ICON_MAP[
      step.en as keyof typeof ICON_MAP
    ] || ClipboardList;


  return (
    <div
      className="
        group relative overflow-hidden
        rounded-3xl
        border border-white/10
        bg-white/[0.03]
        p-7
        transition-all duration-300
        hover:-translate-y-1
        hover:border-[#F58220]/50
        hover:bg-white/[0.05]
      "
    >

      <span
        className="
          absolute left-5 top-5
          text-2xl font-black
          text-white/10
          transition
          group-hover:text-[#F58220]/30
        "
      >
        {step.num}
      </span>


      <div
        className="
          mb-5 flex
          h-14 w-14
          items-center justify-center
          rounded-2xl
          bg-[#F58220]/15
          text-[#F58220]
          transition-transform
          duration-300
          group-hover:scale-110
        "
      >
        <Icon className="h-7 w-7" />
      </div>


      <div
        className="
          text-[10px]
          font-bold
          uppercase
          tracking-[0.2em]
          text-white/35
        "
      >
        {step.en}
      </div>


      <h3
        className="
          mt-1
          text-lg
          font-black
          text-white
        "
      >
        {step.fa}
      </h3>


      <p
        className="
          mt-3
          text-xs
          leading-6
          text-white/45
        "
      >
        {step.desc}
      </p>

    </div>
  );
}