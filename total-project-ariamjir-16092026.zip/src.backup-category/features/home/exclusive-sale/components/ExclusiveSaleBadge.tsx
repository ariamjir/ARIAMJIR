import { CheckCircle2 } from "lucide-react";

interface Props {
  text: string;
}

export default function ExclusiveSaleBadge({
  text,
}: Props) {
  return (
    <span
      className="
        inline-flex items-center gap-1.5
        rounded-full
        border border-white/10
        bg-white/[0.04]
        px-4 py-2
        text-xs font-bold
        text-white/70
      "
    >
      <CheckCircle2 className="h-3.5 w-3.5 text-[#F58220]" />
      {text}
    </span>
  );
}