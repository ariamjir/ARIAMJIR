import type { ExclusiveSaleStep } from "../types/exclusiveSale.types";

export const exclusiveSaleSteps: ExclusiveSaleStep[] = [
  {
    num: "۰۱",
    fa: "ثبت دستگاه و تأیید رزرو",
    en: "Register & Reserve",
    desc: "اطلاعات دستگاه ثبت شده و فرآیند فروش ویژه آغاز می‌شود.",
  },
  {
    num: "۰۲",
    fa: "کارشناسی فنی، حقوقی و بدنه",
    en: "Inspection",
    desc: "بررسی کامل وضعیت فنی، اسناد و سلامت دستگاه.",
  },
  {
    num: "۰۳",
    fa: "ارزش‌گذاری و اعلام قیمت",
    en: "Valuation",
    desc: "تعیین قیمت واقعی بر اساس شرایط بازار.",
  },
  {
    num: "۰۴",
    fa: "عقد قرارداد و تسویه",
    en: "Contract & Settlement",
    desc: "انجام قرارداد، انتقال و تسویه نهایی.",
  },
];

export const exclusiveSaleTrustChips = [
  "کارشناسی فنی",
  "کارشناسی حقوقی",
  "ارزش‌گذاری رسمی",
  "مالک تأییدشده",
  "آماده انتقال",
];

export const exclusiveSaleDefaultConfig = {
  ctaText: "ثبت دستگاه در فروش ویژه",
  ctaUrl: "/machines/new?program=PREMIUM",
  trustChips: exclusiveSaleTrustChips,
  steps: exclusiveSaleSteps,
};