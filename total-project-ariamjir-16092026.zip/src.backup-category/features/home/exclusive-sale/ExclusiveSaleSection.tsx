"use client";

import Link from "next/link";
import {
  ArrowLeft,
  Crown,
} from "lucide-react";

import ExclusiveSaleGrid from "./components/ExclusiveSaleGrid";
import ExclusiveSaleBadge from "./components/ExclusiveSaleBadge";

import {
  useExclusiveSale,
} from "./hooks/useExclusiveSale";


interface Props {
  cmsConfig?: any;
}


export default function ExclusiveSaleSection({
  cmsConfig,
}: Props) {

  const {
    title,
    subtitle,
    description,
    ctaText,
    ctaUrl,
    trustChips,
    steps,
  } = useExclusiveSale(cmsConfig);


  return (
    <section
      className="
        relative
        overflow-hidden
        py-24
      "
    >

      <div
        className="
          relative
          mx-auto
          max-w-[1600px]
          px-8
        "
      >

        {/* Header */}

        <div
          className="
            text-center
          "
        >

          <span
            className="
              inline-flex
              items-center
              gap-2
              text-xs
              font-bold
              uppercase
              tracking-[0.25em]
              text-[#F58220]
            "
          >
            <Crown className="h-4 w-4" />

            {subtitle}

          </span>


          <h2
            className="
              mt-3
              text-3xl
              font-black
              text-white
              md:text-4xl
            "
          >
            {title}

          </h2>


          <p
            className="
              mx-auto
              mt-4
              max-w-2xl
              text-sm
              leading-7
              text-white/45
            "
          >
            {description}

          </p>

        </div>



        {/* Steps */}

        <ExclusiveSaleGrid
          steps={steps}
        />



        {/* Trust */}

        <div
          className="
            mt-10
            flex
            flex-wrap
            items-center
            justify-center
            gap-3
          "
        >

          {trustChips.map(
            (chip: string) => (
              <ExclusiveSaleBadge
                key={chip}
                text={chip}
              />
            )
          )}

        </div>



        {/* CTA */}

        <div
          className="
            mt-12
            text-center
          "
        >

          <Link
            href={ctaUrl}
            className="
              inline-flex
              items-center
              gap-3
              rounded-2xl
              bg-[#F58220]
              px-10
              py-4
              text-base
              font-black
              text-white
              shadow-lg
              shadow-orange-500/25
              transition
              hover:bg-orange-600
            "
          >

            {ctaText}

            <ArrowLeft
              className="h-5 w-5"
            />

          </Link>

        </div>


      </div>

    </section>
  );
}