import {
  exclusiveSaleDefaultConfig,
} from "../constants/exclusiveSale.data";


export function useExclusiveSale(
  cmsConfig?: any
) {

  const config =
    cmsConfig?.config || {};


  return {
    title:
      cmsConfig?.title ||
      "فروش ویژه آریا",


    subtitle:
      cmsConfig?.subtitle ||
      "ARIA MJ EXCLUSIVE SALE",


    description:
      cmsConfig?.description ||
      "هدف ما فروش دستگاه شما در کمتر از ۷ روز است...",


    ctaText:
      config.ctaText ||
      exclusiveSaleDefaultConfig.ctaText,


    ctaUrl:
      config.ctaUrl ||
      exclusiveSaleDefaultConfig.ctaUrl,


    trustChips:
      config.trustChips ||
      exclusiveSaleDefaultConfig.trustChips,


    steps:
      config.steps ||
      exclusiveSaleDefaultConfig.steps,
  };
}